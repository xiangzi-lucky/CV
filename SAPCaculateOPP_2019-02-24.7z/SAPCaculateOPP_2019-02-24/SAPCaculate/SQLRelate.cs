﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
namespace SAPCaculate
{
    //数据库相关操作
    public class SQLRelate
    {

        #region Field

        string sql;
        string strCN;

        #endregion

        #region Property

        public string Sql
        {
            get { return sql; }
            set { sql = value; }
        }
        public string StrCN
        {
            get { return strCN; }
            set { strCN = value; }
        }

        #endregion

        #region Constructor

        public SQLRelate(string strSql, string strConnecting)
        {
            this.Sql = strSql;
            this.StrCN = strConnecting;
        }

        #endregion

        #region StaticMethod

        /// <summary>
        /// 查询数据库，返回datatable
        /// </summary>
        /// <param name="sql"></param>
        /// <param name="strCn"></param>
        /// <returns></returns>
        public static DataTable Query(string strCN, string strSQL, string currentProcess)
        {
            if (strSQL != "") ;

            {
                DataSet ds = new DataSet();
                DataTable dt = new DataTable();

                using (SqlConnection cn = new SqlConnection(strCN))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter(strSQL, cn))
                    {
                        try
                        {
                            da.Fill(ds);
                            dt = ds.Tables[0];
                        }
                        catch (System.Data.SqlClient.SqlException ex)
                        {
                            sendmail("Error with SAPCaculate", "", GetstralertsErrorTO((SQLRelate.sqlconn(Form1.strRDCon)), GetstrsiteID(Form1.site)), "", "<table bgcolor=white border=1 bordercolor=Gray bordercolordark=LemonChiffon><tr><td>" + currentProcess + "</td><td> " + ex.ToString() + "</td></tr></table>");

                        }
                        return dt;
                    }
                }
            }

        }

        public static SqlDataReader QueryDataReader(string strCN, string strSQL, string currentProcess)
        {

            if (strSQL != "") ;

            {
                SqlConnection cn = new SqlConnection(strCN);
                SqlDataReader sdr = null;
                SqlCommand cmd = cn.CreateCommand();
                cmd.CommandText = strSQL;
                try
                {
                    cn.Open();
                    sdr = cmd.ExecuteReader(CommandBehavior.CloseConnection);  //必须加上CommandBehavior.CloseConnection，确保sdr关闭时，依赖的连接也关闭
                }
                catch (System.Data.SqlClient.SqlException ex)
                {
                    sendmail("Error with SAPCaculate", GetstralertsErrorTO((SQLRelate.sqlconn(Form1.strRDCon)), GetstrsiteID(Form1.site)), "", "", "<table bgcolor=white border=1 bordercolor=Gray bordercolordark=LemonChiffon><tr><td>" + currentProcess + "</td><td> " + ex.ToString() + "</td></tr></table>");
                }
                finally
                {
                    //这里不能关闭数据库连接，否则返回的sdr毫无用处
                }
                return sdr;
            }


        }

        public static bool SqlExist(string strCN, string strSql, string currentProcess)
        {
            if (strCN != "" && strSql != "") ;

            {
                using (SqlConnection cn = new SqlConnection(strCN))
                {
                    using (SqlCommand cmd = new SqlCommand(strSql, cn))
                    {
                        try
                        {
                            cn.Open();
                            object obj = cmd.ExecuteScalar();
                            if ((Object.Equals(obj, null)) || (Object.Equals(obj, System.DBNull.Value)))
                            {
                                return false;
                            }
                            else
                            {
                                return true;
                            }
                        }
                        catch (System.Data.SqlClient.SqlException ex)
                        {
                            cn.Close();
                            sendmail("Error with SAPCaculate", GetstralertsErrorTO((SQLRelate.sqlconn(Form1.strRDCon)), GetstrsiteID(Form1.site)), "", "", "<table bgcolor=white border=1 bordercolor=Gray bordercolordark=LemonChiffon><tr><td>" + currentProcess + "</td><td> " + ex.ToString() + "</td></tr></table>");
                            return false;
                        }
                    }
                }
            }

        }

        /// <summary>
        /// 插入，更新数据库
        /// </summary>
        /// <param name="sql"></param>
        /// <param name="strCn"></param>
        /// <returns></returns>
        public static void InsertUpdate(string strCN, string strSQL, string currentProcess)
        {
            if (strSQL != "")

            {
                using (SqlConnection cn = new SqlConnection(strCN))
                {
                    using (SqlCommand cmd = new SqlCommand(strSQL, cn))
                    {
                        try
                        {
                            cn.Open();
                            cmd.ExecuteNonQuery();
                        }
                        catch (Exception ex)
                        {
                            sendmail("Error with SAPCaculate", GetstralertsErrorTO((SQLRelate.sqlconn(Form1.strRDCon)), GetstrsiteID(Form1.site)), "", "", "<table bgcolor=white border=1 bordercolor=Gray bordercolordark=LemonChiffon><tr><td>" + currentProcess + "</td><td> " + ex.ToString() + strSQL + "</td></tr></table>");
                        }

                    }
                }
            }

        }
        /// <summary>
        /// 事务更新，插入sql语句
        /// </summary>
        /// <param name="strCN"></param>
        /// <param name="strSql">sql语句集合</param>
        /// <param name="currentProcess"></param>
        public static void InsertUpdate(string strCN, List<string> strSql, string currentProcess)
        {
            if (strCN != "")

            {
                using (SqlConnection conn = new SqlConnection(strCN))
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = conn;
                    SqlTransaction tx = conn.BeginTransaction();
                    cmd.Transaction = tx;
                    try
                    {
                        for (int n = 0; n < strSql.Count; n++)
                        {
                            string strsql = strSql[n];
                            if (strsql.Trim().Length > 1)
                            {
                                cmd.CommandText = strsql;
                                cmd.ExecuteNonQuery();
                            }
                        }
                        tx.Commit();

                    }
                    catch (Exception ex)
                    {
                        tx.Rollback();
                        sendmail("Error with SAPCaculate", GetstralertsErrorTO((SQLRelate.sqlconn(Form1.strRDCon)), GetstrsiteID(Form1.site)), "", "", "<table bgcolor=white border=1 bordercolor=Gray bordercolordark=LemonChiffon><tr><td>" + currentProcess + "</td><td> " + ex.ToString() + "</td></tr></table>");
                    }
                }
            }


        }


        //add by PCZhou 2018-05-21
        public static string GetstralertsTO(string strCN, string strSiteID)
        {
            string stralertsTO = "";

            SqlConnection cn = new SqlConnection(strCN);

            string sql = "";

            cn.Open();

            if (strSiteID == "L")
            { sql = "select * from Monitor_User_list  where  Property_name = 'ALG_SAPCaculate' and  Property_value ='Y' and  Send_type ='TO'  "; }
            else if (strSiteID == "H")
            { sql = "select * from Monitor_User_list  where  Property_name = 'ATH_SAPCaculate' and  Property_value ='Y' and  Send_type ='TO'  "; }
            else if (strSiteID == "J")
            { sql = "select * from Monitor_User_list  where  Property_name = 'AMC_SAPCaculate' and  Property_value ='Y' and  Send_type ='TO'  "; }

            using (SqlCommand sqlcmd = new SqlCommand(sql, cn))
            {
                try
                {
                    SqlDataReader reader = sqlcmd.ExecuteReader();

                    while (reader.Read())
                    {
                        if (strSiteID == "L")
                        { stralertsTO += "badgealg" + reader["Badge"].ToString() + "@asmpt.com"; break; }
                        else if (strSiteID == "H")
                        { stralertsTO += "badgealg" + reader["Badge"].ToString() + "@asmpt.com"; break; }
                        else if (strSiteID == "J")
                        { stralertsTO += "badgeamc" + reader["Badge"].ToString() + "@asmpt.com"; break; }

                    }

                    reader.Close();
                }
                catch
                {


                }
                finally
                {
                    cn.Close();
                }

            }

            return stralertsTO;

        }

        //add by PCZhou 2018-11-06
        public static string GetMPMSSTDRoutingRequest(string strCN, string PartNum, string Rev, string ProgNum, string OperationNo, string WorkCtr)
        {
            string strMPMSRoutingRequest ="";
            SqlConnection cn = new SqlConnection(strCN);

            string sql = "";

            cn.Open();

            sql = "SELECT c.SAPGroup as SAPGroup FROM cnc_project_management as a left join Prog_Request as b on a.Project_id = b.Project_id left join Routing_Request as c on a.Project_id = c.Project_id";
            sql += " where a.Part_Num='" + PartNum + "' and a.Part_Rev='" + Rev + "' and b.Prog_Num='" + ProgNum + "' and c.Routing_seq='" + OperationNo + "' and c.Workshop+c.Sap_Workcenter='" + WorkCtr + "'";
            sql += " order by a.project_id desc";
            using (SqlCommand sqlcmd = new SqlCommand(sql, cn))
            {
                try
                {
                    SqlDataReader reader = sqlcmd.ExecuteReader();

                    while (reader.Read())
                    {
                        string GetSAPGroup = reader["SAPGroup"].ToString();
                        if (GetSAPGroup.IndexOf("-") >0)
                        { strMPMSRoutingRequest = reader["SAPGroup"].ToString(); }
                    }

                    reader.Close();
                }
                catch
                {


                }
                finally
                {
                    cn.Close();
                }

            }

            return strMPMSRoutingRequest;

        }
        //add by PCZhou 2018-11-06
        public static string GetMPMSJobCardRoutingRequest(string strCN, string PartNum, string Rev, string ProgNum, string OperationNo, string WorkCtr)
        {
            string strMPMSRoutingRequest = "";
            SqlConnection cn = new SqlConnection(strCN);

            string sql = "";

            cn.Open();

            sql = "SELECT c.SAPGroup as SAPGroup FROM cnc_project_management as a left join Prog_Request as b on a.Project_id = b.Project_id left join Routing_Request as c on a.Project_id = c.Project_id";
            sql += " where a.Part_Num='" + PartNum + "' and a.Part_Rev='" + Rev + "' and b.Prog_Num='" + ProgNum + "' and c.Routing_seq='" + OperationNo + "' and c.Workshop+c.Sap_Workcenter='" + WorkCtr + "'";
            sql += " order by a.project_id desc";
            using (SqlCommand sqlcmd = new SqlCommand(sql, cn))
            {
                try
                {
                    SqlDataReader reader = sqlcmd.ExecuteReader();

                    while (reader.Read())
                    {
                        string GetSAPGroup = reader["SAPGroup"].ToString();
                        if (GetSAPGroup.IndexOf("-") == -1)
                        { strMPMSRoutingRequest = reader["SAPGroup"].ToString(); }
                    }

                    reader.Close();
                }
                catch
                {


                }
                finally
                {
                    cn.Close();
                }

            }

            return strMPMSRoutingRequest;

        }

        //add by PCZhou 2018-05-21
        public static string GetstralertsCC(string strCN, string strSiteID)
        {
            string stralertsCC = "";

            SqlConnection cn = new SqlConnection(strCN);

            string sql = "";

            cn.Open();

            if (strSiteID == "L")
            { sql = "select * from Monitor_User_list  where  Property_name = 'ALG_SAPCaculate' and  Property_value ='Y' and  Send_type ='CC'  "; }
            else if (strSiteID == "H")
            { sql = "select * from Monitor_User_list  where  Property_name = 'ATH_SAPCaculate' and  Property_value ='Y' and  Send_type ='CC'  "; }
            else if (strSiteID == "J")
            { sql = "select * from Monitor_User_list  where  Property_name = 'AMC_SAPCaculate' and  Property_value ='Y' and  Send_type ='CC'  "; }

            using (SqlCommand sqlcmd = new SqlCommand(sql, cn))
            {
                try
                {
                    SqlDataReader reader = sqlcmd.ExecuteReader();

                    while (reader.Read())
                    {
                        if (strSiteID == "L")
                        { stralertsCC += "badgealg" + reader["Badge"].ToString() + "@asmpt.com"; break; }
                        else if (strSiteID == "H")
                        { stralertsCC += "badgealg" + reader["Badge"].ToString() + "@asmpt.com"; break; }
                        else if (strSiteID == "J")
                        { stralertsCC += "badgeamc" + reader["Badge"].ToString() + "@asmpt.com"; break; }

                    }

                    reader.Close();
                }
                catch
                {


                }
                finally
                {
                    cn.Close();
                }

            }

            return stralertsCC;

        }

        //add by PCZhou 2018-05-21
        public static string GetstralertsBCC(string strCN, string strSiteID)
        {
            string stralertsBCC = "";

            SqlConnection cn = new SqlConnection(strCN);

            string sql = "";

            cn.Open();

            if (strSiteID == "L")
            { sql = "select * from Monitor_User_list  where  Property_name = 'ALG_SAPCaculate' and  Property_value ='Y' and  Send_type ='BCC'  "; }
            else if (strSiteID == "H")
            { sql = "select * from Monitor_User_list  where  Property_name = 'ATH_SAPCaculate' and  Property_value ='Y' and  Send_type ='BCC'  "; }
            else if (strSiteID == "J")
            { sql = "select * from Monitor_User_list  where  Property_name = 'AMC_SAPCaculate' and  Property_value ='Y' and  Send_type ='BCC'  "; }

            using (SqlCommand sqlcmd = new SqlCommand(sql, cn))
            {
                try
                {
                    SqlDataReader reader = sqlcmd.ExecuteReader();

                    while (reader.Read())
                    {
                        if (strSiteID == "L")
                        { stralertsBCC += "badgealg" + reader["Badge"].ToString() + "@asmpt.com"; break; }
                        else if (strSiteID == "H")
                        { stralertsBCC += "badgealg" + reader["Badge"].ToString() + "@asmpt.com"; break; }
                        else if (strSiteID == "J")
                        { stralertsBCC += "badgeamc" + reader["Badge"].ToString() + "@asmpt.com"; break; }

                    }

                    reader.Close();
                }
                catch
                {


                }
                finally
                {
                    cn.Close();
                }

            }

            return stralertsBCC;

        }

        //add by PCZhou 2018-05-21
        public static string GetstralertsErrorTO(string strCN, string strSiteID)
        {
            string stralertsErrorTO = "";

            SqlConnection cn = new SqlConnection(strCN);

            string sql = "";

            cn.Open();

            if (strSiteID == "L")
            { sql = "select * from Monitor_User_list  where  Property_name = 'ALG_SAPCaculateError' and  Property_value ='Y' and  Send_type ='TO'  "; }
            else if (strSiteID == "H")
            { sql = "select * from Monitor_User_list  where  Property_name = 'ALG_SAPCaculateError' and  Property_value ='Y' and  Send_type ='TO'  "; }
            else if (strSiteID == "J")
            { sql = "select * from Monitor_User_list  where  Property_name = 'ALG_SAPCaculateError' and  Property_value ='Y' and  Send_type ='TO'  "; }

            using (SqlCommand sqlcmd = new SqlCommand(sql, cn))
            {
                try
                {
                    SqlDataReader reader = sqlcmd.ExecuteReader();

                    while (reader.Read())
                    {
                        if (strSiteID == "L")
                        { stralertsErrorTO += "badgealg" + reader["Badge"].ToString() + "@asmpt.com"; break; }
                        else if (strSiteID == "H")
                        { stralertsErrorTO += "badgealg" + reader["Badge"].ToString() + "@asmpt.com"; break; }
                        else if (strSiteID == "J")
                        { stralertsErrorTO += "badgeamc" + reader["Badge"].ToString() + "@asmpt.com"; break; }

                    }

                    reader.Close();
                }
                catch
                {


                }
                finally
                {
                    cn.Close();
                }

            }

            return stralertsErrorTO;

        }
        //add by PCZhou 2018-05-21
        public static string GetstrsiteID(string strSiteID)
        {
            string strSiteID_TEMP = "";
            if (strSiteID == "8700")
            {
                strSiteID_TEMP = "L";
            }
            else if (strSiteID == "A200")
            {
                strSiteID_TEMP = "J";
            }
            else
            {
                strSiteID_TEMP = "H";
            }

            return strSiteID_TEMP;

        }

        public static string sqlconn(string con)
        {
            string strconn = ConfigurationManager.ConnectionStrings[con].ConnectionString.ToString();
            return strconn;
        }
        public static void sendmail(string subject, string receiver, string cc, string bcc, string content)
        {
            using (SqlConnection updateConnection = new SqlConnection(sqlconn(Form1.strMailCon)))
            {

                try
                {
                    string sql;
                    sql = "Insert MailList (receiver, sender,cc,bcc, subject, content,html)";
                    sql += "values ('" + receiver + "','','" + cc + "','" + bcc + "','" + Form1.site.ToUpper() + "  " + subject + "',@content,'1')";
                    SqlCommand cmd = new SqlCommand(sql, updateConnection);
                    SqlParameter sp = new SqlParameter("@content", content);
                    cmd.Parameters.Add(sp);
                    updateConnection.Open();
                    cmd.ExecuteNonQuery();
                }
                catch
                {
                }
            }
        }



        #endregion
    }

}