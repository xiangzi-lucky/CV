﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;
using System.Text.RegularExpressions;
using System.Threading;
using SAPCaculate.SAPWebforSetupTime_ALG;
using SAPCaculate.SAPWebforSetupTime_AMC;
using SAPCaculate.SAPWebforSetupTime_ATH;


namespace SAPCaculate
{
    //用委托实现窗体传值
    public delegate void Delshowmsg(string status);
    public class Workshop
    {

        #region Field

        private string _currentWorkshop;
        private string _site;
        private List<string> stdRouting = new List<string>();   //记录所有的CNC标准工艺
        public static Dictionary<string, string> dicSite = new Dictionary<string, string>();
        private Delshowmsg Delshow;

        #endregion

        #region Property

        public string WorkShop
        {
            get { return _currentWorkshop; }
            set { _currentWorkshop = value; }
        }
        public string Site
        {
            get { return _site; }
            set { _site = value; }
        }
        public Delshowmsg Delshow1
        {
            get { return Delshow; }
            set { Delshow = value; }
        }

        public List<string> StdRouting
        {
            get { return stdRouting; }
            set { stdRouting = value; }
        }

        #endregion

        #region Constructor

        public Workshop(string workshop, string site, Delshowmsg del)
        {
            this.WorkShop = workshop;
            this.Site = site;
            this.Delshow = del;
        }

        public Workshop(string site, Delshowmsg del)
        {
            this._site = site;
            this.Delshow = del;
        }

        #endregion

        #region PrivateMethod

        /// <summary>
        /// 分析工件的CNC工艺sap工时是否由CIM更新
        /// </summary>
        public void CheckCostData()
        {
            #region 获取一段时间内待分析工件

            string preDate = DateTime.Now.Date.AddDays(-2).ToShortDateString();
            StringBuilder sb = new StringBuilder();
            sb.Append("select distinct a.material,a.plant,a.rev,a.[group],a.groupctr,blnSAPstatus=0 from dbo.sap_standard_hour_uploadQ as a ");
            sb.Append(" left join sap_std_cost_calculation_request as b on a.material=b.material and a.plant=b.plant ");
            //sb.Append(" where a.input_time between '" + preDate + "' and '" + DateTime.Now.AddDays(1).ToShortDateString() + "' ");
            //sb.Append(" where a.input_time > '2017/11/10' ");  //11/10之前的数据不处理
            sb.Append(" where a.input_time > '2018/06/07' ");  //2018-06-07之前的数据不处理
            sb.Append(" and a.rev='A' and (a.workctr like '" + this._currentWorkshop + "%') and a.status='s' and b.material is null ");  //只处理版次为A,sap时间成功更新并且没有提交过的工件

            //sb.Append("select distinct material,plant,[group],groupctr,blnSAPstatus=0 from dbo.sap_standard_hour_uploadQ ");
            //sb.Append(" where input_time between '" + yesterday + "' and '" + DateTime.Now.AddDays(0).ToShortDateString() + "' ");
            //sb.Append(" and rev='A' and (workctr like '" + this._currentWorkshop + "%') and status='s' ");  //只处理版次为A且成功更新sap时间的工件

            Delshow("价格计算进行中: 正在获取是否进行价格计算待分析的工件数据");
            string currentProcess;
            currentProcess = "程序SAPCaculate分析工件是否需要上传进行价格计算时报错，請檢查!";
            DataTable dt = new DataTable();
            dt = GetData(sb.ToString(), currentProcess);

            if (stdRouting.Count == 0)
            {
                string strSql = "select distinct sap_code_id from dbo.Sap_Code";
                currentProcess = "程序SAPCaculate获取所有CNC标准工艺时报错，請檢查!";
                SqlDataReader sdr = GetDataReader(strSql, currentProcess);

                while (sdr.Read())
                {
                    StdRouting.Add(sdr[0].ToString());
                }
                sdr.Close();   //关闭sdr的同时也会关闭其依赖的数据库连接
            }

            #endregion

            #region 检查工件所有的CNC工艺sap标准工时是否都是由CIM更新
            string[][] routing = null;
            if (this._site == "8700")
            {
                SAPWeb_ALG._001SoapClient sapOP = new SAPWeb_ALG._001SoapClient();

                //sgWebServiceCaller.sapOperation sapOP = new sgWebServiceCaller.sapOperation(Workshop.dicSite[this._site].ToString());

                bool blnSAPUpdate;
                for (int i = 0; i < dt.Rows.Count; i++)
                {

                    blnSAPUpdate = false;
                    DataRow dr = dt.Rows[i];

                    routing = sapOP.GetRouting(dr["material"].ToString(), dr["plant"].ToString(), dr["group"].ToString(), dr["groupctr"].ToString());
                    //routing = sapOP.getRouting(dr["material"].ToString(), dr["plant"].ToString(), dr["group"].ToString(), dr["groupctr"].ToString());
                    for (int h = 0; h <= routing.Length - 1; h++)
                    {
                        //判断所有的CNC工艺SAP标准工时是否都是由CIM更新
                        if (stdRouting.Contains(routing[h][2].ToString()))
                        {
                            Delshow("正在检查工件 " + i + "/" + dt.Rows.Count + " " + dr["material"].ToString() + "的" + routing[h][2].ToString() + "的SAP工时是否由CIM更新");
                            currentProcess = "程序SAPCaculate检查工件CNC标准工艺sap工时是否由CIM更新时报错，請檢查!";
                            sb.Clear();
                            sb.Append("select top 1 * from dbo.sap_standard_hour_uploadQ ");
                            sb.Append(" where material='" + dr["material"].ToString() + "' and [group]='" + dr["group"].ToString() + "'");
                            sb.Append(" and groupctr='" + dr["groupctr"].ToString() + "' and operationno ='" + routing[h][0].ToString() + "'");
                            //sb.Append(" and [status] ='s' ");
                            sb.Append(" and [status] in('S','C')");

                            blnSAPUpdate = SQLRelate.SqlExist(SQLRelate.sqlconn(Form1.strRDCon), sb.ToString(), currentProcess);

                            if (!blnSAPUpdate)
                            {
                                break;
                            }
                        }
                    }

                    if (blnSAPUpdate)
                    {
                        //blnSAPUpdate为true说明这个工件所有CNC工艺sap工时都是由CIM更新的，可以提交计算价格
                        dt.Rows[i]["blnSAPstatus"] = 1;
                    }
                    else
                    {
                        //将不满足上述条件的工件在sap_standard_hour_uploadQ中的状态status置为H（handle），表示此条数据已经处理，但是没有提交进行价格计算
                        sb.Clear();
                        sb.Append("update sap_standard_hour_uploadQ set [status]='H',return_msg='SAP standard hour updated but not submit to caculate cost' ");
                        //sb.Append(" where rowguid='"+ dr["rowguid"].ToString() + "'");

                        sb.Append(" where material='" + dr["material"].ToString() + "' and rev='" + dr["rev"].ToString() + "'  ");
                        sb.Append(" and [group]='" + dr["group"].ToString() + "' and groupctr='" + dr["groupctr"].ToString() + "' and [status]='S' ");

                        currentProcess = "程序SAPCaculate在更新所有CNC工艺非全部由CIM的记录时报错，請檢查!";
                        SQLRelate.InsertUpdate(SQLRelate.sqlconn(Form1.strCON), sb.ToString(), currentProcess);
                    }
                }
            }
            else if(this._site == "A200")
            {
                SAPWeb_AMC._001SoapClient sapOP = new SAPWeb_AMC._001SoapClient();

                //sgWebServiceCaller.sapOperation sapOP = new sgWebServiceCaller.sapOperation(Workshop.dicSite[this._site].ToString());

                bool blnSAPUpdate;
                for (int i = 0; i < dt.Rows.Count; i++)
                {

                    blnSAPUpdate = false;
                    DataRow dr = dt.Rows[i];

                    routing = sapOP.GetRouting(dr["material"].ToString(), dr["plant"].ToString(), dr["group"].ToString(), dr["groupctr"].ToString());
                    //routing = sapOP.getRouting(dr["material"].ToString(), dr["plant"].ToString(), dr["group"].ToString(), dr["groupctr"].ToString());
                    for (int h = 0; h <= routing.Length - 1; h++)
                    {
                        //判断所有的CNC工艺SAP标准工时是否都是由CIM更新
                        if (stdRouting.Contains(routing[h][2].ToString()))
                        {
                            Delshow("正在检查工件 " + i + "/" + dt.Rows.Count + " " + dr["material"].ToString() + "的" + routing[h][2].ToString() + "的SAP工时是否由CIM更新");
                            currentProcess = "程序SAPCaculate检查工件CNC标准工艺sap工时是否由CIM更新时报错，請檢查!";
                            sb.Clear();
                            sb.Append("select top 1 * from dbo.sap_standard_hour_uploadQ ");
                            sb.Append(" where material='" + dr["material"].ToString() + "' and [group]='" + dr["group"].ToString() + "'");
                            sb.Append(" and groupctr='" + dr["groupctr"].ToString() + "' and operationno ='" + routing[h][0].ToString() + "'");
                            //sb.Append(" and [status] ='s' ");
                            sb.Append(" and [status] in('S','C')");

                            blnSAPUpdate = SQLRelate.SqlExist(SQLRelate.sqlconn(Form1.strRDCon), sb.ToString(), currentProcess);

                            if (!blnSAPUpdate)
                            {
                                break;
                            }
                        }
                    }

                    if (blnSAPUpdate)
                    {
                        //blnSAPUpdate为true说明这个工件所有CNC工艺sap工时都是由CIM更新的，可以提交计算价格
                        dt.Rows[i]["blnSAPstatus"] = 1;
                    }
                    else
                    {
                        //将不满足上述条件的工件在sap_standard_hour_uploadQ中的状态status置为H（handle），表示此条数据已经处理，但是没有提交进行价格计算
                        sb.Clear();
                        sb.Append("update sap_standard_hour_uploadQ set [status]='H',return_msg='SAP standard hour updated but not submit to caculate cost' ");
                        //sb.Append(" where rowguid='"+ dr["rowguid"].ToString() + "'");

                        sb.Append(" where material='" + dr["material"].ToString() + "' and rev='" + dr["rev"].ToString() + "'  ");
                        sb.Append(" and [group]='" + dr["group"].ToString() + "' and groupctr='" + dr["groupctr"].ToString() + "' and [status]='S' ");

                        currentProcess = "程序SAPCaculate在更新所有CNC工艺非全部由CIM的记录时报错，請檢查!";
                        SQLRelate.InsertUpdate(SQLRelate.sqlconn(Form1.strCON), sb.ToString(), currentProcess);
                    }
                }
            }
            else if(this._site == "H100")
            {
                SAPWeb_ATH._001SoapClient sapOP = new SAPWeb_ATH._001SoapClient();

                //sgWebServiceCaller.sapOperation sapOP = new sgWebServiceCaller.sapOperation(Workshop.dicSite[this._site].ToString());

                bool blnSAPUpdate;
                for (int i = 0; i < dt.Rows.Count; i++)
                {

                    blnSAPUpdate = false;
                    DataRow dr = dt.Rows[i];

                    routing = sapOP.GetRouting(dr["material"].ToString(), dr["plant"].ToString(), dr["group"].ToString(), dr["groupctr"].ToString());
                    //routing = sapOP.getRouting(dr["material"].ToString(), dr["plant"].ToString(), dr["group"].ToString(), dr["groupctr"].ToString());
                    for (int h = 0; h <= routing.Length - 1; h++)
                    {
                        //判断所有的CNC工艺SAP标准工时是否都是由CIM更新
                        if (stdRouting.Contains(routing[h][2].ToString()))
                        {
                            Delshow("正在检查工件 " + i + "/" + dt.Rows.Count + " " + dr["material"].ToString() + "的" + routing[h][2].ToString() + "的SAP工时是否由CIM更新");
                            currentProcess = "程序SAPCaculate检查工件CNC标准工艺sap工时是否由CIM更新时报错，請檢查!";
                            sb.Clear();
                            sb.Append("select top 1 * from dbo.sap_standard_hour_uploadQ ");
                            sb.Append(" where material='" + dr["material"].ToString() + "' and [group]='" + dr["group"].ToString() + "'");
                            sb.Append(" and groupctr='" + dr["groupctr"].ToString() + "' and operationno ='" + routing[h][0].ToString() + "'");
                            //sb.Append(" and [status] ='s' ");
                            sb.Append(" and [status] in('S','C')");

                            blnSAPUpdate = SQLRelate.SqlExist(SQLRelate.sqlconn(Form1.strRDCon), sb.ToString(), currentProcess);

                            if (!blnSAPUpdate)
                            {
                                break;
                            }
                        }
                    }

                    if (blnSAPUpdate)
                    {
                        //blnSAPUpdate为true说明这个工件所有CNC工艺sap工时都是由CIM更新的，可以提交计算价格
                        dt.Rows[i]["blnSAPstatus"] = 1;
                    }
                    else
                    {
                        //将不满足上述条件的工件在sap_standard_hour_uploadQ中的状态status置为H（handle），表示此条数据已经处理，但是没有提交进行价格计算
                        sb.Clear();
                        sb.Append("update sap_standard_hour_uploadQ set [status]='H',return_msg='SAP standard hour updated but not submit to caculate cost' ");
                        //sb.Append(" where rowguid='"+ dr["rowguid"].ToString() + "'");

                        sb.Append(" where material='" + dr["material"].ToString() + "' and rev='" + dr["rev"].ToString() + "'  ");
                        sb.Append(" and [group]='" + dr["group"].ToString() + "' and groupctr='" + dr["groupctr"].ToString() + "' and [status]='S' ");

                        currentProcess = "程序SAPCaculate在更新所有CNC工艺非全部由CIM的记录时报错，請檢查!";
                        SQLRelate.InsertUpdate(SQLRelate.sqlconn(Form1.strCON), sb.ToString(), currentProcess);
                    }
                }
            }else 
            {
                SAPWeb._001SoapClient sapOP = new SAPWeb._001SoapClient();

                //sgWebServiceCaller.sapOperation sapOP = new sgWebServiceCaller.sapOperation(Workshop.dicSite[this._site].ToString());

                bool blnSAPUpdate;
                for (int i = 0; i < dt.Rows.Count; i++)
                {

                    blnSAPUpdate = false;
                    DataRow dr = dt.Rows[i];

                    routing = sapOP.GetRouting(dr["material"].ToString(), dr["plant"].ToString(), dr["group"].ToString(), dr["groupctr"].ToString());
                    //routing = sapOP.getRouting(dr["material"].ToString(), dr["plant"].ToString(), dr["group"].ToString(), dr["groupctr"].ToString());
                    for (int h = 0; h <= routing.Length - 1; h++)
                    {
                        //判断所有的CNC工艺SAP标准工时是否都是由CIM更新
                        if (stdRouting.Contains(routing[h][2].ToString()))
                        {
                            Delshow("正在检查工件 " + i + "/" + dt.Rows.Count + " " + dr["material"].ToString() + "的" + routing[h][2].ToString() + "的SAP工时是否由CIM更新");
                            currentProcess = "程序SAPCaculate检查工件CNC标准工艺sap工时是否由CIM更新时报错，請檢查!";
                            sb.Clear();
                            sb.Append("select top 1 * from dbo.sap_standard_hour_uploadQ ");
                            sb.Append(" where material='" + dr["material"].ToString() + "' and [group]='" + dr["group"].ToString() + "'");
                            sb.Append(" and groupctr='" + dr["groupctr"].ToString() + "' and operationno ='" + routing[h][0].ToString() + "'");
                            //sb.Append(" and [status] ='s' ");
                            sb.Append(" and [status] in('S','C')");

                            blnSAPUpdate = SQLRelate.SqlExist(SQLRelate.sqlconn(Form1.strRDCon), sb.ToString(), currentProcess);

                            if (!blnSAPUpdate)
                            {
                                break;
                            }
                        }
                    }

                    if (blnSAPUpdate)
                    {
                        //blnSAPUpdate为true说明这个工件所有CNC工艺sap工时都是由CIM更新的，可以提交计算价格
                        dt.Rows[i]["blnSAPstatus"] = 1;
                    }
                    else
                    {
                        //将不满足上述条件的工件在sap_standard_hour_uploadQ中的状态status置为H（handle），表示此条数据已经处理，但是没有提交进行价格计算
                        sb.Clear();
                        sb.Append("update sap_standard_hour_uploadQ set [status]='H',return_msg='SAP standard hour updated but not submit to caculate cost' ");
                        //sb.Append(" where rowguid='"+ dr["rowguid"].ToString() + "'");

                        sb.Append(" where material='" + dr["material"].ToString() + "' and rev='" + dr["rev"].ToString() + "'  ");
                        sb.Append(" and [group]='" + dr["group"].ToString() + "' and groupctr='" + dr["groupctr"].ToString() + "' and [status]='S' ");

                        currentProcess = "程序SAPCaculate在更新所有CNC工艺非全部由CIM的记录时报错，請檢查!";
                        SQLRelate.InsertUpdate(SQLRelate.sqlconn(Form1.strCON), sb.ToString(), currentProcess);
                    }
                }
            }
            //SAPWeb._001SoapClient sapOP = new SAPWeb._001SoapClient();

            ////sgWebServiceCaller.sapOperation sapOP = new sgWebServiceCaller.sapOperation(Workshop.dicSite[this._site].ToString());

            //bool blnSAPUpdate;
            //for (int i = 0; i < dt.Rows.Count; i++)
            //{

            //    blnSAPUpdate = false;
            //    DataRow dr = dt.Rows[i];

            //    routing = sapOP.GetRouting(dr["material"].ToString(), dr["plant"].ToString(), dr["group"].ToString(), dr["groupctr"].ToString());
            //    //routing = sapOP.getRouting(dr["material"].ToString(), dr["plant"].ToString(), dr["group"].ToString(), dr["groupctr"].ToString());
            //    for (int h = 0; h <= routing.Length - 1; h++)
            //    {
            //        //判断所有的CNC工艺SAP标准工时是否都是由CIM更新
            //        if (stdRouting.Contains(routing[h][2].ToString()))
            //        {
            //            Delshow("正在检查工件 " + i + "/" + dt.Rows.Count + " " + dr["material"].ToString() + "的" + routing[h][2].ToString() + "的SAP工时是否由CIM更新");
            //            currentProcess = "程序SAPCaculate检查工件CNC标准工艺sap工时是否由CIM更新时报错，請檢查!";
            //            sb.Clear();
            //            sb.Append("select top 1 * from dbo.sap_standard_hour_uploadQ ");
            //            sb.Append(" where material='" + dr["material"].ToString() + "' and [group]='" + dr["group"].ToString() + "'");
            //            sb.Append(" and groupctr='" + dr["groupctr"].ToString() + "' and operationno ='" + routing[h][0].ToString() + "'");
            //            //sb.Append(" and [status] ='s' ");
            //            sb.Append(" and [status] in('S','C')");

            //            blnSAPUpdate = SQLRelate.SqlExist(SQLRelate.sqlconn(Form1.strRDCon), sb.ToString(), currentProcess);

            //            if (!blnSAPUpdate)
            //            {
            //                break;
            //            }
            //        }
            //    }

            //    if (blnSAPUpdate)
            //    {
            //        //blnSAPUpdate为true说明这个工件所有CNC工艺sap工时都是由CIM更新的，可以提交计算价格
            //        dt.Rows[i]["blnSAPstatus"] = 1;
            //    }
            //    else
            //    {
            //        //将不满足上述条件的工件在sap_standard_hour_uploadQ中的状态status置为H（handle），表示此条数据已经处理，但是没有提交进行价格计算
            //        sb.Clear();
            //        sb.Append("update sap_standard_hour_uploadQ set [status]='H',return_msg='SAP standard hour updated but not submit to caculate cost' ");
            //        //sb.Append(" where rowguid='"+ dr["rowguid"].ToString() + "'");

            //        sb.Append(" where material='" + dr["material"].ToString() + "' and rev='" + dr["rev"].ToString() + "'  ");
            //        sb.Append(" and [group]='" + dr["group"].ToString() + "' and groupctr='" + dr["groupctr"].ToString() + "' and [status]='S' ");

            //        currentProcess = "程序SAPCaculate在更新所有CNC工艺非全部由CIM的记录时报错，請檢查!";
            //        SQLRelate.InsertUpdate(SQLRelate.sqlconn(Form1.strCON), sb.ToString(), currentProcess);
            //    }
            //}

            #endregion

            #region 提交数据至sap_std_cost_calculation_request表

            DataView dv = new DataView(dt);
            //过滤掉不提交计算价格的工件
            dv.RowFilter = "blnSAPstatus ='1'";
            DataTable dtCost = dv.ToTable();

            for (int i = 0; i < dtCost.Rows.Count; i++)
            {
                DataRow dr = dtCost.Rows[i];
                sb.Clear();
                //sb.Append("if(not exists(select material,plant from sap_std_cost_calculation_request where material='"+dr["material"].ToString() + "'");
                //sb.Append(" and plant='"+ dr["plant"].ToString() + "'))\n\r ");
                //sb.Append(" begin \n\r");
                sb.Append("   insert sap_std_cost_calculation_request (material,plant,rev,routinggroup,routinggroupcounter,add_date,status)values");
                sb.Append(" ('" + dr["material"].ToString() + "','" + dr["plant"].ToString() + "','" + dr["rev"].ToString() + "','" + dr["group"].ToString() + "',");
                sb.Append(" '" + dr["groupctr"].ToString() + "',getdate(),'0') \n\r");
                //sb.Append(" end");

                Delshow("正在提交工件 " + i + "/" + dtCost.Rows.Count + " " + dr["material"].ToString() + "至价格计算数据表中");

                //currentProcess = "程序SAPCaculate在上传工件至数据库进行价格计算时报错，請檢查!";
                //SQLRelate.InsertUpdate(SQLRelate.sqlconn(Form1.strCON), sb.ToString(), currentProcess);

                List<string> strSqlList = new List<string>();
                strSqlList.Add(sb.ToString());
                sb.Clear();
                sb.Append("update dbo.sap_standard_hour_uploadQ set [status]='C',return_msg='Material was submitted to cacalute cost' ");
                //sb.Append(" where rowguid ='"+ dr["rowguid"].ToString()+ "'");
                //提交计算价格成功后，将此工件在sap_standard_hour_uploadQ中的所有记录状态都更新为C
                sb.Append(" where material='" + dr["material"].ToString() + "' and rev='" + dr["rev"].ToString() + "'  ");
                sb.Append(" and [group]='" + dr["rev"].ToString() + "' and groupctr='" + dr["groupctr"].ToString() + "' ");
                strSqlList.Add(sb.ToString());

                currentProcess = "程序SAPCaculate在上传工件至等待进行价格计算数据表时报错，請檢查!";
                SQLRelate.InsertUpdate(SQLRelate.sqlconn(Form1.strCON), strSqlList, currentProcess);

            }
            #endregion

        }
        public void SubmitCostData()
        {
            #region 获取要提交的数据
            string currentProcess;
            string strSql = "select * from dbo.sap_std_cost_calculation_request  where  status='0' and plant='" + this._site + "' ";
            currentProcess = "程序SAPCaculate获取计算价格记录報錯，請檢查!";
            DataTable dt = GetData(strSql, currentProcess);
            #endregion

            //处理获取的数据
            if (dt.Rows.Count > 0)
            {
                string output;   //用于接收调用存储过程的返回值
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    DataRow dr = dt.Rows[i];
                    #region 调用存储过程插入数据
                    //逐行判断插入的值与接收返回的结果
                    using (SqlConnection cn = new SqlConnection(SQLRelate.sqlconn("aaa45CON")))
                    {
                        SqlCommand cmd = new SqlCommand(ConfigurationManager.AppSettings["SPName"].ToString(), cn);
                        cmd.CommandType = CommandType.StoredProcedure;
                        Delshow("正在处理" + this.WorkShop + " 工件 " + (i + 1) + "/" + dt.Rows.Count + " " + dr["material"]);
                        //lbStatus.Text = "Handling material " + (i + 1) + "/" + dt.Rows.Count + dr["material"];

                        cmd.Parameters.AddWithValue("@type", "N");
                        cmd.Parameters.AddWithValue("@Material", dr["material"]);
                        cmd.Parameters.AddWithValue("@Plant", dr["plant"]);
                        cmd.Parameters.AddWithValue("@ReleasedAt", DateTime.Now);
                        cmd.Parameters.AddWithValue("@ReleasedBy", "CIM");
                        cmd.Parameters.AddWithValue("@Active ", "1");
                        cmd.Parameters.AddWithValue("@Status", "P");
                        cmd.Parameters.AddWithValue("@RoutingGroup", dr["RoutingGroup"]);
                        cmd.Parameters.AddWithValue("@RoutingGroupCounter", dr["RoutingGroupCounter"]);
                        cmd.Parameters.AddWithValue("@Case_type", "RECALC");
                        SqlParameter parOutput = new SqlParameter("@output", SqlDbType.VarChar, 8);　　//output result
                        parOutput.Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(parOutput);
                        try
                        {
                            cn.Open();
                            cmd.ExecuteNonQuery();
                            output = cmd.Parameters["@output"].Value.ToString();
                        }
                        catch (Exception ex)
                        {
                            SQLRelate.sendmail("Error with SAPCaculate", SQLRelate.GetstralertsErrorTO((SQLRelate.sqlconn(Form1.strRDCon)), SQLRelate.GetstrsiteID(Form1.site)), "", "", "<table bgcolor=white border=1 bordercolor=Gray bordercolordark=LemonChiffon><tr><td>" + currentProcess + "</td><td> " + ex.ToString() + "</td></tr></table>");
                            continue;
                        }
                        finally
                        {
                            cn.Close();
                        }
                    }
                    #endregion

                    #region 根据插入数据的结果更新sap_std_cost_calculation_request
                    StringBuilder sb = new StringBuilder();
                    sb.Append("update dbo.sap_std_cost_calculation_request set post_date=getdate(),status='1', ");
                    switch (output)
                    {
                        case "E1":
                            sb.Append("result='Fail(Status or RoutingGroup or RoutingGroupCounter is NULL)' ");
                            break;
                        case "E2":
                            sb.Append("result='Fail(Error with Status)' ");
                            break;
                        case "E3":
                            sb.Append("result='Fail(Records exist already)' ");
                            break;
                        case "E4":
                            sb.Append("result='Fail(Unknow reason)' ");
                            break;
                        case "S":
                            sb.Append("result='Successful' ");
                            break;
                    }
                    sb.Append(" where material='" + dr["material"] + "' and plant='" + dr["plant"] + "'");
                    currentProcess = "程序SAPCaculate更新上传计算价格后的记录報錯，請檢查!";
                    SQLRelate.InsertUpdate(SQLRelate.sqlconn(Form1.strCON), sb.ToString(), currentProcess);
                    #endregion
                }
            }
        }

        public void CheckData()
        {
            //lbNextTime.Text = "";
            DataTable DTsap_standard_hourInfor = new DataTable();
            Delshow("更新标准工时: 正在查询" + this.WorkShop + "需要处理的数据...");
            //
            DTsap_standard_hourInfor = Loadsap_standard_hourInfor();//在sap_standard_hour_uploadQ中读取数据
            Delshow("更新标准工时: 正在处理" + this.WorkShop + "数据...");
            //
            ComParerSAPandUpdate(DTsap_standard_hourInfor); //与SAP进行匹配并且获取SAP工时
            Delshow("更新标准工时: 已完成" + this.WorkShop + "预先处理！");
        }
        public void UpdateSAP_StdHour()
        {
            Delshow("更新标准工时: 正在查询" + this.WorkShop + "需要更新SAP工时的记录...");

            DataTable dt = GetDataforSAPTimeUpdate();
            if (dt.Rows.Count > 0)
            {
                UpdateSAPTime_StdHour(dt);
                Delshow("更新标准工时: 更新" + this.WorkShop + "SAP标准工时完成！");
            }
        }
        //public void Update_SAPStdHour_OnOffLoadTime()
        //{
        //    Delshow("更新标准工时 和 On_Off_Load_Time: 正在查询" + this.WorkShop + "需要更新SAP的记录...");

        //    DataTable dt = GetDataforSAPTimeUpdate();
        //    if (dt.Rows.Count > 0)
        //    {
        //        UpdateSAPTime_StdHour(dt);
        //        Delshow("更新标准工时: 更新" + this.WorkShop + "SAP 标准工时完成！");
        //        //
        //        UpdateONOFFLOADTime(dt);
        //        Delshow("更新On_Off_Load_Time: 更新" + this.WorkShop + "SAP On_Off_Load_Time完成！");
        //    }
        //}
        public void UpdateSAP_JobCardHour()  //add by PCZhou 2018-11-06: "处理sap_standard_hour_uploadQ数据, 得到工卡工时的过程"
        {
            DataTable dt = new DataTable();
            //
            Delshow("更新工卡工时: 正在查询" + this.WorkShop + "数据信息与SAP信息不一致的数据...");
            dt = Getdata_standard_hourInfor_JobCard();
            //
            Delshow("更新工卡工时: 正在处理" + this.WorkShop + "数据...");
            ComParerSAPandUpdate_JobCard(dt);
            //
            UpdateSAPTime_JobCard(dt);
            //
            Delshow("更新" + this.WorkShop + "SAP工卡工时完成！");
            //
        }
        public void UpdateSAP_On_Off_Load_Time()
        {
            Delshow("更新On_Off_Load_Time: 正在查询" + this.WorkShop + "需要更新SAP的记录...");
            DataTable dt = Getdata_on_off_load_time();
            if (dt.Rows.Count > 0)
            {
                UpdateSAPTime_On_Off_Load_Time(dt);
                Delshow("更新On_Off_Load_Time: 更新" + this.WorkShop + "SAP On_Off_Load_Time完成！");
            }
        }
        /// <summary>
        /// 获取需要更新SAP标准工时的数据
        /// </summary>
        private DataTable GetDataforSAPTimeUpdate()
        {
            DataTable dt = new DataTable();
            //string yesterday = DateTime.Now.Date.AddDays(-6).ToString();

            StringBuilder sb = new StringBuilder();

            //ATH采用on_off_load_time模式，ug时间不用乘以1.1
            if (this._site == "H100")
            {
                //目前UG模拟时间更新为SAP时间
                //sb.Append("select material,rev,fix_seq,p_num,p_rev,plant,[group],groupCtr,operationNo,updateStdVal1,updateStdVal2,newStdVal1,newStdVal2,on_off_load_time,On_Load_Time, Off_Load_Time, oldStdVal2,status,Status_OnOff_Load_Time, rowguid from dbo.sap_standard_hour_uploadQ  where status in('F') and input_time > '2018-01-01' ");
                sb.Append("select material,rev,fix_seq,p_num,p_rev,plant,[group],groupCtr,operationNo,updateStdVal1,updateStdVal2,newStdVal1,newStdVal2,on_off_load_time,On_Load_Time, Off_Load_Time, oldStdVal2,status,Status_OnOff_Load_Time, rowguid from dbo.sap_standard_hour_uploadQ  where  status in('w') ");
                sb.Append(" and input_time > '" + Form1.strdatetime + "'");//只处理当天的数据
                //sb.Append(" and (workctr like '" + this._currentWorkshop + "%') order by material, rev, fix_seq, p_rev ");
                // ------------------------------- ---------------------------------- ----------------------------------------------------------------
            }
            else
            {
                ////目前需要将UG模拟时间增加10%才能更新为SAP时间
                //sb.Append("select material,rev,fix_seq,p_num,p_rev,plant,[group],groupCtr,operationNo,updateStdVal1,updateStdVal2,newStdVal1,newStdVal2,on_off_load_time,On_Load_Time, Off_Load_Time, oldStdVal2,status,Status_OnOff_Load_Time, rowguid from dbo.sap_standard_hour_uploadQ  where status in('F') and input_time > '2018-11-01' ");
                sb.Append("select material,rev,fix_seq,p_num,p_rev,plant,[group],groupCtr,operationNo,updateStdVal1,updateStdVal2,newStdVal1,newStdVal2 * 1.1 as newStdVal2, on_off_load_time,On_Load_Time, Off_Load_Time, oldStdVal2,status,Status_OnOff_Load_Time,rowguid from dbo.sap_standard_hour_uploadQ  where  status in('w') ");
                sb.Append(" and input_time > '" + Form1.strdatetime + "'");//只处理当天的数据
                //sb.Append(" and material='26-i66059' ");//只处理当天的数据
                //sb.Append(" and (workctr like '" + this._currentWorkshop + "%') order by material, rev, fix_seq, p_rev ");
                //// ------------------------------- ---------------------------------- ----------------------------------------------------------------
            }

            string currentProcess;
            currentProcess = "程序SAPCaculate获取待更新SAP工时的数据记录报错，請檢查!";
            dt = GetData(sb.ToString(), currentProcess);

            return dt;
        }

        ///// <summary>
        ///// 获取需要更新SAP JobCard工时的数据
        ///// </summary>
        //private DataTable GetDataforSAPTimeUpdate_JobCard()
        //{
        //    DataTable dt = new DataTable();
        //    //string yesterday = DateTime.Now.Date.AddDays(-6).ToString();

        //    StringBuilder sb = new StringBuilder();

        //    //ATH采用on_off_load_time模式，ug时间不用乘以1.1
        //    if (this._site == "H100")
        //    {
        //        //目前UG模拟时间更新为SAP时间
        //        sb.Append("select material,rev,fix_seq,p_num,p_rev,plant,[group],groupCtr,operationNo,updateStdVal1,updateStdVal2,newStdVal1,newStdVal2,on_off_load_time,oldStdVal2,status,rowguid from dbo.sap_standard_hour_uploadQ  where  status in('F') ");
        //        sb.Append(" and input_time > '2018/10/15' order by material, rev, fix_seq, p_rev");
        //        //sb.Append(" and input_time > '" + Form1.strdatetime + "'"); //只处理当天的数据
        //        //sb.Append(" and (workctr like '" + this._currentWorkshop + "%') order by material, rev, fix_seq, p_rev");
        //        // ------------------------------- ---------------------------------- ----------------------------------------------------------------
        //    }
        //    else
        //    {
        //        //目前需要将UG模拟时间增加10%才能更新为SAP时间
        //        sb.Append("select material,rev,fix_seq,p_num,p_rev,plant,[group],groupCtr,operationNo,updateStdVal1,updateStdVal2,newStdVal1,newStdVal2 * 1.1 as newStdVal2,oldStdVal2,status,rowguid from dbo.sap_standard_hour_uploadQ  where  status in('F') ");
        //        sb.Append(" and input_time > '2018/10/15' order by material, rev, fix_seq, p_rev");
        //        //sb.Append(" and input_time > '" + Form1.strdatetime + "'");//只处理当天的数据
        //        //sb.Append(" and (workctr like '" + this._currentWorkshop + "%') order by material, rev, fix_seq, p_rev ");
        //        //// ------------------------------- ---------------------------------- ----------------------------------------------------------------
        //    }

        //    string currentProcess;
        //    currentProcess = "程序SAPCaculate获取待更新SAP工时的数据记录报错，請檢查!";
        //    dt = GetData(sb.ToString(), currentProcess);

        //    return dt;
        //}

        /// <summary>
        /// 逐行更新sap标准工时
        /// </summary>
        /// <param name="dt">要更新的数据记录</param>
        /// <param name="lbStatus">Form1状态控件</param>
        public void UpdateSAPTime_StdHour(DataTable dt)
        {
            //
            if (this._site == "8700")
            {
                SAPWeb_ALG._001SoapClient cg = new SAPWeb_ALG._001SoapClient();
                for (int i = 0; i < dt.Rows.Count; i++)
                {

                    DataRow dr = dt.Rows[i];
                    Delshow((i + 1) + "/" + dt.Rows.Count.ToString() + "正在更新" + this.WorkShop + "工件" + dr["material"] + "的SAP标准工时...");

                    string material = dr["material"].ToString();
                    string plant = dr["plant"].ToString().PadLeft(4);
                    string group = dr["group"].ToString().PadLeft(8);
                    string groupCtr = dr["groupCtr"].ToString().PadLeft(2, '0');
                    string oprationNo = dr["operationNo"].ToString().PadLeft(4, '0');
                    bool updateStdVal1 = false;  //目前暂时不更新stdval1，默认false

                    bool updateStdVal2;
                    if (dr["updateStdVal2"].ToString() == "F")
                        updateStdVal2 = false;
                    else
                        updateStdVal2 = true;

                    Single newStdVal1 = 0;  // 目前暂时默认newstdval1值为0，且不进行更新

                    decimal newStdVal2_temp = Math.Round(Convert.ToDecimal((dr["newStdVal2"].ToString())), 3);
                    Single newStdVal2 = Convert.ToSingle(newStdVal2_temp);

                    decimal oldStdVal2_temp = Math.Round(Convert.ToDecimal((dr["oldStdVal2"].ToString())), 3);
                    Single oldStdVal2 = Convert.ToSingle(oldStdVal2_temp);

                    if (newStdVal2 == 0)
                    {
                        //检测到UG 时间为0，就废掉此条记录
                        Update_sap_standard_hour_uploadQ_StdHour(new string[] { "WrongUGT" }, dr["rowguid"].ToString(), dr["status"].ToString(), dr["newStdVal2"].ToString());
                        continue;
                    }

                    try
                    {
                        string[] temp = cg.ChangeRouting(material, plant, group, groupCtr, oprationNo, updateStdVal1, newStdVal1, updateStdVal2, newStdVal2);

                        if (temp[0]=="F")
                        {

                            temp = cg.ChangeRouting(material, plant, group, groupCtr, oprationNo, updateStdVal1, newStdVal1, updateStdVal2, newStdVal2);
                        }

                        //更新sap_standard_hour_uploadq表中的状态
                        Update_sap_standard_hour_uploadQ_StdHour(temp, dr["rowguid"].ToString(), dr["status"].ToString(), dr["newStdVal2"].ToString());

                        //废掉低P_Rev的记录
                        DisableLowerVersionRecord(dr["material"].ToString(), dr["rev"].ToString(), dr["fix_seq"].ToString(), dr["p_num"].ToString(), dr["p_rev"].ToString());
                    }
                    catch (Exception ex)
                    {
                        string currentProcess;
                        currentProcess = "程序SAPCaculate调用WebService更新SAP标准工时報錯，請檢查!";
                        SQLRelate.sendmail("Error with SAPCaculate", SQLRelate.GetstralertsErrorTO((SQLRelate.sqlconn(Form1.strRDCon)), SQLRelate.GetstrsiteID(Form1.site)), "", "", "<table bgcolor=white border=1 bordercolor=Gray bordercolordark=LemonChiffon><tr><td>" + currentProcess + "</td><td> " + ex.ToString() + "</td></tr></table>");
                    }

                    //Form1.strdatetime = DateTime.Now.ToString("d");

                }
            }
            else if (this._site == "A200")
            {
                SAPWeb_AMC._001SoapClient cg = new SAPWeb_AMC._001SoapClient();
                for (int i = 0; i < dt.Rows.Count; i++)
                {

                    DataRow dr = dt.Rows[i];
                    Delshow((i + 1) + "/" + dt.Rows.Count.ToString() + "正在更新" + this.WorkShop + "工件" + dr["material"] + "的SAP标准工时...");

                    string material = dr["material"].ToString();
                    string plant = dr["plant"].ToString().PadLeft(4);
                    string group = dr["group"].ToString().PadLeft(8);
                    string groupCtr = dr["groupCtr"].ToString().PadLeft(2, '0');
                    string oprationNo = dr["operationNo"].ToString().PadLeft(4, '0');
                    bool updateStdVal1 = false;  //目前暂时不更新stdval1，默认false

                    bool updateStdVal2;
                    if (dr["updateStdVal2"].ToString() == "F")
                        updateStdVal2 = false;
                    else
                        updateStdVal2 = true;

                    Single newStdVal1 = 0;  // 目前暂时默认newstdval1值为0，且不进行更新

                    decimal newStdVal2_temp = Math.Round(Convert.ToDecimal((dr["newStdVal2"].ToString())), 3);
                    Single newStdVal2 = Convert.ToSingle(newStdVal2_temp);

                    decimal oldStdVal2_temp = Math.Round(Convert.ToDecimal((dr["oldStdVal2"].ToString())), 3);
                    Single oldStdVal2 = Convert.ToSingle(oldStdVal2_temp);

                    if (newStdVal2 == 0)
                    {
                        //检测到UG 时间为0，就废掉此条记录
                        Update_sap_standard_hour_uploadQ_StdHour(new string[] { "WrongUGT" }, dr["rowguid"].ToString(), dr["status"].ToString(), dr["newStdVal2"].ToString());
                        continue;
                    }

                    try
                    {
                        string[] temp = cg.ChangeRouting(material, plant, group, groupCtr, oprationNo, updateStdVal1, newStdVal1, updateStdVal2, newStdVal2);

                        if (temp[0].ToUpper()=="F")
                        {

                        }

                        //更新sap_standard_hour_uploadq表中的状态
                        Update_sap_standard_hour_uploadQ_StdHour(temp, dr["rowguid"].ToString(), dr["status"].ToString(), dr["newStdVal2"].ToString());

                        //废掉低P_Rev的记录
                        DisableLowerVersionRecord(dr["material"].ToString(), dr["rev"].ToString(), dr["fix_seq"].ToString(), dr["p_num"].ToString(), dr["p_rev"].ToString());
                    }
                    catch (Exception ex)
                    {
                        string currentProcess;
                        currentProcess = "程序SAPCaculate调用WebService更新SAP标准工时報錯，請檢查!";
                        SQLRelate.sendmail("Error with SAPCaculate", SQLRelate.GetstralertsErrorTO((SQLRelate.sqlconn(Form1.strRDCon)), SQLRelate.GetstrsiteID(Form1.site)), "", "", "<table bgcolor=white border=1 bordercolor=Gray bordercolordark=LemonChiffon><tr><td>" + currentProcess + "</td><td> " + ex.ToString() + "</td></tr></table>");
                    }

                    //Form1.strdatetime = DateTime.Now.ToString("d");

                }
            }
            else if (this._site == "H100")
            {
                SAPWeb_ATH._001SoapClient cg = new SAPWeb_ATH._001SoapClient();
                for (int i = 0; i < dt.Rows.Count; i++)
                {

                    DataRow dr = dt.Rows[i];
                    Delshow((i + 1) + "/" + dt.Rows.Count.ToString() + "正在更新" + this.WorkShop + "工件" + dr["material"] + "的SAP标准工时...");

                    string material = dr["material"].ToString();
                    string plant = dr["plant"].ToString().PadLeft(4);
                    string group = dr["group"].ToString().PadLeft(8);
                    string groupCtr = dr["groupCtr"].ToString().PadLeft(2, '0');
                    string oprationNo = dr["operationNo"].ToString().PadLeft(4, '0');
                    bool updateStdVal1 = false;  //目前暂时不更新stdval1，默认false

                    bool updateStdVal2;
                    if (dr["updateStdVal2"].ToString() == "F")
                        updateStdVal2 = false;
                    else
                        updateStdVal2 = true;

                    Single newStdVal1 = 0;  // 目前暂时默认newstdval1值为0，且不进行更新

                    decimal newStdVal2_temp = Math.Round(Convert.ToDecimal((dr["newStdVal2"].ToString())), 3);
                    Single newStdVal2 = Convert.ToSingle(newStdVal2_temp);

                    decimal oldStdVal2_temp = Math.Round(Convert.ToDecimal((dr["oldStdVal2"].ToString())), 3);
                    Single oldStdVal2 = Convert.ToSingle(oldStdVal2_temp);

                    if (newStdVal2 == 0)
                    {
                        //检测到UG 时间为0，就废掉此条记录
                        Update_sap_standard_hour_uploadQ_StdHour(new string[] { "WrongUGT" }, dr["rowguid"].ToString(), dr["status"].ToString(), dr["newStdVal2"].ToString());
                        continue;
                    }

                    try
                    {
                        string[] temp = cg.ChangeRouting(material, plant, group, groupCtr, oprationNo, updateStdVal1, newStdVal1, updateStdVal2, newStdVal2);

                        //更新sap_standard_hour_uploadq表中的状态
                        Update_sap_standard_hour_uploadQ_StdHour(temp, dr["rowguid"].ToString(), dr["status"].ToString(), dr["newStdVal2"].ToString());

                        //废掉低P_Rev的记录
                        DisableLowerVersionRecord(dr["material"].ToString(), dr["rev"].ToString(), dr["fix_seq"].ToString(), dr["p_num"].ToString(), dr["p_rev"].ToString());
                    }
                    catch (Exception ex)
                    {
                        string currentProcess;
                        currentProcess = "程序SAPCaculate调用WebService更新SAP标准工时報錯，請檢查!";
                        SQLRelate.sendmail("Error with SAPCaculate", SQLRelate.GetstralertsErrorTO((SQLRelate.sqlconn(Form1.strRDCon)), SQLRelate.GetstrsiteID(Form1.site)), "", "", "<table bgcolor=white border=1 bordercolor=Gray bordercolordark=LemonChiffon><tr><td>" + currentProcess + "</td><td> " + ex.ToString() + "</td></tr></table>");
                    }

                    //Form1.strdatetime = DateTime.Now.ToString("d");

                }

            }
            else 
            {
                SAPWeb._001SoapClient cg = new SAPWeb._001SoapClient();
                for (int i = 0; i < dt.Rows.Count; i++)
                {

                    DataRow dr = dt.Rows[i];
                    Delshow((i + 1) + "/" + dt.Rows.Count.ToString() + "正在更新" + this.WorkShop + "工件" + dr["material"] + "的SAP标准工时...");

                    string material = dr["material"].ToString();
                    string plant = dr["plant"].ToString().PadLeft(4);
                    string group = dr["group"].ToString().PadLeft(8);
                    string groupCtr = dr["groupCtr"].ToString().PadLeft(2, '0');
                    string oprationNo = dr["operationNo"].ToString().PadLeft(4, '0');
                    bool updateStdVal1 = false;  //目前暂时不更新stdval1，默认false

                    bool updateStdVal2;
                    if (dr["updateStdVal2"].ToString() == "F")
                        updateStdVal2 = false;
                    else
                        updateStdVal2 = true;

                    Single newStdVal1 = 0;  // 目前暂时默认newstdval1值为0，且不进行更新

                    decimal newStdVal2_temp = Math.Round(Convert.ToDecimal((dr["newStdVal2"].ToString())), 3);
                    Single newStdVal2 = Convert.ToSingle(newStdVal2_temp);

                    decimal oldStdVal2_temp = Math.Round(Convert.ToDecimal((dr["oldStdVal2"].ToString())), 3);
                    Single oldStdVal2 = Convert.ToSingle(oldStdVal2_temp);

                    if (newStdVal2 == 0)
                    {
                        //检测到UG 时间为0，就废掉此条记录
                        Update_sap_standard_hour_uploadQ_StdHour(new string[] { "WrongUGT" }, dr["rowguid"].ToString(), dr["status"].ToString(), dr["newStdVal2"].ToString());
                        continue;
                    }

                    try
                    {
                        string[] temp = cg.ChangeRouting(material, plant, group, groupCtr, oprationNo, updateStdVal1, newStdVal1, updateStdVal2, newStdVal2);

                        //更新sap_standard_hour_uploadq表中的状态
                        Update_sap_standard_hour_uploadQ_StdHour(temp, dr["rowguid"].ToString(), dr["status"].ToString(), dr["newStdVal2"].ToString());

                        //废掉低P_Rev的记录
                        DisableLowerVersionRecord(dr["material"].ToString(), dr["rev"].ToString(), dr["fix_seq"].ToString(), dr["p_num"].ToString(), dr["p_rev"].ToString());
                    }
                    catch (Exception ex)
                    {
                        string currentProcess;
                        currentProcess = "程序SAPCaculate调用WebService更新SAP标准工时報錯，請檢查!";
                        SQLRelate.sendmail("Error with SAPCaculate", SQLRelate.GetstralertsErrorTO((SQLRelate.sqlconn(Form1.strRDCon)), SQLRelate.GetstrsiteID(Form1.site)), "", "", "<table bgcolor=white border=1 bordercolor=Gray bordercolordark=LemonChiffon><tr><td>" + currentProcess + "</td><td> " + ex.ToString() + "</td></tr></table>");
                    }

                    //Form1.strdatetime = DateTime.Now.ToString("d");

                }
            }
            //SAPWeb._001SoapClient cg = new SAPWeb._001SoapClient();
            //sgWebServiceCaller.sapOperation changeRouting = new sgWebServiceCaller.sapOperation("");
            //
            //for (int i = 0; i < dt.Rows.Count; i++)
            //{

            //    DataRow dr = dt.Rows[i];
            //    Delshow((i + 1) + "/" + dt.Rows.Count.ToString() + "正在更新" + this.WorkShop + "工件" + dr["material"] + "的SAP标准工时...");

            //    string material = dr["material"].ToString();
            //    string plant = dr["plant"].ToString().PadLeft(4);
            //    string group = dr["group"].ToString().PadLeft(8);
            //    string groupCtr = dr["groupCtr"].ToString().PadLeft(2, '0');
            //    string oprationNo = dr["operationNo"].ToString().PadLeft(4, '0');
            //    bool updateStdVal1 = false;  //目前暂时不更新stdval1，默认false

            //    bool updateStdVal2;
            //    if (dr["updateStdVal2"].ToString() == "F")
            //        updateStdVal2 = false;
            //    else
            //        updateStdVal2 = true;

            //    Single newStdVal1 = 0;  // 目前暂时默认newstdval1值为0，且不进行更新

            //    decimal newStdVal2_temp = Math.Round(Convert.ToDecimal((dr["newStdVal2"].ToString())), 3);
            //    Single newStdVal2 = Convert.ToSingle(newStdVal2_temp);

            //    decimal oldStdVal2_temp = Math.Round(Convert.ToDecimal((dr["oldStdVal2"].ToString())), 3);
            //    Single oldStdVal2 = Convert.ToSingle(oldStdVal2_temp);

            //    if (newStdVal2 == 0)
            //    {
            //        //检测到UG 时间为0，就废掉此条记录
            //        Update_sap_standard_hour_uploadQ_StdHour(new string[] { "WrongUGT" }, dr["rowguid"].ToString(), dr["status"].ToString(), dr["newStdVal2"].ToString());
            //        continue;
            //    }

            //    try
            //    {
            //        string[] temp = cg.ChangeRouting(material, plant, group, groupCtr, oprationNo, updateStdVal1, newStdVal1, updateStdVal2, newStdVal2);

            //        //更新sap_standard_hour_uploadq表中的状态
            //        Update_sap_standard_hour_uploadQ_StdHour(temp, dr["rowguid"].ToString(), dr["status"].ToString(), dr["newStdVal2"].ToString());

            //        //废掉低P_Rev的记录
            //        DisableLowerVersionRecord(dr["material"].ToString(), dr["rev"].ToString(), dr["fix_seq"].ToString(), dr["p_num"].ToString(), dr["p_rev"].ToString());
            //    }
            //    catch (Exception ex)
            //    {
            //        string currentProcess;
            //        currentProcess = "程序SAPCaculate调用WebService更新SAP标准工时報錯，請檢查!";
            //        SQLRelate.sendmail("Error with SAPCaculate", SQLRelate.GetstralertsErrorTO((SQLRelate.sqlconn(Form1.strRDCon)), SQLRelate.GetstrsiteID(Form1.site)), "", "", "<table bgcolor=white border=1 bordercolor=Gray bordercolordark=LemonChiffon><tr><td>" + currentProcess + "</td><td> " + ex.ToString() + "</td></tr></table>");
            //    }

            //    //Form1.strdatetime = DateTime.Now.ToString("d");

            //}
        }
        public void UpdateSAPTime_On_Off_Load_Time(DataTable dt)
        {
            if (this._site == "8700")
            {
                SAPWeb_ALG._001SoapClient cg = new SAPWeb_ALG._001SoapClient();
                //sgWebServiceCaller.sapOperation changeRouting = new sgWebServiceCaller.sapOperation("");

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    //
                    DataRow dr = dt.Rows[i];
                    //
                    if (Convert.ToSingle(dr["on_off_load_time"].ToString()) > 0)
                    {

                        SAPWebforSetupTime_ALG.IprodUpdateClient cli = new SAPWebforSetupTime_ALG.IprodUpdateClient();
                        SAPWebforSetupTime_ALG.UpdateRoutingBOM bom = new SAPWebforSetupTime_ALG.UpdateRoutingBOM();
                        SAPWebforSetupTime_ALG.UpdateRoutingHeader header = new SAPWebforSetupTime_ALG.UpdateRoutingHeader();
                        SAPWebforSetupTime_ALG.UpdateRoutingItem items = new SAPWebforSetupTime_ALG.UpdateRoutingItem();
                        SAPWebforSetupTime_ALG.UpdateRoutingResult result = new SAPWebforSetupTime_ALG.UpdateRoutingResult();
                        List<SAPCaculate.SAPWebforSetupTime_ALG.UpdateRoutingResult> Result = new List<SAPWebforSetupTime_ALG.UpdateRoutingResult>();
                        List<SAPCaculate.SAPWebforSetupTime_ALG.UpdateRoutingBOM> Boms = new List<SAPWebforSetupTime_ALG.UpdateRoutingBOM>();
                        List<SAPCaculate.SAPWebforSetupTime_ALG.UpdateRoutingItem> Items = new List<SAPWebforSetupTime_ALG.UpdateRoutingItem>();

                        Delshow((i + 1) + "/" + dt.Rows.Count + " 正在更新" + this.WorkShop + "工件 " + dt.Rows[i]["material"].ToString().Trim() + "  on_off_load_time 信息...");
                        //List<SapTest.ServiceReference1.UpdateRoutingItem> routingitemslist = new List<UpdateRoutingItem>();
                        //header.CHANGE_NO = GetChangeNo("26-I68614V1").ToString();
                        header.CHANGE_NO = ""; //null;
                        //header.DEL_IND = null;                        //---不允许外部输入
                        //
                        //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                        header.GROUP_COUNTER = dr["groupCtr"].ToString();                                                                    //---不允许null,可以为""
                        header.TASK_LIST_GROUP = dr["group"].ToString();
                        System.DateTime currentTime = new System.DateTime();
                        currentTime = System.DateTime.Now;           //       取当前年月日时分秒
                        header.KEY_DATE = currentTime;
                        header.MATERIAL = dr["material"].ToString();                                                //--N90 ？
                        header.PLANT = dr["plant"].ToString();
                        items.ACTIVITY = dr["OperationNo"].ToString();
                        items.WORK_CNTR = dr["workCtr"].ToString();                                              //---工厂部门
                        items.PLANT = dr["plant"].ToString();
                        items.VGE03 = "H";
                        items.VGE04 = "H";

                        //
                        //header.GROUP_COUNTER = "07"; //dr["groupCtr"].ToString();                                                                    //---不允许null,可以为""
                        //header.TASK_LIST_GROUP = "52419852"; //dr["group"].ToString();
                        //System.DateTime currentTime = new System.DateTime();
                        //currentTime = System.DateTime.Now;           //       取当前年月日时分秒
                        //header.KEY_DATE = currentTime;
                        ////header.LOT_SIZE_FROM = null;
                        ////header.LOT_SIZE_TO = null;
                        //header.MATERIAL = "26K-E02026"; //dr["material"].ToString();                                                //--N90 ？
                        //header.PLANT = "8700"; //dr["plant"].ToString();
                        ////header.RESP_PLANNER_GROUP = null;
                        ////header.TASK_LIST_STATUS = null;
                        ////header.TASK_LIST_USAGE = null;
                        ////header.TASK_MEASURE_UNIT = null;
                        //items.ACTIVITY = "0040"; // dr["OperationNo"].ToString();
                        ////items.BASE_QUANTITY = null;
                        ////items.CONTROL_KEY = null;
                        ////items.DESCRIPTION = null;
                        ////items.STANDARD_TEXT_KEY = null;                                                   //--工序
                        ////items.UNIT_MEASURE = null;
                        //items.WORK_CNTR = "L03M5"; //dr["workCtr"].ToString();                                              //---工厂部门
                        //items.PLANT = "8700"; //dr["plant"].ToString();
                        ////items.LAR01 = null;
                        ////items.LAR02 = null;
                        ////items.LAR03 = null;
                        ////items.LAR04 = null;
                        ////items.LAR05 = null;
                        ////items.LAR06 = null;
                        ////items.VGE01 = "H";
                        ////items.VGE02 = "H";

                        //items.VGE03 = "H";
                        //items.VGE04 = "H";

                        ////items.VGE05 = "H";
                        ////items.VGE06 = "H";
                        ////items.VGW01 = null;  //set up time 
                        ////items.VGW02 = null;
                        //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

                        if (Convert.ToSingle(dr["On_Load_Time"].ToString()) > 0)
                        {
                            items.VGW03 = dr["On_Load_Time"].ToString();
                        }
                        else
                        {
                            items.VGW03 = (2 * (Convert.ToSingle(dr["on_off_load_time"].ToString())) / 3).ToString();
                        }

                        if (Convert.ToSingle(dr["Off_Load_Time"].ToString()) > 0)
                        {
                            items.VGW04 = dr["Off_Load_Time"].ToString();
                        }
                        else
                        {
                            items.VGW04 = (1 * (Convert.ToSingle(dr["on_off_load_time"].ToString())) / 3).ToString();
                        }
                        items.VGW03 = (Convert.ToSingle(items.VGW03) / 60).ToString("####0.###");
                        items.VGW04 = (Convert.ToSingle(items.VGW04) / 60).ToString("####0.###");

                        Items.Add(items);

                        try
                        {
                            //Result = cli.sap_update_routing(Boms, Items, header, 'M');
                            Result = cli.sap_update_routing("WEBBATCH", false, "M", header, Boms, Items);

                            string return_msg_OnOff_Load_Time = "";
                            string Status_OnOff_Load_Time = "";

                            result = Result[0];
                            return_msg_OnOff_Load_Time = result.MESSAGE.ToString();
                            Status_OnOff_Load_Time = result.FIELD.ToString();

                            //更新sap_standard_hour_uploadq表中的状态
                            Update_sap_standard_hour_uploadQ_on_off_load_time(dr["rowguid"].ToString(), Status_OnOff_Load_Time, return_msg_OnOff_Load_Time);
                        }
                        catch (Exception ex)
                        {
                            string currentProcess;
                            currentProcess = "程序SAPCaculate调用WebService更新 On_Off_Load_Time 報錯，請檢查!";
                            SQLRelate.sendmail("Error with SAPCaculate", SQLRelate.GetstralertsErrorTO((SQLRelate.sqlconn(Form1.strRDCon)), SQLRelate.GetstrsiteID(Form1.site)), "", "", "<table bgcolor=white border=1 bordercolor=Gray bordercolordark=LemonChiffon><tr><td>" + currentProcess + "</td><td> " + ex.ToString() + "</td></tr></table>");
                        }
                        //
                        cli.Close();

                    }
                }
            }
            else if (this._site == "A200")
            {
                SAPWeb_AMC._001SoapClient cg = new SAPWeb_AMC._001SoapClient();
                //sgWebServiceCaller.sapOperation changeRouting = new sgWebServiceCaller.sapOperation("");

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    DataRow dr = dt.Rows[i];
                    //
                    if (Convert.ToSingle(dr["on_off_load_time"].ToString()) > 0)
                    {
                        SAPWebforSetupTime_AMC.IprodUpdateClient cli = new SAPWebforSetupTime_AMC.IprodUpdateClient();
                        SAPWebforSetupTime_AMC.UpdateRoutingBOM bom = new SAPWebforSetupTime_AMC.UpdateRoutingBOM();
                        SAPWebforSetupTime_AMC.UpdateRoutingHeader header = new SAPWebforSetupTime_AMC.UpdateRoutingHeader();
                        SAPWebforSetupTime_AMC.UpdateRoutingItem items = new SAPWebforSetupTime_AMC.UpdateRoutingItem();
                        SAPWebforSetupTime_AMC.UpdateRoutingResult result = new SAPWebforSetupTime_AMC.UpdateRoutingResult();
                        List<SAPCaculate.SAPWebforSetupTime_AMC.UpdateRoutingResult> Result = new List<SAPWebforSetupTime_AMC.UpdateRoutingResult>();
                        List<SAPCaculate.SAPWebforSetupTime_AMC.UpdateRoutingBOM> Boms = new List<SAPWebforSetupTime_AMC.UpdateRoutingBOM>();
                        List<SAPCaculate.SAPWebforSetupTime_AMC.UpdateRoutingItem> Items = new List<SAPWebforSetupTime_AMC.UpdateRoutingItem>();

                        //List<SapTest.ServiceReference1.UpdateRoutingItem> routingitemslist = new List<UpdateRoutingItem>();
                        header.CHANGE_NO = GetChangeNo(dr["material"].ToString()).ToString();
                        //header.DEL_IND = null;                        //---不允许外部输入
                        //
                        //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                        header.GROUP_COUNTER = dr["groupCtr"].ToString();                                                                    //---不允许null,可以为""
                        header.TASK_LIST_GROUP = dr["group"].ToString();
                        System.DateTime currentTime = new System.DateTime();
                        currentTime = System.DateTime.Now;           //       取当前年月日时分秒
                        header.KEY_DATE = currentTime;
                        header.MATERIAL = dr["material"].ToString();                                                //--N90 ？
                        header.PLANT = dr["plant"].ToString();
                        items.ACTIVITY = dr["OperationNo"].ToString();
                        items.WORK_CNTR = dr["workCtr"].ToString();                                              //---工厂部门
                        items.PLANT = dr["plant"].ToString();
                        items.VGE03 = "H";
                        items.VGE04 = "H";

                        //
                        //header.GROUP_COUNTER = "07"; //dr["groupCtr"].ToString();                                                                    //---不允许null,可以为""
                        //header.TASK_LIST_GROUP = "52419852"; //dr["group"].ToString();
                        //System.DateTime currentTime = new System.DateTime();
                        //currentTime = System.DateTime.Now;           //       取当前年月日时分秒
                        //header.KEY_DATE = currentTime;
                        ////header.LOT_SIZE_FROM = null;
                        ////header.LOT_SIZE_TO = null;
                        //header.MATERIAL = "26K-E02026"; //dr["material"].ToString();                                                //--N90 ？
                        //header.PLANT = "8700"; //dr["plant"].ToString();
                        ////header.RESP_PLANNER_GROUP = null;
                        ////header.TASK_LIST_STATUS = null;
                        ////header.TASK_LIST_USAGE = null;
                        ////header.TASK_MEASURE_UNIT = null;
                        //items.ACTIVITY = "0040"; // dr["OperationNo"].ToString();
                        ////items.BASE_QUANTITY = null;
                        ////items.CONTROL_KEY = null;
                        ////items.DESCRIPTION = null;
                        ////items.STANDARD_TEXT_KEY = null;                                                   //--工序
                        ////items.UNIT_MEASURE = null;
                        //items.WORK_CNTR = "L03M5"; //dr["workCtr"].ToString();                                              //---工厂部门
                        //items.PLANT = "8700"; //dr["plant"].ToString();
                        ////items.LAR01 = null;
                        ////items.LAR02 = null;
                        ////items.LAR03 = null;
                        ////items.LAR04 = null;
                        ////items.LAR05 = null;
                        ////items.LAR06 = null;
                        ////items.VGE01 = "H";
                        ////items.VGE02 = "H";

                        //items.VGE03 = "H";
                        //items.VGE04 = "H";

                        ////items.VGE05 = "H";
                        ////items.VGE06 = "H";
                        ////items.VGW01 = null;  //set up time 
                        ////items.VGW02 = null;
                        //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

                        if (Convert.ToSingle(dr["On_Load_Time"].ToString()) > 0)
                        {
                            items.VGW03 = dr["On_Load_Time"].ToString();
                        }
                        else
                        {
                            items.VGW03 = (2 * (Convert.ToSingle(dr["on_off_load_time"].ToString())) / 3).ToString();
                        }

                        if (Convert.ToSingle(dr["Off_Load_Time"].ToString()) > 0)
                        {
                            items.VGW04 = dr["Off_Load_Time"].ToString();
                        }
                        else
                        {
                            items.VGW04 = (1 * (Convert.ToSingle(dr["on_off_load_time"].ToString())) / 3).ToString();
                        }
                        items.VGW03 = (Convert.ToSingle(items.VGW03) / 60).ToString("####0.###");
                        items.VGW04 = (Convert.ToSingle(items.VGW04) / 60).ToString("####0.###");

                        Items.Add(items);

                        try
                        {
                            //Result = cli.sap_update_routing(Boms, Items, header, 'M');
                            Result = cli.sap_update_routing("WEBBATCH", false, "M", header, Boms, Items);
                            //
                            string return_msg_OnOff_Load_Time = "";
                            string Status_OnOff_Load_Time = "";

                            result = Result[0];
                            return_msg_OnOff_Load_Time = result.MESSAGE.ToString();
                            Status_OnOff_Load_Time = result.FIELD.ToString();

                            //更新sap_standard_hour_uploadq表中的状态
                            Update_sap_standard_hour_uploadQ_on_off_load_time(dr["rowguid"].ToString(), Status_OnOff_Load_Time, return_msg_OnOff_Load_Time);
                        }
                        catch (Exception ex)
                        {
                            string currentProcess;
                            currentProcess = "程序SAPCaculate调用WebService更新 On_Off_Load_Time 報錯，請檢查!";
                            SQLRelate.sendmail("Error with SAPCaculate", SQLRelate.GetstralertsErrorTO((SQLRelate.sqlconn(Form1.strRDCon)), SQLRelate.GetstrsiteID(Form1.site)), "", "", "<table bgcolor=white border=1 bordercolor=Gray bordercolordark=LemonChiffon><tr><td>" + currentProcess + "</td><td> " + ex.ToString() + "</td></tr></table>");
                        }
                        //
                        cli.Close();
                    }

                }
            }
            else if (this._site == "H100")
            {
                SAPWeb_ATH._001SoapClient cg = new SAPWeb_ATH._001SoapClient();
                //sgWebServiceCaller.sapOperation changeRouting = new sgWebServiceCaller.sapOperation("");

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    DataRow dr = dt.Rows[i];
                    //
                    if (Convert.ToSingle(dr["on_off_load_time"].ToString()) > 0)
                    {
                        SAPWebforSetupTime_ATH.IprodUpdateClient cli = new SAPWebforSetupTime_ATH.IprodUpdateClient();
                        SAPWebforSetupTime_ATH.UpdateRoutingBOM bom = new SAPWebforSetupTime_ATH.UpdateRoutingBOM();
                        SAPWebforSetupTime_ATH.UpdateRoutingHeader header = new SAPWebforSetupTime_ATH.UpdateRoutingHeader();
                        SAPWebforSetupTime_ATH.UpdateRoutingItem items = new SAPWebforSetupTime_ATH.UpdateRoutingItem();
                        SAPWebforSetupTime_ATH.UpdateRoutingResult result = new SAPWebforSetupTime_ATH.UpdateRoutingResult();
                        List<SAPCaculate.SAPWebforSetupTime_ATH.UpdateRoutingResult> Result = new List<SAPWebforSetupTime_ATH.UpdateRoutingResult>();
                        List<SAPCaculate.SAPWebforSetupTime_ATH.UpdateRoutingBOM> Boms = new List<SAPWebforSetupTime_ATH.UpdateRoutingBOM>();
                        List<SAPCaculate.SAPWebforSetupTime_ATH.UpdateRoutingItem> Items = new List<SAPWebforSetupTime_ATH.UpdateRoutingItem>();

                        //List<SapTest.ServiceReference1.UpdateRoutingItem> routingitemslist = new List<UpdateRoutingItem>();
                        header.CHANGE_NO = GetChangeNo(dr["material"].ToString()).ToString();
                        //header.DEL_IND = null;                        //---不允许外部输入
                        //
                        //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                        header.GROUP_COUNTER = dr["groupCtr"].ToString();                                        //---不允许null,可以为""
                        header.TASK_LIST_GROUP = dr["group"].ToString();
                        System.DateTime currentTime = new System.DateTime();
                        currentTime = System.DateTime.Now;           //       取当前年月日时分秒
                        header.KEY_DATE = currentTime;
                        header.MATERIAL = dr["material"].ToString();                                             //--N90 ？
                        header.PLANT = dr["plant"].ToString();
                        items.ACTIVITY = dr["OperationNo"].ToString();
                        items.WORK_CNTR = dr["workCtr"].ToString();                                              //---工厂部门
                        items.PLANT = dr["plant"].ToString();
                        items.VGE03 = "H";
                        items.VGE04 = "H";

                        //
                        //header.GROUP_COUNTER = "07"; //dr["groupCtr"].ToString();                                                                    //---不允许null,可以为""
                        //header.TASK_LIST_GROUP = "52419852"; //dr["group"].ToString();
                        //System.DateTime currentTime = new System.DateTime();
                        //currentTime = System.DateTime.Now;           //       取当前年月日时分秒
                        //header.KEY_DATE = currentTime;
                        ////header.LOT_SIZE_FROM = null;
                        ////header.LOT_SIZE_TO = null;
                        //header.MATERIAL = "26K-E02026"; //dr["material"].ToString();                        //--N90 ？
                        //header.PLANT = "8700"; //dr["plant"].ToString();
                        ////header.RESP_PLANNER_GROUP = null;
                        ////header.TASK_LIST_STATUS = null;
                        ////header.TASK_LIST_USAGE = null;
                        ////header.TASK_MEASURE_UNIT = null;
                        //items.ACTIVITY = "0040"; // dr["OperationNo"].ToString();
                        ////items.BASE_QUANTITY = null;
                        ////items.CONTROL_KEY = null;
                        ////items.DESCRIPTION = null;
                        ////items.STANDARD_TEXT_KEY = null;                                                   //--工序
                        ////items.UNIT_MEASURE = null;
                        //items.WORK_CNTR = "L03M5"; //dr["workCtr"].ToString();                              //---工厂部门
                        //items.PLANT = "8700"; //dr["plant"].ToString();
                        ////items.LAR01 = null;
                        ////items.LAR02 = null;
                        ////items.LAR03 = null;
                        ////items.LAR04 = null;
                        ////items.LAR05 = null;
                        ////items.LAR06 = null;
                        ////items.VGE01 = "H";
                        ////items.VGE02 = "H";

                        //items.VGE03 = "H";
                        //items.VGE04 = "H";

                        ////items.VGE05 = "H";
                        ////items.VGE06 = "H";
                        ////items.VGW01 = null;  //set up time 
                        ////items.VGW02 = null;
                        //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

                        if (Convert.ToSingle(dr["On_Load_Time"].ToString()) > 0)
                        {
                            items.VGW03 = dr["On_Load_Time"].ToString();
                        }
                        else
                        {
                            items.VGW03 = (2 * (Convert.ToSingle(dr["on_off_load_time"].ToString())) / 3).ToString();
                        }

                        if (Convert.ToSingle(dr["Off_Load_Time"].ToString()) > 0)
                        {
                            items.VGW04 = dr["Off_Load_Time"].ToString();
                        }
                        else
                        {
                            items.VGW04 = (1 * (Convert.ToSingle(dr["on_off_load_time"].ToString())) / 3).ToString();
                        }
                        items.VGW03 = (Convert.ToSingle(items.VGW03) / 60).ToString("####0.###");
                        items.VGW04 = (Convert.ToSingle(items.VGW04) / 60).ToString("####0.###");

                        Items.Add(items);

                        try
                        {
                            //Result = cli.sap_update_routing(Boms, Items, header, 'M');
                            Result = cli.sap_update_routing("WEBBATCH", false, "M", header, Boms, Items);
                            //
                            string return_msg_OnOff_Load_Time = "";
                            string Status_OnOff_Load_Time = "";

                            result = Result[0];
                            return_msg_OnOff_Load_Time = result.MESSAGE.ToString();
                            Status_OnOff_Load_Time = result.FIELD.ToString();

                            //更新sap_standard_hour_uploadq表中的状态
                            Update_sap_standard_hour_uploadQ_on_off_load_time(dr["rowguid"].ToString(), Status_OnOff_Load_Time, return_msg_OnOff_Load_Time);
                        }
                        catch (Exception ex)
                        {
                            string currentProcess;
                            currentProcess = "程序SAPCaculate调用WebService更新 On_Off_Load_Time 報錯，請檢查!";
                            SQLRelate.sendmail("Error with SAPCaculate", SQLRelate.GetstralertsErrorTO((SQLRelate.sqlconn(Form1.strRDCon)), SQLRelate.GetstrsiteID(Form1.site)), "", "", "<table bgcolor=white border=1 bordercolor=Gray bordercolordark=LemonChiffon><tr><td>" + currentProcess + "</td><td> " + ex.ToString() + "</td></tr></table>");
                        }
                        //
                        cli.Close();
                    }
                }
            }
            else
            {
                SAPWeb._001SoapClient cg = new SAPWeb._001SoapClient();
                //sgWebServiceCaller.sapOperation changeRouting = new sgWebServiceCaller.sapOperation("");

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    DataRow dr = dt.Rows[i];
                    //
                    if (Convert.ToSingle(dr["on_off_load_time"].ToString()) > 0)
                    {
                        SAPWebforSetupTime_ALG.IprodUpdateClient cli = new SAPWebforSetupTime_ALG.IprodUpdateClient();
                        SAPWebforSetupTime_ALG.UpdateRoutingBOM bom = new SAPWebforSetupTime_ALG.UpdateRoutingBOM();
                        SAPWebforSetupTime_ALG.UpdateRoutingHeader header = new SAPWebforSetupTime_ALG.UpdateRoutingHeader();
                        SAPWebforSetupTime_ALG.UpdateRoutingItem items = new SAPWebforSetupTime_ALG.UpdateRoutingItem();
                        SAPWebforSetupTime_ALG.UpdateRoutingResult result = new SAPWebforSetupTime_ALG.UpdateRoutingResult();
                        List<SAPCaculate.SAPWebforSetupTime_ALG.UpdateRoutingResult> Result = new List<SAPWebforSetupTime_ALG.UpdateRoutingResult>();
                        List<SAPCaculate.SAPWebforSetupTime_ALG.UpdateRoutingBOM> Boms = new List<SAPWebforSetupTime_ALG.UpdateRoutingBOM>();
                        List<SAPCaculate.SAPWebforSetupTime_ALG.UpdateRoutingItem> Items = new List<SAPWebforSetupTime_ALG.UpdateRoutingItem>();

                        //List<SapTest.ServiceReference1.UpdateRoutingItem> routingitemslist = new List<UpdateRoutingItem>();
                        header.CHANGE_NO = dr[8].ToString();
                        header.DEL_IND = null;                        //---不允许外部输入
                        header.GROUP_COUNTER = dr[2].ToString();                                                                    //---不允许null,可以为""
                        header.TASK_LIST_GROUP = dr[1].ToString();
                        System.DateTime currentTime = new System.DateTime();
                        currentTime = System.DateTime.Now;           //       取当前年月日时分秒
                        header.KEY_DATE = currentTime;
                        header.LOT_SIZE_FROM = null;
                        header.LOT_SIZE_TO = null;
                        header.MATERIAL = dr[0].ToString();                                                //--N90 ？
                        header.PLANT = dr[4].ToString();
                        header.RESP_PLANNER_GROUP = null;
                        header.TASK_LIST_STATUS = null;
                        header.TASK_LIST_USAGE = null;
                        header.TASK_MEASURE_UNIT = null;
                        items.ACTIVITY = "00" + dr[3].ToString();
                        items.BASE_QUANTITY = null;
                        items.CONTROL_KEY = null;
                        items.DESCRIPTION = null;
                        items.STANDARD_TEXT_KEY = null;                                                   //--工序
                        items.UNIT_MEASURE = null;
                        items.WORK_CNTR = dr[5].ToString();                                              //---工厂部门
                        items.PLANT = dr[4].ToString();
                        items.LAR01 = null;
                        items.LAR02 = null;
                        items.LAR03 = null;
                        items.LAR04 = "";
                        items.LAR05 = null;
                        items.LAR06 = null;
                        items.VGE01 = "H";
                        items.VGE02 = "H";
                        items.VGE03 = "H";
                        items.VGE04 = "H";
                        items.VGE05 = "H";
                        items.VGE06 = "H";
                        items.VGW01 = dr[6].ToString();
                        items.VGW02 = null;
                        items.VGW03 = null;
                        items.VGW04 = null;

                        if (Convert.ToSingle(dr["On_Load_Time"].ToString()) > 0)
                        {
                            items.VGW03 = dr["On_Load_Time"].ToString();
                        }
                        else
                        {
                            items.VGW03 = (2 * (Convert.ToSingle(dr["on_off_load_time"].ToString())) / 3).ToString();
                        }

                        if (Convert.ToSingle(dr["Off_Load_Time"].ToString()) > 0)
                        {
                            items.VGW04 = dr["Off_Load_Time"].ToString();
                        }
                        else
                        {
                            items.VGW04 = (1 * (Convert.ToSingle(dr["on_off_load_time"].ToString())) / 3).ToString();
                        }
                        items.VGW03 = (Convert.ToSingle(items.VGW03) / 60).ToString();
                        items.VGW04 = (Convert.ToSingle(items.VGW04) / 60).ToString();

                        //items.VGW03 = "0.2"; //dr["On_Load_Time"].ToString();
                        //items.VGW04 = "0.1"; // dr["Off_Load_Time"].ToString();
                        //
                        items.VGW05 = null;
                        items.VGW06 = null;

                        try
                        {
                            //Result = cli.sap_update_routing(Boms, Items, header, 'M');
                            Result = cli.sap_update_routing("WEBBATCH", false, "M", header, Boms, Items);

                            string return_msg_OnOff_Load_Time = "";
                            string Status_OnOff_Load_Time = "";

                            result = Result[0];
                            return_msg_OnOff_Load_Time = result.MESSAGE.ToString();
                            Status_OnOff_Load_Time = result.FIELD.ToString();

                            //更新sap_standard_hour_uploadq表中的状态
                            Update_sap_standard_hour_uploadQ_on_off_load_time(dr["rowguid"].ToString(), Status_OnOff_Load_Time, return_msg_OnOff_Load_Time);
                        }
                        catch (Exception ex)
                        {
                            string currentProcess;
                            currentProcess = "程序SAPCaculate调用WebService更新SAP标准工时報錯，請檢查!";
                            SQLRelate.sendmail("Error with SAPCaculate", SQLRelate.GetstralertsErrorTO((SQLRelate.sqlconn(Form1.strRDCon)), SQLRelate.GetstrsiteID(Form1.site)), "", "", "<table bgcolor=white border=1 bordercolor=Gray bordercolordark=LemonChiffon><tr><td>" + currentProcess + "</td><td> " + ex.ToString() + "</td></tr></table>");
                        }
                        //
                        cli.Close();
                        cli.Close();
                    }

                }
            }

            //SAPWeb._001SoapClient cg = new SAPWeb._001SoapClient();
            ////sgWebServiceCaller.sapOperation changeRouting = new sgWebServiceCaller.sapOperation("");

            //for (int i = 0; i < dt.Rows.Count; i++)
            //{
            //    DataRow dr = dt.Rows[i];
            //    //
            //    SAPWebforSetupTime_ALG.IprodUpdateClient cli = new SAPWebforSetupTime_ALG.IprodUpdateClient();
            //    SAPWebforSetupTime_ALG.UpdateRoutingBOM bom = new SAPWebforSetupTime_ALG.UpdateRoutingBOM();
            //    SAPWebforSetupTime_ALG.UpdateRoutingHeader header = new SAPWebforSetupTime_ALG.UpdateRoutingHeader();
            //    SAPWebforSetupTime_ALG.UpdateRoutingItem items = new SAPWebforSetupTime_ALG.UpdateRoutingItem();
            //    SAPWebforSetupTime_ALG.UpdateRoutingResult result = new SAPWebforSetupTime_ALG.UpdateRoutingResult();
            //    List<SAPCaculate.SAPWebforSetupTime_ALG.UpdateRoutingResult> Result = new List<SAPWebforSetupTime_ALG.UpdateRoutingResult>();
            //    List<SAPCaculate.SAPWebforSetupTime_ALG.UpdateRoutingBOM> Boms = new List<SAPWebforSetupTime_ALG.UpdateRoutingBOM>();
            //    List<SAPCaculate.SAPWebforSetupTime_ALG.UpdateRoutingItem> Items = new List<SAPWebforSetupTime_ALG.UpdateRoutingItem>();

            //    //List<SapTest.ServiceReference1.UpdateRoutingItem> routingitemslist = new List<UpdateRoutingItem>();
            //    header.CHANGE_NO = dr[8].ToString();
            //    header.DEL_IND = null;                        //---不允许外部输入
            //    header.GROUP_COUNTER = dr[2].ToString();                                                                    //---不允许null,可以为""
            //    header.TASK_LIST_GROUP = dr[1].ToString();
            //    System.DateTime currentTime = new System.DateTime();
            //    currentTime = System.DateTime.Now;           //       取当前年月日时分秒
            //    header.KEY_DATE = currentTime;
            //    header.LOT_SIZE_FROM = null;
            //    header.LOT_SIZE_TO = null;
            //    header.MATERIAL = dr[0].ToString();                                                //--N90 ？
            //    header.PLANT = dr[4].ToString();
            //    header.RESP_PLANNER_GROUP = null;
            //    header.TASK_LIST_STATUS = null;
            //    header.TASK_LIST_USAGE = null;
            //    header.TASK_MEASURE_UNIT = null;
            //    items.ACTIVITY = "00" + dr[3].ToString();
            //    items.BASE_QUANTITY = null;
            //    items.CONTROL_KEY = null;
            //    items.DESCRIPTION = null;
            //    items.STANDARD_TEXT_KEY = null;                                                   //--工序
            //    items.UNIT_MEASURE = null;
            //    items.WORK_CNTR = dr[5].ToString();                                              //---工厂部门
            //    items.PLANT = dr[4].ToString();
            //    items.LAR01 = null;
            //    items.LAR02 = null;
            //    items.LAR03 = null;
            //    items.LAR04 = "";
            //    items.LAR05 = null;
            //    items.LAR06 = null;
            //    items.VGE01 = "H";
            //    items.VGE02 = "H";
            //    items.VGE03 = "H";
            //    items.VGE04 = "H";
            //    items.VGE05 = "H";
            //    items.VGE06 = "H";
            //    items.VGW01 = dr[6].ToString();
            //    items.VGW02 = null;
            //    items.VGW03 = null;
            //    items.VGW04 = null;
            //    items.VGW05 = null;
            //    items.VGW06 = null;
            //    Result = cli.sap_update_routing(Boms, Items, header, 'M');

            //    int sus = 0;
            //    int fail = 0;
            //    result = Result[0];
            //    if (result.MESSAGE.ToString() == "Routing updated successfully.")   //Routing updated successfully.
            //    {
            //        sus += 1;
            //        //susList.Add(header.MATERIAL.ToString());
            //        //sbSus.Append(header.MATERIAL.ToString());
            //        //sbSus.Append("\r\n");
            //    }
            //    else
            //    {
            //        fail += 1;
            //        //failList.Add(header.MATERIAL.ToString());
            //        //susList.Add(header.MATERIAL.ToString());
            //        //sbFail.Append(header.MATERIAL.ToString());
            //        //sbFail.Append("\r\n");
            //    }
            //    cli.Close();
            //}
        }
        /// <summary>
        /// 逐行更新sap工卡工时
        /// </summary>
        /// <param name="dt">要更新的数据记录</param>
        /// <param name="lbStatus">Form1状态控件</param>
        public void UpdateSAPTime_JobCard(DataTable dt)
        {
            //SAPWebALG._001SoapClient cg = new SAPWebALG._001SoapClient();

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                DataRow dr = dt.Rows[i];
                string JobCard_temp = dr["JobCard"].ToString();

                if (JobCard_temp != "")
                {
                    Delshow((i + 1) + "/" + dt.Rows.Count.ToString() + "正在更新" + this.WorkShop + "工件" + dr["material"] + "的SAP JobCard 工时...");
                    //
                    string ProOrderNum = dr["JobCard"].ToString().PadLeft(12, '0');
                    string Operation = dr["operationNo"].ToString().PadLeft(4, '0');
                    string LaborHour = dr["UG_Time"].ToString().PadLeft(8);
                    //
                    string Partno = dr["material"].ToString().Trim();
                    string Rev = dr["rev"].ToString().Trim();
                    string Plant = dr["Plant"].ToString().Trim();
                    //string SAPGroupPre = dr["group"].ToString().Trim();
                    //string SAPGroupSuf = dr["groupctr"].ToString().Trim(); ;
                    string OperationNo = dr["OperationNo"].ToString().Trim();
                    string SetupHour = GetSAPSetupTime(Plant, Partno, Rev, Operation);           // string SetupHour = "0.3";
                    string rowguid = dr["rowguid"].ToString().Trim();
                    //
                    try
                    {
                        float LaborHour_UG = float.Parse(LaborHour) / 60;  //将分钟转换为小时  <-- PCZhou 2018-11-06
                        //
                         if (this._site == "A200")
                        {
                            //目前需要将UG模拟时间增加10%才能更新为SAP时间 -------------------
                            double LaborHour_UG_temp = Convert.ToDouble(LaborHour_UG) ;
                            LaborHour_UG_temp = 1.1 * LaborHour_UG_temp;
                            LaborHour_UG = float.Parse(Convert.ToString(LaborHour_UG_temp));
                            // -------------------------------------------------------------
                            List<SAPWeb_AMC.ChangeOrderHourModel> inputModeltemp = new List<SAPWeb_AMC.ChangeOrderHourModel>();
                            SAPWeb_AMC._001SoapClient SAPInfo = new SAPWeb_AMC._001SoapClient();
                            SAPWeb_AMC.ChangeOrderHourModel inputTemp = new SAPWeb_AMC.ChangeOrderHourModel();
                            inputTemp.ProOrderNum = ProOrderNum;
                            inputTemp.Operation = Operation;
                            inputTemp.LaborHour = float.Parse(Math.Round(LaborHour_UG, 3).ToString());   //inputTemp.LaborHour = float.Parse(LaborHour) / 60;
                            inputTemp.SetupHour = float.Parse(SetupHour);
                            inputModeltemp.Add(inputTemp);
                            SAPWeb_AMC.ChangeOrderHourModel[] inputModel = inputModeltemp.ToArray();
                            SAPWeb_AMC.ChangeOrderHourModel[] temp = SAPInfo.ChangeOrderHour(inputModel); //add by pczhou 2018-11-06: 调用sapweb更新工卡工时
                            //
                            string temp_status = "E";
                            string temp_message = "";
                            temp_status = temp[0].Status.ToString();
                            temp_message = temp[0].Message.ToString();

                            //更新sap_standard_hour_uploadq表中的状态  <-- add by pczhou 2018-11-06
                            UpdateSAP_Standard_Upload_HourQ_forJobCard(ProOrderNum, temp_status, temp_message, rowguid);

                            //废掉低P_Rev的记录
                            DisableLowerVersionRecord(dr["material"].ToString(), dr["rev"].ToString(), dr["fix_seq"].ToString(), dr["p_num"].ToString(), dr["p_rev"].ToString());
                        }
                        else if (this._site == "8700")
                        {
                            //目前需要将UG模拟时间增加10%才能更新为SAP时间 -------------------
                            double LaborHour_UG_temp = Convert.ToDouble(LaborHour_UG);
                            LaborHour_UG_temp = 1.1 * LaborHour_UG_temp;
                            LaborHour_UG = float.Parse(Convert.ToString(LaborHour_UG_temp));
                            // -------------------------------------------------------------
                            List<SAPWeb_ALG.ChangeOrderHourModel> inputModeltemp = new List<SAPWeb_ALG.ChangeOrderHourModel>();
                            SAPWeb_ALG._001SoapClient SAPInfo = new SAPWeb_ALG._001SoapClient();
                            SAPWeb_ALG.ChangeOrderHourModel inputTemp = new SAPWeb_ALG.ChangeOrderHourModel();
                            inputTemp.ProOrderNum = ProOrderNum;
                            inputTemp.Operation = Operation;
                            inputTemp.LaborHour = float.Parse(Math.Round(LaborHour_UG, 3).ToString());   //inputTemp.LaborHour = float.Parse(LaborHour) / 60;
                            inputTemp.SetupHour = float.Parse(SetupHour);
                            inputModeltemp.Add(inputTemp);
                            SAPWeb_ALG.ChangeOrderHourModel[] inputModel = inputModeltemp.ToArray();
                            SAPWeb_ALG.ChangeOrderHourModel[] temp = SAPInfo.ChangeOrderHour(inputModel); //add by pczhou 2018-11-06: 调用sapweb更新工卡工时
                            //
                            string temp_status = "E";
                            string temp_message = "";
                            temp_status = temp[0].Status.ToString();
                            temp_message = temp[0].Message.ToString();

                            //更新sap_standard_hour_uploadq表中的状态  <-- add by pczhou 2018-11-06
                            UpdateSAP_Standard_Upload_HourQ_forJobCard(ProOrderNum, temp_status, temp_message, rowguid);

                            //废掉低P_Rev的记录
                            DisableLowerVersionRecord(dr["material"].ToString(), dr["rev"].ToString(), dr["fix_seq"].ToString(), dr["p_num"].ToString(), dr["p_rev"].ToString());
                        }
                        else if (this._site == "H100")
                        {
                            //ATH采用on_off_load_time模式，ug时间不用乘以1.1
                            // -------------------------------------------
                            //
                            List<SAPWeb_ATH.ChangeOrderHourModel> inputModeltemp = new List<SAPWeb_ATH.ChangeOrderHourModel>();
                            SAPWeb_ATH._001SoapClient SAPInfo = new SAPWeb_ATH._001SoapClient();
                            SAPWeb_ATH.ChangeOrderHourModel inputTemp = new SAPWeb_ATH.ChangeOrderHourModel();
                            inputTemp.ProOrderNum = ProOrderNum;
                            inputTemp.Operation = Operation;
                            inputTemp.LaborHour = float.Parse(Math.Round(LaborHour_UG, 3).ToString());   //inputTemp.LaborHour = float.Parse(LaborHour) / 60;
                            inputTemp.SetupHour = float.Parse(SetupHour);
                            inputModeltemp.Add(inputTemp);
                            SAPWeb_ATH.ChangeOrderHourModel[] inputModel = inputModeltemp.ToArray();
                            SAPWeb_ATH.ChangeOrderHourModel[] temp = SAPInfo.ChangeOrderHour(inputModel); //add by pczhou 2018-11-06: 调用sapweb更新工卡工时
                            //
                            string temp_status = "E";
                            string temp_message = "";
                            temp_status = temp[0].Status.ToString();
                            temp_message = temp[0].Message.ToString();

                            //更新sap_standard_hour_uploadq表中的状态  <-- add by pczhou 2018-11-06
                            UpdateSAP_Standard_Upload_HourQ_forJobCard(ProOrderNum, temp_status, temp_message, rowguid);

                            //废掉低P_Rev的记录
                            DisableLowerVersionRecord(dr["material"].ToString(), dr["rev"].ToString(), dr["fix_seq"].ToString(), dr["p_num"].ToString(), dr["p_rev"].ToString());
                        }
                        //
                        //List<SAPWeb.ChangeOrderHourModel> inputModeltemp = new List<SAPWeb.ChangeOrderHourModel>();
                        //SAPWeb._001SoapClient SAPInfo = new SAPWeb._001SoapClient();
                        //SAPWeb.ChangeOrderHourModel inputTemp = new SAPWeb.ChangeOrderHourModel();
                        //inputTemp.ProOrderNum = ProOrderNum;    
                        //inputTemp.Operation = Operation;
                        //inputTemp.LaborHour = float.Parse(Math.Round(LaborHour_UG,3).ToString());   //inputTemp.LaborHour = float.Parse(LaborHour) / 60;
                        //inputTemp.SetupHour = float.Parse(SetupHour);
                        //inputModeltemp.Add(inputTemp);
                        //SAPWeb.ChangeOrderHourModel[] inputModel = inputModeltemp.ToArray();
                        //SAPWeb.ChangeOrderHourModel[] temp = SAPInfo.ChangeOrderHour(inputModel); //add by pczhou 2018-11-06: 调用sapweb更新工卡工时
                        //
                        //string temp_status = "E";
                        //string temp_message = "";
                        //temp_status=temp[0].Status.ToString();
                        //temp_message = temp[0].Message.ToString();

                        ////更新sap_standard_hour_uploadq表中的状态  <-- add by pczhou 2018-11-06
                        //UpdateSAP_Standard_Upload_HourQ_forJobCard(ProOrderNum, temp_status, temp_message, rowguid);

                        ////废掉低P_Rev的记录
                        //DisableLowerVersionRecord(dr["material"].ToString(), dr["rev"].ToString(), dr["fix_seq"].ToString(), dr["p_num"].ToString(), dr["p_rev"].ToString());
                        //

                    }
                    catch (Exception ex)
                    {
                        string currentProcess;
                        currentProcess = "程序SAPCaculate调用WebService更新SAP标准工时報錯，請檢查!";
                        SQLRelate.sendmail("Error with SAPCaculate", SQLRelate.GetstralertsErrorTO((SQLRelate.sqlconn(Form1.strRDCon)), SQLRelate.GetstrsiteID(Form1.site)), "", "", "<table bgcolor=white border=1 bordercolor=Gray bordercolordark=LemonChiffon><tr><td>" + currentProcess + "</td><td> " + ex.ToString() + "</td></tr></table>");
                    }


                }

            }
        }

        /// <summary>
        /// 更新sap_standard_hour_uploadQ表中的状态（记录WebService的更新结果）
        /// </summary>
        /// <param name="s"></param>
        /// <param name="key"></param>
        /// <param name="status"></param>
        /// <param name="cfm_newStdVal2"></param>
        private void Update_sap_standard_hour_uploadQ_StdHour(string[] s, string key, string status, string cfm_newStdVal2)
        {
            string sql = "";
            string return_msg = "";
            if (s.Length >= 2)
            {
                return_msg = s[1].Length > 100 ? s[1].Substring(0, 95) : s[1];
            }

            if (s[0].ToUpper() == "E")
            {
                if (status.ToUpper() == "E")
                {
                    sql = "UPDATE sap_standard_hour_uploadQ SET status='F',return_msg='" + return_msg + "' WHERE rowguid='" + key + "'";
                }
                else
                {
                    sql = "UPDATE sap_standard_hour_uploadQ SET status='" + s[0] + "',return_msg='" + return_msg + "' WHERE rowguid='" + key + "'";
                }
            }
            else if (s[0].ToUpper() == "WRONGUGT")
            {
                sql = "UPDATE sap_standard_hour_uploadQ SET status='F',return_msg='UGTime is zero' WHERE rowguid='" + key + "'";
            }
            else
            {

                //------此处更新: PCZHOU 2018-06-04 : 不需要条件this._site != "H100"-------------------------------
                sql = "UPDATE sap_standard_hour_uploadQ SET status='" + s[0] + "',return_msg='" + return_msg + "',sap_upload_time=getdate(),newstdval2='" + cfm_newStdVal2 + "' WHERE rowguid='" + key + "'";
                //------------------------------- ----------------------------------------------------------------
            }


            string currentProcess;
            currentProcess = "程序SAPCaculate更新sap_standard_uplaod_hourq表时報錯，請檢查!";
            SQLRelate.InsertUpdate(SQLRelate.sqlconn(Form1.strCON), sql, currentProcess);
        }

        private void Update_sap_standard_hour_uploadQ_on_off_load_time(string key, string status, string return_msg)
        {
            string sql = "";
            sql = "UPDATE sap_standard_hour_uploadQ SET Status_OnOff_Load_Time='" + status + "' ,return_msg_OnOff_Load_Time='" + return_msg + "' WHERE rowguid='" + key + "'";

            string currentProcess;
            currentProcess = "程序SAPCaculate更新sap_standard_uplaod_hourq表时報錯，請檢查!";
            SQLRelate.InsertUpdate(SQLRelate.sqlconn(Form1.strCON), sql, currentProcess);

        }
        /// <summary>
        /// 更新sap_standard_hour_uploadQ表中的状态: 更新工卡工时的记录
        /// </summary>
        /// <param name="s"></param>
        /// <param name="key"></param>
        /// <param name="status"></param>
        /// <param name="cfm_newStdVal2"></param>
        private void UpdateSAP_Standard_Upload_HourQ_forJobCard(string JobCard, string status, string return_msg ,string key) // add by PCZhou 2018-11-06
        {
            string sql = "";

            if (status == "S")
            {
                status = "O";  //更新工卡工时成功的记录
            }
            else if (status == "E")
            {
                status = "J";  //更新工卡工时不成功的记录
            }
            else
            {
                status = "k";   // 更新工卡工时不成功的记录
            }
            //
            sql = "UPDATE sap_standard_hour_uploadQ SET status='" + status + "' ,return_msg='" + return_msg + "' WHERE rowguid='" + key + "'";
            string currentProcess;
            currentProcess = "程序SAPCaculate更新sap_standard_uplaod_hourq表时報錯，請檢查!";
            SQLRelate.InsertUpdate(SQLRelate.sqlconn(Form1.strCON), sql, currentProcess);
        }


        /// <summary>
        /// 更新某条记录成功后，将与此记录同工件，版本，夹次，程式号并且P_Rev低于本条记录的数据废掉
        /// </summary>
        private void DisableLowerVersionRecord(string material, string rev, string fix_seq, string p_num, string p_rev)
        {
            StringBuilder sb = new StringBuilder();
            //检查有无低P_Rev的记录存在
            sb.Append("if exists(select * from sap_standard_hour_uploadQ ");
            sb.Append(" where material ='" + material + "' and rev='" + rev + "' and fix_seq='" + fix_seq + "'");
            sb.Append(" and p_num='" + p_num + "' and cast(p_rev as int) <'" + p_rev + "') \n\r");
            //废掉低P_Rev记录，部门不用再确认低P_Rev记录的UG模拟时间
            sb.Append(" update sap_standard_hour_uploadQ set status='N',return_msg='Higher Version Std Hour Has Been Updated' ");
            sb.Append(" where material ='" + material + "' and rev='" + rev + "' and fix_seq='" + fix_seq + "'");
            sb.Append(" and p_num='" + p_num + "' and cast(p_rev as int) <'" + p_rev + "'");
            //------------------------------------------------------------------------------------------------------------
            string currentProcess;
            currentProcess = "程序SAPCaculate废除低P_rev记录时报错，请检查！";
            SQLRelate.InsertUpdate(SQLRelate.sqlconn(Form1.strCON), sb.ToString(), currentProcess);
        }

        /// <summary>
        /// 比较Group等并且获取sap标准工时,主体逻辑来自Huang Xiang Qi的SAPGroup工具
        /// </summary>
        /// <param name="DTsapstandardhourInfor">从sap_standard_hour_uploadQ表中获取的数据</param>
        /// 
        private void ComParerSAPandUpdate(DataTable DTsapstandardhourInfor)
        {

            Int16 i = 0;
            Int16 j = 0;
            Int16 k = 0;
            //
            //DTsapstandardhourInfor.Columns.Add("STD_Group", typeof(string));
            //DTsapstandardhourInfor.Columns.Add("STD_GrpCounter", typeof(string));
            //
            try
            {
                string[][] Routing;
                string[][] StrRouting;
                if (DTsapstandardhourInfor.Rows.Count != 0)
                {
                    for (i = 0; i <= DTsapstandardhourInfor.Rows.Count - 1; i++)
                    {
                        Delshow((i + 1) + "/" + DTsapstandardhourInfor.Rows.Count + " 正在比对" + this.WorkShop + "工件 " + DTsapstandardhourInfor.Rows[i]["material"].ToString().Trim() + "信息...");
                        string Partno = DTsapstandardhourInfor.Rows[i]["material"].ToString().Trim();
                        string Rev = DTsapstandardhourInfor.Rows[i]["rev"].ToString().Trim();
                        string Plant = DTsapstandardhourInfor.Rows[i]["Plant"].ToString().Trim();
                        string SAPGroupPre = DTsapstandardhourInfor.Rows[i]["group"].ToString().Trim();
                        string SAPGroupSuf = DTsapstandardhourInfor.Rows[i]["groupctr"].ToString().Trim(); ;
                        string OperationNo = DTsapstandardhourInfor.Rows[i]["OperationNo"].ToString().Trim();
                        string WorkCtr = DTsapstandardhourInfor.Rows[i]["WorkCtr"].ToString().Trim();
                        string rowguid = DTsapstandardhourInfor.Rows[i]["rowguid"].ToString().Trim();
                        string UgTime = DTsapstandardhourInfor.Rows[i]["newStdVal2"].ToString().Trim();
                        string OldStdValue1 = "";
                        string OldStdValue2 = "";
                        string ReturnReason = "";
                        bool BoolReturnReason = false;
                        string Status = "";

                        if (this._site == "8700")
                        {
                            SAPWeb_ALG._001SoapClient SAPWebs = new SAPWeb_ALG._001SoapClient();
                            //从webservice获取sap相关信息
                            Routing = SAPWebs.GetRoutingList(Partno, Plant, Rev);
                            if (Routing.Length == 0 || Routing[0][0].ToString().ToUpper().IndexOf("EXCEPTION") > -1)
                            {
                                //数据找不到 状态更新为F
                                Status = "F";
                                ReturnReason = Routing[0][0].ToString();
                                //防止返回值过长，插入数据库时出错
                                if (ReturnReason.Length > 100)
                                {
                                    ReturnReason = ReturnReason.Substring(0, 95);
                                }
                                UpdateRecord(rowguid, ReturnReason, Status);
                            }
                            else
                            {
                                for (j = 0; j <= Routing.Length - 1; j++)
                                {
                                    //筛选出返回信息非“Exception: Revision”以及非SAPGroup信息的数据（如WebService自身报错返回的信息等），不作处理，等待下次运行再次处理
                                    if (Regex.IsMatch(Routing[j][0].ToString(), @"^\d+$"))
                                    {
                                        if (SAPGroupPre + "0" + SAPGroupSuf == Routing[j][0].ToString() + Routing[j][1].ToString() || SAPGroupPre + SAPGroupSuf == Routing[j][0].ToString() + Routing[j][1].ToString())//匹配SAPGroup和Groupno
                                        {
                                            StrRouting = SAPWebs.GetRouting(Partno, Plant, SAPGroupPre, SAPGroupSuf);
                                            //StrRouting = SAPWebs.getRouting(Partno, Plant, SAPGroupPre, SAPGroupSuf);
                                            for (k = 0; k <= StrRouting.Length - 1; k++)
                                            {
                                                //匹配workcenter和OperationNo: PCZhou 重新写配对逻辑 2018-06-08
                                                if (OperationNo == StrRouting[k][0])//匹配OperationNo
                                                {
                                                    string[] S = SAPWebs.GetWorkCenterDetails(StrRouting[k][1]);
                                                    if (WorkCtr == S[0])//匹配workcenter
                                                    {
                                                        Status = "";
                                                        ReturnReason = "";
                                                        OldStdValue1 = StrRouting[k][4];
                                                        OldStdValue2 = StrRouting[k][5];
                                                        UpdateRecord(rowguid, ReturnReason, UgTime, OldStdValue1, OldStdValue2, Status);
                                                        BoolReturnReason = false;
                                                        break;
                                                    }
                                                }

                                                else
                                                {
                                                    BoolReturnReason = true;
                                                }
                                            }
                                            if (BoolReturnReason == true)//
                                            {
                                                ReturnReason = "WorkCenter or OperationNo is not matched";
                                                Status = "F";
                                                UpdateRecord(rowguid, ReturnReason, Status);
                                            }
                                            break;

                                        }
                                        else
                                        {
                                            ReturnReason = "SAP Group is not matched";
                                            Status = "F";
                                            //UpdateRecord(rowguid, ReturnReason, Status);
                                            if (j >= Routing.Length - 1)
                                            {
                                                UpdateRecord(rowguid, ReturnReason, Status);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        else if (this._site == "A200")
                        {
                            SAPWeb_AMC._001SoapClient SAPWebs = new SAPWeb_AMC._001SoapClient();
                            //从webservice获取sap相关信息
                            Routing = SAPWebs.GetRoutingList(Partno, Plant, Rev);
                            if (Routing.Length == 0 || Routing[0][0].ToString().ToUpper().IndexOf("EXCEPTION") > -1)
                            {
                                //数据找不到 状态更新为F
                                Status = "F";
                                ReturnReason = Routing[0][0].ToString();
                                //防止返回值过长，插入数据库时出错
                                if (ReturnReason.Length > 100)
                                {
                                    ReturnReason = ReturnReason.Substring(0, 95);
                                }
                                UpdateRecord(rowguid, ReturnReason, Status);
                            }
                            else
                            {
                                for (j = 0; j <= Routing.Length - 1; j++)
                                {
                                    //筛选出返回信息非“Exception: Revision”以及非SAPGroup信息的数据（如WebService自身报错返回的信息等），不作处理，等待下次运行再次处理
                                    if (Regex.IsMatch(Routing[j][0].ToString(), @"^\d+$"))
                                    {
                                        if (SAPGroupPre + "0" + SAPGroupSuf == Routing[j][0].ToString() + Routing[j][1].ToString() || SAPGroupPre + SAPGroupSuf == Routing[j][0].ToString() + Routing[j][1].ToString())//匹配SAPGroup和Groupno
                                        {
                                            StrRouting = SAPWebs.GetRouting(Partno, Plant, SAPGroupPre, SAPGroupSuf);
                                            //StrRouting = SAPWebs.getRouting(Partno, Plant, SAPGroupPre, SAPGroupSuf);
                                            for (k = 0; k <= StrRouting.Length - 1; k++)
                                            {
                                                //匹配workcenter和OperationNo: PCZhou 重新写配对逻辑 2018-06-08
                                                if (OperationNo == StrRouting[k][0])//匹配OperationNo
                                                {
                                                    string[] S = SAPWebs.GetWorkCenterDetails(StrRouting[k][1]);
                                                    if (WorkCtr == S[0])//匹配workcenter
                                                    {
                                                        Status = "";
                                                        ReturnReason = "";
                                                        OldStdValue1 = StrRouting[k][4];
                                                        OldStdValue2 = StrRouting[k][5];
                                                        UpdateRecord(rowguid, ReturnReason, UgTime, OldStdValue1, OldStdValue2, Status);
                                                        BoolReturnReason = false;
                                                        break;
                                                    }
                                                }

                                                else
                                                {
                                                    BoolReturnReason = true;
                                                }
                                            }
                                            if (BoolReturnReason == true)//
                                            {
                                                ReturnReason = "WorkCenter or OperationNo is not matched";
                                                Status = "F";
                                                UpdateRecord(rowguid, ReturnReason, Status);
                                            }
                                            break;

                                        }
                                        else
                                        {
                                            ReturnReason = "SAP Group is not matched";
                                            Status = "F";
                                            //UpdateRecord(rowguid, ReturnReason, Status);
                                            if (j >= Routing.Length - 1)
                                            {
                                                UpdateRecord(rowguid, ReturnReason, Status);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        else if (this._site == "H100")
                        {
                            SAPWeb_ATH._001SoapClient SAPWebs = new SAPWeb_ATH._001SoapClient();
                            //从webservice获取sap相关信息
                            Routing = SAPWebs.GetRoutingList(Partno, Plant, Rev);
                            if (Routing.Length == 0 || Routing[0][0].ToString().ToUpper().IndexOf("EXCEPTION") > -1)
                            {
                                //数据找不到 状态更新为F
                                Status = "F";
                                ReturnReason = Routing[0][0].ToString();
                                //防止返回值过长，插入数据库时出错
                                if (ReturnReason.Length > 100)
                                {
                                    ReturnReason = ReturnReason.Substring(0, 95);
                                }
                                UpdateRecord(rowguid, ReturnReason, Status);
                            }
                            else
                            {
                                for (j = 0; j <= Routing.Length - 1; j++)
                                {
                                    //筛选出返回信息非“Exception: Revision”以及非SAPGroup信息的数据（如WebService自身报错返回的信息等），不作处理，等待下次运行再次处理
                                    if (Regex.IsMatch(Routing[j][0].ToString(), @"^\d+$"))
                                    {
                                        if (SAPGroupPre + "0" + SAPGroupSuf == Routing[j][0].ToString() + Routing[j][1].ToString() || SAPGroupPre + SAPGroupSuf == Routing[j][0].ToString() + Routing[j][1].ToString())//匹配SAPGroup和Groupno
                                        {
                                            StrRouting = SAPWebs.GetRouting(Partno, Plant, SAPGroupPre, SAPGroupSuf);
                                            //StrRouting = SAPWebs.getRouting(Partno, Plant, SAPGroupPre, SAPGroupSuf);
                                            for (k = 0; k <= StrRouting.Length - 1; k++)
                                            {
                                                //匹配workcenter和OperationNo: PCZhou 重新写配对逻辑 2018-06-08
                                                if (OperationNo == StrRouting[k][0])//匹配OperationNo
                                                {
                                                    string[] S = SAPWebs.GetWorkCenterDetails(StrRouting[k][1]);
                                                    if (WorkCtr == S[0])//匹配workcenter
                                                    {
                                                        Status = "";
                                                        ReturnReason = "";
                                                        OldStdValue1 = StrRouting[k][4];
                                                        OldStdValue2 = StrRouting[k][5];
                                                        UpdateRecord(rowguid, ReturnReason, UgTime, OldStdValue1, OldStdValue2, Status);
                                                        BoolReturnReason = false;
                                                        break;
                                                    }
                                                }

                                                else
                                                {
                                                    BoolReturnReason = true;
                                                }
                                            }
                                            if (BoolReturnReason == true)//
                                            {
                                                ReturnReason = "WorkCenter or OperationNo is not matched";
                                                Status = "F";
                                                UpdateRecord(rowguid, ReturnReason, Status);
                                            }
                                            break;

                                        }
                                        else
                                        {
                                            ReturnReason = "SAP Group is not matched";
                                            Status = "F";
                                            //UpdateRecord(rowguid, ReturnReason, Status);
                                            if (j >= Routing.Length - 1)
                                            {
                                                UpdateRecord(rowguid, ReturnReason, Status);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        else
                        {
                            SAPWeb._001SoapClient SAPWebs = new SAPWeb._001SoapClient();
                            //从webservice获取sap相关信息
                            Routing = SAPWebs.GetRoutingList(Partno, Plant, Rev);
                            if (Routing.Length == 0 || Routing[0][0].ToString().ToUpper().IndexOf("EXCEPTION") > -1)
                            {
                                //数据找不到 状态更新为F
                                Status = "F";
                                ReturnReason = Routing[0][0].ToString();
                                //防止返回值过长，插入数据库时出错
                                if (ReturnReason.Length > 100)
                                {
                                    ReturnReason = ReturnReason.Substring(0, 95);
                                }
                                UpdateRecord(rowguid, ReturnReason, Status);
                            }
                            else
                            {
                                for (j = 0; j <= Routing.Length - 1; j++)
                                {
                                    //筛选出返回信息非“Exception: Revision”以及非SAPGroup信息的数据（如WebService自身报错返回的信息等），不作处理，等待下次运行再次处理
                                    if (Regex.IsMatch(Routing[j][0].ToString(), @"^\d+$"))
                                    {
                                        if (SAPGroupPre + "0" + SAPGroupSuf == Routing[j][0].ToString() + Routing[j][1].ToString() || SAPGroupPre + SAPGroupSuf == Routing[j][0].ToString() + Routing[j][1].ToString())//匹配SAPGroup和Groupno
                                        {
                                            StrRouting = SAPWebs.GetRouting(Partno, Plant, SAPGroupPre, SAPGroupSuf);
                                            //StrRouting = SAPWebs.getRouting(Partno, Plant, SAPGroupPre, SAPGroupSuf);
                                            for (k = 0; k <= StrRouting.Length - 1; k++)
                                            {
                                                //匹配workcenter和OperationNo: PCZhou 重新写配对逻辑 2018-06-08
                                                if (OperationNo == StrRouting[k][0])//匹配OperationNo
                                                {
                                                    string[] S = SAPWebs.GetWorkCenterDetails(StrRouting[k][1]);
                                                    if (WorkCtr == S[0])//匹配workcenter
                                                    {
                                                        Status = "";
                                                        ReturnReason = "";
                                                        OldStdValue1 = StrRouting[k][4];
                                                        OldStdValue2 = StrRouting[k][5];
                                                        UpdateRecord(rowguid, ReturnReason, UgTime, OldStdValue1, OldStdValue2, Status);
                                                        BoolReturnReason = false;
                                                        break;
                                                    }
                                                }

                                                else
                                                {
                                                    BoolReturnReason = true;
                                                }
                                            }
                                            if (BoolReturnReason == true)//
                                            {
                                                ReturnReason = "WorkCenter or OperationNo is not matched";
                                                Status = "F";
                                                UpdateRecord(rowguid, ReturnReason, Status);
                                            }
                                            break;

                                        }
                                        else
                                        {
                                            ReturnReason = "SAP Group is not matched";
                                            Status = "F";
                                            //UpdateRecord(rowguid, ReturnReason, Status);
                                            if (j >= Routing.Length - 1)
                                            {
                                                UpdateRecord(rowguid, ReturnReason, Status);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        //SAPWeb._001SoapClient SAPWebs = new SAPWeb._001SoapClient();
                        ////从webservice获取sap相关信息
                        //Routing = SAPWebs.GetRoutingList(Partno, Plant, Rev);

                        //if (Routing.Length == 0 || Routing[0][0].ToString().ToUpper().IndexOf("EXCEPTION") > -1)
                        //{
                        //    //数据找不到 状态更新为F
                        //    Status = "F";
                        //    ReturnReason = Routing[0][0].ToString();
                        //    //防止返回值过长，插入数据库时出错
                        //    if (ReturnReason.Length > 100)
                        //    {
                        //        ReturnReason = ReturnReason.Substring(0, 95);
                        //    }
                        //    UpdateRecord(rowguid, ReturnReason, Status);
                        //}
                        //else
                        //{
                        //    for (j = 0; j <= Routing.Length - 1; j++)
                        //    {
                        //        //筛选出返回信息非“Exception: Revision”以及非SAPGroup信息的数据（如WebService自身报错返回的信息等），不作处理，等待下次运行再次处理
                        //        if (Regex.IsMatch(Routing[j][0].ToString(), @"^\d+$"))
                        //        {
                        //            if (SAPGroupPre + "0" + SAPGroupSuf == Routing[j][0].ToString() + Routing[j][1].ToString() || SAPGroupPre + SAPGroupSuf == Routing[j][0].ToString() + Routing[j][1].ToString())//匹配SAPGroup和Groupno
                        //            {
                        //                StrRouting = SAPWebs.GetRouting(Partno, Plant, SAPGroupPre, SAPGroupSuf);
                        //                //StrRouting = SAPWebs.getRouting(Partno, Plant, SAPGroupPre, SAPGroupSuf);
                        //                for (k = 0; k <= StrRouting.Length - 1; k++)
                        //                {
                        //                    //匹配workcenter和OperationNo: PCZhou 重新写配对逻辑 2018-06-08
                        //                    if (OperationNo == StrRouting[k][0])//匹配OperationNo
                        //                    {
                        //                        string[] S = SAPWebs.GetWorkCenterDetails(StrRouting[k][1]);
                        //                        if (WorkCtr == S[0])//匹配workcenter
                        //                        {
                        //                            Status = "";
                        //                            ReturnReason = "";
                        //                            OldStdValue1 = StrRouting[k][4];
                        //                            OldStdValue2 = StrRouting[k][5];
                        //                            UpdateRecord(rowguid, ReturnReason, UgTime, OldStdValue1, OldStdValue2, Status);
                        //                            BoolReturnReason = false;
                        //                            break;
                        //                        }
                        //                    }

                        //                    else
                        //                    {
                        //                        BoolReturnReason = true;
                        //                    }
                        //                }
                        //                if (BoolReturnReason == true)//
                        //                {
                        //                    ReturnReason = "WorkCenter or OperationNo is not matched";
                        //                    Status = "F";
                        //                    UpdateRecord(rowguid, ReturnReason, Status);
                        //                }
                        //                break;

                        //            }
                        //            else
                        //            {
                        //                ReturnReason = "SAP Group is not matched";
                        //                Status = "F";
                        //                //UpdateRecord(rowguid, ReturnReason, Status);
                        //                if (j >= Routing.Length - 1)
                        //                {
                        //                    UpdateRecord(rowguid, ReturnReason, Status);
                        //                }
                        //            }
                        //        }
                        //    }
                        //}
                        //pBar.Value = i + 1;
                    }

                }
            }
            catch
            {

            }
            finally
            {

            }
            //pBar.Visible = false;
            //lbbar.Visible = false;
        }
        //

        /// <summary>
        /// 比较Group等并且获取sap工卡工时
        /// </summary>
        /// <param name="DTsapstandardhourInfor">从sap_standard_hour_uploadQ表中获取的数据</param>
        /// 
        private void ComParerSAPandUpdate_JobCard(DataTable DTsapstandardhourInfor)  //add by PCZhou 2018-11-06
        {
            Int16 i = 0;
            //
            DTsapstandardhourInfor.Columns.Add("JobCard", typeof(string));
            //
            try
            {
                if (DTsapstandardhourInfor.Rows.Count != 0)
                {
                    for (i = 0; i <= DTsapstandardhourInfor.Rows.Count - 1; i++)
                    {
                        Delshow((i + 1) + "/" + DTsapstandardhourInfor.Rows.Count + " 正在比对" + this.WorkShop + "工件 " + DTsapstandardhourInfor.Rows[i]["material"].ToString().Trim() + "工卡信息...");
                        //
                        string Partno = DTsapstandardhourInfor.Rows[i]["material"].ToString().Trim();
                        string Rev = DTsapstandardhourInfor.Rows[i]["rev"].ToString().Trim();
                        string Plant = DTsapstandardhourInfor.Rows[i]["Plant"].ToString().Trim();
                        string ProgNum = DTsapstandardhourInfor.Rows[i]["p_num"].ToString().Trim(); ;
                        string OperationNo = DTsapstandardhourInfor.Rows[i]["OperationNo"].ToString().Trim();
                        string WorkCtr = DTsapstandardhourInfor.Rows[i]["WorkCtr"].ToString().Trim();
                        string rowguid = DTsapstandardhourInfor.Rows[i]["rowguid"].ToString().Trim();
                        string UgTime = DTsapstandardhourInfor.Rows[i]["newStdVal2"].ToString().Trim();
                        //string Status = "";
                        string JobCard = SQLRelate.GetMPMSJobCardRoutingRequest((SQLRelate.sqlconn(Form1.strRDCon)), Partno, Rev, ProgNum, OperationNo, WorkCtr);
                        if (JobCard != "")
                        {
                            DTsapstandardhourInfor.Rows[i]["JobCard"] = JobCard;
                        }

                    }

                }
            }
            catch
            {

            }
            finally
            {

            }
        }
        //

        /// <summary>
        /// 比较Group等并且获取sap标准工时,主体逻辑来自Huang Xiang Qi的SAPGroup工具
        /// </summary>
        /// <param name="DTsapstandardhourInfor">从sap_standard_hour_uploadQ表中获取的数据</param>
        /// 
        private static string GetSAPSetupTime(string Plant, string Partno, string Rev, string OperationNo)
        {
            string strSAPSetupTime = "0.0";
            
            //Int16 i = 0;
            Int16 j = 0;
            Int16 k = 0;
            try
            {
                string[][] Routing;
                string[][] StrRouting;
                //
                if (Plant == "8700")
                {
                    SAPWeb_ALG._001SoapClient SAPWebs = new SAPWeb_ALG._001SoapClient();
                    //从webservice获取sap相关信息
                    Routing = SAPWebs.GetRoutingList(Partno, Plant, Rev);
                    for (j = 0; j <= Routing.Length - 1; j++)
                    {
                        //筛选出返回信息非“Exception: Revision”以及非SAPGroup信息的数据（如WebService自身报错返回的信息等），不作处理，等待下次运行再次处理
                        if (Regex.IsMatch(Routing[j][0].ToString(), @"^\d+$"))
                        {
                            string SAPGroupPre = Routing[j][0].ToString();
                            string SAPGroupSuf = Routing[j][1].ToString();

                            StrRouting = SAPWebs.GetRouting(Partno, Plant, SAPGroupPre, SAPGroupSuf);
                            for (k = 0; k <= StrRouting.Length - 1; k++)
                            {
                                if (OperationNo == StrRouting[k][0])//匹配OperationNo
                                {
                                    strSAPSetupTime = StrRouting[k][4].ToString().Trim();
                                }
                            }
                        }
                    }
                }
                else if (Plant == "A200")
                {
                    SAPWeb_AMC._001SoapClient SAPWebs = new SAPWeb_AMC._001SoapClient();
                    //从webservice获取sap相关信息
                    Routing = SAPWebs.GetRoutingList(Partno, Plant, Rev);
                    for (j = 0; j <= Routing.Length - 1; j++)
                    {
                        //筛选出返回信息非“Exception: Revision”以及非SAPGroup信息的数据（如WebService自身报错返回的信息等），不作处理，等待下次运行再次处理
                        if (Regex.IsMatch(Routing[j][0].ToString(), @"^\d+$"))
                        {
                            string SAPGroupPre = Routing[j][0].ToString();
                            string SAPGroupSuf = Routing[j][1].ToString();

                            StrRouting = SAPWebs.GetRouting(Partno, Plant, SAPGroupPre, SAPGroupSuf);
                            for (k = 0; k <= StrRouting.Length - 1; k++)
                            {
                                if (OperationNo == StrRouting[k][0])//匹配OperationNo
                                {
                                    strSAPSetupTime = StrRouting[k][4].ToString().Trim();
                                }
                            }
                        }
                    }
                }
                else if (Plant == "H100")
                {
                    SAPWeb_ATH._001SoapClient SAPWebs = new SAPWeb_ATH._001SoapClient();
                    //从webservice获取sap相关信息
                    Routing = SAPWebs.GetRoutingList(Partno, Plant, Rev);
                    for (j = 0; j <= Routing.Length - 1; j++)
                    {
                        //筛选出返回信息非“Exception: Revision”以及非SAPGroup信息的数据（如WebService自身报错返回的信息等），不作处理，等待下次运行再次处理
                        if (Regex.IsMatch(Routing[j][0].ToString(), @"^\d+$"))
                        {
                            string SAPGroupPre = Routing[j][0].ToString();
                            string SAPGroupSuf = Routing[j][1].ToString();

                            StrRouting = SAPWebs.GetRouting(Partno, Plant, SAPGroupPre, SAPGroupSuf);
                            for (k = 0; k <= StrRouting.Length - 1; k++)
                            {
                                if (OperationNo == StrRouting[k][0])//匹配OperationNo
                                {
                                    strSAPSetupTime = StrRouting[k][4].ToString().Trim();
                                }
                            }
                        }
                    }
                }
                else
                {
                    SAPWeb._001SoapClient SAPWebs = new SAPWeb._001SoapClient();
                    //从webservice获取sap相关信息
                    Routing = SAPWebs.GetRoutingList(Partno, Plant, Rev);
                    for (j = 0; j <= Routing.Length - 1; j++)
                    {
                        //筛选出返回信息非“Exception: Revision”以及非SAPGroup信息的数据（如WebService自身报错返回的信息等），不作处理，等待下次运行再次处理
                        if (Regex.IsMatch(Routing[j][0].ToString(), @"^\d+$"))
                        {
                            string SAPGroupPre = Routing[j][0].ToString();
                            string SAPGroupSuf = Routing[j][1].ToString();

                            StrRouting = SAPWebs.GetRouting(Partno, Plant, SAPGroupPre, SAPGroupSuf);
                            for (k = 0; k <= StrRouting.Length - 1; k++)
                            {
                                if (OperationNo == StrRouting[k][0])//匹配OperationNo
                                {
                                    strSAPSetupTime = StrRouting[k][4].ToString().Trim();
                                }
                            }
                        }
                    }
                }
                //SAPWeb._001SoapClient SAPWebs = new SAPWeb._001SoapClient();
                ////从webservice获取sap相关信息
                //Routing = SAPWebs.GetRoutingList(Partno, Plant, Rev);

                //for (j = 0; j <= Routing.Length - 1; j++)
                //{
                //    //筛选出返回信息非“Exception: Revision”以及非SAPGroup信息的数据（如WebService自身报错返回的信息等），不作处理，等待下次运行再次处理
                //    if (Regex.IsMatch(Routing[j][0].ToString(), @"^\d+$"))
                //    {
                //        string SAPGroupPre = Routing[j][0].ToString();
                //        string SAPGroupSuf = Routing[j][1].ToString();

                //        StrRouting = SAPWebs.GetRouting(Partno, Plant, SAPGroupPre, SAPGroupSuf);
                //        for (k = 0; k <= StrRouting.Length - 1; k++)
                //        {
                //            if (OperationNo == StrRouting[k][0])//匹配OperationNo
                //            {
                //                strSAPSetupTime = StrRouting[k][4].ToString().Trim();
                //            }
                //        }
                //    }
                //}

            }
            catch
            {

            }
            finally
            {

            }

            return strSAPSetupTime;

        }
        //

        /// <summary>
        /// 以rowguid为唯一标识列更新
        /// </summary>
        /// <param name="strReturnReason">return_msg</param>
        /// <param name="strUgTime">ug模拟时间</param>
        /// <param name="strOldStdValue2">目前的标准工时</param>
        private void UpdateRecord(string strRowguid, string strReturnReason, string strUgTime, string strOldStdValue1, string strOldStdValue2, string strStatus)
        {
            StringBuilder strSql = new StringBuilder();
            Single ugTime = Convert.ToSingle(strUgTime);
            Single oldStdValue1 = Convert.ToSingle(strOldStdValue1);
            Single oldStdValue2 = Convert.ToSingle(strOldStdValue2);

            //string strsite_id = "";
            //string Wrongmessage_temp = "";

            if (ugTime==0)
            {   //UG时间为0，废掉此记录。
                strStatus = "F";
                strSql.AppendLine("update  sap_standard_hour_uploadQ set ");
                strSql.AppendLine("return_msg='UGTime is zero' ,Status='" + strStatus + "' ");
                strSql.AppendLine("where rowguid='" + strRowguid + "'");

            }
            //UG模拟时间与部门人员手动填写的sap时间若差异超过20%，则需要部门进行再次确认后才能进行更新
            //ALG自2017/11/16起，不再比较ug时间与sap时间的20%差异
            //else if (((ugTime - oldStdValue2) / ugTime) <= 0.2 || this._site == "8700")
            //{
            //    strStatus = "W";
            //    strSql.AppendLine("update  sap_standard_hour_uploadQ set ");
            //    strSql.AppendLine("oldStdVal1='" + oldStdValue1.ToString() + "' ,oldStdVal2='" + oldStdValue2.ToString() + "' , return_msg='" + strReturnReason + "' ,Status='" + strStatus + "' ");
            //    strSql.AppendLine("where rowguid='" + strRowguid + "'");//状态为P的才查，然后更新为W。
            //}
            //else
            //{
            //    strStatus = "F";
            //    strReturnReason = "difference beyond 20%";
            //    strSql.AppendLine("update  sap_standard_hour_uploadQ set ");
            //    strSql.AppendLine("oldStdVal1='" + oldStdValue1.ToString() + "' ,oldStdVal2='" + oldStdValue2.ToString() + "' , return_msg='" + strReturnReason + "' ,Status='" + strStatus + "' ");
            //    strSql.AppendLine("where rowguid='" + strRowguid + "'");//UG模拟时间与SAP时间相差超过20%的状态标为F并且return_msg更新为difference beyond 20%
            //}

            else if ((ugTime - oldStdValue2) != 0 )
            {
                //// 增加邮件报警功能 -PCZHOU 2018-05-21
                //if ((oldStdValue2 - ugTime) / ugTime > 2)
                //{   
                //    if (Form1.site == "8700")
                //    {
                //        strsite_id="L";
                //    }
                //    else if (Form1.site == "A200")
                //    {
                //        strsite_id = "J";
                //    }
                //    else
                //    {
                //        strsite_id="H";
                //    }
                //    Wrongmessage_temp = "Dear Colleagues,\f\f" + "以下工件的SAP标准工时过大, 系统已根据UG Time更新SAP标准工时";
                //    Wrongmessage_temp = Wrongmessage_temp + "\f\n\f" + "<table bgcolor=white border=1 bordercolor=blue bordercolordark=LemonChiffon><tr><td><font size=4 color=blue><B>" + "Plant" + "</td><td><font size=4 color=blue><B> " + "Part Num" + "</td><td><font size=4 color=blue><B> " + "Part Rev" + "</td><td><font size=4 color=blue><B> " + "SAP OperationNo" + "</td><td><font size=4 color=blue><B> " + "SAP STDHour（h）" + "</td><td><font size=4 color=blue><B> " + "UG Time(h)" + "</td><td><font size=4 color=blue><B> " + "SAP STDHour/UG Time(%)" + "</td></tr>" + "<bgcolor=white border=1 bordercolor=blue bordercolordark=LemonChiffon><tr><td align= center ><B>" + plant_def + "</td><td align= center ><B> " + strpartnum + "</td><td align= center ><B> " + strpartrev + "</td><td align= center ><B> " + OperationNo_def + "</td><td align= center ><font size=4 color=blue><B> " + oldStdValue2 + "</td><td align= center ><font size=4 color=blue><B> " + ugTime + "</td><td align= center ><font size=4 color=red><B> " + Math.Floor(100 * (oldStdValue2 / ugTime)) + "%" + "</td></tr></table>";
                //    Wrongmessage_temp = Wrongmessage_temp + "\f\f\f\f" + "感谢您的关注！\f如有问题请联系：CIM 周培纯 （15231）\f此邮件是系统(W)自动发出，请不要回复！\f\f\f谢谢！";
                //    //Wrongmessage_temp = Wrongmessage_temp + "<table bgcolor=white border=1 bordercolor=blue bordercolordark=LemonChiffon><tr><td><font size=4 color=blue><B>" + "SAP STDHour(h)" + "</td><td><font size=4 color=blue><B> " + "UG Time(h)" + "</td><td><font size=4 color=blue><B> " + "SAP STDHour/UG Time(%)" + "</td></tr>" + "<bgcolor=white border=1 bordercolor=blue bordercolordark=LemonChiffon><tr><td align= center ><font size=4 color=blue><B>" + oldStdValue2 + "</td><td align= center ><font size=4 color=blue><B> " + ugTime + "</td><td align= center ><font size=4 color=red><B> " + Math.Floor(100 * (oldStdValue2 / ugTime)) + "%" + "</td></tr></table>" + "感谢您的关注！\f\n如有问题请联系：周培纯 （设计工程师）（15231）\f\n此邮件是系统(W)自动发出，请不要回复！\f\n谢谢！";
                //    SQLRelate.sendmail("SAP STDHour is Large", GetstralertsTO((SQLRelate.sqlconn(Form1.strRDCon)), strsite_id), GetstralertsCC((SQLRelate.sqlconn(Form1.strRDCon)), strsite_id), GetstralertsBCC((SQLRelate.sqlconn(Form1.strRDCon)), strsite_id), Wrongmessage_temp);
                //}

                strStatus = "W";
                strSql.AppendLine("update  sap_standard_hour_uploadQ set ");
                strSql.AppendLine("oldStdVal1='" + oldStdValue1.ToString() + "' ,oldStdVal2='" + oldStdValue2.ToString() + "' , return_msg='" + strReturnReason + "' ,Status='" + strStatus + "' ");
                strSql.AppendLine("where rowguid='" + strRowguid + "'");//状态为P的才查，然后更新为W。
            }

            string currentProcess;
            currentProcess = "程序SAPCaculate比较Group一致的数据工时報錯，請檢查!";
            SQLRelate.InsertUpdate(SQLRelate.sqlconn(Form1.strCON), strSql.ToString(), currentProcess);
        }
        private void UpdateRecord(string Strrowguid, string StrReturnReason, string StrStatus)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.AppendLine("update  sap_standard_hour_uploadQ set ");
            strSql.AppendLine("return_msg='" + StrReturnReason + "' ,Status='" + StrStatus + "' ");
            strSql.AppendLine("where rowguid='" + Strrowguid + "'");

            string currentProcess;
            currentProcess = "程序SAPCaculate比较Group不一致的数据報錯，請檢查!";
            SQLRelate.InsertUpdate(SQLRelate.sqlconn(Form1.strCON), strSql.ToString(), currentProcess);
        }

        /// <summary>
        /// 从sap_standard_hour_uploadQ表中获取待处理的数据
        /// </summary>
        /// 
        private DataTable Loadsap_standard_hourInfor()
        {

            DataTable dt = new DataTable();
            //string preDate = DateTime.Now.AddDays(-3).ToShortDateString();
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(" select * from sap_standard_hour_uploadQ ");
            //状态为P的才查，然后更新为W。数据不对更新为F
            //sb.AppendLine(" where status='p' and input_time between '" + preDate + "' and '" + DateTime.Now.AddDays(1).ToShortDateString() + "'");
            //sb.AppendLine(" where status='p' and input_time > '2017/03/10' ");
            //sb.AppendLine(" where status='p' and input_time > '2018/06/07' ");
            ////Form1.strdatetime = "2018-08-21";
            //sb.AppendLine(" where status='p' and material='26-i44978' and input_time > '" + Form1.strdatetime + "'"); //只处理当天的数据

            sb.AppendLine(" where status='p' and input_time > '" + Form1.strdatetime + "'"); //只处理当天的数据
            sb.AppendLine(" and (workctr like '" + this._currentWorkshop + "%') ");
            sb.AppendLine(" order by input_time desc");

            // This is test 
            //sb.AppendLine(" where material ='26-c48149' and fix_seq='2' ");
            //sb.AppendLine(" order by input_time desc");

            string currentProcess;
            currentProcess = "程序SAPCaculate获取待比较数据记录報錯，請檢查!";
            dt = GetData(sb.ToString(), currentProcess);
            return dt;
        }
        
        //
        /// <summary>
        /// 从sap_standard_hour_uploadQ表中获取status='F'的数据
        /// </summary>
        /// 
        private DataTable Getdata_standard_hourInfor_JobCard()
        {
            DataTable dt = new DataTable();
            //string preDate = DateTime.Now.AddDays(-3).ToShortDateString();
            StringBuilder sb = new StringBuilder();
            //
            sb.AppendLine(" select * from sap_standard_hour_uploadQ ");

            //状态为F的才查
            //sb.AppendLine(" where status='F' and input_time > '2018/10/15' ");
            //sb.AppendLine(" and (workctr like '" + this._currentWorkshop + "%') ");
            sb.AppendLine(" where status='F' and input_time > '" + Form1.strdatetime + "'"); //只处理当天的数据
            sb.AppendLine(" and (workctr like '" + this._currentWorkshop + "%') ");
            sb.AppendLine(" order by input_time desc");

            string currentProcess;
            currentProcess = "程序SAPCaculate获取待比较数据记录報錯，請檢查!";
            dt = GetData(sb.ToString(), currentProcess);
            return dt;
        }
        private DataTable Getdata_on_off_load_time()
        {
            DataTable dt = new DataTable();
            //string preDate = DateTime.Now.AddDays(-3).ToShortDateString();
            StringBuilder sb = new StringBuilder();
            //
            sb.AppendLine(" select * from sap_standard_hour_uploadQ ");

            //状态为S的才查
            //sb.AppendLine(" where status='S' and input_time > '2018/10/15' ");
            //sb.AppendLine(" where status='S' and on_off_load_time > 0 and on_off_load_time <> '999' and Status_OnOff_Load_Time is null and input_time > '2019/01/01' ");
            sb.AppendLine(" where status='S' and on_off_load_time > 0 and on_off_load_time <> '999' and Status_OnOff_Load_Time is null and input_time > '" + Form1.strdatetime + "'"); //只处理当天的数据
            sb.AppendLine(" and (workctr like '" + this._currentWorkshop + "%') ");
            sb.AppendLine(" order by input_time desc");

            string currentProcess;
            currentProcess = "程序SAPCaculate获取待比较数据记录報錯，請檢查!";
            dt = GetData(sb.ToString(), currentProcess);
            return dt;
        }
        private string GetChangeNo(string filename)
        {
            string currentProcess;
            string ChangeNo = "";

            string strSql = "select top 1 doc_no from [vw_asmdwglib] ";
            strSql = strSql + "where [filename] like '" + filename + "%' ";
            strSql = strSql + "order by doc_date desc ";
            currentProcess = "程序SAPCaculate获取所有CNC标准工艺时报错，請檢查!";
            SqlDataReader sdr = GetDataReader_YTGNTS113(strSql, currentProcess);

            while (sdr.Read())
            {
                ChangeNo =sdr[0].ToString();
            }
            sdr.Close();   //关闭sdr的同时也会关闭其依赖的数据库连接

            return ChangeNo;
            
        }

        //
        /// <summary>
        /// 从数据库查询数据,返回datatable
        /// </summary>
        /// <param name="strSql">sql语句</param>
        /// <param name="currentProcess">记录当前操作步骤</param>
        /// <returns></returns>
        private DataTable GetData(string strSql, string currentProcess)
        {
            DataTable dt = SQLRelate.Query(SQLRelate.sqlconn(Form1.strRDCon), strSql, currentProcess);
            return dt;
        }
        //private DataTable GetData_YTGNTS113(string strSql, string currentProcess)
        //{
        //    DataTable dt = SQLRelate.Query(SQLRelate.sqlconn(Form1.strRDCon_YTG113), strSql, currentProcess);
        //    return dt;
        //}
        /// <summary>
        /// 从数据库查询数据,返回sqldatareader
        /// </summary>
        /// <param name="strSql">sql语句</param>
        /// <param name="currentProcess">记录当前操作步骤</param>
        /// <returns></returns>
        private SqlDataReader GetDataReader(string strSql, string currentProcess)
        {
            SqlDataReader sdr = SQLRelate.QueryDataReader(SQLRelate.sqlconn(Form1.strRDCon), strSql, currentProcess);
            return sdr;
        }
        private SqlDataReader GetDataReader_YTGNTS113(string strSql, string currentProcess)
        {
            SqlDataReader sdr = SQLRelate.QueryDataReader(SQLRelate.sqlconn(Form1.strRDCon_YTG113), strSql, currentProcess);
            return sdr;
        }
        private void CheckSAPSTDHour(Single UGTime_def, Single SAPSTDHour_def, string plant_def, string strpartnum, string strpartrev, string OperationNo_def)
        {

            //string strsite_id = "";
            string Wrongmessage_temp = "";

            // 增加邮件报警功能 -PCZHOU 2018-05-21
            if ((SAPSTDHour_def - UGTime_def) / UGTime_def > 2)
            {

                //if (Form1.site == "8700")
                //{
                //    strsite_id = "L";
                //}
                //else if (Form1.site == "A200")
                //{
                //    strsite_id = "J";
                //}
                //else
                //{
                //    strsite_id = "H";
                //}

                Wrongmessage_temp = "Dear Colleagues,\f\f" + "以下工件的SAP标准工时过大, 系统已根据UG Time更新SAP标准工时";
                Wrongmessage_temp = Wrongmessage_temp + "\f\n\f" + "<table bgcolor=white border=1 bordercolor=blue bordercolordark=LemonChiffon><tr><td><font size=4 color=blue><B>" + "Plant" + "</td><td><font size=4 color=blue><B> " + "Part Num" + "</td><td><font size=4 color=blue><B> " + "Part Rev" + "</td><td><font size=4 color=blue><B> " + "SAP OperationNo" + "</td><td><font size=4 color=blue><B> " + "SAP STDHour（h）" + "</td><td><font size=4 color=blue><B> " + "UG Time(h)" + "</td><td><font size=4 color=blue><B> " + "SAP STDHour/UG Time(%)" + "</td></tr>" + "<bgcolor=white border=1 bordercolor=blue bordercolordark=LemonChiffon><tr><td align= center ><B>" + plant_def + "</td><td align= center ><B> " + strpartnum + "</td><td align= center ><B> " + strpartrev + "</td><td align= center ><B> " + OperationNo_def + "</td><td align= center ><font size=4 color=blue><B> " + SAPSTDHour_def + "</td><td align= center ><font size=4 color=blue><B> " + UGTime_def + "</td><td align= center ><font size=4 color=red><B> " + Math.Floor(100 * (SAPSTDHour_def / UGTime_def)) + "%" + "</td></tr></table>";
                Wrongmessage_temp = Wrongmessage_temp + "\f\f\f\f" + "感谢您的关注！\f如有问题请联系：CIM 周培纯 （15231）\f此邮件是系统(W)自动发出，请不要回复！\f\f\f谢谢！";
                SQLRelate.sendmail("SAP STDHour is Large", SQLRelate.GetstralertsTO((SQLRelate.sqlconn(Form1.strRDCon)), SQLRelate.GetstrsiteID(Form1.site)), SQLRelate.GetstralertsCC((SQLRelate.sqlconn(Form1.strRDCon)), SQLRelate.GetstrsiteID(Form1.site)), SQLRelate.GetstralertsBCC((SQLRelate.sqlconn(Form1.strRDCon)), SQLRelate.GetstrsiteID(Form1.site)), Wrongmessage_temp);
            }

        }

        #endregion

    }

}
