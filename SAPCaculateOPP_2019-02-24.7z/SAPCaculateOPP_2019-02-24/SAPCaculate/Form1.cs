﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;
using System.Text.RegularExpressions;
using System.Threading;
using System.Drawing.Drawing2D;



namespace SAPCaculate
{

    public partial class Form1 : Form
    {
        #region Field

        public static string site;
        public static string workShop;
        public static string strCON;
        public static string strRDCon;
        public static string strRDCon_YTG113 = "ytg113rdCON";
        public static string strMailCon;

        public static string strdatetime;

        public string errMessage = "";
        public string strSite_ID = "";

        #endregion

        #region Property

        #endregion

        #region Constructor

        public Form1()
        {
            InitializeComponent();
        }

        #endregion

        #region Events

        private void Form1_Load(object sender, EventArgs e)
        {
            this.Size = new System.Drawing.Size(558, 143);  //初始化页面大小
            string path = Environment.CurrentDirectory;  //获取程序所在路径
            label4.Text = "Program Location:" + path + "\n\rFunction:1)Update SAP standard hour\n\r               2)submit  materials of which cost need to\n\r               be recalculated";
            string PCName = Environment.MachineName.ToUpper().ToString();  //获取当前电脑号，用于做权限管控


            //if (PCName.IndexOf("AMC") == -1 && PCName.IndexOf("ALG") == -1 && PCName.IndexOf("ATH") == -1 && PCName.IndexOf("PC05966") == -1)
            //{
            //    MessageBox.Show("无权限使用此工具，请联系CIM");
            //    Application.Exit();
            //}
            if (PCName.IndexOf("AMC") > -1 && PCName.IndexOf("PC04394") == -1)
            {
                rbSiteAMC.Checked = true;
                rbSiteAMC.Enabled = false;
                rbSiteALG.Checked = false;
                rbSiteALG.Enabled = false;
                rbSiteATH.Checked = false;
                rbSiteATH.Enabled = false;

            }
            if (PCName.IndexOf("ALG") > -1 && PCName.IndexOf("PC04394") == -1)
            {
                rbSiteALG.Checked = true;
                rbSiteALG.Enabled = false;
                rbSiteAMC.Checked = false;
                rbSiteAMC.Enabled = false;
                rbSiteATH.Checked = false;
                rbSiteATH.Enabled = false;

            }
            if (PCName.IndexOf("ATH") > -1 && PCName.IndexOf("PC04394") == -1)
            {
                rbSiteATH.Checked  = true;
                rbSiteATH.Enabled = false;
                rbSiteAMC.Checked = false;
                rbSiteAMC.Enabled = false;
                rbSiteALG.Checked = false;
                rbSiteALG.Enabled = false;

            }
            //取消跨线程调用控件的限制，注意这个是全局控制，若其他地方需要对其进行修改，则跨线程访问控件则应采取其他方式
            Control.CheckForIllegalCrossThreadCalls = false;

            if (rbSiteAMC.Checked)
            {
                site = "A200";
                workShop = "J31;J02;J52;J58";
                strCON = "amc113con";
                strRDCon = "amc113rdCON";
                strMailCon = "amc113mail";

            }
            else if (rbSiteALG.Checked)
            {
                site = "8700";
                workShop = "ALL Workshop of ALG";
                strCON = "alg133CON";    //搬数据库 2017/12/13
                strRDCon = "alg133rdCON";
                //strCON = "alg133CON";
                //strRDCon = "alg133rdCON";
                strMailCon = "alg133mail";

            }
            else if (rbSiteALG.Checked)
            {
                site = "H100";
                workShop = "ALL Workshop of ATH";
                strCON = "ath31con";
                strRDCon = "ath31rdCON";
                strMailCon = "ath31mail";

            }


            label8.Text = " Program is running now,Relative workshop: " + workShop + " !  ";

            lbStatus.Refresh();
            lbNextTime.Refresh();
            lbStatus.Text = "";
            lbNextTime.Text = "";
            timer1.Enabled = true;
            timer2.Enabled = false;
            //tmStatus.Enabled = true;
            timer1.Interval = 1 * 30 * 60 * 1000;
            timer2.Interval = 1 * 30 * 60 * 1000;
            nextrunningtime();

            Workshop.dicSite.Add("A200", "AMC");
            Workshop.dicSite.Add("8700", "ALG");
            Workshop.dicSite.Add("H100", "ATH");

            RunNow.Text = "Caculate";

        }
        private void RunNow_Click(object sender, EventArgs e)
        {
            if (timer1.Enabled)
            {
                timer1.Interval = 100;

            }
            else if (timer2.Enabled)
            {
                timer2.Interval = 100;
            }
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Interval = 1 * 30 * 60 * 1000;
            timer1.Enabled = false;
            try
            {
                Thread th = new Thread(new ThreadStart(UpdateCostCaculateData));
                th.IsBackground = true;
                th.Start();
            }
            catch (Exception)
            {

            }

            timer2.Enabled = true;
        }
        private void timer2_Tick(object sender, EventArgs e)
        {
            timer2.Interval = 1 * 30 * 60 * 1000;
            timer2.Enabled = false;

            strdatetime = DateTime.Now.AddDays(-1).ToString("d"); //注意：更新时间：昨天到今天 〈-- PCZhou 2018-06-12

            try
            {
                Thread th = new Thread(new ThreadStart(UpdateSAPHour));
                //Thread th = new Thread(new ThreadStart(UpdateSAPStandardHour));
                th.IsBackground = true;
                th.Start();
            }
            catch (Exception)
            {

            }
            timer1.Enabled = true;
        }
        private void rbSiteAMC_CheckedChanged(object sender, EventArgs e)
        {

            if (rbSiteAMC.Checked)
            {
                site = "A200";
                workShop = "J02;J22;J31;J52;J58";
                strCON = "amc113con";
                strRDCon = "amc113rdCON";
                strMailCon = "amc113mail";

                strSite_ID = "J";

                label8.Text = " Program is running now,Relative workshop: " + workShop + " !  ";
            }

        }
        private void rbSiteALG_CheckedChanged(object sender, EventArgs e)
        {

            if (rbSiteALG.Checked)
            {
                site = "8700";
                //workShop = "L03;L12";
                workShop = "ALL Workshop of ALG";       //All WS of ALG start to run SAP standard hour update from 2017/05/02

                strCON = "alg133CON";
                strRDCon = "alg133rdCON";
                strMailCon = "alg133mail";

                strSite_ID = "L";

                label8.Text = " Program is running now,Relative workshop: " + workShop + " !  ";
            }

        }
        private void rbSiteATH_CheckedChanged(object sender, EventArgs e)
        {
            if (rbSiteATH.Checked)
            {
                site = "H100";
                workShop = "ALL Workshop of ATH";      //All WS of ATH start to run SAP standard hour update from 2017/07/30
                strCON = "ath31con";
                strRDCon = "ath31rdCON";
                strMailCon = "ath31mail";

                strSite_ID = "H";

                label8.Text = " Program is running now,Relative workshop: " + workShop + " !  ";
            }
        }
        private void tmStatus_Tick(object sender, EventArgs e)
        {
            //string status = " Program is running now, do not close ! ";

            //label8.Text = label8.Text.Substring(1) + label8.Text.Substring(0, 1);
            label8.Text = label8.Text.Trim();
            label8.Left -= 4;
            if (label8.Right < 0)
            {
                label8.Left = this.Width;
            }

        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (Form1.ActiveForm.Height > 143)
            {
                this.Size = new System.Drawing.Size(468, 143);
            }
            else
            {
                this.Size = new System.Drawing.Size(468, 278);
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.ApplicationExitCall)
            {
                e.Cancel = false;
            }
            else
            {
                if (MessageBox.Show("是否退出程序？", "确认", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    e.Cancel = false;
                    Application.ExitThread();
                }
                else
                {
                    e.Cancel = true;
                }

            }
        }

        #endregion

        #region PrivateMethod

        /// <summary>
        /// 调用存储过程上传需要进行价格更新的数据至MIS
        /// </summary>
        private void UpdateCostCaculateData()
        {
            if (Form1.site == "A200" || Form1.site == "8700")
            {
                RunNow.Enabled = false;
                lbNextTime.Text = "";

                string[] allWorkshop = SelectWorkshop(workShop).ToArray();

                Workshop currentWorkshop = new Workshop(Form1.site, (string status) => lbStatus.Text = status);
                currentWorkshop.SubmitCostData();
                currentWorkshop = null;
                nextrunningtime();
                RunNow.Enabled = true;
                RunNow.Text = "Update";
                try
                {
                    Thread.CurrentThread.Abort();        //销毁当前线程
                }
                catch (Exception ex)
                {

                }
            }
            else
            {
                nextrunningtime();
                lbStatus.Text = Workshop.dicSite[Form1.site] + "厂区暂时未进行价格计算...";
            }
            RunNow.Text = "Update";
        }

        /// <summary>
        /// 核查数据准确性，并且更新sap工时  : add by PCZhou 2018-11-06:新增更新工卡工时
        /// </summary>
        private void UpdateSAPHour()
        {
            RunNow.Enabled = false;
            lbNextTime.Text = "";

            string[] allWorkshop = SelectWorkshop(workShop).ToArray();

            Workshop currentWorkshop = new Workshop(Form1.site, (string status) => lbStatus.Text = status);
            foreach (string item in allWorkshop)
            {
                currentWorkshop.WorkShop = item.ToString();
                //
                //更新SAP Std hours
                currentWorkshop.CheckData();//检查数据是否与SAP系统一致（sapgroup，operationno等）
                //
                currentWorkshop.UpdateSAP_StdHour();//用ug模拟时间更新sap工时：ALG/AMC/ATH 执行相同的功能 PCZhou 2018-05-25
                //=====================================================================================================
                //
                //价格计算
                if (Form1.site == "A200" || Form1.site == "8700")
                {
                    currentWorkshop.CheckCostData();//自动将所有CNC工艺都由CIM更新的工件提交到价格计算数据表中
                }
                //========================================================================================
                //
                //更新工卡工时 ++ add by PCZhou 2018-11-06
                currentWorkshop.UpdateSAP_JobCardHour(); //add by PCZhou 2018-11-06: 更新工卡工时
                // =============================================================================
                //
                //更新on_off_load_time --> add by PCZhou 2019-01-09
                currentWorkshop.UpdateSAP_On_Off_Load_Time(); 
                //if (Form1.site == "8700")
                //{
                //    currentWorkshop.UpdateSAP_On_Off_Load_Time(); 
                //}
                //
                //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ 
                
            }
            currentWorkshop = null;
            nextrunningtime();
            RunNow.Enabled = true;
            RunNow.Text = "Caculate";

            try
            {
                Thread.CurrentThread.Abort();  //销毁当前线程
            }
            catch (Exception ex)
            {

            }
        }

        ///// <summary>  : Cancel by PCZhou 2018-1106
        ///// 核查数据准确性，并且更新sap标准工时
        ///// </summary>
        //private void UpdateSAPStandardHour()
        //{
        //    RunNow.Enabled = false;
        //    lbNextTime.Text = "";

        //    string[] allWorkshop = SelectWorkshop(workShop).ToArray();

        //    Workshop currentWorkshop = new Workshop(Form1.site,(string status)=>lbStatus.Text=status);
        //    foreach (string item in allWorkshop)
        //    {
        //        currentWorkshop.WorkShop = item.ToString();

        //        currentWorkshop.CheckData();//检查数据是否与SAP系统一致（sapgroup，operationno等）
        //        //
        //        //currentWorkshop.UpdateSAP_StdHour();//用ug模拟时间更新sap工时 ---- PCZhou 2018-05-25 更新： ALG，AMC，ATH执行相同的功能
        //        currentWorkshop.Update_SAPStdHour_OnOffLoadTime();//用ug模拟时间更新sap工时 ---- PCZhou 2018-05-25 更新： ALG，AMC，ATH执行相同的功能

        //        //
        //        //价格计算 ======================================
        //        if (Form1.site == "A200" || Form1.site == "8700")
        //        {
        //            currentWorkshop.CheckCostData();  //自动将所有CNC工艺都由CIM更新的工件提交到价格计算数据表中
        //        }               
        //    }
        //    currentWorkshop = null;
        //    nextrunningtime();
        //    RunNow.Enabled = true;
        //    RunNow.Text = "Caculate";

        //    try
        //    {
        //        Thread.CurrentThread.Abort();  //销毁当前线程
        //    }
        //    catch (Exception ex)
        //    {
                
        //    }
            
          
        //}

        private void nextrunningtime()
        {
            string nexttime;
            nexttime = DateTime.Now.AddMinutes (30).ToLongTimeString ();

            lbNextTime.Refresh();
            lbStatus.Refresh();
            lbStatus.Text = "Idle...";
            lbNextTime.Text = nexttime.ToString();
        }
        //public string workshopSelect(string strWS)
        //{
        //    string strSQL = "";
        //    if (strWS.IndexOf("ALL")>-1)
        //    {
        //        return strSQL;
        //    }
        //    MatchCollection mc = Regex.Matches(strWS, @"\w{3}");
        //    foreach (Match item in mc)
        //    {
        //        strSQL += "workctr like '" + item + "%' or ";
        //    }
        //    strSQL = strSQL.Substring(0, strSQL.Length - 3);
        //    strSQL = " and (" + strSQL + ")";

        //    return strSQL;
        //}
        public List<string> SelectWorkshop(string strWS)
        {
            List<string> workshop = new List<string>();

            if (strWS.IndexOf("ALG") > -1)
            {
                workshop.Add("L03");
                workshop.Add("L08");
                workshop.Add("L11");
                workshop.Add("L12");
                workshop.Add("L23");
                workshop.Add("L29");
                workshop.Add("L33");
                workshop.Add("L80");
                workshop.Add("L89"); 
                return workshop;
            }
            else if (strWS.IndexOf("ATH") > -1)
            {
                workshop.Add("H02");
                workshop.Add("H03");
                workshop.Add("H04");
                workshop.Add("H07");
                workshop.Add("H11");
                workshop.Add("H12");
                workshop.Add("H13");
                workshop.Add("H22");
                workshop.Add("H23");
                workshop.Add("H62");
                workshop.Add("PA2");
                return workshop;

            }

            MatchCollection mc = Regex.Matches(strWS, @"\w{3}");
            foreach (Match item in mc)
            {
                workshop.Add(item.ToString());
            }
            return workshop;
        }
        private string  sqlconn(string con)
        {
            string strconn=ConfigurationManager.ConnectionStrings[con].ConnectionString.ToString();
            return strconn;
        }
        //private void ShowStatus(string status)
        //{
        //    lbStatus.Text = status;
        //}

        #endregion

    }
}
