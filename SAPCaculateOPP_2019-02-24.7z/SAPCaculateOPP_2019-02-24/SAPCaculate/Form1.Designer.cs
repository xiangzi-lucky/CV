﻿namespace SAPCaculate
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.label1 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.RunNow = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lbStatus = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lbNextTime = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.rbSiteAMC = new System.Windows.Forms.RadioButton();
            this.label8 = new System.Windows.Forms.Label();
            this.rbSiteALG = new System.Windows.Forms.RadioButton();
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.tmStatus = new System.Windows.Forms.Timer(this.components);
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.rbSiteATH = new System.Windows.Forms.RadioButton();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(74, 69);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 17);
            this.label1.TabIndex = 0;
            // 
            // timer1
            // 
            this.timer1.Interval = 5000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // RunNow
            // 
            this.RunNow.BackColor = System.Drawing.Color.Transparent;
            this.RunNow.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RunNow.ForeColor = System.Drawing.SystemColors.InfoText;
            this.RunNow.Location = new System.Drawing.Point(460, 24);
            this.RunNow.Name = "RunNow";
            this.RunNow.Size = new System.Drawing.Size(89, 31);
            this.RunNow.TabIndex = 2;
            this.RunNow.Text = "Run";
            this.RunNow.UseVisualStyleBackColor = false;
            this.RunNow.Click += new System.EventHandler(this.RunNow_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.InfoText;
            this.label2.Location = new System.Drawing.Point(21, 8);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 18);
            this.label2.TabIndex = 3;
            this.label2.Text = "Status:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(74, 25);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 18);
            this.label3.TabIndex = 4;
            // 
            // lbStatus
            // 
            this.lbStatus.AutoSize = true;
            this.lbStatus.BackColor = System.Drawing.Color.LightSteelBlue;
            this.lbStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbStatus.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.lbStatus.Location = new System.Drawing.Point(71, 8);
            this.lbStatus.Name = "lbStatus";
            this.lbStatus.Size = new System.Drawing.Size(46, 18);
            this.lbStatus.TabIndex = 5;
            this.lbStatus.Text = "label4";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.InfoText;
            this.label5.Location = new System.Drawing.Point(21, 26);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(137, 18);
            this.label5.TabIndex = 6;
            this.label5.Text = "Next Running Time:";
            // 
            // lbNextTime
            // 
            this.lbNextTime.AutoSize = true;
            this.lbNextTime.BackColor = System.Drawing.Color.LightSteelBlue;
            this.lbNextTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbNextTime.ForeColor = System.Drawing.Color.SeaShell;
            this.lbNextTime.Location = new System.Drawing.Point(154, 26);
            this.lbNextTime.Name = "lbNextTime";
            this.lbNextTime.Size = new System.Drawing.Size(46, 18);
            this.lbNextTime.TabIndex = 7;
            this.lbNextTime.Text = "label6";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Gray;
            this.label7.Location = new System.Drawing.Point(440, 92);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(110, 13);
            this.label7.TabIndex = 8;
            this.label7.Text = "Support by PCZhou V2.0";
            // 
            // rbSiteAMC
            // 
            this.rbSiteAMC.AutoSize = true;
            this.rbSiteAMC.BackColor = System.Drawing.Color.Transparent;
            this.rbSiteAMC.Checked = true;
            this.rbSiteAMC.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbSiteAMC.Location = new System.Drawing.Point(21, 47);
            this.rbSiteAMC.Name = "rbSiteAMC";
            this.rbSiteAMC.Size = new System.Drawing.Size(51, 19);
            this.rbSiteAMC.TabIndex = 9;
            this.rbSiteAMC.TabStop = true;
            this.rbSiteAMC.Text = "AMC";
            this.rbSiteAMC.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.rbSiteAMC.UseVisualStyleBackColor = false;
            this.rbSiteAMC.CheckedChanged += new System.EventHandler(this.rbSiteAMC_CheckedChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.LightSteelBlue;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.SeaShell;
            this.label8.Location = new System.Drawing.Point(3, 69);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(65, 18);
            this.label8.TabIndex = 10;
            this.label8.Text = "scrollbar";
            // 
            // rbSiteALG
            // 
            this.rbSiteALG.AutoSize = true;
            this.rbSiteALG.BackColor = System.Drawing.Color.Transparent;
            this.rbSiteALG.Location = new System.Drawing.Point(100, 48);
            this.rbSiteALG.Name = "rbSiteALG";
            this.rbSiteALG.Size = new System.Drawing.Size(46, 17);
            this.rbSiteALG.TabIndex = 11;
            this.rbSiteALG.TabStop = true;
            this.rbSiteALG.Text = "ALG";
            this.rbSiteALG.UseVisualStyleBackColor = false;
            this.rbSiteALG.CheckedChanged += new System.EventHandler(this.rbSiteALG_CheckedChanged);
            // 
            // timer2
            // 
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // tmStatus
            // 
            this.tmStatus.Tick += new System.EventHandler(this.tmStatus_Tick);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.Black;
            this.groupBox1.Location = new System.Drawing.Point(17, 119);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(433, 109);
            this.groupBox1.TabIndex = 12;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Information";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.SeaShell;
            this.label4.Location = new System.Drawing.Point(6, 20);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(350, 72);
            this.label4.TabIndex = 0;
            this.label4.Text = "Program Location: C:\\SAPCaculate   \r\nFunction: 1)Update SAP standard hour \r\n     " +
    "           2) submit  materials of which cost need to \r\n                    be r" +
    "ecalculated";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Transparent;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.Location = new System.Drawing.Point(21, 92);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(33, 21);
            this.button1.TabIndex = 13;
            this.button1.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Visible = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // rbSiteATH
            // 
            this.rbSiteATH.AutoSize = true;
            this.rbSiteATH.Location = new System.Drawing.Point(175, 48);
            this.rbSiteATH.Name = "rbSiteATH";
            this.rbSiteATH.Size = new System.Drawing.Size(47, 17);
            this.rbSiteATH.TabIndex = 14;
            this.rbSiteATH.TabStop = true;
            this.rbSiteATH.Text = "ATH";
            this.rbSiteATH.UseVisualStyleBackColor = true;
            this.rbSiteATH.CheckedChanged += new System.EventHandler(this.rbSiteATH_CheckedChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSteelBlue;
            this.ClientSize = new System.Drawing.Size(552, 237);
            this.Controls.Add(this.rbSiteATH);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.rbSiteALG);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.rbSiteAMC);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.lbNextTime);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lbStatus);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.RunNow);
            this.Controls.Add(this.label1);
            this.ForeColor = System.Drawing.SystemColors.Desktop;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "SAPCaculate V1.0";
            this.TransparencyKey = System.Drawing.Color.Lime;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button RunNow;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lbStatus;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lbNextTime;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.RadioButton rbSiteAMC;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.RadioButton rbSiteALG;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.Timer tmStatus;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.RadioButton rbSiteATH;
    }
}

