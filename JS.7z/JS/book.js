﻿var RootPath = "";
$(function () {
    RootPath = getRootPath();
$("#Sitechange").change(function () {
    getSites($("#Sitechange").find("option:selected").val());
});
function add(obj) {
    var badge = $(obj).attr("value");
    $.post("../Employee/SearchAttendees", { "Dept": "", "Name": "", "Badge": badge }, function (result) {
        var ds = JSON.parse(result);
        var body;
        for (var i = 0; i < ds.length; i++) {
            body += "<tr><td>" + ds[i]._dept + "</td><td>" + ds[i]._name + "</td><td>" + ds[i]._badge + "</td><td><i class=\"layui-icon\" style=\"font-size: 26px; color: #5FB878;\" value=" + ds[i]._badge + " onclick=\"del(this)\">&#xe640;</i></td></tr>";
        }
        $("#AttendessInfoGroup").append(body);
        layer.msg("Add Success");
    })
}
function del(obj) {
    $(obj).parents('tr').remove();
    layer.msg("Remove Success");
}
//将时间戳转化为时间
function ConvertTimestampToTime(current_date) {
    var date = new Date(current_date);
    var datetime = date.getFullYear() + "-" + ((date.getMonth() + 1) >= 10 ? (date.getMonth() + 1) : "0" + (date.getMonth() + 1)) + "-"
            + (date.getDate() < 10 ? "0" + date.getDate() : date.getDate()) + " "
            + (date.getHours() < 10 ? "0" + date.getHours() : date.getHours()) + ":"
            + (date.getMinutes() < 10 ? "0" + date.getMinutes() : date.getMinutes());
    return datetime;
}
/*yyyy-MM-dd hh:mm:ss*/
function convertTime(strDate, string) {
    var date = new Date(strDate);
    var y = date.getFullYear();
    var m = date.getMonth() + 1;
    m = m < 10 ? ('0' + m) : m;
    var d = date.getDate();
    d = d < 10 ? ('0' + d) : d;
    var h = date.getHours();
    var minute = date.getMinutes();
    minute = minute < 10 ? ('0' + minute) : minute;
    var str = ""
    if (string == "hm") {
        str = h + ":" + minute;
    } else {
        // str = y + "-" + m + "-" + d + " " + h + ":" + minute; 返回date+hour+minutes
        str = y + "-" + m + "-" + d;
    }
    return str;
};
//读取cookies
function getCookie(name) {
    var arr, reg = new RegExp("(^| )" + name + "=([^;]*)(;|$)");
    if (arr = document.cookie.match(reg))
        return unescape((arr[2]));
    else
        return null;
}
//设置cookie
function setCookie(name, value) {
    var exp = new Date();
    exp.setTime(exp.getTime() + 60 * 60 * 1000);
    document.cookie = name + "=" + encodeURI(value) + ";expires=" + exp.toGMTString() + ";path=/";
}
function formatDate(date) {
    var d = new Date(date),
      month = '' + (d.getMonth() + 1),
      day = '' + d.getDate(),
      year = d.getFullYear();

    if (month.length < 2) month = '0' + month;
    if (day.length < 2) day = '0' + day;

    return [year, month, day].join('-');
}
function getSites(n) {
    var tbody = '';
    $("#meetingInfo").empty();
    for (var i = 0; i <= n - 1; i++) {
        var siteid = 'Sites' + i;
        var roomid = 'Rooms' + i;
        var inputid = 'Input' + i;
        var attendessid = 'Attendess' + i;
        var inputHiddenId = 'inputHiddenId' + i;
        tbody += '<tr><td></td><td><select class="selectpicker" name="' + siteid + '"  id="' + siteid + '" data-width="90px" onchange="SiteSelectChange(this)" required ></select></td><td><select class="selectpicker" name="' + roomid + '" id="' + roomid + '" ></select></td><td><input class=\'layui-input\' id="' + attendessid + '" name="' + attendessid + '" width="20"/></td><td><input id="' + inputid + '"  name="' + inputid + '" class=\'layui-input\' width="40" onkeyup="keyup(this)"/><input type="hidden" id="' + inputHiddenId + '"/></td></tr>';
    }
    $("#meetingInfo").html(tbody);
    $.post(RootPath+'/Home/getSites', function (data) {
        var dt = JSON.parse(data);
        if (n == 1) {
            $("#Sitechange").selectpicker('val', 1);
        } else if (n == 2) {
            $("#Sitechange").selectpicker('val', 2);
        }
        var Site = '';
        for (var i = 0; i < dt.length; i++) {
            Site += '<option value=' + dt[i].ID + '>' + dt[i].Site + '</option>';
        }
        for (var j = 0; j <= n - 1; j++) {
            var siteid = 'Sites' + j;
            var roomid = 'Rooms' + j;

            $("#" + siteid).append(Site);

            $("#" + siteid).selectpicker('refresh');
            $("#" + siteid).selectpicker('render');
            if (j !== 0) {
                $("#" + siteid).selectpicker("val", []);
            }

            $("#" + roomid).selectpicker('refresh');
            $("#" + roomid).selectpicker('render');
        }
    })
}
function SiteSelectChange(obj) {
    var radio = document.getElementsByName('Type');
    var type = '';
    for (var i = 0; i < radio.length; i++) {
        if (radio[i].checked == true) {
            type = radio[i].value;
        }
    }
    $.ajax({
        type: "post",
        url: RootPath+"/M_Room/getFreeRooms",
        dataType: "json",
        data: { "Type": type, "stime": $("#test1").val() + " " + $("#stime").val(), "etime": $("#test1").val() + " " + $("#etime").val(), "site": $("#" + $(obj).attr("id")).val() },
        success: function (result) {
            var dt = JSON.parse(result);
            var option = '';
            for (var i = 0; i < dt.FreeRoom.length; i++) {
                option += '<option value=' + dt.FreeRoom[i]._id + '>' + dt.FreeRoom[i]._roomTitle + '</option>';
            }
            var RoomId = $(obj).attr("id").replace("Sites", "Rooms");
            $("#" + RoomId).empty();
            $("#" + RoomId).append(option);
            $("#" + RoomId).selectpicker('val', "");
            $("#" + RoomId).selectpicker('refresh');
            $("#" + RoomId).selectpicker('render');
        }
    })
}
function getFromRoom() {
    var length = $("#Sitechange").val();
    var sites = '';
    for (var i = 0; i < length; i++) {
        sites = sites + $("#" + 'Sites' + i).val() + ',';
    }
    var radio = document.getElementsByName('Type');
    var type = '';
    for (var i = 0; i < radio.length; i++) {
        if (radio[i].checked == true) {
            type = radio[i].value;
        }
    }
    $.ajax({
        type: "post",
        url: RootPath + "/M_Conference/getFreeRooms",
        dataType: "json",
        async: true,
        //cache:true,
        data: { "Type": type, "stime": $("#test1").val() + " " + $("#stime").val(), "etime": $("#test1").val() + " " + $("#etime").val(), "site": sites.trim(',') },
        success: function (result) {
            var dt = JSON.parse(result);
            console.log(dt);
            for (var i = 0; i < length; i++) {
                var option = '';
                var p = $("#" + 'Sites' + i).val();
                for (var j = 0; j < dt.FreeRoom.length; j++) {
                    if ($("#" + 'Sites' + i).val() == dt.FreeRoom[j]._siteid)
                        option += '<option value=' + dt.FreeRoom[j]._id + '>' + dt.FreeRoom[j]._roomTitle + '</option>';
                }
                $("#" + 'Rooms' + i).empty();
                $("#" + 'Rooms' + i).append(option);
                $("#" + 'Rooms' + i).selectpicker('val', "");
                $("#" + 'Rooms' + i).selectpicker('refresh');
                $("#" + 'Rooms' + i).selectpicker('render');
            }
        },
        error: function (data) {

        }
    })

}

function keyup(obj) {
    if (obj == null || obj == "") {
        return;
    }
    var inputHiddenId = $(obj).attr("id").replace("Input", "inputHiddenId");
    var input = $("#" + $(obj).attr("id")).val();
    var Res = "";
    if (checkNumber(input)) {
        Res = "Number";
    } else {
        Res = "Character";
    }
    $.ajax({
        type: "post",
        url: RootPath+"/Employee/SearchEmployee",
        dataType: "json",
        data: { "input": input, "inputType": Res },
        success: function (result) {
            var data = JSON.parse(result);
            if (data == null || data == '') {
                return;
            }
            $("#" + $(obj).attr("id")).autocomplete({
                minLength: 0,
                source: data,
                focus: function (event, ui) {
                    if (Res == "Number") {
                        $("#" + $(obj).attr("id")).val(ui.item.label);
                    } else {
                        $("#" + $(obj).attr("id")).val(ui.item.icon);
                    }
                    return false;
                },
                select: function (event, ui) {
                    if (Res == "Number") {
                        $("#" + $(obj).attr("id")).val(ui.item.icon);
                    } else {
                        $("#" + $(obj).attr("id")).val(ui.item.label);
                    }
                    $("#" + inputHiddenId).val(ui.item.value);
                    return false;
                }
            })
           .autocomplete("instance")._renderItem = function (ul, item) {
               if (Res == "Number") {
                   return $("<li style='z-index:19891015'>").append("<div>" + item.icon + "<br>" + item.desc + "</div>").appendTo(ul);
               } else {
                   return $("<li style='z-index:19891015'>").append("<div>" + item.label + "<br>" + item.desc + "</div>").appendTo(ul);
               }
           };
        },
        error: function () {
            return;
        },
    })
}
function disable(T) {
    RecurrenceRangeDisable(T);
    DailyDisable(T);
    WeeklyDisable(T);
    MonthlyDisable(T);
}
function RecurrenceRangeDisable(T) {
    var date = document.getElementsByName('date');
    for (var i = 0; i < date.length; i++) {
        if (T == true) {
            $(date[i]).attr("disabled", "disabled");

        } else if (T == false) {
            $(date[i]).removeAttr("disabled");
        }
    }
    if (T == true) {
        $("#radioUntil").attr("disabled", "disabled");
        $("#For").attr("disabled", "disabled");
    } else {
        $("#radioUntil").removeAttr("disabled");
        $("#For").removeAttr("disabled");
        layui.use(['form'], function () {
            var form = layui.form;
            form.render("radio");
        })
    }
}
function DailyDisable(T) {
    if (T == true) {
        $("#EDay").attr("disabled", "disabled");
        $("#EWeekly").attr("disabled", "disabled");
    } else if (T == false) {
        $("#EDay").removeAttr("disabled");
        $("#EWeekly").removeAttr("disabled");

    }
    layui.use(['form'], function () {
        var form = layui.form;
        form.render("radio");
    })
}
function WeeklyDisable(T) {
    var WeeklyRadio = document.getElementsByName('Weekly');
    if (T == true) {
        for (var i = 0; i < WeeklyRadio.length; i++) {
            $(WeeklyRadio[i]).attr("disabled", "disabled");

            $('input:checkbox[name=Weekly]')[i].checked = false;

        }
    } else {
        for (var i = 0; i < WeeklyRadio.length; i++) {
            $(WeeklyRadio[i]).removeAttr("disabled");

        }
    }

    layui.use(['form'], function () {
        var form = layui.form;
        form.render("checkbox");
    })
}
function MonthlyDisable(T) {
    if (T == true) {
        $("#Every").attr("disabled", "disabled");
        $("#Monthly").attr("disabled", "disabled");
        $("#eFirst").attr("disabled", "disabled")
        $("#eSecond").attr("disabled", "disabled")
    } else {
        $("#Every").removeAttr("disabled");
        $("#Monthly").removeAttr("disabled");
        $("#eFirst").removeAttr("disabled");
        $("#eSecond").removeAttr("disabled");
    }
    layui.use(['form'], function () {
        var form = layui.form;
        form.render("radio");
    })
    $('#eFirst').selectpicker('refresh');
    $('#eFirst').selectpicker('render');
    $('#eSecond').selectpicker('refresh');
    $('#eSecond').selectpicker('render');

}

function SwitchRenderDaily() {
    layui.use(['form'], function () {
        var form = layui.form
        form.on('radio(EDay)', function (data) {
            if (data.elem.checked) {
                $('input:radio[name=EDay]')[0].checked = false;
            } else {
                $('input:radio[name=EDay]')[0].checked = true;
            }
            form.render("radio");
        });
        form.on('radio(EWeekly)', function (data) {
            if (data.elem.checked) {
                $('input:radio[name=EWeekly]')[0].checked = false;
            } else {
                $('input:radio[name=EWeekly]')[0].checked = true;
            }
            form.render("radio");
        });
    })
}
/*正则表达式 验证字符串是否是数字*/
function checkNumber(Obj) {
    var reg = /^[0-9]+.?[0-9]*$/;
    if (reg.test(Obj)) {
        return true;
    }
    return false;
}
/*正则表达式 验证字符串是否是字母*/
function CheckCharacter(Obj) {
    var reg = /^[A-Za-z]+$/;
    if (reg.test(Obj)) {
        return true;
    }
    return false;
}
function DateAdd(i) {
    var now = new Date();
    var result = ConvertTimestampToTime(now.setDate(now.getDate() + i));
    return result;
}

function AddDays(dayIn) {
    var date = new Date();
    var myDate = new Date(date.getTime() + dayIn * 24 * 60 * 60 * 1000);
    var year = myDate.getFullYear();
    var month = myDate.getMonth() + 1;
    var day = myDate.getDate();
    CurrentDate = year + "-";
    if (month >= 10) {
        CurrentDate = CurrentDate + month + "-";
    }
    else {
        CurrentDate = CurrentDate + "0" + month + "-";
    }
    if (day >= 10) {
        CurrentDate = CurrentDate + day;
    }
    else {
        CurrentDate = CurrentDate + "0" + day;
    }
    return CurrentDate;
}
function setWeeklyCheck() {
    layui.use(['form'], function () {
        var form = layui.form;
        var date = new Date();
        var a = date.getDay();
        var title = "";
        switch (a) {
            case 1:
                title = "Mon";
                break;
            case 2:
                title = "Tue";
                break;
            case 3:
                title = "Wed";
                break;
            case 4:
                title = "Thu";
                break;
            case 5:
                title = "Fri";
                break;
            case 6:
                title = "Sta";
                break;
            case 7:
                title = "Sun";
                break;
        }
        var WeeklyRadio = document.getElementsByName('Weekly');
        for (var i = 0; i < WeeklyRadio.length; i++) {
            if ($('input:checkbox[name=Weekly]')[i].title == title) {
                $('input:checkbox[name=Weekly]')[i].checked = true;
            }
        }
        form.render("checkbox");
    })
}
/*获取服务器根路径*/
function getRootPath() {
    var curPath = window.document.location.href;
    //var pathName = window.document.location.pathname;
    //var index = curPath.indexOf(pathName);
    //var localhostPaht = curPath.substring(0, index);
    //var projectName = pathName.substring(0, pathName.substr(1).indexOf('/') + 1);
    //return (localhostPaht + projectName);
    return curPath;
}
})