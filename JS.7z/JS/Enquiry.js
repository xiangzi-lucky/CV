﻿$(function () {
    $.ajax({
        type: "post",
        url: "./Home/getSites",
        success: function (result) {
            var dt = JSON.parse(result);
            var Site = '';
            for (var i = 0; i < dt.length; i++) {
                Site += '<option value=' + dt[i].ID + '>' + dt[i].Site + '</option>';
            }
            $("#Site").append(Site);
            $("#Site").selectpicker('val', '');
            $("#Site").selectpicker('refresh');
            $("#Site").selectpicker('render');
        }
    });
    layui.use('laydate', function () {
        var laydate = layui.laydate;
        //执行一个laydate实例
        laydate.render({
            elem: '#stime', //指定元素
            showBottom: false,//是否显示底部的按钮
            lang: 'en',
            calendar: true,
        });
        laydate.render({
            elem: '#etime',
            showBottom: false,
            lang: 'en',
            calendar: true,
        });
    });

    $("#input").keyup(function () {
        var input = $("#input").val();
        if (input == null || input == "") {
            return;
        }
        var reg = /^[0-9]+.?[0-9]*$/;
        var Res = '';
        if (reg.test(input)) {
            Res = "Number";
        } else {
            Res = "Character";
        }
        $.ajax({
            type: "post",
            url: "./Employee/SearchEmployee",
            dataType: "json",
            data: { "input": input, "inputType": Res },
            success: function (result) {
                var data = JSON.parse(result);
                if (data == null || data == '') {
                    return;
                }
                $("#input").autocomplete({
                    minLength: 0,
                    source: data,
                    focus: function (event, ui) {
                        if (Res == "Number") {
                            $("#input").val(ui.item.label);
                        } else {
                            $("#input").val(ui.item.icon);
                        }
                        return false;
                    },
                    select: function (event, ui) {
                        if (Res == "Number") {
                            $("#input").val(ui.item.icon);
                        } else {
                            $("#input").val(ui.item.label);
                        }
                        $("#hinput").val(ui.item.value);
                        return false;
                    }
                })
               .autocomplete("instance")._renderItem = function (ul, item) {
                   if (Res == "Number") {
                       return $("<li>").append("<div>" + item.icon + "<br>" + item.desc + "</div>").appendTo(ul);
                   } else {
                       return $("<li>").append("<div>" + item.label + "<br>" + item.desc + "</div>").appendTo(ul);
                   }
               };
            }

        })
    });
    $("#Query").click(function (){
        $.post('./Enquiry/Query', { "site": $("#Site").val(), "roomid": $("#Room").val(), "sdate": $("#stime").val(), "edate": $("#etime").val(), "badge": $("#input").val() }, function (result) {
            console.log(result);

        }, "json")
    })
      
})