﻿/*获取服务器根路径*/
function getRootPath()
{
    //var curPath = window.document.location.href;
    //var pathName = window.location.pathname.substring(1).split("/");
    //var webName = pathName == '' ? '' : pathName[0];
    //if (webName == "")
    //{
    //    return window.location.protocol + '//' + window.location.host;
    //}
    //else
    //{
    //    return window.location.protocol + '//' + window.location.host + '/' + webName;
    //}
    var curPath = window.document.location.href;
    var pathName = window.location.pathname.substring(1);
    var webName = pathName == '' ? '' : pathName;
    if (webName == "") {
        return window.location.protocol + '//' + window.location.host;
    }
    else {
        return window.location.protocol + '//' + window.location.host + '/' + webName;
    }
}
function getRootPath2() {
    var curPath = window.document.location.href;
    var pathName = window.location.pathname.substring(1).split("/");
    var webName = pathName[0] == 'StaffHouseBookingAdmin' ? pathName[0] :'';
    if (webName == "") {
        return window.location.protocol + '//' + window.location.host;
    }
    else {
        return window.location.protocol + '//' + window.location.host + '/' + webName;
    }
}

/*yyyy-MM-dd hh:mm:ss*/
function convertTime(strDate, string) {
    var date = new Date(strDate);
    var y = date.getFullYear();
    var m = date.getMonth() + 1;
    m = m < 10 ? ('0' + m) : m;
    var d = date.getDate();
    d = d < 10 ? ('0' + d) : d;
    var h = date.getHours();
    var minute = date.getMinutes();
    minute = minute < 10 ? ('0' + minute) : minute;
    var str = ""
    if (string == "hm") {
        str = h + ":" + minute;
    } else {
        // str = y + "-" + m + "-" + d + " " + h + ":" + minute; 返回date+hour+minutes
        str = y + "-" + m + "-" + d;
    }
    return str;
};
/*将时间戳转化为时间*/
function ConvertTimestampToTime(current_date) {
    var date = new Date(current_date);
    var datetime = date.getFullYear() + "-" + ((date.getMonth() + 1) >= 10 ? (date.getMonth() + 1) : "0" + (date.getMonth() + 1)) + "-"
            + (date.getDate() < 10 ? "0" + date.getDate() : date.getDate()) + " "
            + (date.getHours() < 10 ? "0" + date.getHours() : date.getHours()) + ":"
            + (date.getMinutes() < 10 ? "0" + date.getMinutes() : date.getMinutes());
    return datetime;
}
//设置cookies 
function setCookie(name, value) {
    var exp = new Date();
    exp.setTime(exp.getTime() + 60 * 60 * 1000);
    document.cookie = name + "=" + encodeURI(value) + ";expires=" + exp.toGMTString() + ";path=/";
}
//读取cookies 
function getCookie(name) {
    var arr, reg = new RegExp("(^| )" + name + "=([^;]*)(;|$)");

    if (arr = document.cookie.match(reg))

        return unescape(arr[2]);
    else
        return null;
}
/*删除Cookie*/
function delCookie(name) {
    var exp = new Date();
    exp.setTime(exp.getTime() - 1);
    var cval = getCookie(name);
    if (cval != null)
        document.cookie = name + "=" + cval + ";expires=" + exp.toGMTString();
}

function getNowFormatDate() {
    var date = new Date();
    var seperator1 = "-";
    var seperator2 = ":";
    var month = date.getMonth() + 1;
    var strDate = date.getDate();
    if (month >= 1 && month <= 9) {
        month = "0" + month;
    }
    if (strDate >= 0 && strDate <= 9) {
        strDate = "0" + strDate;
    }
    var currentdate = date.getFullYear() + seperator1 + month + seperator1 + strDate
            + " " + date.getHours() + seperator2 + date.getMinutes()
            + seperator2 + date.getSeconds();
    return currentdate;
}


