﻿$(function () {
    var RootPath = getRootPath();
    layui.use(['layer', 'element'], function () {
        var $ = layui.jquery,
            layer = layui.layer,
            element = layui.element; //Tab的切换功能，切换事件监听等，需要依赖element模块
            //监听Tab切换
            element.on('tab(demo)', function (e) {
                var lay_id = $(this).attr("lay-id");
                $("#tabid").val(lay_id);
                $("#room").empty();
                $('#room').selectpicker('refresh');
                $('#room').selectpicker('render');
                var startDate = ConvertTimestampToTime($(".scheduler").dxScheduler("instance").option("currentDate")).substring(0,10);                         
                $.post(RootPath + '/M_Conference/FirstLogin', { "lay_id": $("#tabid").val(), "startdate": startDate }, function (result) {
                    var dt = JSON.parse(result);
                    scheduler(dt.Conference, dt.Resource, startDate);                                 
                })               
            })
        // 监听Tab删除
        $(".layui-tab").on("click", function (e) {
            if ($(e.target).is(".layui-tab-close")) {
                var layid = $(e.target).parent().attr("lay-id");
                $.post(RootPath + '/M_MyTabList/DelTab', { "layid": layid }, function (data) {
                    if (JSON.parse(data) == "true") {
                        layer.msg("Delete Success", { time: 4000, icon: 6 });
                    } else {
                        layer.msg("Delete Failed", { time: 4000, icon: 5 });
                    }
                })
            }        
        })
        //触发事件
        var active = {
            tabAdd: function () {
                layer.open({
                    type: 1,
                    title: false, //不显示标题栏
                    closeBtn: false,
                    area: '300px;',
                    shade: 0.3,
                    id: 'LAY_layuipro', //设定一个id，防止重复弹出
                    resize: false,
                    btn: ['submit', 'cancle'],
                    btnAlign: 'c',
                    moveType: 1, //拖拽模式，0或者1
                    content: '<div style="padding: 50px; line-height: 22px; background-color: #FFFFFF; color: #fff; font-weight: 300;"><span>Name</span>:<input class=\"layui-input\" type=\"text\" id=\"InputTabName\" placeholder=\"input name\" required/></div>',
                    success: function (layero) {
                        var btn = layero.find('.layui-layer-btn');
                        btn.find('.layui-layer-btn0').click(function () {
                            var name = $("#InputTabName").val();
                            $.post(RootPath + "/M_MyTabList/AddTab", { "TabName": name }, function (data) {
                                var dt = JSON.parse(data);
                                element.tabAdd('demo', {
                                    title: dt.Adt._TabName,
                                    id: dt.Adt._id
                                })                          
                                if (dt.Flag==true) {
                                    $("#UlContent li:first").addClass("layui-this");
                                    if ($("#tabid").val() == "") {
                                        $("#tabid").val(dt.Adt._id);
                                    }
                                }
                            })
                        })
                    }
                });
            },
            tabDelete: function (othis) {
                //删除指定Tab项
                element.tabDelete('demo', '44');
                othis.addClass('layui-btn-disabled');
            },
            tabChange: function () {
                //切换到指定Tab项
                element.tabChange('demo', '22');
            },
            tabEdit: function (e) {
                //编辑一个Tab项
                var layid = $("#tabid").val();
                $.post(RootPath + "/M_MyTabList/getTabName", { "layid": layid }, function (data) {
                  
                    if (data !== null || data !== undefined || data !== '') {
                        var a = JSON.parse(data);
                        layer.open({
                            type: 1,
                            title: false, //不显示标题栏
                            closeBtn: false,
                            area: '300px;',
                            shade: 0.3,
                            id: 'LAY_layuipro', //设定一个id，防止重复弹出
                            resize: false,
                            btn: ['submit', 'cancle'],
                            btnAlign: 'c',
                            moveType: 1, //拖拽模式，0或者1
                            content: '<div style="padding: 50px; line-height: 22px; background-color: #FFFFFF; color: #fff; font-weight: 300;"><span>Name</span>:<input class=\"layui-input\" type=\"text\" id=\"EditTabName\" placeholder=\"input name\"/></div>',
                            success: function (layero) {
                                $("#EditTabName").val(a);
                                var btn = layero.find('.layui-layer-btn');
                                btn.find('.layui-layer-btn0').click(function () {
                                    var name = $("#EditTabName").val();
                                    $.post(RootPath + "/M_MyTabList/UpdateTab", { "layid": layid, "updateTabName": name }, function (data) {
                                        var dt = JSON.parse(data);
                                        if (dt == "true") {
                                            $.post(RootPath+'/Home/Load', function (data) {
                                                var dt = JSON.parse(data);
                                                $("#UlContent").empty();
                                                for (var i = 0; i < dt.length; i++) {
                                                    element.tabAdd('demo', {
                                                        title: dt[i].TabName,
                                                        id: dt[i].ID,
                                                    })
                                                    if (dt[i].ID == layid) {
                                                        $("#UlContent li:first").addClass("layui-this");
                                                        $("#tabid").val(dt[i].ID);
                                                    }
                                                }
                                            }, "JSON")
                                        }
                                    })
                                })
                            }
                        });
                    } else {
                        layer.msg("no data");
                    }
                })
            }
        };
        /*监听添加按钮*/
        $('#menu').on('click', function () {
            var othis = $(this), type = othis.context.lastElementChild.dataset.type; // type = type = othis.data('type');
            active[type] ? active[type].call(this, othis) : '';
        });
        /*监听编辑按钮*/
        $('#edit').on('click', function () {
            var othis = $(this), type = othis.context.lastElementChild.dataset.type;
            active[type] ? active[type].call(this, othis) : '';
        });
    });
  
    //function bindingScheduler() {
    //    var roomid = $('#room').val();
    //    var lay_id = $("#tabid").val();
    //    var siteIds = $("#Sites").val();
    //    var CurrentDate = $(".scheduler").dxScheduler("instance").option("currentDate");
    //    var startdate = ConvertTimestampToTime(CurrentDate);
    //    $.post(RootPath + "/M_Conference/getConference", { "roomid[]": roomid, "lay_id": lay_id, "startdate": startdate, "siteIds[]": siteIds }, function (data) {
    //        var dt = JSON.parse(data);           
    //        if (dt !== null || dt !== undefined || dt !== "") {
    //            scheduler(dt.Conference, dt.Resource, CurrentDate);
    //        } else {
    //            scheduler("", "", CurrentDate);
    //        }
    //    })
    //}
    //function scheduler(Conference, Room, Date) {
    //    var isSelectionStarted = false;
    //    var target;
    //    var startData;
    //    //  拖动功能
    //    var downHandler = function (e) {
    //        var el = $(e.target);
    //        if (el.hasClass("dx-scheduler-date-table-cell")) {
    //            startData = el.data().dxCellData;
    //            isSelectionStarted = true;
    //            target = e.target;
    //        }
    //    }
    //    var upHandler = function (e) {
    //        e.cancel = true;
    //        var el = $(e.target);
    //        if (el.hasClass("dx-scheduler-date-table-cell") && target !== e.target) {
    //            if (isSelectionStarted) {
    //                StartTime = startData.startDate;
    //                EndTime = el.data().dxCellData.endDate;
    //            }
    //        }
    //        isSelectionStarted = false;
    //        target = null;
    //        startData = null;
    //    }
    //    // end 拖动功能   
    //    $(".scheduler").dxScheduler({
    //        views: ["day"],
    //        currentView: "day",
    //        currentDate: Date,
    //        useDropDownViewSwitcher: false,
    //        firstDayOfWeek: 0,
    //        dataSource: Conference,
    //        visible: true,
    //        editing: {
    //            allowAdding: false,
    //            allowUpdating: false,
    //            //allowDeleting: false,
    //            //allowDragging:false,
    //        },
    //        dateSerializationFormat: "yyyy-MM-dd",
    //        startDayHour: 8,
    //        endDayHour: 23,
    //        noDataText: '<h1>No Data!!!</h1>',
    //        groups: ['ResourceId'],
    //        resources: [{
    //            fieldExpr: "ResourceId",
    //            allowMultiple: true,
    //            dataSource: Room,
            
    //        }],
    //        width: "100%",
    //        height: 600,
    //        crossScrollingEnabled: true,
    //        onCellClick: function (e) {
    //            var hm = "hm";
    //            setCookie("ResourceId", e.cellData.groups.ResourceId);
    //            setCookie("StartTime", convertTime(e.cellData.startDate, hm));
    //            setCookie("date", convertTime(e.cellData.startDate, "date"))
    //            setCookie("EndTime", convertTime(e.cellData.endDate, hm));
    //            layer.open({
    //                type: 1,
    //                area: ['880px', '88%'],
    //                maxmin: true,
    //                zIndex: 2,
    //                title: 'Create',
    //                content: $('#book'),
    //                end: function () {
    //                    $("#recurrenceContent").hide();
    //                    $("#inviteContent").hide();
    //                    $("#addContent").hide();
    //                    $('#form')[0].reset();
    //                }

    //            })   
    //            e.cellData.cancel = false;
    //        },
    //        onAppointmentFormCreated: function (e) {
               
    //        },
    //        onAppointmentDblClick: function (e) {
    //           // e.cancel = true;
    //               var appointmentData = e.appointmentData;
    //               var targetedAppointmentData = e.targetedAppointmentData;
    //        },
    //        onAppointmentClick: function (e) {

    //            var no = e.cellData.ownerId;
    //            if (no == "")

    //                return;

    //            console.log(e);
    //            console.log(e.cancel);
    //            layer.msg(no);
    //            e.cellData.cancel = false;
    //        },
    //        resourceCellTemplate: function (cellData, index, container) {
    //            var name = $("<div>")
    //                   .addClass("name")
    //                   .css({ "backgroundColor": "#fff", "width": "80%", "float": "left" })
    //                   .append($("<h2 style='margin-top:8px'>")
    //                   .text(cellData.text));
    //            var Remove = "";
    //            if (cellData.id.length != 8) {
    //                Remove = $("<div>")
    //                             .addClass("RemoveIcon")
    //                             .html("<span class=\"RemoveIconSelect\"><input  value=\"" + cellData.id + "\" style=\"display:none\"/><i class=\"layui-icon\" >&#x1006;</i></span>")
    //            }
    //            return $("<div>").append([name, Remove]);
    //        },
    //        timeCellTemplate: function (cellData, index, container) {
    //            container.parent().html('<td class="dx-scheduler-time-panel-cell" style="width:45px"><span style="font-size: 15px">' +
    //            cellData.text + '</span></td>' +
    //            '<td class="dx-scheduler-time-panel-cell" style="width:45px"><span style="font-size: 15px">' +
    //             cellData.text + "</span></td>"
    //            );
    //        },
    //        onOptionChanged: function (data) {
    //            //if(data.name == "currentView"){DatumNavigatie();}
    //            // if(data.name == "currentDate"){DatumNavigatie();}
    //            //scheduler.scrollToTime(7,0);
    //            // console.log(data);
    //            //时间改变
    //            switch (data.name) {
    //                case "currentDate":
    //                    var roomid = $('#room').val();
    //                    var lay_id = $("#tabid").val();
    //                    var siteIds = $("#Sites").val();
    //                    var date = $(".scheduler").dxScheduler("instance").option("currentDate");
    //                    var startdate = ConvertTimestampToTime(date);
    //                    var stop = "";
    //                    $.ajax({ 
    //                        type: "post",
    //                        url: RootPath + "/M_Conference/getConference",
    //                        data: { "roomid[]": roomid, "lay_id": lay_id, "startdate": startdate, "siteIds": siteIds },
    //                        beforeSend: function () {
    //                            stop = layer.load(0, { shade: [0.3, '#fff'] });
    //                        },
    //                        success: function (data) {
    //                            var result = JSON.parse(data);
    //                            scheduler(result.Conference, result.Room, date);
    //                            layer.close(stop);
    //                        },
    //                        error: function (XMLHttpRequest, textStatus, errorThrown) {
    //                            layer.msg("textStatus = " + textStatus + ", XMLHttpRequest.status = " + XMLHttpRequest.status + ", XMLHttpRequest.readyState = " + XMLHttpRequest.readyState);
    //                        },
    //                        complete: function () {
    //                        layer.close(stop);
    //                    }
    //                    })
    //                    break;
    //                case "currentView":
    //                    break;
    //            }
    //        },
    //        onContentReady: function (arg) {
    //            $(arg.element).off("dxpointerdown", downHandler);
    //            $(arg.element).off("dxpointerup", upHandler);
    //            $(arg.element).on("dxpointerdown", downHandler);
    //            $(arg.element).on("dxpointerup", upHandler);
    //        },
    //    }).dxScheduler("instance");
    //    $(".RemoveIconSelect").click(function () {
    //        var roomid = $(this).children("input").val();
    //        var TabID = $("#tabid").val();
    //        try {
    //            $.post(RootPath + '/M_Room/DeleteRoom', { "roomid": roomid, "TabID": $("#tabid").val() }, function (result) {
    //                var result = JSON.parse(result);

    //                if (result == true) {
    //                    layer.msg("Delete Success", { time: 4000, icon: 6 });
    //                    var Resourceid = $("#room").val();
    //                    if (Resourceid !== null) {
    //                        var result = [];
    //                        for (var i = 0; i < Resourceid.length; i++) {
    //                            if (Resourceid[i] != roomid) {
    //                                result.push(Resourceid[i]);
    //                            }
    //                        }
    //                        $("#room").selectpicker('val', result);
    //                        $("#room").selectpicker('refresh');
    //                        $("#room").selectpicker('render');
                            
    //                    }
    //                    bindingScheduler();
    //                } else {
    //                    layer.msg("Delete Failed", { time: 4000, icon: 5 });
    //                }
    //            })
    //        } catch (e) {
    //            layer.msg("error:" + e);
    //        }
    //    })
    //}
    
})