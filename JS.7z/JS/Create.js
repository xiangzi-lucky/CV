﻿var RootPath = getRootPath2();
var lay = layui.use(['form', 'laydate'], function () {
    layer = layui.layer;
});
//日历控件
$(function () {

    $("#datepicker").datepicker({
        numberOfMonths: 3,
        minDate: 0,
        altField: '#showDate',
        width: 500
    });
    BindTime();
    SelectSites();
    BindTime1();
    instantiationLayui();
});

//事件操作
var eventFun = {
    setStep: function (index) {
        $("#st").html($("#stime").val());
        $("#et").html($("#etime").val());
        $("#date").html($("#datepicker").val());
        for (var i = 2; i <= index; i++) {
            $("#StepId" + i).css("color", "red");

        }

        for (var j = index + 1; j <= 5; j++) {
            $("#StepId" + j).css("color", "");
            //$("#step" + j).hide();
            //$("#datepicker").hide();
        }
        for (var j = 1; j <= 5; j++) {
            $("#step" + j).hide();
            $("#datepicker").hide();
        }
        if (index == 1) {
            $("#datepicker").show();
        }
        $("#step" + index).show();
    }
};

//checkbox
function CheckType1() {
    $("#checkbox2").attr("checked", false)
    $("#s_room").empty();
    $("#s_site").empty();
    $("#typename").html("Normal Conference");
    SelectSites();
    $("#rlab").hide();
}
function CheckType2() {
    $("#checkbox1").attr("checked", false)
    $("#s_room").empty();
    $("#s_site").empty();
    $("#typename").html("Video Conference");
    SelectSites();
    $("#rlab").hide();
}

//绑定时间
function BindTime() {
    $.ajax({
        type: "post",
        async: true,
        contentType: "application/json",
        url: RootPath + "/M_TimeScale/getTimeScale",
        //url: "@Url.Action("getTimeScale", "M_TimeScale")",
        success: function (data) {
            var result = JSON.parse(data);
            //$("#test1").val(SelectDate);
            var Soption = '';
            var Eoption = '';
            for (var i = 0; i < result.length; i++) {
                if (i != result.length - 1) {
                    Soption += '<option value=' + result[i].value + '>' + result[i].value + '</option>';
                }
                if (i > 0) {
                    Eoption += '<option value=' + result[i].value + '>' + result[i].value + '</option>';
                }
            }
            var st = currentTime()[0];
            var et = currentTime()[1];
            $("#stime").html(Soption);
            $("#etime").html(Eoption);
            $('#stime').selectpicker('refresh');
            $('#stime').selectpicker('render');
            $('#stime').selectpicker('val', st);
            $('#etime').selectpicker('refresh');
            $('#etime').selectpicker('render');
            $('#etime').selectpicker('val', et);
        },
    })
}
function BindTime1() {
    $.ajax({
        type: "post",
        async: true,
        contentType: "application/json",
        url: RootPath + "/M_TimeScale/getTimeScale",
        //url: "@Url.Action("getTimeScale", "M_TimeScale")",
        success: function (data) {
            var result = JSON.parse(data);
            //$("#test1").val(SelectDate);
            var Soption = '';
            var Eoption = '';
            for (var i = 0; i < result.length; i++) {
                if (i != result.length - 1) {
                    Soption += '<option value=' + result[i].value + '>' + result[i].value + '</option>';
                }
                if (i > 0) {
                    Eoption += '<option value=' + result[i].value + '>' + result[i].value + '</option>';
                }
            }
            $("#starttime").html(Soption);
            $("#endtime").html(Eoption);
            var st = $("#stime").val();
            var et = $("#etime").val();
            $('#starttime').selectpicker('refresh');
            $('#starttime').selectpicker('render');
            $('#starttime').selectpicker('val', st);
            $('#endtime').selectpicker('refresh');
            $('#endtime').selectpicker('render');
            $('#endtime').selectpicker('val', et);
        },
    })
}
//获取当前时间
function currentTime() {

    var stime = "";
    var etime = "";
    var myDate = new Date();
    var hh = myDate.getHours();            //时
    var mm = myDate.getMinutes();          //分
    if (mm > 30) {
        stime = hh + 1 + ":00";
        etime = hh + 1 + ":30";
    }
    else if (mm == 00) {
        stime = hh + ":00";
        etime = hh + ":30";
    }
    else {
        stime = hh + ":30";
        etime = hh + 1 + ":00";
    }
    var arr = new Array(2);
    arr[0] = stime;
    arr[1] = etime;
    return arr;     //获取当前时间
}

//绑定sites
function SelectSites() {
    var content = "<div><span class=\"box-title font\">* Please select site</span></div>";
    $.ajax({
        type: "post",
        async: true,
        contentType: "application/json",
        url: RootPath + "/M_Site/getSites",
        success: function (result) {
            var dt = JSON.parse(result);
            content += "<div class=\"btn-group\" role=\"group\" aria-label=\"...\">";
            for (var i = 0; i < dt.length; i++) {
                content += "<button type=\"button\" class=\"btn btn-default site\" id=\"site" + dt[i]._id + "\" onclick=\"SelectRooms(" + dt[i]._id + ") \" style=\"Margin:1px; height:36px; width: 64px;\">" + dt[i]._site + "</button>"
            }
            content += "</div>";
            $("#s_site").append(content);
        },
    })
}

//绑定room
function SelectRooms(site) {
    var status = "1";
    if (checkbox2.checked) {
        //$("div").remove("#der.blue");
        status = "0";
    }
    var stime = $("#datepicker").val() + " " + $("#stime").val();
    var etime = $("#datepicker").val() + " " + $("#etime").val();
    $.ajax({
        type: "post",
        async: true,
        contentType: "application/json",
        url: RootPath + "/M_Room/getFreeRooms",
        dataType: "json",
        data: JSON.stringify({ "Type": status, "stime": stime, "etime": etime, "site": site }),
        success: function (result) {
            var dt = JSON.parse(result);
            if (dt.FreeRoom.length > 0) {          //判定是否有房间
                if ($("#site" + site).hasClass("btn btn-danger site")) {
                    $("#site" + site).attr("class", "btn btn-default site");
                    //if (checkbox1.checked)
                    //    $("button[class$='site']").attr("disabled", false);
                    $("#con" + site).remove();
                }
                else {
                    $("#rlab").show();
                    if (checkbox1.checked) {  //normal会议只能选择一个site
                        $("button[class$='site']").attr("class", "btn btn-default site");
                        $("#site" + site).attr("class", "btn btn-danger site");
                        $("#s_room").empty();
                    }
                    else {
                        $("#site" + site).attr("class", "btn btn-danger site");
                    }
                    //var content = "<span class=\"box-title fontsize\">* Please select room</span><div style=\"display:block\">";
                    var content = "<div id=\"con" + site + "\" class=\"blue\"><span><font style=\"font-size:20px\">" + dt.FreeRoom[0]._site + ":</font></span>";
                    for (var i = 0; i < dt.FreeRoom.length; i++) {
                        content += "<a id=\"ar" + dt.FreeRoom[i]._id + "\" title=\"" + dt.FreeRoom[i]._room + "\r\n6seat\r\next:12345\r\ncomputer\r\n\" id=\"room" + dt.FreeRoom[i]._id + "\" onclick=\"selectrooms(" + dt.FreeRoom[i]._id + ")\"><u>" + dt.FreeRoom[i]._room + "</u></a>&nbsp &nbsp";
                    }
                    content += "</div>";
                    $("#s_room").append(content);
                }
            }
        },
    })
}

//选取room
function selectrooms(roomid) {
    var roomids = "";
    if ($("#ar" + roomid).hasClass("alert-danger room")) {
        $("#ar" + roomid).attr("class", "alert-default room")
        var roomids = $("#rooms").val().replace(roomid + ",", "");
    }
    else {
        if (checkbox1.checked) {        //normal会议只能选择一个房间
            $("a[class$='room']").attr("class", "alert-default room");
            $("#ar" + roomid).attr("class", "alert-danger room")
            roomids = roomid;
        }
        else {
            $("#ar" + roomid).attr("class", "alert-danger room")
            roomids = $("#rooms").val() + roomid + ",";
        }
    }
    $("#rooms").val(roomids);
}

//绑定roomdetail
$(document).ready(function () {
    $("#next1").click(function () {
        startdate();
        $("#roomdetail").empty();
        var roomids = $("#rooms").val();
        $.ajax({
            type: "post",
            async: true,
            url: RootPath + "/M_Room/getRoomById",
            data: "ResourceId=" + roomids,
            success: function (result) {
                var dt = JSON.parse(result);
                var content = "<table class=\"table table-bordered\"><tr><th>Room</th><th>Attendees *</th><th>Contact Person *</th></tr>";
                if (roomids == "" || roomids == undefined || roomids == null) {          //判定是否选择了房间
                }
                else {
                    for (var i = 0; i < dt.length; i++) {
                        content += "<tr><td><input id=\"Roomid" + i + "\" type=\"hidden\" value=\"" + dt[i]._id + "\" /><input id=\"Sites" + i + "\" type=\"hidden\" value=\"" + dt[i]._site + "\" /><input id=\"Siteid" + i + "\" type=\"hidden\" value=\"" + dt[i]._siteid + "\" />" + dt[i]._room + "</span></td><td contentEditable=\"true\">"
                                + "<input type=\"text\" class=\"form-control\" style=\"width:70%\" id=\"Attendess" + i + "\"placeholder=\"请输入名称\">"
                                + "</td><td contentEditable=\"true\"><input type=\"text\" onkeyup=\"keyup(this)\" class=\"form-control\" id=\"Input" + i + "\" placeholder=\"请输入名称\" /><input type=\"hidden\" id=\"inputHiddenId" + i + "\" /></td></tr>";
                    }
                    content += "</table>";
                    $("#roomdetail").append(content);
                }
            },
        })
        $.ajax({
            type: "post",
            async: true,
            url: RootPath + "/M_Employee/CurrentUserInfo",
            success: function (data) {
                var dt = JSON.parse(data);
                $("#Input").val(dt._name);
                $("#inputHiddenId").val(dt._badge);
            }
        })
    });
});

//创建会议
function save() {
    var flag = $("#form").valid();
    if (!flag) {
        return;
    }
    var mymeetingdatasource, no, type, subject, notes, recurrence, operator, contact, site, description, status, applicant, appname, contactname, datesubject, datenotes, uid, href, room, roomip, MaxNoOfVCConnection, roomadmin, remark, location, appext,
    contactext, OSAremark, Ext, badge, time, meetingdesc, siteid, roomid, attendees, ver, Seat, startdate, enddate, appdate,
    opdate, starttime, endtime, c_time, confirm, confirmCheck, ignoreAttendees, sendUpdate, needConfirm;
    type = "1";
    if (checkbox2.checked) {
        type = "0";
    }
    notes = $("#notes").val();
    appname = $("#Input").val();
    applicant = $("#inputHiddenId").val();
    time = $("#datepicker").val();
    starttime = time + " " + $("#stime").val();
    endtime = time + " " + $("#etime").val();
    c_time = $("#stime").val() + " - " + $("#etime").val();
    ver = 1;
    badge = $("#inputHiddenId").val();
    var NO = $("#hidden_no").html();
    var s = $("#rooms").val();
    //if (s == null || s == "") {
    //    layer.msg("请选择房间");
    //    return
    //}
    subject = $("#subject").val();
    //if (subject == null || subject == "") {
    //    layer.msg("请填写Subject");
    //    $("#subject").focus();
    //    return
    //}
    var num = s.substring(0, s.length - 1).split(',');
    var c_room = "";
    var arry = [];
    for (var i = 0; i < num.length; i++) {
        contactname = $("#" + 'Input' + i).val();
        contact = $("#" + 'inputHiddenId' + i).val();
        attendees = $("#" + 'Attendess' + i).val();
        roomid = $("#" + 'Roomid' + i).val();
        recurrence = $("#freq").val();
        no = NO;
        $.ajax({
            type: "post",
            url: RootPath + "/M_Room/getRoomById",
            dataType: "json",
            async: false,
            data: { "resourceid": roomid },
            success: function (result) {
                var dt = JSON.parse(result);
                for (var i = 0; i < dt.length; i++) {
                    room = dt[i]._room + ",";
                    c_room += room;
                    roomip = dt[i]._roomIP;
                    description = dt[i]._description;
                    Ext = dt[i]._Ext;
                    type = dt[i]._type;
                    remark = dt[i]._remark;
                    roomadmin = dt[i]._roomadmin;
                    Seat = dt[i]._Seatl;
                    MaxNoOfVCConnection = dt[i]._MaxNoOfVCConnection;
                    needConfirm = dt[i]._needConfirm;
                }
            }
        })
        $.ajax({
            type: "post",
            url: RootPath + "/M_Employee/GetUserByBadge",
            dataType: "json",
            async: false,
            data: { "badge": contact },
            success: function (result) {
                var dt = JSON.parse(result);
                if (dt == "" || dt == null)
                    return;
                contactext = dt._ext;
                ext = dt._ext;
            }
        })
        siteid = $("#" + 'Siteid' + i).val();
        arry.push(new M_Conference(mymeetingdatasource, no, type, subject, notes, recurrence, operator, contact, site, description, status, applicant, appname,
        contactname, datesubject, datenotes, uid, href, room, roomip, MaxNoOfVCConnection, roomadmin, remark, location, appext,
        contactext, OSAremark, Ext, badge, time, meetingdesc, siteid, roomid, attendees, ver, Seat, startdate, enddate, appdate,
        opdate, starttime, endtime, confirm, confirmCheck, ignoreAttendees, sendUpdate, needConfirm))
    }
    var recu = [];
    var startTime, endTime, date, status, no, subject, notes, flag;
    if (!$("#recu").val() == "") {
        var dt = JSON.parse($("#recu").val());
        for (var i = 0; i < dt.length; i++) {
            startTime = dt[i]._startTime.substring(0, 10) + " " + $("#stime").val();
            endTime = dt[i]._endTime.substring(0, 10) + " " + $("#etime").val();
            date = dt[i]._date;
            status = dt[i]._status;
            no = $("#no").html();
            subject = dt[i]._subject;
            notes = dt[i]._notes;
            flag = dt[i]._flag;
            recu.push(new M_Recu(startTime, endTime, date, status, no, subject, notes, flag));
        }
        $("#isRecu").val(true);
    }
    var Attendees = [];
    $("#AttendessInfoGroup").find("tr").each(function () {
        var tdArr = $(this).children();
        var dept = tdArr.eq(0).text();
        var name = tdArr.eq(1).text();
        var badge = tdArr.eq(2).text();
        no = $("#no").html();
        siteid = 0;
        ext = "";
        var groupname = $("#InputGroup").val();
        Attendees.push(new M_Attendees(no, badge, name, ext, dept, siteid));
    });
    $.ajax({
        type: "post",
        url: RootPath + "/M_Conference/CreateConference",
        dataType: "json",
        async: false,
        data: { "M_Conference[]": JSON.stringify(arry), "Recu[]": JSON.stringify(recu), "Attendees[]": JSON.stringify(Attendees) },
        success: function (result) {
            var dt = JSON.parse(result);
            if (dt.IsSuccess == "S") {
                $("#c_no").html(dt.NO);
                $("#c_dete").html(time);
                $("#c_time").html(c_time);
                $("#c_room").html(c_room.substring(0, c_room.length - 1));
                $("#c_applicant").html(appname);
                //$("#c_contact").html(contact);
                $("#c_subject").html(subject);
                layer.msg("Book Success", { time: 4000, icon: 6 });
            } else if (dt[0] == "F") {
                layer.msg("Book failed", { time: 4000, icon: 5 });
            }
        }
    })
    eventFun.setStep(5);
}
/*M_Conference.cs*/
function M_Conference(_mymeetingdatasource, _no, _type, _subject, _notes, _recurrence, _operator, _contact, _site, _description, _status, _applicant, _appname,
 _contactname, _datesubject, _datenotes, _uid, _href, _room, _roomip, _MaxNoOfVCConnection, _roomadmin, _remark, _location, _appext,
 _contactext, _OSAremark, _Ext, _badge, _time, _meetingdesc, _siteid, _roomid, _attendees, _ver, _Seat, _startdate, _enddate, _appdate,
 _opdate, _starttime, _endtime, _confirm, _confirmCheck, _ignoreAttendees, _sendUpdate, _needConfirm) //声明对象
{

    this._mymeetingdatasource = _mymeetingdatasource;
    this._no = _no;
    this._type = _type;
    this._subject = _subject;
    this._notes = _notes;
    this._recurrence = _recurrence;
    this._operator = _operator;
    this._contact = _contact;
    this._site = _site;
    this._description = _description;
    this._status = _status;
    this._applicant = _applicant;
    this._appname = _appname;
    this._contactname = _contactname;
    this._datesubject = _datesubject;
    this._datenotes = _datenotes;
    this._uid = _uid;
    this._href = _href;
    this._room = _room;
    this._roomip = _roomip;
    this._MaxNoOfVCConnection = _MaxNoOfVCConnection;
    this._roomadmin = _roomadmin;
    this._remark = _remark;
    this._location = _location;
    this._appext = _appext;
    this._contactext = _contactext;
    this._OSAremark = _OSAremark;
    this._Ext = _Ext;
    this._badge = _badge;
    this._time = _time;
    this._meetingdesc = _meetingdesc;
    this._siteid = _siteid;
    this._roomid = _roomid;
    this._attendees = _attendees;
    this._ver = _ver;
    this._Seat = _Seat;
    this._startdate = _time;
    this._enddate = _time;
    this._appdate = _time;
    this._opdate = _time;
    this._starttime = _starttime;
    this._endtime = _endtime;
    this._confirm = false;
    this._confirmCheck = false;
    this._ignoreAttendees = false;
    this._sendUpdate = false;
    this._needConfirm = false;
}

/*M_Recu.cs*/
function M_Recu(startTime, endTime, date, status, no, subject, notes, flag) {
    this._startTime = startTime;
    this._endTime = endTime;
    this._date = date;
    this._status = status;
    this._no = no;
    this._subject = subject;
    this._notes = notes;
    this._flag = flag;
}
/*M_Attendees.cs*/
function M_Attendees(no, badge, name, ext, dept, siteid) {
    this._no = no;
    this._badge = badge;
    this._name = name;
    this._ext = ext;
    this._dept = dept;
    this._siteid = siteid;
}
/*M_Room.cs*/
function M_Room(_site, _room, _roomIP, _description, _Ext, _type, _crtby, _roomdesc, _roomStatus, _roomTitle, _remark, _path, _roomadmin, _deptDesc, _mark, _Seat, _id, _siteid, _MaxNoOfVCConnection, _start, _end, _needConfirm, _deptUse) {
    this._site = _site;
    this._room = _room;
    this._roomIP = _roomIP;
    this._description = _description;
    this._Ext = _Ext;
    this._type = _type;
    this._crtby = _crtby;
    this._roomdesc = _roomdesc;
    this._roomStatus = _roomStatus;
    this._roomTitle = _roomTitle;
    this._remark = _remark;
    this._path = _path;
    this._roomadmin = _roomadmin;
    this._deptDesc = _deptDesc;
    this._mark = _mark;
    this._Seat = _Seat;
    this._id = _id;
    this._siteid = _siteid;
    this._MaxNoOfVCConnection = _MaxNoOfVCConnection;
    this._start = _start;
    this._end = _end;
    this._needConfirm = _needConfirm;
    this._deptUse = _deptUse;
}
/*M_Contacts.cs*/
function M_Contacts(owner, groupname, badge, gid) {
    this._owner = owner;
    this._groupname = groupname;
    this._badge = badge;
    this._gid = gid;
}

//名字工号自动填充
function keyup(obj) {
    if (obj == null || obj == "") {
        return;
    }
    var inputHiddenId = $(obj).attr("id").replace("Input", "inputHiddenId");
    var input = $("#" + $(obj).attr("id")).val();
    var Res = "";
    if (checkNumber(input)) {
        Res = "Number";
    } else {
        Res = "Character";
    }
    $.ajax({
        type: "post",
        url: RootPath + "/M_Employee/SearchEmployee",
        dataType: "json",
        data: { "input": input, "inputType": Res },
        success: function (result) {
            var data = JSON.parse(result);
            if (data == null || data == '') {
                return;
            }
            $("#" + $(obj).attr("id")).autocomplete({
                minLength: 0,
                source: data,
                focus: function (event, ui) {
                    if (Res == "Number") {
                        $("#" + $(obj).attr("id")).val(ui.item.label);
                    } else {
                        $("#" + $(obj).attr("id")).val(ui.item.icon);
                    }
                    return false;
                },
                select: function (event, ui) {
                    if (Res == "Number") {
                        $("#" + $(obj).attr("id")).val(ui.item.icon);
                    } else {
                        $("#" + $(obj).attr("id")).val(ui.item.label);
                    }
                    $("#" + inputHiddenId).val(ui.item.value);
                    return false;
                }
            })
           .autocomplete("instance")._renderItem = function (ul, item) {
               if (Res == "Number") {
                   return $("<li style='z-index:19891015'>").append("<div>" + item.icon + "<br>" + item.desc + "</div>").appendTo(ul);
               } else {
                   return $("<li style='z-index:19891015'>").append("<div>" + item.label + "<br>" + item.desc + "</div>").appendTo(ul);
               }
           };
        },
        error: function () {
            return;
        },
    })
}

/*正则表达式 验证字符串是否是数字*/
function checkNumber(Obj) {
    var reg = /^[0-9]+.?[0-9]*$/;
    if (reg.test(Obj)) {
        return true;
    }
    return false;
}

/*Recurrence Frequency*/
$(document).ready(function () {
    $("select#ReFreq").change(function () {
        var frefreq = $("#ReFreq").val();
        if (frefreq == "1") {
            $("#daily").show();
            $("#weekly").hide();
            $("#monthly").hide();
        }
        else if (frefreq == "2") {
            $("#daily").hide();
            $("#weekly").show();
            $("#monthly").hide();
        }
        else if (frefreq == "3") {
            $("#daily").hide();
            $("#weekly").hide();
            $("#monthly").show();
        }
    });
})

/*Recurrence Range*/
$(document).ready(function () {
    $("#radio").click(function () {
        $("#radio").attr("checked", true);
        $("#radioUntil").attr("checked", false);
    });
})
$(document).ready(function () {
    $("#radioUntil").click(function () {
        $("#radioUntil").attr("checked", true);
        $("#radio").attr("checked", false);
    });
})

/*Recurrence Extra--daily*/
$(document).ready(function () {
    $("#EDay").click(function () {
        $("#EDay").attr("checked", true);
        $("#EWeekly").attr("checked", false);
    });
})
$(document).ready(function () {
    $("#EWeekly").click(function () {
        $("#EWeekly").attr("checked", true);
        $("#EDay").attr("checked", false);
    });
})

/*Recurrence Extra--monthly*/
$(document).ready(function () {
    $("#monthly1").click(function () {
        $("#monthly1").attr("checked", true);
        $("#monthly2").attr("checked", false);
    });
})
$(document).ready(function () {
    $("#monthly2").click(function () {
        $("#monthly2").attr("checked", true);
        $("#monthly1").attr("checked", false);
    });
})

$(document).ready(function () {
    $("#AddRecurrence").click(function () {
        //var flag = $("#form").valid();
        //if (!flag) {
        //    return;
        //}
        //if ($("#form").valid()) {
        if (true) {
            var drpFrequency = $("#ReFreq").find("option:selected").text();
            var txtInterval = $("#Interval").val();
            var StartDate = $("#StartDate").val();
            var ForDay = $("#ForDay").val();
            var RangeCheck = "";
            var RangeValue = "";
            var DailyCheck = "";
            var WeeklyChecks = "";
            var MonthlyCheck = "";
            var drpRecValue = "";
            var drpMonthDay = "";
            var freq = "";
            var endtime = "";
            var startTime = "";
            var minDate = "";
            var maxDate = "";
            var RoomArry = new Array();
            if ($('input:radio[name=radioUntil]')[0].checked == true) {
                RangeCheck = 2;
                RangeValue = $("#UntilDate").val();
            } else {
                RangeCheck = 1;
                RangeValue = $("#ForDay").val();
            }
            var ReFreq = $("#ReFreq").find("option:selected").text();
            switch (ReFreq) {
                case "Daily":
                    if ($('input:radio[name=EDay]')[0].checked == true) {
                        DailyCheck = 2;
                    }
                    else {
                        DailyCheck = 1;
                    }
                    break;
                case "Weekly":
                    var WeeklyRadio = document.getElementsByName('Weekly');
                    for (var i = 0; i < WeeklyRadio.length; i++) {
                        if ($('input:checkbox[name=Weekly]')[i].checked == true) {
                            WeeklyChecks += "," + $('input:checkbox[name=Weekly]')[i].title;
                        }
                    }
                    break;
                case "Monthly":
                    if ($('input:radio[name=Month]')[0].checked == true) {
                        MonthlyCheck = 1;
                    } else {
                        drpRecValue = $("#eFirst").val();
                        drpMonthDay = $("#eSecond").val();
                    }
                    break;
            }
            $.ajax({
                type: "post",
                url: RootPath + "/M_Recu/GetRecurrenceRule",
                dataType: "json",
                async: true,
                data: { "drpFrequency": drpFrequency, "txtInterval": txtInterval, "StartDate": StartDate, "ForDay": ForDay, "RangeCheck": RangeCheck, "RangeValue": RangeValue, "DailyCheck": DailyCheck, "WeeklyChecks": WeeklyChecks, "MonthlyCheck": MonthlyCheck, "drpRecValue": drpRecValue, "drpMonthDay": drpMonthDay },
                success: function (data) {
                    freq = JSON.parse(data);
                    $("#freq").val(freq);
                    var _site, _room, _roomIP, _description, _Ext, _type, _crtby, _roomdesc, _roomStatus, _roomTitle, _remark, _path, _roomadmin, _deptDesc, _mark, _Seat, _id, _siteid, _MaxNoOfVCConnection, _start, _end, _needConfirm, _deptUse;
                    startTime = $("#StartDate").val() + " " + $("#starttime").val();
                    minDate = $("#StartDate").val();
                    var test = $("#ForDay").val();
                    if ($("#ForDay").val() != "") {
                        maxDate = new Date(convertTime(minDate, ""));
                        maxDate = convertTime(maxDate.setDate(maxDate.getDate() + $("#ForDay").val()), "");
                    } else {
                        maxDate = $("#UntilDate").val();
                    }
                    endtime = maxDate + " " + $("#endtime").val();
                    var sites = $("#rooms").val().split(',');
                    _start = startTime;
                    _end = maxDate;
                    $("#StatusBody").empty();
                    for (var i = 0; i < sites.length + 1; i++) {
                        _id = $("#" + 'Roomid' + i).val();
                        _siteid = siteid = $("#" + 'Siteid' + i).val();
                        _site = $("#" + 'Sites' + i).val();
                        $.ajax({
                            type: "post",
                            url: RootPath + "/M_Room/getRoomById",
                            dataType: "json",
                            async: false,
                            dataType: "json",
                            data: { "resourceid": _id },
                            success: function (data) {
                                var dt = JSON.parse(data);
                                _room = dt._room;
                                _roomIP = dt._roomIP;
                                _description = dt._description;
                                _Ext = dt._Ext;
                                _type = dt._type;
                                _crtby = dt._crtby;
                                _roomdesc = dt._roomdesc;
                                _roomStatus = dt._roomStatus;
                                _roomTitle = dt._roomTitle;
                                _remark = dt._remark;
                                _path = dt._path;
                                _roomadmin = dt._roomadmin;
                                _deptDesc = dt._deptDesc;
                                _mark = dt._mark;
                                _Seat = dt._Seatl;
                                _MaxNoOfVCConnection = dt._MaxNoOfVCConnection;
                                _needConfirm = dt._needConfirm;
                                _deptUse = dt._deptUse;
                            }
                        })
                        RoomArry.push(new M_Room(_site, _room, _roomIP, _description, _Ext, _type, _crtby, _roomdesc, _roomStatus, _roomTitle, _remark, _path, _roomadmin, _deptDesc, _mark, _Seat, _id, _siteid, _MaxNoOfVCConnection, _start, _end, _needConfirm, _deptUse));
                    }
                    $.post(RootPath + "/M_Recu/RecurrenceToList", { "freq": freq, "startTime": startTime, "endtime": endtime, "minDate": minDate, "maxDate": maxDate, "RoomArry[]": JSON.stringify(RoomArry) }, function (dtsource) {
                        if (dtsource == "")
                            return;
                        var result = JSON.parse(dtsource);

                        $("#recu").val(dtsource);
                        $("#StatusTable").show();
                        $("#scroll").show();
                        var tbody = "";
                        $.each(result, function (i, item) {
                            if (item._status == "Unavailable") {
                                tbody += '<tr><td>' + item._date.substring(0, 10) + '</td><td  style="color:red;">' + item._status + '</td></tr>';
                            } else {
                                tbody += '<tr><td>' + item._date.substring(0, 10) + '</td><td>' + item._status + '</td></tr>';
                            }
                        })
                        $("#StatusBody").append(tbody);
                    })
                }
            })
        }
        return false;
    })
})

//starttime endtime  click
$(document).ready(function () {
    $("#starttime").change(function () {
        var st = $("#starttime").val();
        $("#stime").selectpicker('val', st);
    });
})
$(document).ready(function () {
    $("#endtime").change(function () {
        var et = $("#endtime").val();
        $("#etime").selectpicker('val', et);
    });
})


//绑定循环日期
function startdate() {
    var sd = $("#datepicker").val();
    var startdate = convertTime(sd, "");
    var untildate = MonthAdd(3);
    $("#StartDate").val(startdate);
    $("#UntilDate").val(untildate);
}
//until date
function instantiationLayui() {
    var lay = layui.use(['form', 'laydate'], function () {
        var laydate = layui.laydate;
        var form = layui.form,
         layer = layui.layer
        //laydate.render({
        //    elem: '#test1',
        //    showBottom: false,
        //    lang: 'en',
        //    calendar: true,
        //});
        laydate.render({
            elem: '#StartDate',
            showBottom: false,
            lang: 'en',
            format: 'yyyy-MM-dd',
            calendar: true,
            min: DateAdd(0),
            max: MonthAdd(3)
        });
        laydate.render({
            elem: '#UntilDate',
            showBottom: false,
            lang: 'en',
            calendar: true,
            format: 'yyyy-MM-dd',
            min: DateAdd(1),
            max: MonthAdd(3),
        });
    });
}

/*Attendees templete */

$(document).ready(function () {
    $("#Query").click(function () {
        var Dept = $("#Dept").val();
        var Name = $("#Name").val();
        var Badge = $("#Badge").val();
        if (Dept == "" && Name == "" && Badge == "") {
            layer.msg("Query condition could not be empty.");
            return false;
        }
        $.post(RootPath + "/M_Employee/SearchAttendees", { "Dept": $("#Dept").val(), "Name": $("#Name").val(), "Badge": $("#Badge").val() }, function (result) {
            var ds = JSON.parse(result);
            var body;
            for (var i = 0; i < ds.length; i++) {
                body += "<tr><td>" + ds[i]._dept + "</td><td>" + ds[i]._name + "</td><td>" + ds[i]._badge + "</td><td><i class=\"layui-icon\" style=\"font-size: 26px; color: #5FB878;\" value=" + ds[i]._badge + " onclick=\"add(this)\">&#xe608;</i></td></tr>";
            }
            //$("#AttendessTable").attr("display","block");
            $("#AttendessInfo").html(body);
        })
        return false;
    })

    $("#Update").click(function () {
        var arr = new Array();
        var owner = "";
        var gid = $("#ugSelect").val();
        $.post(RootPath + "/M_Employee/CurrentUser", function (result) {
            owner = JSON.parse(result);
            $("#AttendessInfoGroup").find("tr").each(function () {
                var tdArr = $(this).children();
                var badge = tdArr.eq(2).text();
                var groupname = $("#ugSelect").find("option:selected").text();
                arr.push(new M_Contacts(owner, groupname, badge, gid));
            });
            $.ajax({
                type: "post",
                url: RootPath + "/M_Attendees/UpdateAttendeesGroup",
                dataType: "json",
                async: false,
                data: { "M_Contacts[]": JSON.stringify(arr), "gid": $("#ugSelect").val() },
                success: function (result) {
                    if (JSON.parse(result) == "S")
                        layer.msg("Update Success");
                }
            })
        })
    })
    //add attendees group
    $("#Savegroup").click(function () {
        var arr = new Array();
        var owner = "";
        var promiseA = $.post(RootPath + "/M_Employee/CurrentUser", function (result) {
            owner = JSON.parse(result);
            $("#AttendessInfoGroup").find("tr").each(function () {
                var tdArr = $(this).children();
                var badge = tdArr.eq(2).text();
                var gid = 0;
                var groupname = $("#InputGroup").val();
                arr.push(new M_Contacts(owner, groupname, badge, gid));
            });
        })
        var promiseB = promiseA.then(function () {
            return $.ajax({
                type: "post",
                url: RootPath + "/M_Attendees/CreateAttendeesGroup",
                dataType: "json",
                async: true,
                data: { "M_Contacts[]": JSON.stringify(arr) },
                success: function (result) {
                    if (result == "") {
                        layer.msg("Fail");
                        return;
                    }
                    if (JSON.parse(result) == "S")
                        layer.msg("Success");
                }
            });
        });
    })

    //checkbok
    $("#SaveGroup").click(function () {
        $("#SaveGroup").attr("checked", true);
        $("#UpdateGroup").attr("checked", false);
        $("#sg").show();
        $("#ug").hide();
    });
    $("#UpdateGroup").click(function () {
        $("#UpdateGroup").attr("checked", true);
        $("#SaveGroup").attr("checked", false);
        $("#sg").hide();
        $("#ug").show();
        $.ajax({
            type: "post",
            url: RootPath + "/M_Attendees/GetAttendeesGroupName",
            dataType: "json",
            async: false,
            success: function (result) {
                var dt = JSON.parse(result);
                var ugoption = '';
                for (var i = 0; i < dt.length; i++) {
                    ugoption += '<option value=' + dt[i]._gid + '>' + dt[i]._groupname + '</option>';
                }
                $("#ugSelect").html(ugoption);
                $('#ugSelect').selectpicker('refresh');
                $('#ugSelect').selectpicker('render');
                //$('#starttime').selectpicker('val', st);
            }
        })
    });
})



function add(obj) {
    var badge = $(obj).attr("value");
    $.post(RootPath + "/M_Employee/SearchAttendees", { "Dept": "", "Name": "", "Badge": badge }, function (result) {
        var ds = JSON.parse(result);
        var body;
        for (var i = 0; i < ds.length; i++) {
            body += "<tr><td>" + ds[i]._dept + "</td><td>" + ds[i]._name + "</td><td>" + ds[i]._badge + "</td><td><i class=\"layui-icon\" style=\"font-size: 26px; color: #5FB878;\" value=" + ds[i]._badge + " onclick=\"del(this)\">&#xe640;</i></td></tr>";
        }
        $("#AttendessInfoGroup").append(body);
        layer.msg("Add Success");
    })
}
function del(obj) {
    $(obj).parents('tr').remove();
    layer.msg("Remove Success");
}
/*月份加*/
function MonthAdd(j) {
    var now = new Date();
    var result = ConvertTimestampToTime(now.setMonth(now.getMonth() + j));
    var result2 = new Date(result);
    var result3 = result2.getFullYear() + "-" + (result2.getMonth() + 1) + "-" + result2.getDate();
    return result3;
}
/*天加*/
function DateAdd(i) {
    var now = new Date();
    var result = ConvertTimestampToTime(now.setDate(now.getDate() + i));
    return result;
}