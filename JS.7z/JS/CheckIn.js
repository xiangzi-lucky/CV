﻿$(function () {
    layui.use('laydate', function () {
        var laydate = layui.laydate;       
        laydate.render({
            elem: '#Date', //指定元素
            showBottom: false,//是否显示底部的按钮
            lang: 'en',//英文
            calendar: true,
            done: function (value, date) {


            }
        });      
    });
})