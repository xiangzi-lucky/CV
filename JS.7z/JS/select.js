﻿var StartTime;
var EndTime;
var html = "";
var RootPath = getRootPath();
$(function () {
    //初次加载
    layui.use(['layer', 'element'], function () {
        var $ = layui.jquery,
            layer = layui.layer,
            element = layui.element;
        element.on('tab(demo)', function (e) {
            var lay_id = $(this).attr("lay-id");
            $("#tabid").val(lay_id);
            $("#room").empty();
            $('#room').selectpicker('refresh');
            $('#room').selectpicker('render');
            //var startDate = ConvertTimestampToTime($(".scheduler").dxScheduler("instance").option("currentDate")).substring(0, 10);
            //$.post(RootPath + '/M_Conference/FirstLogin', { "lay_id": $("#tabid").val(), "startdate": startDate }, function (result) {
            //    var dt = JSON.parse(result);
            //    scheduler(dt.Conference, dt.Resource, startDate);
            //})
            cancelCallBack();
        })
        // 监听Tab删除
        $(".layui-tab").on("click", function (e) {
            if ($(e.target).is(".layui-tab-close")) {
                var layid = $(e.target).parent().attr("lay-id");
                $.post(RootPath + '/M_MyTabList/DelTab', { "layid": layid }, function (data) {
                    if (JSON.parse(data) == "true") {
                        layer.msg("Delete Success", { time: 4000, icon: 6 });
                    } else {
                        layer.msg("Delete Failed", { time: 4000, icon: 5 });
                    }
                })
            }
        })
        //触发事件
        var active = {
            tabAdd: function () {
                layer.open({
                    type: 1,
                    title: false, //不显示标题栏
                    closeBtn: false,
                    area: '300px;',
                    shade: 0.3,
                    id: 'LAY_layuipro', //设定一个id，防止重复弹出
                    resize: false,
                    btn: ['submit', 'cancle'],
                    btnAlign: 'c',
                    moveType: 1, //拖拽模式，0或者1
                    content: '<div style="padding: 50px; line-height: 22px; background-color: #FFFFFF; color: #fff; font-weight: 300;"><span>Name</span>:<input class=\"layui-input\" type=\"text\" id=\"InputTabName\" placeholder=\"input name\" required/></div>',
                    success: function (layero) {
                        var btn = layero.find('.layui-layer-btn');
                        btn.find('.layui-layer-btn0').click(function () {
                            var name = $("#InputTabName").val();
                            $.post(RootPath + "/M_MyTabList/AddTab", { "TabName": name }, function (data) {
                                var dt = JSON.parse(data);
                                element.tabAdd('demo', {
                                    title: dt.Adt._TabName,
                                    id: dt.Adt._id
                                })
                                if (dt.Flag == true) {
                                    $("#UlContent li:first").addClass("layui-this");
                                    if ($("#tabid").val() == "") {
                                        $("#tabid").val(dt.Adt._id);
                                    }
                                }
                            })
                        })
                    }
                });
            },
            tabDelete: function (othis) {
                //删除指定Tab项
                element.tabDelete('demo', '44');
                othis.addClass('layui-btn-disabled');
            },
            tabChange: function () {
                //切换到指定Tab项
                element.tabChange('demo', '22');
            },
            tabEdit: function (e) {
                //编辑一个Tab项
                var layid = $("#tabid").val();
                $.post(RootPath + "/M_MyTabList/getTabName", { "layid": layid }, function (data) {

                    if (data !== null || data !== undefined || data !== '') {
                        var a = JSON.parse(data);
                        layer.open({
                            type: 1,
                            title: false, //不显示标题栏
                            closeBtn: false,
                            area: '300px;',
                            shade: 0.3,
                            id: 'LAY_layuipro', //设定一个id，防止重复弹出
                            resize: false,
                            btn: ['submit', 'cancle'],
                            btnAlign: 'c',
                            moveType: 1, //拖拽模式，0或者1
                            content: '<div style="padding: 50px; line-height: 22px; background-color: #FFFFFF; color: #fff; font-weight: 300;"><span>Name</span>:<input class=\"layui-input\" type=\"text\" id=\"EditTabName\" placeholder=\"input name\"/></div>',
                            success: function (layero) {
                                $("#EditTabName").val(a);
                                var btn = layero.find('.layui-layer-btn');
                                btn.find('.layui-layer-btn0').click(function () {
                                    var name = $("#EditTabName").val();
                                    $.post(RootPath + "/M_MyTabList/UpdateTab", { "layid": layid, "updateTabName": name }, function (data) {
                                        var dt = JSON.parse(data);
                                        if (dt == "true") {
                                            $.post(RootPath + '/M_MyTabList/Load', function (data) {
                                                var dt = JSON.parse(data);
                                                $("#UlContent").empty();
                                                for (var i = 0; i < dt.length; i++) {
                                                    element.tabAdd('demo', {
                                                        title: dt[i]._TabName,
                                                        id: dt[i]._id,
                                                    })
                                                    if (dt[i]._id == layid) {
                                                        $("#UlContent li:first").addClass("layui-this");
                                                        $("#tabid").val(dt[i]._id);
                                                    }
                                                }
                                            }, "JSON")
                                        }
                                    })
                                })
                            }
                        });
                    } else {
                        layer.msg("no data");
                    }
                })
            }
        };
        /*监听添加按钮*/
        $('#menu').on('click', function () {
            var othis = $(this), type = othis.context.lastElementChild.dataset.type; // type = type = othis.data('type');
            active[type] ? active[type].call(this, othis) : '';
        });
        /*监听编辑按钮*/
        $('#edit').on('click', function () {
            var othis = $(this), type = othis.context.lastElementChild.dataset.type;
            active[type] ? active[type].call(this, othis) : '';
        });
        var promiseTab = $.ajax({
            type: "post",
            async: false,
            url: RootPath + "/M_MyTabList/Load",
            success: function (rs) {
                if (rs == "" || rs == null) {
                    layer.msg("Error");
                    return;
                }
                var dt = JSON.parse(rs);
                if (dt.length == 0) {
                    element.tabAdd('demo', {
                        title: dt._TabName,
                        id: dt._id,
                    })
                    $("#UlContent li:first").addClass("layui-this");
                    $("#tabid").val(dt._id);

                } else {
                    for (var i = 0; i < dt.length; i++) {

                        element.tabAdd('demo', {
                            title: dt[i]._TabName,
                            id: dt[i]._id,
                        })
                        if (i == 0) {
                            $("#UlContent li:first").addClass("layui-this");
                            $("#tabid").val(dt[i]._id);
                        }
                    }
                }
            },
            error: function (e) {
                layer.msg(e);
            },
        });
        var startDate = ConvertTimestampToTime(new Date().getTime()).substring(0, 10);
        $.ajax({
            type: "post",
            async: true,
            url: RootPath + "/M_Conference/FirstLogin",
            data: { "lay_id": $("#tabid").val(), "startdate": startDate },
            success: function (result) {
                var r = JSON.parse(result);
                scheduler(r.Conference, r.Resource, startDate);
                var tabid = $("#tabid").val();
            },
            error: function (e) {
                layer.msg(e);
            },
        })
        $.ajax({
            type: "post",
            async: true,
            url: RootPath + "/M_Type/GetMeetingType",
            success: function (result) {
                var dt = JSON.parse(result);
                var Type = '';
                for (var i = 0; i < dt.length; i++) {
                    if (dt[i]._type != 2)
                        Type += '<option value=' + dt[i]._type + '>' + dt[i]._roomdesc + '</option>';
                }
                $("#type").html(Type);
                $('#type').selectpicker('refresh');
                $('#type').selectpicker('render');
            }
        })
        $.ajax({
            type: "post",
            async: true,
            url: RootPath + "/M_Site/getSites",
            success: function (result) {
                var dt = JSON.parse(result);
                var Site = '';
                for (var i = 0; i < dt.length; i++) {
                    Site += '<option value=' + dt[i]._id + '>' + dt[i]._site + '</option>';
                }
                $("#Sites").html(Site);
                $('#Sites').selectpicker('refresh');
                $('#Sites').selectpicker('render');
            }
        })
    })
    $("#type").change(function () {
        var type = $("#type").val();
        var Site = '';
        $("#room").find("option").remove();
        $("#room").selectpicker('refresh')
        $.ajax({
            type: "post",
            url: RootPath + "/M_Site/getSites",
            success: function (result) {
                var dt = JSON.parse(result);
                var Site = '';
                if (type == 1) {
                    $("#Sites").removeAttr("multiple");
                    for (var i = 0; i < dt.length; i++) {
                        Site += '<option value=' + dt[i]._id + '>' + dt[i]._site + '</option>';
                    }
                    $("#Sites").html(Site);
                    $("#Sites").selectpicker("val", '');
                    $('#Sites').selectpicker('refresh');
                    $('#Sites').selectpicker('render');

                } else {
                    $("#Sites").attr("multiple", "multiple");
                    for (var i = 0; i < dt.length; i++) {
                        Site += '<option value=' + dt[i]._id + '>' + dt[i]._site + '</option>';
                    }
                    $("#Sites").html(Site);
                    $('#Sites').selectpicker('refresh');
                    $('#Sites').selectpicker('render');
                }
            }
        })
    });
    $("#Sites").change(function () {
        var Type = $('#type').val();
        var Sites = $('#Sites').val();
        $.ajax({
            type: "post",
            url: RootPath + "/M_Room/GetRoomAndSite",
            dataType: "json",
            data: { "Type": Type, "Sites[]": Sites, "layid": $('#tabid').val() },
            traditional: true,
            success: function (result) {
                var dt = JSON.parse(result);

                var option = '';
                var group = '';
                if (dt != null) {
                    for (var j = 0; j < dt.all[0].room.length; j++) {
                        option += '<option value="' + dt.all[0].room[j]._id + '" class="selected">' + dt.all[0].room[j]._room + '</option>'
                    }
                } else {
                    for (var j = 0; j < dt.all[0].room.length; j++) {
                        option += '<option value="' + dt.all[0].room[j]._id + '">' + dt.all[0].room[j]._room + '</option>'
                    }
                }
                $("#room").html(option);
                if (dt.part != null) {
                    var partArray = [];
                    for (var k = 0; k < dt.part.length; k++) {
                        partArray.push(dt.part[k]._id);
                    }
                    $("#room").selectpicker('val', partArray);
                }
                $('.selectpicker').selectpicker('refresh');
                $('.selectpicker').selectpicker('render');
                bindingScheduler();
            }
        });
    })
    $("#room").change(function () {
        bindingScheduler();
    })
    //$('#room').on('changed.bs.select', function (clickedIndex, newValue, oldValue) {
    //    if (oldValue == false) {
    //        var roomid = $('#room option:eq(' + newValue + ')').val();
    //        var TabID = $("#tabid").val();
    //        $.post(RootPath + "/M_Room/DeleteRoom", { "roomid": roomid, "TabID": TabID }, function (result) {
    //            if (JSON.parse(result) == false) {
    //                layer.msg("Delete Failed", { time: 4000, icon: 5 });
    //            }
    //        });
    //    }
    //});
    $("#Create").click(function () {
        location.href = RootPath+'/Create/Index';
    })
    $("#Advanced").click(function () {
        location.href =RootPath+'/AdvancedSearch/Index';
    })
    $("#Query").click(function () {
        var Dept = $("#Dept").val();
        var Name = $("#Name").val();
        var Badge = $("#Badge").val();
        if (Dept == "" && Name == "" && Badge == "") {
            layer.msg("Query condition could not be empty.");
            return false;
        }
        $.post(RootPath + "/M_Employee/SearchAttendees", { "Dept": $("#Dept").val(), "Name": $("#Name").val(), "Badge": $("#Badge").val() }, function (result) {
            var ds = JSON.parse(result);
            var body;
            for (var i = 0; i < ds.length; i++) {
                body += "<tr><td>" + ds[i]._dept + "</td><td>" + ds[i]._name + "</td><td>" + ds[i]._badge + "</td><td><i class=\"layui-icon\" style=\"font-size: 26px; color: #5FB878;\" value=" + ds[i]._badge + " onclick=\"add(this)\">&#xe608;</i></td></tr>";
            }
            $("#AttendessInfo").html(body);
        })
        return false;
    })
    $("#ReFreq").change(function () {
        var v = $("#ReFreq").find("option:selected").text();
        switch (v) {
            case "None":
                disable(true);
                break;
            case "Daily":
                RecurrenceRangeDisable(false);
                DailyDisable(false);
                WeeklyDisable(true);
                setWeeklyCheck();
                MonthlyDisable(true);
                break;
            case "Weekly":
                RecurrenceRangeDisable(false);
                DailyDisable(true);
                WeeklyDisable(false);
                MonthlyDisable(true);
                break;
            case "Monthly":
                RecurrenceRangeDisable(false);
                DailyDisable(true);
                WeeklyDisable(true);
                setWeeklyCheck();
                MonthlyDisable(false);
                break;
        }
    })
    $("#RemoveRecurrence").click(function () {
        $("#StatusBody").empty();
        $("#StatusTable").hide();
        $("#scroll").hide();
        $("#StatusBody").html("<tbody id='StatusBody'></tbody>")
        return false;
    })

    $("#Update").click(function () {
        var arr = new Array();
        var owner = "";
        var gid = $("#Group").val();
        $.post(RootPath + "/M_Employee/CurrentUser", function (result) {
            owner = JSON.parse(result);
            $("#AttendessInfoGroup").find("tr").each(function () {
                var tdArr = $(this).children();
                var badge = tdArr.eq(2).text();
                var groupname = $("#InputGroup").val();
                arr.push(new M_Contacts(owner, groupname, badge, gid));
            });
            $.ajax({
                type: "post",
                url: RootPath + "/M_Attendees/UpdateAttendeesGroup",
                dataType: "json",
                async: false,
                data: { "M_Contacts[]": JSON.stringify(arr), "gid": $("#Group").val() },
                success: function (result) {
                    if (JSON.parse(result) == "S")
                        layer.msg("Update Success");
                }
            })
        })

    })

    $("#Savegroup").click(function () {
        var arr = new Array();
        var owner = "";
        var promiseA = $.post(RootPath + "/M_Employee/CurrentUser", function (result) {
            owner = JSON.parse(result);
            $("#AttendessInfoGroup").find("tr").each(function () {
                var tdArr = $(this).children();
                var badge = tdArr.eq(2).text();
                var gid = "";
                var groupname = $("#InputGroup").val();
                arr.push(new M_Contacts(owner, groupname, badge, gid));
            });
        })
        var promiseB = promiseA.then(function () {
            return $.ajax({
                type: "post",
                url: RootPath + "/M_Attendees/CreateAttendeesGroup",
                dataType: "json",
                async: true,
                data: { "M_Contacts[]": JSON.stringify(arr) },
                success: function (result) {
                    if (result == "") {
                        layer.msg("Fail");
                        return;
                    }
                    if (JSON.parse(result) == "S")
                        layer.msg("Success");
                }
            });
        });

    })
    $("#AddRecurrence").click(function () {
        //var flag = $("#form").valid();
        //if (!flag) {
        //    return;
        //}
        //if ($("#form").valid()) {
        if(true){
            var drpFrequency = $("#ReFreq").find("option:selected").text();
            var txtInterval = $("#Interval").val();
            var StartDate = $("#StartDate").val();
            var ForDay = $("#ForDay").val();
            var RangeCheck = "";
            var RangeValue = "";
            var DailyCheck = "";
            var WeeklyChecks = "";
            var MonthlyCheck = "";
            var drpRecValue = "";
            var drpMonthDay = "";
            var freq = "";
            var endtime = "";
            var startTime = "";
            var minDate = "";
            var maxDate = "";
            var RoomArry = new Array();
            if ($('input:radio[name=radioUntil]')[0].checked == true) {
                RangeCheck = 2;
                RangeValue = $("#UntilDate").val();
            } else {
                RangeCheck = 1;
                RangeValue = $("#ForDay").val();
            }
            var ReFreq = $("#ReFreq").find("option:selected").text();
            switch (ReFreq) {
                case "Daily":
                    if ($('input:radio[name=EDay]')[0].checked == true) {
                        DailyCheck = 1;
                    }
                    break;
                case "Weekly":
                    var WeeklyRadio = document.getElementsByName('Weekly');
                    for (var i = 0; i < WeeklyRadio.length; i++) {
                        if ($('input:checkbox[name=Weekly]')[i].checked == true) {
                            WeeklyChecks += "," + $('input:checkbox[name=Weekly]')[i].title;
                        }
                    }
                    break;
                case "Monthly":
                    if ($('input:radio[name=Month]')[0].checked == true) {
                        MonthlyCheck = 1;
                    } else {
                        drpRecValue = $("#eFirst").val();
                        drpMonthDay = $("#eSecond").val();
                    }
                    break;
            }
            $.ajax({
                type: "post",
                url: RootPath + "/M_Recu/GetRecurrenceRule",
                dataType: "json",
                async: true,
                data: { "drpFrequency": drpFrequency, "txtInterval": txtInterval, "StartDate": StartDate, "ForDay": ForDay, "RangeCheck": RangeCheck, "RangeValue": RangeValue, "DailyCheck": DailyCheck, "WeeklyChecks": WeeklyChecks, "MonthlyCheck": MonthlyCheck, "drpRecValue": drpRecValue, "drpMonthDay": drpMonthDay },
                success: function (data) {
                    freq = JSON.parse(data);
                    $("#freq").val(freq);
                    var _site, _room, _roomIP, _description, _Ext, _type, _crtby, _roomdesc, _roomStatus, _roomTitle, _remark, _path, _roomadmin, _deptDesc, _mark, _Seat, _id, _siteid, _MaxNoOfVCConnection, _start, _end, _needConfirm, _deptUse;
                    startTime = $("#StartDate").val() + " " + $("#stime").val();
                    minDate = $("#StartDate").val();
                    var test = $("#ForDay").val();
                    if ($("#ForDay").val() != "") {
                        maxDate = new Date(convertTime(minDate, ""));
                        maxDate = convertTime(maxDate.setDate(maxDate.getDate() + $("#ForDay").val()), "");
                    } else {
                        maxDate = $("#UntilDate").val();
                    }
                    endtime = maxDate + " " + $("#etime").val();
                    var sites = $("#Sitechange").val();
                    _start = startTime;
                    _end = maxDate;
                    $("#StatusBody").empty();
                    for (var i = 0; i < sites.length + 1; i++) {
                        _id = $("#" + 'Rooms' + i).val();
                        _siteid = $("#" + 'Sites' + i).val();
                        _site = $("#" + 'Sites' + i).find("option:selected").text();
                        $.ajax({
                            type: "post",
                            url: RootPath + "/M_Room/getRoomById",
                            dataType: "json",
                            async: false,
                            dataType: "json",
                            data: { "resourceid": _id },
                            success: function (data) {
                                var dt = JSON.parse(data);
                                _room = dt._room;
                                _roomIP = dt._roomIP;
                                _description = dt._description;
                                _Ext = dt._Ext;
                                _type = dt._type;
                                _crtby = dt._crtby;
                                _roomdesc = dt._roomdesc;
                                _roomStatus = dt._roomStatus;
                                _roomTitle = dt._roomTitle;
                                _remark = dt._remark;
                                _path = dt._path;
                                _roomadmin = dt._roomadmin;
                                _deptDesc = dt._deptDesc;
                                _mark = dt._mark;
                                _Seat = dt._Seatl;
                                _MaxNoOfVCConnection = dt._MaxNoOfVCConnection;
                                _needConfirm = dt._needConfirm;
                                _deptUse = dt._deptUse;
                            }
                        })
                        RoomArry.push(new M_Room(_site, _room, _roomIP, _description, _Ext, _type, _crtby, _roomdesc, _roomStatus, _roomTitle, _remark, _path, _roomadmin, _deptDesc, _mark, _Seat, _id, _siteid, _MaxNoOfVCConnection, _start, _end, _needConfirm, _deptUse));
                    }
                    $.post(RootPath + "/M_Recu/RecurrenceToList", { "freq": freq, "startTime": startTime, "endtime": endtime, "minDate": minDate, "maxDate": maxDate, "RoomArry[]": JSON.stringify(RoomArry) }, function (dtsource) {
                        if (dtsource == "")
                            return;
                        var result = JSON.parse(dtsource);

                        $("#recu").val(dtsource);
                        $("#StatusTable").show();
                        $("#scroll").show();
                        var tbody = "";
                        $.each(result, function (i, item) {
                            if (item._status == "Unavailable") {
                                tbody += '<tr><td>' + item._date.substring(0, 10) + '</td><td  style="color:red;">' + item._status + '</td></tr>';
                            } else {
                                tbody += '<tr><td>' + item._date.substring(0, 10) + '</td><td>' + item._status + '</td></tr>';
                            }
                        })
                        $("#StatusBody").append(tbody);
                    })
                }
            })
        }
        return false;
    })

    $("#stime").change(function () {
        var stime = $("#stime").val().substring(0, 2);
        var etime = $("#etime").val().substring(0, 2);
        if (stime >= etime) {
            var timeScale = [];
            $("#etime option").each(function (i) { timeScale.push(this.value); })
            for (var i = 0; i < timeScale.length; i++) {
                if (timeScale[i] >= $("#stime").val()) {
                    $("#etime").selectpicker('val', timeScale[i + 1]);
                    break;
                }
            }
            $("#etime").selectpicker('refresh');
            $("#etime").selectpicker('render');
        }
        getFromRoom();
    })
    $("#etime").change(function () {
        var stimeHours = $("#stime").val().substring(0, 2);
        var etimeHours = $("#etime").val().substring(0, 2);
        if (stimeHours >= etimeHours) {
            var timeScale = [];
            $("#stime option").each(function (i) { timeScale.push(this.value); })
            for (var i = timeScale.length; i <= timeScale.length; i--) {
                if (timeScale[i] <= $("#etime").val()) {
                    $("#stime").selectpicker('val', timeScale[i - 1]);
                    break;
                }
            }
            $("#stime").selectpicker('refresh');
            $("#stime").selectpicker('render');
        }
        getFromRoom();
    })
    $("#Save").click(function () {
        var flag = $("#form").valid();
        if (!flag) {
            return;
        }
        var arry = [];
        var mymeetingdatasource, no, type, subject, notes, recurrence, operator, contact, site, description, status, applicant, appname, contactname, datesubject, datenotes, uid, href, room, roomip, MaxNoOfVCConnection, roomadmin, remark, location, appext,
        contactext, OSAremark, Ext, badge, time, meetingdesc, siteid, roomid, attendees, ver, Seat, startdate, enddate, appdate,
        opdate, starttime, endtime, confirm, confirmCheck, ignoreAttendees, sendUpdate, needConfirm;
        var WeeklyRadio = document.getElementsByName('Type');
        for (var i = 0; i < WeeklyRadio.length; i++) {
            if ($('input:radio[name=Type]')[i].checked == true) {
                type = $('input:radio[name=Type]')[i].value;
            }
        }
        subject = $("#Subject").val();
        notes = $("#Notes").text();
        appname = $("#Input").val();
        applicant = $("#inputHiddenId").val();
        time = $("#test1").val();
        starttime = $("#test1").val() + " " + $("#stime").val();
        endtime = $("#test1").val() + " " + $("#etime").val();
        badge = $("#inputHiddenId").val();
        no = $("#no").html();
        if (no == "") {
            ver = 1;
            appdate = Date.now;
        } else {
            $.ajax({
                type: "post",
                url: RootPath + "/M_Conference/getConferenceByNO",
                dataType: "json",
                async: false,
                data: { "no": no },
                success: function (result) {
                    var dt = JSON.parse(result);
                    ver = dt[0]._ver;
                    opdate = Date.now;
                }
            })
        }
        $.ajax({
            type: "post",
            url: RootPath + "/M_Employee/CurrentUser",
            dataType: "json",
            async: false,
            success: function (result) {
                var dt = JSON.parse(result);
                operator = dt;
            }
        })
        var sites = $("#Sitechange").val();
        for (var i = 0; i < sites.length; i++) {
            contactname = $("#" + 'Input' + i).val();
            contact = $("#" + 'inputHiddenId' + i).val();
            attendees = $("#" + 'Attendess' + i).val();
            roomid = $("#" + 'Rooms' + i).val();
            recurrence = $("#freq").val();
            $.ajax({
                type: "post",
                url: RootPath + "/M_Room/getRoomById",
                dataType: "json",
                async: false,
                data: { "resourceid": roomid },
                success: function (result) {
                    var dt = JSON.parse(result);
                    for (var i = 0; i < dt.length; i++) {
                        room = dt[i]._room;
                        roomip = dt[i]._roomIP;
                        description = dt[i]._description;
                        Ext = dt[i]._Ext;
                        type = dt[i]._type;
                        remark = dt[i]._remark;
                        roomadmin = dt[i]._roomadmin;
                        Seat = dt[i]._Seatl;
                        MaxNoOfVCConnection = dt[i]._MaxNoOfVCConnection;
                        needConfirm = dt[i].needConfirm;
                        if (needConfirm)
                            ConfirmCheck = true;
                        else
                            ConfirmCheck = false;
                    }
                }
            })
            $.ajax({
                type: "post",
                url: RootPath + "/M_Employee/GetUserByBadge",
                dataType: "json",
                async: false,
                data: { "badge": "80028560" },
                success: function (result) {
                    var dt = JSON.parse(result);
                    if (dt == ""||dt==null)
                        return;
                    contactext = dt._ext;
                    ext = dt._ext;
                }
            })
            siteid = $("#" + 'Sites' + i).val();
            arry.push(new M_Conference(mymeetingdatasource, no, type, subject, notes, recurrence, operator, contact, site, description, status, applicant, appname,
            contactname, datesubject, datenotes, uid, href, room, roomip, MaxNoOfVCConnection, roomadmin, remark, location, appext,
            contactext, OSAremark, Ext, badge, time, meetingdesc, siteid, roomid, attendees, ver, Seat, startdate, enddate, appdate,
            opdate, starttime, endtime, confirm, confirmCheck, ignoreAttendees, sendUpdate, needConfirm))
        }
        var recu = [];
        var startTime, endTime, date, status, no, subject, notes, flag;
        if (!$("#recu").val() == "") {
            var dt = JSON.parse($("#recu").val());
            for (var i = 0; i < dt.length; i++)
            {
                startTime = dt[i]._startTime.substring(0, 10) + " " + $("#stime").val();
                endTime = dt[i]._endTime.substring(0, 10) + " " + $("#etime").val();
                date = dt[i]._date;
                status = dt[i]._status;
                no =$("#no").html();
                subject = dt[i]._subject;
                notes = dt[i]._notes;
                flag = dt[i]._flag;
                recu.push(new M_Recu(startTime, endTime, date, status, no, subject, notes, flag));
            }
            $("#isRecu").val(true);
        }
        var Attendees = [];
        var no, Badge, name, ext, dept, siteid;
        var key = "";
        if ($("#no").html() != "") {         
            key = $("#no").html() + "," + getCookie("OldStartTime") + "," + getCookie("OldEndTime");
        }
        $("#AttendessInfoGroup").find("tr").each(function () {
            var tdArr = $(this).children();
            var dept = tdArr.eq(0).text();
            var name = tdArr.eq(1).text();
            var badge = tdArr.eq(2).text();
            no = $("#no").html();
            siteid = 0;
            ext = "";
            var groupname = $("#InputGroup").val();
            Attendees.push(new M_Attendees(no, badge, name, ext, dept, siteid));
        });
        $.ajax({
            type: "POST",
            async: false,
            url: RootPath + "/M_Conference/CreateConference",
            data: { "key": key, "type": $("#kind").val(), "M_Conference[]": JSON.stringify(arry), "Recu[]": JSON.stringify(recu), "Attendees[]": JSON.stringify(Attendees) },
            dataType: "json"
        }).then(function (result) {
            var dt = JSON.parse(result);
            console.log(dt);
            if (dt.IsSuccess == "S") {
                $("#Span_App").show();
                $("#div_NO").show();
                $("#no").html(dt.NO);
                layer.msg("Success", { time: 4000, icon: 6 });
            } else if (dt[0] == "F") {
                layer.msg("failed", { time: 4000, icon: 5 });
            }
        }).fail(function (data, status, xhr) {

        });
        return false;
    })
    $("#Sitechange").change(function () {
        getSites($("#Sitechange").find("option:selected").val());
    });
    $("#btn_Remove").click(function () {
        var no = $("#no").text();
        if (no == "") {
            layer.msg("no Is empty");
            return;
        }
        var start = getCookie("StartTime");
        var isrecu = $("#isRecu").val();
        var Remark = $("#Input_Remark").val();
        $.ajax({
            url: RootPath + "/M_Conference/RemoveConference",
            type: "post",
            data: { "no": no, "start": start, "isrecu": $("#isRecu").val(), "Remark": Remark },
            success: function (result) {
                var dt = JSON.parse(result);
                if (dt == "") {
                    return;
                }
                if (dt == "S")
                    layer.msg("Meeting is removed", { time: 4000, icon: 6 });
                else
                    layer.msg("Remove failed", { time: 4000, icon: 5 });
            }
        })
        return false;
    })
    /*M_Conference.cs*/
    function M_Conference(_mymeetingdatasource, _no, _type, _subject, _notes, _recurrence, _operator, _contact, _site, _description, _status, _applicant, _appname,
     _contactname, _datesubject, _datenotes, _uid, _href, _room, _roomip, _MaxNoOfVCConnection, _roomadmin, _remark, _location, _appext,
     _contactext, _OSAremark, _Ext, _badge, _time, _meetingdesc, _siteid, _roomid, _attendees, _ver, _Seat, _startdate, _enddate, _appdate,
     _opdate, _starttime, _endtime, _confirm, _confirmCheck, _ignoreAttendees, _sendUpdate, _needConfirm) //声明对象
    {

        this._mymeetingdatasource = _mymeetingdatasource;
        this._no = _no;
        this._type = _type;
        this._subject = _subject;
        this._notes = _notes;
        this._recurrence = _recurrence;
        this._operator = _operator;
        this._contact = _contact;
        this._site = _site;
        this._description = _description;
        this._status = _status;
        this._applicant = _applicant;
        this._appname = _appname;
        this._contactname = _contactname;
        this._datesubject = _datesubject;
        this._datenotes = _datenotes;
        this._uid = _uid;
        this._href = _href;
        this._room = _room;
        this._roomip = _roomip;
        this._MaxNoOfVCConnection = _MaxNoOfVCConnection;
        this._roomadmin = _roomadmin;
        this._remark = _remark;
        this._location = _location;
        this._appext = _appext;
        this._contactext = _contactext;
        this._OSAremark = _OSAremark;
        this._Ext = _Ext;
        this._badge = _badge;
        this._time = _time;
        this._meetingdesc = _meetingdesc;
        this._siteid = _siteid;
        this._roomid = _roomid;
        this._attendees = _attendees;
        this._ver = _ver;
        this._Seat = _Seat;
        this._startdate = _time;
        this._enddate = _time;
        this._appdate = _time;
        this._opdate = _time;
        this._starttime = _starttime;
        this._endtime = _endtime;
        this._confirm = false;
        this._confirmCheck = false;
        this._ignoreAttendees = false;
        this._sendUpdate = false;
        this._needConfirm = false;
    }
    /*M_Recu.cs*/
    function M_Recu(startTime, endTime, date, status, no, subject, notes, flag) {
        this._startTime = startTime;
        this._endTime = endTime;
        this._date = date;
        this._status = status;
        this._no = no;
        this._subject = subject;
        this._notes = notes;
        this._flag = flag;
    }
    /*M_Attendees.cs*/
    function M_Attendees(no, badge, name, ext, dept, siteid) {
        this._no = no;
        this._badge = badge;
        this._name = name;
        this._ext = ext;
        this._dept = dept;
        this._siteid = siteid;
    }
    /*M_Room.cs*/
    function M_Room(_site, _room, _roomIP, _description, _Ext, _type, _crtby, _roomdesc, _roomStatus, _roomTitle, _remark, _path, _roomadmin, _deptDesc, _mark, _Seat, _id, _siteid, _MaxNoOfVCConnection, _start, _end, _needConfirm, _deptUse) {
        this._site = _site;
        this._room = _room;
        this._roomIP = _roomIP;
        this._description = _description;
        this._Ext = _Ext;
        this._type = _type;
        this._crtby = _crtby;
        this._roomdesc = _roomdesc;
        this._roomStatus = _roomStatus;
        this._roomTitle = _roomTitle;
        this._remark = _remark;
        this._path = _path;
        this._roomadmin = _roomadmin;
        this._deptDesc = _deptDesc;
        this._mark = _mark;
        this._Seat = _Seat;
        this._id = _id;
        this._siteid = _siteid;
        this._MaxNoOfVCConnection = _MaxNoOfVCConnection;
        this._start = _start;
        this._end = _end;
        this._needConfirm = _needConfirm;
        this._deptUse = _deptUse;
    }
    /*M_Contacts.cs*/
    function M_Contacts(owner, groupname, badge, gid) {
        this._owner = owner;
        this._groupname = groupname;
        this._badge = badge;
        this._gid = gid;
    }
    function bindingScheduler() {
        var roomid = $('#room').val();
        var lay_id = $("#tabid").val();
        var siteIds = $("#Sites").val();
        var CurrentDate = $(".scheduler").dxScheduler("instance").option("currentDate");
        var startdate = ConvertTimestampToTime(CurrentDate);
        $.post(RootPath + "/M_Conference/getConference", { "roomid[]": roomid, "lay_id": lay_id, "startdate": startdate, "siteIds[]": siteIds }, function (data) {
            var dt = JSON.parse(data);
            if (dt !== null || dt !== undefined || dt !== "") {
                scheduler(dt.Conference, dt.Resource, CurrentDate);
            } else {
                scheduler("", "", CurrentDate);
            }
        })
    }

    function scheduler(Conference, Room, Date) {
        var isSelectionStarted = false;
        var target;
        var startData;
        var Dates = [];
        $("#isDrag").val("false");
        //  拖动功能
        var downHandler = function (e) {
            var el = $(e.target);
            if (el.hasClass("dx-scheduler-date-table-cell")) {
                startData = el.data().dxCellData;
                isSelectionStarted = true;
                target = e.target;
                setCookie("ResourceId", startData.groups.ResourceId);
            }
        }
        var upHandler = function (e) {
            e.cancel = true;
            var el = $(e.target);
            if (el.hasClass("dx-scheduler-date-table-cell") && target !== e.target) {
                if (isSelectionStarted) {
                    Dates.length = 0;
                    Dates.push(startData.startDate);
                    Dates.push(startData.endDate);
                    Dates.push(el.data().dxCellData.startDate);
                    Dates.push(el.data().dxCellData.endDate);
                    var result = sort(Dates);
                    setCookie("StartTime", convertTime(result[0][0], "hm"))
                    setCookie("EndTime", convertTime(result[0][3], "hm"))
                    setCookie("date", convertTime(result[0][0], "date"))
                    $("#isDrag").val("true");
                }
            }
            isSelectionStarted = false;
            target = null;
            startData = null;

        }
        // end 拖动功能   
        $(".scheduler").dxScheduler({
            views: ["day"],
            currentView: "day",
            currentDate: Date,
            firstDayOfWeek: 0,
            dataSource: Conference,
            allDayExpr: "festival",
            editing: {
                allowAdding: false,
                allowUpdating: false,
                allowDeleting: false,
                allowDragging: false,
            },
            startDayHour: 8,
            endDayHour: 23,
            noDataText: '<h1>No Data!!!</h1>',
            groups: ['ResourceId'],
            resources: [{
                fieldExpr: "ResourceId",
                allowMultiple: true,
                dataSource: Room,
            }],
            width: "100%",
            height: 780,
            crossScrollingEnabled: true,
            onCellClick: function (e) {
                if ($("#isDrag").val() == 'false') {
                    setCookie("ResourceId", e.cellData.groups.ResourceId);
                    setCookie("StartTime", convertTime(e.cellData.startDate, "hm"));
                    setCookie("date", convertTime(e.cellData.startDate, "date"))
                    setCookie("EndTime", convertTime(e.cellData.endDate, "hm"));
                }
                layer.open({
                    type: 1,
                    area: ['880px', '88%'],
                    maxmin: true,
                    zIndex: 2,
                    title: 'Create',
                    content: $('#book'),
                    cancel: function (layero) {
                        delCookie("ResourceId");
                        delCookie("StartTime");
                        delCookie("date");
                        delCookie("EndTime");
                        $("#no").empty();
                    },
                    success: function (layero, index) {
                        var startdate = getCookie("StartTime");//hh:mm
                        var SelectDate = getCookie("date");//yyyy-MM-dd
                        var enddate = getCookie("EndTime");//hh:mm
                        var ResourceId = getCookie("ResourceId");
                        $.post(RootPath + '/M_TimeScale/getTimeScale', function (data) {
                            var result = JSON.parse(data);
                            $("#test1").val(SelectDate);
                            var Soption = '';
                            var Eoption = '';
                            for (var i = 0; i < result.length; i++) {
                                if (i != result.length - 1) {
                                    Soption += '<option value=' + result[i].value + '>' + result[i].value + '</option>';
                                }
                                if (i > 0) {
                                    Eoption += '<option value=' + result[i].value + '>' + result[i].value + '</option>';
                                }
                            }
                            $("#stime").html(Soption);
                            $("#etime").html(Eoption);
                            $("#stime").selectpicker('val', startdate);
                            $("#etime").selectpicker('val', enddate);
                            $('#stime').selectpicker('refresh');
                            $('#stime').selectpicker('render');
                            $('#etime').selectpicker('refresh');
                            $('#etime').selectpicker('render');
                        })
                        $.post(RootPath + '/M_Site/getSites', function (data) {
                            var dt = JSON.parse(data);
                            var site = '';
                            for (var i = 0; i < dt.length; i++) {
                                site += '<option value=' + dt[i]._id + '>' + dt[i]._id + '</option>';
                            }
                            var radio = document.getElementsByName('Type');
                            var type = '';
                            for (var i = 0; i < radio.length; i++) {
                                if (radio[i].checked == true) {
                                    type = radio[i].value;
                                }
                            }
                            $("#Sitechange").append(site);
                            $("#Sitechange").selectpicker('refresh');
                            $("#Sitechange").selectpicker('render');
                        });
                        $.post(RootPath + '/M_Employee/CurrentUserInfo', function (data) {
                            var dt = JSON.parse(data);
                            $("#Input").val(dt._name);
                            $("#inputHiddenId").val(dt._badge);
                        });
                        layui.use(['form', 'laydate'], function () {
                            var laydate = layui.laydate;
                            var form = layui.form,
                             layer = layui.layer
                            laydate.render({
                                elem: '#test1',
                                showBottom: false,
                                lang: 'en',
                                calendar: true,
                            });
                            laydate.render({
                                elem: '#StartDate',
                                showBottom: false,
                                lang: 'en',
                                format: 'yyyy-MM-dd',
                                calendar: true,
                                min: DateAdd(0),
                                max: MonthAdd(3)
                            });
                            laydate.render({
                                elem: '#UntilDate',
                                showBottom: false,
                                lang: 'en',
                                calendar: true,
                                format: 'yyyy-MM-dd',
                                min: DateAdd(1),
                                max: MonthAdd(3),
                            });

                            form.on('switch(switchRecurrence)', function (data) {
                                if (this.checked == true) {
                                    $("#recurrenceContent").show();
                                    $("#Interval").val(1);
                                    $("#ForDay").val(0);
                                    RecurrenceRangeDisable(false);
                                    $("#ReFreq").selectpicker('val', '');
                                    $.post(RootPath + "/Home/getDate", function (result) {
                                        var dt = JSON.parse(result);
                                        $("#StartDate").val(dt.start.substring(0, 10));
                                        $("#UntilDate").val(dt.end.substring(0, 10));
                                    })
                                } else {
                                    $("#recurrenceContent").hide();
                                }
                            });
                            //监听邀请开关
                            form.on('switch(switchInvite)', function (data) {
                                if (this.checked == true) {
                                    $("#inviteContent").show();
                                    $('#Group').selectpicker('hide');
                                    $("#Update").hide();
                                } else {
                                    $("#inviteContent").hide();
                                }
                            });
                            //监听添加开关
                            form.on('switch(switchAdd)', function (data) {
                                if (this.checked == true) {
                                    $("#addContent").show();
                                } else {
                                    $("#addContent").hide();
                                }
                            });
                            SwitchRenderRecurrenceRange();
                            form.on('radio(everyTop)', function (data) {
                                if (data.elem.checked) {
                                    $('input:radio[name=Monthly]')[0].checked = false;

                                } else {
                                    $('input:radio[name=Monthly]')[0].checked = true;
                                }
                            });
                            SwitchRenderDaily();
                            form.on('radio(Every)', function (data) {
                                if (data.elem.checked) {
                                    $('input:radio[name=Month]')[0].checked = false;
                                } else {
                                    $('input:radio[name=Month]')[0].checked = true;
                                }
                            });
                            //Daily
                            form.on('radio(EDay)', function (data) {
                                if (data.elem.checked) {
                                    $('input:radio[name=EWeekly]')[0].checked = false;
                                } else {
                                    $('input:radio[name=EDay]')[0].checked = true;
                                }
                                form.render("radio");
                            });
                            form.on('radio(EWeekly)', function (data) {
                                if (data.elem.checked) {

                                    $('input:radio[name=EDay]')[0].checked = false;
                                } else {

                                    $('input:radio[name=EWeekly]')[0].checked = true;
                                }
                                form.render("radio");
                            });
                            // Monthly
                            form.on('radio(everyTop)', function (data) {
                                if (data.elem.checked) {
                                    $('input:radio[name=Monthly]')[0].checked = false;
                                } else {
                                    $('input:radio[name=Month]')[0].checked = true;
                                }
                                form.render("radio");
                            });
                            form.on('radio(Every)', function (data) {
                                if (data.elem.checked) {
                                    $('input:radio[name=Month]')[0].checked = false;
                                } else {
                                    $('input:radio[name=Monthly]')[0].checked = true;
                                }
                                form.render("radio");
                            });
                            //end Monthly
                            //GROUP
                            form.on('radio(SaveGroup)', function (data) {
                                if (data.elem.checked) {
                                    $('input:radio[name=groupUpdate]')[0].checked = false;
                                } else {
                                    $('input:radio[name=groupSave]')[0].checked = true;
                                }
                                form.render("radio");
                                $("#InputGroup").show();
                                $("#Savegroup").show();
                                $("#Update").hide();
                                $("#Group").selectpicker('hide');

                            });
                            form.on('radio(UpdateGroup)', function (data) {
                                if (data.elem.checked) {
                                    $('input:radio[name=groupSave]')[0].checked = false;
                                    $.post(RootPath + "/M_Attendees/GetAttendeesGroupName", function (data) {
                                        var dt = JSON.parse(data);
                                        if (dt.length != 0) {
                                            var option = "";
                                            $.each(dt, function (i, item) {
                                                option += '<option value="' + item._gid + '">' + item._groupname + '</option>';
                                            })
                                            $("#Group").html(option);
                                            $('#Group').selectpicker('refresh');
                                            $('#Group').selectpicker('render');
                                        } else {
                                            $('input:radio[name=groupSave]').checked = true;
                                            // form.render("radio");
                                        }
                                    })
                                } else {
                                    $('input:radio[name=groupUpdate]')[0].checked = true;
                                }
                                form.render("radio");
                                $("#InputGroup").hide();
                                $("#Savegroup").hide();
                                $("#Update").show();
                                $("#Group").selectpicker('show');

                            });
                            //END GROUP
                            form.on('radio(For)', function (data) {
                                if (data.elem.checked) {
                                    $('input:radio[name=radioUntil]')[0].checked = false;
                                } else {
                                    $('input:radio[name=For]')[0].checked = true;
                                }
                                form.render("radio");
                            })
                            form.on('radio(radioUntil)', function (data) {
                                if (data.elem.checked) {
                                    $('input:radio[name=For]')[0].checked = false;
                                } else {
                                    $('input:radio[name=radioUntil]')[0].checked = true;
                                }
                                form.render("radio");
                            })
                           
                            if (ResourceId != null || ResourceId != "") {
                                MeetingType(ResourceId);
                                form.render();
                            }
                        });
                        isCheckedRecurrenceSwitch(false);
                        disable(true);
                        $("#recurrenceContent").hide();
                        Drag(startdate, SelectDate, enddate, ResourceId);
                        $("#StatusTable").hide();
                        $("#scroll").hide();
                        $("#Span_App").hide();
                        setWeeklyCheck();
                    },
                    end: function () {
                        $("#recurrenceContent").hide();
                        $("#inviteContent").hide();
                        $("#addContent").hide();
                        $('#form')[0].reset();
                        $("#no").empty();
                        layer.msg("2");
                    }
                })
                e.cellData.cancel = false;
                $("#isDrag").val('false');
            },
            onAppointmentFormCreated: function (e) {

            },
            onAppointmentDblClick: function (e) {
                e.cancel = true;
            },
            //会议被点击
            onAppointmentClick: function (e) {
                var no = e.appointmentData;
                console.log(no);
                setCookie("OldStartTime", no.startDate);//为移除
                setCookie("OldEndTime", no.endDate);
                if (no == "")
                    return;
                var dt;
                var isRecurrence = false;
                var stop = "";
                $.ajax({
                    type: "post",
                    url: RootPath + "/M_Conference/CheckRecu",
                    data: { "no": no.ownerId },
                    dataType: "json",
                    async: true,
                    beforeSend: function () {
                        stop = layer.load(0, { shade: [0.3, '#fff'] });
                    },
                    success: function (result) {
                        if (JSON.parse(result) == 'Y') {
                            isRecurrence = true;
                        }
                        layer.close(stop);
                        var startdate = "";
                        var enddate = "";
                        if (isRecurrence == true) {
                            $("#isRecu").val(true);
                            $("#kind").val("occurrence");
                            layer.open({
                                title: "Open Recurring Item",
                                btn: ['OK', 'Cancel'],
                                area: ['420px', '240px'],
                                btnAlign: 'c',
                                content: "<div class=\"row\" id=\"OpenRecuItem\">"
                                            + "<div class=\"col-xs-3\">"
                                                     + "<div class=\"center-block IconPadding\">"
                                                        + "<i class=\"layui-icon\" style=\"font-size: 60px; color: #1E9FFF;\">&#xe607;</i>"
                                                     + "</div>"
                                            + "</div>"
                                            + "<div class=\"col-xs-9\">"
                                                    + "<div class=\"row\">"
                                                        + "<span class=\"\">Do you want to open only this occurrence or the series?</span>"
                                                    + "</div>"
                                                    + "<div class=\"row\">"
                                                          + "<div class='layui-form'>"
                                                              + "<input type=\"radio\" name=\"occurrence\" value=\"0\" title=\"Open this occurrence\" id=\"occurrence\" lay-filter=\"occurrence\" checked=\"\">"
                                                              + "<input type=\"radio\" name=\"series\" value=\"1\" title=\"Open this series\" id=\"series\" lay-filter=\"series\">"
                                                          + "</div>"
                                                    + "</div>"
                                             + "</div>"
                                        + "</div>",
                                success: function () {
                                    layui.use(['form'], function () {
                                        var form = layui.form
                                        form.on('radio(occurrence)', function (data) {
                                            if (data.elem.checked) {
                                                $('input:radio[name=series]')[0].checked = false;
                                                // $("#isRecu").val(false);

                                                $("#kind").val("occurrence");
                                            } else {
                                                $('input:radio[name=occurrence]')[0].checked = true;
                                            }
                                            form.render("radio");
                                        });
                                        form.on('radio(series)', function (data) {
                                            if (data.elem.checked) {
                                                $('input:radio[name=occurrence]')[0].checked = false;
                                                //  $("#isRecu").val(true);
                                                $("#kind").val("series");
                                            } else {
                                                $('input:radio[name=series]')[0].checked = true;
                                            }
                                            form.render("radio");
                                        });
                                        form.render();
                                    })
                                },
                                yes: function (index, layero) {
                                    var value = null;
                                    $("#Span_App").show();
                                    if ($('input:radio[name=occurrence]')[0].checked == true) {
                                        value = $('input:radio[name=occurrence]')[0].value;
                                    } else if ($('input:radio[name=series]')[0].checked == true) {
                                        value = $('input:radio[name=series]')[0].value;
                                    }
                                    var meetingSource = null;
                                    $.ajax({
                                        type: "post",
                                        async: true,
                                        data: { "no": no.ownerId, "startTime": no.startDate, "endTime": no.endDate },
                                        url: RootPath + "/M_Conference/GetAllMeetings",
                                        success: function (restult) {
                                            meetingSource = JSON.parse(restult);
                                            instantiationLayui();
                                            if (value == "1")
                                            {
                                                /*获取循环规则*/
                                                getM_Freq(meetingSource);
                                                getRecuList(no.ownerId);
                                                isDisabledRecurrenceSwitch(false);
                                                isCheckedRecurrenceSwitch(true);
                                            } else
                                            {
                                                isCheckedRecurrenceSwitch(false);
                                                isDisabledRecurrenceSwitch(true);
                                                $("#recurrenceContent").hide();
                                                setWeeklyCheck();
                                            }
                                            /*获取会议的类型，并设置type radio选中的值*/
                                            MeetingType(no.ResourceId);
                                            /*获取与会人数*/
                                            getAttendees(no.ownerId);
                                            /*获取select标签值，并设置选中的值*/
                                            startdate = convertTime(no.startDate, "hm");
                                            enddate = convertTime(no.endDate, "hm");
                                            getTimeScale(startdate, enddate);
                                            getSites(meetingSource.length);
                                            /*获取空闲房间信息*/
                                            GetConferenceDetailInfo(no.ownerId, meetingSource[0]._type, no.startDate, no.endDate, meetingSource);
                                            layer.open({
                                                type: 1,
                                                area: ['880px', '88%'],
                                                maxmin: true,
                                                zIndex: 2,
                                                title: 'Update',
                                                content: $('#book'),
                                                success: function (layero, index) {
                                                    layer.close(stop);
                                                },
                                                cancel: function () {
                                                    $("#scroll").hide();
                                                    $("#StatusBody").empty();
                                                    isDisabledRecurrenceSwitch(false);
                                                    isCheckedRecurrenceSwitch(false);
                                                    $("#recurrenceContent").hide();
                                                    $("#no").empty();
                                                    $("#Span_App").hide();
                                                    $('#form')[0].reset();
                                                    cancelCallBack();
                                                }
                                            })
                                            layer.close(index);
                                        }
                                    })
                                },
                                cancel: function () {


                                }
                            })
                        } else {
                            $("#isRecu").val(false);
                            $("#kind").val("occurrence");
                            var meetingSource = null;
                            disable(true);
                            var main = $.ajax({
                                type: "post",
                                async: true,
                                data: { "no": no.ownerId, "startTime": no.startDate, "endTime": no.endDate },
                                url: RootPath + "/M_Conference/GetAllMeetings",
                                success: function (restult) {
                                    meetingSource = JSON.parse(restult);
                                }
                            });
                            main.then(function () {
                                instantiationLayui();
                                /*获取会议的类型，并设置type radio选中的值*/
                                var type = MeetingType(no.ResourceId);
                                /*获取与会人数*/
                                var deferredTime = getSites(meetingSource.length);
                                /*获取select标签值，并设置选中的值*/
                                var promiseGetSites = deferredTime.then(function () {
                                    startdate = convertTime(no.startDate, "hm");
                                    enddate = convertTime(no.endDate, "hm");
                                    getTimeScale(startdate, enddate);
                                })
                                /*获取与会人数*/
                                var derfered_M_Attendees = type.then(function () {
                                    getAttendees(no.ownerId);
                                })
                                /*获取循环规则*/
                                var derfered_M_Recu = derfered_M_Attendees.then(function () {
                                    return getRecuList(no.ownerId);
                                })
                                /*获取空闲房间信息*/
                                var derferedConferenceDetail = type.then(function (result) {
                                    return GetConferenceDetailInfo(no.ownerId, JSON.parse(result)[0]._type, no.startDate, no.endDate, meetingSource)
                                })
                                /*获取选中的会议信息*/
                                var deferred_M_Conference = derferedConferenceDetail.then(function () {
                                    if (meetingSource == "" || meetingSource == null) {
                                        layer.msg("NO data");
                                        return;
                                    }
                                    $("#Input").val(meetingSource[0]._appname);
                                    $("#inputHiddenId").val(meetingSource[0]._applicant);
                                    $("#Subject").val(meetingSource[0]._subject);
                                    $("#Notes").val(meetingSource[0]._notes);
                                    $("#test1").val(meetingSource[0]._starttime.substring(0, 10));
                                    $("#div_NO").show();
                                    $("#no").html(meetingSource[0]._no);
                                    $("#no").show();
                                    $("#Span_App").show();
                                    getSitesCount(meetingSource.length);
                                    $.each(meetingSource, function (i, item) {
                                        var siteid = 'Sites' + i;
                                        var roomid = 'Rooms' + i;
                                        var inputid = 'Input' + i;
                                        var attendessid = 'Attendess' + i;
                                        var inputHiddenId = 'inputHiddenId' + i;

                                        $("#" + inputid).val(item._contactname);

                                        $("#" + attendessid).val(item._attendees);
                                        $("#" + inputHiddenId).val(item._badge);

                                        $("#" + siteid).selectpicker('refresh');
                                        $("#" + siteid).selectpicker('render');
                                        $("#" + siteid).selectpicker("val", item._siteid);


                                        $("#" + roomid).selectpicker('refresh');
                                        $("#" + roomid).selectpicker('render');
                                        $("#" + roomid).selectpicker('val', item._roomid)
                                    })
                                    startdate = convertTime(meetingSource[0]._starttime, "hm");
                                    enddate = convertTime(meetingSource[0]._endtime, "hm");
                                })
                                var Open = deferred_M_Conference.then(function (result) {
                                    layer.open({
                                        type: 1,
                                        area: ['880px', '88%'],
                                        maxmin: true,
                                        zIndex: 2,
                                        title: 'Update',
                                        content: $('#book'),
                                        success: function (layero, index) {
                                            layer.close(stop);
                                            $("#Span_App").show();
                                        },
                                        cancel: function () {
                                            $("#scroll").hide();
                                            $("#StatusBody").empty();
                                            isDisabledRecurrenceSwitch(false);
                                            isCheckedRecurrenceSwitch(false);
                                            $("#recurrenceContent").hide();
                                            $("#no").html("");
                                            $('#form')[0].reset();
                                            cancelCallBack();
                                        }
                                    })
                                });
                            })
                        }
                    },
                    error: function (XMLHttpRequest, textStatus, errorThrown) {
                        layer.msg("textStatus = " + textStatus + ", XMLHttpRequest.status = " + XMLHttpRequest.status + ", XMLHttpRequest.readyState = " + XMLHttpRequest.readyState);
                        layer.close(stop);
                    },
                })
                e.cancel = true;
            },
            resourceCellTemplate: function (cellData, index, container) {
                var name = $("<div>")
                       .addClass("name")
                       .css({ "backgroundColor": "#fff", "width": "80%", "float": "left" })
                       .append($("<h2 style='margin-top:8px'>")
                       .text(cellData.text));
                var Remove = "";
                if (cellData.id.length != 8) {
                    Remove = $("<div>")
                                 .addClass("RemoveIcon").css({ "width": "20%", "float": "left" })
                                 .html("<span class=\"RemoveIconSelect\"><input  value=\"" + cellData.id + "\" style=\"display:none\"/><i class=\"layui-icon\" >&#x1006;</i></span>")
                }
                return $("<div>").append([name, Remove]);
            },
            timeCellTemplate: function (cellData, index, container) {
                container.parent().html('<td class="dx-scheduler-time-panel-cell" style="width:45px"><span style="font-size: 15px">' +
                cellData.text + '</span></td>' +
                '<td class="dx-scheduler-time-panel-cell" style="width:45px"><span style="font-size: 15px">' +
                 cellData.text + "</span></td>"
                );
            },
            onOptionChanged: function (data) {
                //if(data.name == "currentView"){DatumNavigatie();}
                // if(data.name == "currentDate"){DatumNavigatie();}
                //scheduler.scrollToTime(7,0);
                // console.log(data);
                //时间改变
                switch (data.name) {
                    case "currentDate":
                        var roomid = $('#room').val();
                        var lay_id = $("#tabid").val();
                        var date = $(".scheduler").dxScheduler("instance").option("currentDate");
                        var startdate = ConvertTimestampToTime(date);
                        var siteIds = $("#Sites").val();
                        var stop = "";
                        $.ajax({
                            type: "post",
                            async: false,
                            url: RootPath + "/M_Conference/FirstLogin",
                            data: { "lay_id": lay_id, "startdate": startdate },
                            beforeSend: function () {
                                stop = layer.load(0, { shade: [0.3, '#fff'] });
                            },
                            success: function (data) {
                                var result = JSON.parse(data);

                                layer.close(stop);
                                scheduler(result.Conference, result.Resource, date);
                            },
                            error: function (XMLHttpRequest, textStatus, errorThrown) {
                                layer.msg("textStatus = " + textStatus + ", XMLHttpRequest.status = " + XMLHttpRequest.status + ", XMLHttpRequest.readyState = " + XMLHttpRequest.readyState);
                                layer.close(stop);
                            },
                        })
                        break;
                    case "currentView":
                        break;
                }
            },
            onContentReady: function (arg) {
                $(arg.element).off("dxpointerdown", downHandler);
                $(arg.element).off("dxpointerup", upHandler);
                $(arg.element).on("dxpointerdown", downHandler);
                $(arg.element).on("dxpointerup", upHandler);
            },
        }).dxScheduler("instance");
        $(".RemoveIconSelect").click(function () {
            var roomid = $(this).children("input").val();
            var TabID = $("#tabid").val();
            try {
                $.post(RootPath + '/M_Room/DeleteRoom', { "roomid": roomid, "TabID": $("#tabid").val() }, function (result) {
                    var result = JSON.parse(result);

                    if (result == true) {
                        layer.msg("Delete Success", { time: 4000, icon: 6 });
                        var Resourceid = $("#room").val();
                        if (Resourceid !== null) {
                            var result = [];
                            for (var i = 0; i < Resourceid.length; i++) {
                                if (Resourceid[i] != roomid) {
                                    result.push(Resourceid[i]);
                                }
                            }
                            $("#room").selectpicker('val', result);
                            $("#room").selectpicker('refresh');
                            $("#room").selectpicker('render');
                        }
                        bindingScheduler();
                    } else {
                        layer.msg("Delete Failed", { time: 4000, icon: 5 });
                    }
                })
            } catch (e) {
                layer.msg("error:" + e);
            }
        })
    }
    /*拖动*/
    function Drag(startdate, SelectDate, enddate, ResourceId) {
        var radio = document.getElementsByName('Type');
        var type = '';
        for (var i = 0; i < radio.length; i++) {
            if (radio[i].checked == true) {
                type = radio[i].value;
            }
        }
        var stime = SelectDate + " " + startdate;
        var etime = SelectDate + " " + enddate;
        $.ajax({
            type: "post",
            url: RootPath + "/M_Room/getRoomById",
            dataType: "json",
            data: { "ResourceId": ResourceId },
            success: function (result) {
                var Dt = JSON.parse(result);
                $.post(RootPath + '/M_Room/getFreeRooms', { "Type": type, "stime": stime, "etime": etime, "site": Dt[0]._siteid }, function (result) {
                    var dt = JSON.parse(result);
                    var option = '';
                    for (var i = 0; i < dt.FreeRoom.length; i++) {
                        option += '<option value=' + dt.FreeRoom[i]._id + '>' + dt.FreeRoom[i]._roomTitle + '</option>';
                    }
                    $("#Sites0").selectpicker('val', Dt[0]._siteid);
                    $("#Sites1").selectpicker('val', "");
                    $("#Rooms0").append(option);
                    $("#Rooms0").selectpicker('val', ResourceId);
                    $("#Rooms0").selectpicker('refresh');
                    $("#Rooms0").selectpicker('render');
                })
            }
        })
    }
    /*开始  控制Recurrence效果*/
    function disable(T) {
        RecurrenceRangeDisable(T);
        DailyDisable(T);
        WeeklyDisable(T);
        MonthlyDisable(T);
    }
    function isDisabledRecurrenceSwitch(para) {
        var result = layui.use(['form'], function () {
            var form = layui.form
            $("#switchRecurrence").attr("disabled", para);
            form.render("checkbox")
        })
        return result;
    }
    function isCheckedRecurrenceSwitch(para) {
        var result = layui.use(['form'], function () {
            var form = layui.form
            $("#switchRecurrence").attr("checked", para);
            form.render("checkbox");
        })
        return result;
    }

    function RecurrenceRangeDisable(T) {
        var date = document.getElementsByName('date');
        for (var i = 0; i < date.length; i++) {
            if (T == true) {
                $(date[i]).attr("disabled", "disabled");

            } else if (T == false) {
                $(date[i]).removeAttr("disabled");
            }
        }
        if (T == true) {
            $("#radioUntil").attr("disabled", "disabled");
            $("#For").attr("disabled", "disabled");
        } else {
            $("#radioUntil").removeAttr("disabled");
            $("#For").removeAttr("disabled");
            layui.use(['form'], function () {
                var form = layui.form;
                form.render("radio");
            })
        }
    }
    function DailyDisable(T) {
        if (T == true) {
            $("#EDay").attr("disabled", "disabled");
            $("#EWeekly").attr("disabled", "disabled");
        } else if (T == false) {
            $("#EDay").removeAttr("disabled");
            $("#EWeekly").removeAttr("disabled");

        }
        layui.use(['form'], function () {
            var form = layui.form;
            form.render("radio");
        })
    }
    function WeeklyDisable(T) {
        var WeeklyRadio = document.getElementsByName('Weekly');
        if (T == true) {
            for (var i = 0; i < WeeklyRadio.length; i++) {
                $(WeeklyRadio[i]).attr("disabled", "disabled");

                $('input:checkbox[name=Weekly]')[i].checked = false;

            }
        } else {
            for (var i = 0; i < WeeklyRadio.length; i++) {
                $(WeeklyRadio[i]).removeAttr("disabled");

            }
        }

        layui.use(['form'], function () {
            var form = layui.form;
            form.render("checkbox");
        })
    }
    function MonthlyDisable(T) {
        if (T == true) {
            $("#Every").attr("disabled", "disabled");
            $("#Monthly").attr("disabled", "disabled");
            $("#eFirst").attr("disabled", "disabled")
            $("#eSecond").attr("disabled", "disabled")
        } else {
            $("#Every").removeAttr("disabled");
            $("#Monthly").removeAttr("disabled");
            $("#eFirst").removeAttr("disabled");
            $("#eSecond").removeAttr("disabled");
        }
        layui.use(['form'], function () {
            var form = layui.form;
            form.render("radio");
        })
        $('#eFirst').selectpicker('refresh');
        $('#eFirst').selectpicker('render');
        $('#eSecond').selectpicker('refresh');
        $('#eSecond').selectpicker('render');

    }
    function SwitchRenderRecurrenceRange() {
        layui.use(['form'], function () {
            var form = layui.form
            form.on('radio(radioUntil)', function (data) {
                if (data.elem.checked) {
                    $('input:radio[name=date]')[0].checked = false;
                } else {
                    $('input:radio[name=date]')[0].checked = true;
                }
                form.render("radio");
            });
            form.on('radio(For)', function (data) {

                if (data.elem.checked) {

                    $('input:radio[name=radioUntil]')[0].checked = false;
                } else {

                    $('input:radio[name=radioUntil]')[0].checked = true;
                }
                form.render("radio");
            });
        })
    }
    function SwitchRenderDaily() {
        layui.use(['form'], function () {
            var form = layui.form
            form.on('radio(EDay)', function (data) {
                if (data.elem.checked) {
                    $('input:radio[name=EDay]')[0].checked = false;
                } else {
                    $('input:radio[name=EDay]')[0].checked = true;
                }
                form.render("radio");
            });
            form.on('radio(EWeekly)', function (data) {
                if (data.elem.checked) {
                    $('input:radio[name=EWeekly]')[0].checked = false;
                } else {
                    $('input:radio[name=EWeekly]')[0].checked = true;
                }
                form.render("radio");
            });
        })
    }
    /*设置选择星期几*/
    function setWeeklyCheck() {
        layui.use(['form'], function () {
            var form = layui.form;
            var date = new Date();
            var a = date.getDay();
            var title = "";
            switch (a) {
                case 1:
                    title = "Mon";
                    break;
                case 2:
                    title = "Tue";
                    break;
                case 3:
                    title = "Wed";
                    break;
                case 4:
                    title = "Thu";
                    break;
                case 5:
                    title = "Fri";
                    break;
                case 6:
                    title = "Sta";
                    break;
                case 7:
                    title = "Sun";
                    break;
            }
            var WeeklyRadio = document.getElementsByName('Weekly');
            for (var i = 0; i < WeeklyRadio.length; i++) {
                if ($('input:checkbox[name=Weekly]')[i].title == title) {
                    $('input:checkbox[name=Weekly]')[i].checked = true;
                }
            }
            form.render("checkbox");
        })
    }
    /*编辑 开始*/
    function getSitesCount(count) {
        var site = $.ajax({
            type: "post",
            async: true,
            url: RootPath + "/M_Site/getSites",
            success: function (data) {
                var dt = JSON.parse(data);
                var site = '';
                for (var i = 0; i < dt.length; i++) {
                    site += '<option value=' + dt[i]._id + '>' + dt[i]._id + '</option>';
                }
                $("#Sitechange").html(site);
                $("#Sitechange").selectpicker('val', count);
                $("#Sitechange").selectpicker('refresh');
                $("#Sitechange").selectpicker('render');
            }
        })
        return site;
    }
    function getTimeScale(startdate, enddate) {
        var TimeScale = $.ajax({
            type: "post",
            async: false,
            url: RootPath + "/M_TimeScale/getTimeScale",
            success: function (data) {
                var result = JSON.parse(data);
                var Soption = '';
                var Eoption = '';
                for (var i = 0; i < result.length; i++) {
                    if (i != result.length - 1) {
                        Soption += '<option value=' + result[i].value + '>' + result[i].value + '</option>';
                    }
                    if (i > 0) {
                        Eoption += '<option value=' + result[i].value + '>' + result[i].value + '</option>';
                    }
                }
                $("#stime").html(Soption);
                $("#etime").html(Eoption);
                $("#stime").selectpicker('val', startdate);
                $('#stime').selectpicker('refresh');
                $('#stime').selectpicker('render');
                $("#etime").selectpicker('val', enddate);
                $('#etime').selectpicker('refresh');
                $('#etime').selectpicker('render');
            }
        })
        return TimeScale;
    }
    function getAttendees(NO) {
        var Attendees = $.ajax({
            type: "POST",
            url: RootPath + "/M_Attendees/GetAttendees",
            dataType: "json",
            async: true,
            data: { "no": NO },
            success: function (result) {
                var ds = JSON.parse(result);
                if (ds.length > 0) {
                    var body;
                    for (var i = 0; i < ds.length; i++) {
                        body += "<tr><td>" + ds[i]._dept + "</td><td>" + ds[i]._name + "</td><td>" + ds[i]._badge + "</td><td><i class=\"layui-icon\" style=\"font-size: 26px; color: #5FB878;\" value=" + ds[i]._badge + " onclick=\"del(this)\">&#xe640;</i></td></tr>";
                    }
                    $("#AttendessInfoGroup").append(body);
                    IsShowInvite(true);
                    $("#inviteContent").show();
                } else {
                    $("#inviteContent").hide();
                }
            }
        })
        return Attendees;
    }
    function getRecuList(NO) {
        var Recu = $.ajax({
            type: "POST",
            url: RootPath + "/M_Recu/GetRecuList",
            dataType: "json",
            async: false,
            data: { "no": NO },
            success: function (result) {
                if (result == null && result == "") { return; }
                var dt = JSON.parse(result);
                if (dt.length > 1) {
                    var tbody = "";
                    $.each(dt, function (i, item) {
                        tbody += '<tr><td>' + item._date.substring(0, 10) + '</td><td>' + item._status + '</td></tr>';
                    })
                    $("#StatusBody").html(tbody);

                    isShowRecurrence(true);
                    $("#recurrenceContent").show();
                    $("#scroll").show();
                    $("#StatusTable").show();
                    $("#StatusBody").show();
                } else {
                    isShowRecurrence(false);
                }
            }
        })


        return Recu;
    }
    function GetConferenceDetailInfo(No, Type, StartTime, EndTime, meetingSource) {
        var meeting = $.ajax({
            type: "POST",
            url: RootPath + "/M_Conference/GetEidtConference",
            dataType: "json",
            async: false,
            data: { "no": No, "type": Type, "StartTime": StartTime, "EndTime": EndTime },
            success: function (jsonResult) {
                var dtsource = JSON.parse(jsonResult);
                $("#Input").val(meetingSource[0]._appname);
                $("#inputHiddenId").val(meetingSource[0]._applicant);
                $("#Subject").val(meetingSource[0]._subject);
                $("#Notes").val(meetingSource[0]._notes);
                $("#test1").val(meetingSource[0]._starttime.substring(0, 10));
                $("#div_NO").show();
                $("#no").html(meetingSource[0]._no);
                $("#no").show();
                getSitesCount(meetingSource.length);
                getSites(meetingSource.length);
                for (var j = 0; j < meetingSource.length; j++) {
                    var roomid = 'Rooms' + j;
                    var siteid = 'Sites' + j;
                    var inputid = 'Input' + j;
                    var attendessid = 'Attendess' + j;
                    var inputHiddenId = 'inputHiddenId' + j;
                    var room = "";

                    for (var i = 0; i < dtsource.length; i++) {
                        if (meetingSource[j]._siteid == dtsource[i]._siteid)
                            room += '<option value=' + dtsource[i]._id + '>' + dtsource[i]._roomTitle + '</option>';
                    }

                    $("#" + roomid).html(room);
                    $("#" + roomid).selectpicker('refresh');
                    $("#" + roomid).selectpicker('render');

                    $("#" + siteid).selectpicker("val", meetingSource[j]._siteid);

                    $("#" + attendessid).val(meetingSource[j]._attendees);

                    $("#" + inputid).val(meetingSource[j]._contactname);

                    $("#" + inputHiddenId).val(meetingSource[j]._badge);
                    $("#" + roomid).selectpicker('val', meetingSource[j]._roomid);
                }
            }
        });
        return meeting;
    }
    //将循环规则还原为form object
    function getM_Freq(obj) {
        $.ajax({
            type: "POST",
            url: RootPath + "/M_Freq/getM_Freq",
            dataType: "json",
            async: false,
            data: { "freq": obj[0]._recurrence, "Sdate": obj[0]._startdate, "Edate": obj[0]._enddate },
            success: function (result) {
                var dt = JSON.parse(result);
                $("#Interval").val(dt._interval);
                $("#StartDate").val(obj[0]._startdate.substring(0, 10));
                if (dt._rangecheck == "1") {
                    $("#ForDay").val(dt._rangevalue);
                    layui.use(['form'], function () {
                        var form = layui.form;
                        $('input:radio[name=For]')[0].checked = true;
                        $('input:radio[name=radioUntil]')[0].checked = false;
                        form.render("radio");
                    })
                    $("#UntilDate").val(dt._untildate.substring(0, 10));
                    renderRange(true, false);
                } else {

                    $("#UntilDate").val(dt._untildate.substring(0, 10));
                    renderRange(false, true);
                }
                switch (dt._frequency) {
                    case "Daily":
                        $("#ReFreq").selectpicker('val', "1");
                        WeeklyDisable(true);
                        MonthlyDisable(true);
                        break;
                    case "Weekly":
                        $("#ReFreq").selectpicker('val', "2");
                        DailyDisable(true);
                        MonthlyDisable(true);
                        var arry = dt._weeklychecks.split(",");
                        var WeeklyRadio = document.getElementsByName('Weekly');
                        for (var j = 0; j < arry.length; j++) {
                            for (var i = 0; i < WeeklyRadio.length; i++) {
                                if ($('input:checkbox[name=Weekly]')[i].title == arry[j]) {
                                    $('input:checkbox[name=Weekly]')[i].checked = true;
                                }
                            }
                        }
                        break;
                    case "Monthly":
                        $("#ReFreq").selectpicker('val', "3");
                        DailyDisable(true);
                        WeeklyDisable(true);
                        break;
                }
                $('#ReFreq').selectpicker('refresh');
                $('#ReFreq').selectpicker('render');
            }
        })
    }
    function renderRange(obj1, obj2) {
        var result = layui.use(['form'], function () {
            var form = layui.form;
            form.on('radio(For)', function (data) {
                $('input:radio[name=For]')[0].checked == obj1;
                $('input:radio[name=radioUntil]')[0].checked == obj2;
            })
            form.render("radio");
        })
        return result;
    }
    /*编辑 结束*/
    function MeetingType(ResourceId) {
        var type = $.ajax({
            type: "POST",
            url: RootPath + "/M_Room/getRoomById",
            dataType: "json",
            async: false,
            data: { "ResourceId": ResourceId },
            success: function (data) {
                var result = JSON.parse(data);
                if (result[0]._type == "0") {
                    $("#VC").prop('checked', true);       
                    getSites(2);
                   // $("#Sitechange").selectpicker('val', "2");
                } else {
                    $("#NR").prop('checked', true);
                   // $("#Sitechange").selectpicker('val', "1");
                    getSites(1);
                }
                renderForm();
            }
        })
        return type;
    }
    /*重新渲染Layui Form 样式*/
    function renderForm() {
        var render = layui.use(['form'], function () {
            var form = layui.form
            form.render();
        })
        return render;
    }
    
    /*结束  控制Recurrence效果*/
    /*设置选择scheduler上的什么类型的房间(vc or  normal)*/
    /*实例化Layui*/
    function instantiationLayui() {
        var lay = layui.use(['form', 'laydate'], function () {
            var laydate = layui.laydate;
            var form = layui.form,
             layer = layui.layer
            laydate.render({
                elem: '#test1',
                showBottom: false,
                lang: 'en',
                calendar: true,
            });
            laydate.render({
                elem: '#StartDate',
                showBottom: false,
                lang: 'en',
                format: 'yyyy-MM-dd',
                calendar: true,
                min: DateAdd(0),
                max: MonthAdd(3)
            });
            laydate.render({
                elem: '#UntilDate',
                showBottom: false,
                lang: 'en',
                calendar: true,
                format: 'yyyy-MM-dd',
                min: DateAdd(1),
                max: MonthAdd(3),
            });
            form.on('switch(switchRecurrence)', function (data) {
                if (this.checked == true) {
                    $("#recurrenceContent").show();
                    $("#Interval").val(1);
                    $("#ForDay").val(0);
                    RecurrenceRangeDisable(false);
                    $("#ReFreq").selectpicker('val', '');
                    $.post(RootPath + "/Home/getDate", function (result) {
                        var dt = JSON.parse(result);
                        $("#StartDate").val(dt.start.substring(0, 10));
                        $("#UntilDate").val(dt.end.substring(0, 10));
                    })
                } else {
                    $("#recurrenceContent").hide();
                }
            });
            //监听邀请开关
            form.on('switch(switchInvite)', function (data) {
                if (this.checked == true) {
                    $("#inviteContent").show();
                    $('#Group').selectpicker('hide');
                    $("#Update").hide();
                } else {
                    $("#inviteContent").hide();
                }
            });
            //监听添加开关
            form.on('switch(switchAdd)', function (data) {
                if (this.checked == true) {
                    $("#addContent").show();
                } else {
                    $("#addContent").hide();
                }
            });
            SwitchRenderRecurrenceRange();
            form.on('radio(everyTop)', function (data) {
                if (data.elem.checked) {
                    $('input:radio[name=Monthly]')[0].checked = false;

                } else {
                    $('input:radio[name=Monthly]')[0].checked = true;
                }
            });
            SwitchRenderDaily();
            form.on('radio(Every)', function (data) {
                if (data.elem.checked) {
                    $('input:radio[name=Month]')[0].checked = false;
                } else {
                    $('input:radio[name=Month]')[0].checked = true;
                }
            });
            //Daily
            form.on('radio(EDay)', function (data) {
                if (data.elem.checked) {
                    $('input:radio[name=EWeekly]')[0].checked = false;
                } else {
                    $('input:radio[name=EDay]')[0].checked = true;
                }
                form.render("radio");
            });
            form.on('radio(EWeekly)', function (data) {
                if (data.elem.checked) {

                    $('input:radio[name=EDay]')[0].checked = false;
                } else {

                    $('input:radio[name=EWeekly]')[0].checked = true;
                }
                form.render("radio");
            });
            // Monthly
            form.on('radio(everyTop)', function (data) {
                if (data.elem.checked) {
                    $('input:radio[name=Monthly]')[0].checked = false;
                } else {
                    $('input:radio[name=Month]')[0].checked = true;
                }
                form.render("radio");
            });
            form.on('radio(Every)', function (data) {
                if (data.elem.checked) {
                    $('input:radio[name=Month]')[0].checked = false;
                } else {
                    $('input:radio[name=Monthly]')[0].checked = true;
                }
                form.render("radio");
            });
            //end Monthly

            //GROUP
            form.on('radio(SaveGroup)', function (data) {
                if (data.elem.checked) {
                    $('input:radio[name=groupUpdate]')[0].checked = false;
                } else {
                    $('input:radio[name=groupSave]')[0].checked = true;
                }
                form.render("radio");
                $("#InputGroup").show();
                $("#Savegroup").show();
                $("#Update").hide();
                $("#Group").selectpicker('hide');

            });
            form.on('radio(UpdateGroup)', function (data) {
                if (data.elem.checked) {
                    $('input:radio[name=groupSave]')[0].checked = false;
                    $.post(RootPath + "/M_Attendees/GetAttendeesGroupName", function (data) {
                        var dt = JSON.parse(data);
                        if (dt.length != 0) {
                            var option = "";
                            $.each(dt, function (i, item) {
                                option += '<option value="' + item._gid + '">' + item._groupname + '</option>';
                            })
                            $("#Group").html(option);
                            $('#Group').selectpicker('refresh');
                            $('#Group').selectpicker('render');
                        } else {
                            $('input:radio[name=groupSave]').checked = true;
                        }
                    })
                } else {
                    $('input:radio[name=groupUpdate]')[0].checked = true;
                }
                form.render("radio");
                $("#InputGroup").hide();
                $("#Savegroup").hide();
                $("#Update").show();
                $("#Group").selectpicker('show');

            });
            //END GROUP
            form.on('radio(For)', function (data) {
                if (data.elem.checked) {
                    $('input:radio[name=radioUntil]')[0].checked = false;
                } else {
                    $('input:radio[name=For]')[0].checked = true;
                }
                form.render("radio");
            })
            form.on('radio(radioUntil)', function (data) {
                if (data.elem.checked) {
                    $('input:radio[name=For]')[0].checked = false;
                } else {
                    $('input:radio[name=radioUntil]')[0].checked = true;
                }
                form.render("radio");
            })
            setWeeklyCheck();

        });
        return lay;
    }
    /*控制Invite Switch*/
    function IsShowInvite(result) {
        var inviteSwitch = layui.use(['form'], function () {
            var form = layui.form,
             layer = layui.layer
            $('#Group').selectpicker('hide');
            $("#Update").hide();
            $("#switchInvite").prop('checked', result);
            form.render('checkbox');
        })
        return inviteSwitch;
    }
    /*控制Recurrence Switch*/
    function isShowRecurrence(result) {
        var RecurrenceSwitch = layui.use(['form'], function () {
            var form = layui.form,
             layer = layui.layer
            $("#switchRecurrence").prop('checked', result);
            form.render('checkbox');
        })
        return RecurrenceSwitch;
    }
    function getSites(n) {
        var tbody = '';
        $("#meetingInfo").empty();
        for (var i = 0; i <= n - 1; i++) {
            var siteid = 'Sites' + i;
            var roomid = 'Rooms' + i;
            var inputid = 'Input' + i;
            var attendessid = 'Attendess' + i;
            var inputHiddenId = 'inputHiddenId' + i;
            tbody += '<tr><td></td><td><select class="selectpicker" name="' + siteid + '"  id="' + siteid + '" data-width="90px" onchange="SiteSelectChange(this)" required ></select></td><td><select class="selectpicker" name="' + roomid + '" id="' + roomid + '" ></select></td><td><input class=\'layui-input\' id="' + attendessid + '" name="' + attendessid + '" width="20"/></td><td><input id="' + inputid + '"  name="' + inputid + '" class=\'layui-input\' width="40" onkeyup="keyup(this)"/><input type="hidden" id="' + inputHiddenId + '"/></td></tr>';
        }
        $("#meetingInfo").html(tbody);
        var sites = $.ajax({
            type: "post",
            url: RootPath + '/M_Site/getSites',
            async: false,
            success: function (data) {
                var dt = JSON.parse(data);
                var dt = JSON.parse(data);
                if (n == 1) {
                    $("#Sitechange").selectpicker('val', 1);
                } else if (n == 2) {
                    $("#Sitechange").selectpicker('val', 2);
                } else {
                    $("#Sitechange").selectpicker('val', n);
                }
                var Site = '';
                for (var i = 0; i < dt.length; i++) {
                    Site += '<option value=' + dt[i]._id + '>' + dt[i]._site + '</option>';
                }
                for (var j = 0; j <= n - 1; j++) {
                    var siteid = 'Sites' + j;
                    var roomid = 'Rooms' + j;
                    $("#" + siteid).append(Site);
                    $("#" + siteid).selectpicker('refresh');
                    $("#" + siteid).selectpicker('render');
                    if (j !== 0)
                    {
                        $("#" + siteid).selectpicker("val", []);
                    }
                    $("#" + roomid).selectpicker('refresh');
                    $("#" + roomid).selectpicker('render');
                }
            }
        })
        return sites;
    }

    /*时间排序从小到大*/
    function sort(Dates) {
        var resultSort = new Array();
        var i;
        for (i = Dates.length; i;) Dates[--i] = [(new Date(Dates[i])).getTime(), Dates[i]]
        Dates.sort(function (A, B) { return A[0] - B[0] })
        for (i = Dates.length; i;) Dates[--i] = Dates[i][1]

        resultSort.push(Dates);
        return resultSort;
    }

    /*月份加*/
    function MonthAdd(j) {
        var now = new Date();
        var result = ConvertTimestampToTime(now.setMonth(now.getMonth() + j));
        var result2 = new Date(result);
        var result3 = result2.getFullYear() + "-" + (result2.getMonth() + 1) + "-" + result2.getDate();
        return result3;
    }
    /*天加*/
    function DateAdd(i) {
        var now = new Date();
        var result = ConvertTimestampToTime(now.setDate(now.getDate() + i));
        return result;
    }
    /*获取空闲房间信息*/
    function getFromRoom() {
        var length = $("#Sitechange").val();
        var sites = '';
        for (var i = 0; i < length; i++) {
            sites = sites + $("#" + 'Sites' + i).val() + ',';
        }
        var radio = document.getElementsByName('Type');
        var type = '';
        for (var i = 0; i < radio.length; i++) {
            if (radio[i].checked == true) {
                type = radio[i].value;
            }
        }
        $.ajax({
            type: "post",
            url: RootPath + "/M_Room/getFreeRooms",
            dataType: "json",
            async: true,
            data: { "Type": type, "stime": $("#test1").val() + " " + $("#stime").val(), "etime": $("#test1").val() + " " + $("#etime").val(), "site": sites.trim(',') },
            success: function (result) {
                var dt = JSON.parse(result);
                console.log(dt);
                for (var i = 0; i < length; i++) {
                    var option = '';
                    var p = $("#" + 'Sites' + i).val();
                    for (var j = 0; j < dt.FreeRoom.length; j++) {
                        if ($("#" + 'Sites' + i).val() == dt.FreeRoom[j]._siteid)
                            option += '<option value=' + dt.FreeRoom[j]._id + '>' + dt.FreeRoom[j]._roomTitle + '</option>';
                    }
                    $("#" + 'Rooms' + i).empty();
                    $("#" + 'Rooms' + i).append(option);
                    $("#" + 'Rooms' + i).selectpicker('val', "");
                    $("#" + 'Rooms' + i).selectpicker('refresh');
                    $("#" + 'Rooms' + i).selectpicker('render');
                }
            },
            error: function (data) {

            }
        })

    }
    /*关闭模态框的回调，重新绑定scheduler数据*/
    function cancelCallBack() {
        var startDate = ConvertTimestampToTime($(".scheduler").dxScheduler("instance").option("currentDate")).substring(0, 10);
        var result = $.ajax({
            type: "post",
            url: RootPath + '/M_Conference/FirstLogin',
            dataType: "json",
            async: false,
            data: { "lay_id": $("#tabid").val(), "startdate": startDate },
            success: function (result) {
                var dt = JSON.parse(result);
                scheduler(dt.Conference, dt.Resource, startDate);
            }
        })
        return result;
    }
})
/*名字工号自动填充*/
function keyup(obj) {
    if (obj == null || obj == "") {
        return;
    }
    var inputHiddenId = $(obj).attr("id").replace("Input", "inputHiddenId");
    var input = $("#" + $(obj).attr("id")).val();
    var Res = "";
    if (checkNumber(input)) {
        Res = "Number";
    } else {
        Res = "Character";
    }
    $.ajax({
        type: "post",
        url: RootPath + "/M_Employee/SearchEmployee",
        dataType: "json",
        data: { "input": input, "inputType": Res },
        success: function (result) {
            var data = JSON.parse(result);
            if (data == null || data == '') {
                return;
            }
            $("#" + $(obj).attr("id")).autocomplete({
                minLength: 0,
                source: data,
                focus: function (event, ui) {
                    if (Res == "Number") {
                        $("#" + $(obj).attr("id")).val(ui.item.label);
                    } else {
                        $("#" + $(obj).attr("id")).val(ui.item.icon);
                    }
                    return false;
                },
                select: function (event, ui) {
                    if (Res == "Number") {
                        $("#" + $(obj).attr("id")).val(ui.item.icon);
                    } else {
                        $("#" + $(obj).attr("id")).val(ui.item.label);
                    }
                    $("#" + inputHiddenId).val(ui.item.value);
                    return false;
                }
            })
           .autocomplete("instance")._renderItem = function (ul, item) {
               if (Res == "Number") {
                   return $("<li style='z-index:19891015'>").append("<div>" + item.icon + "<br>" + item.desc + "</div>").appendTo(ul);
               } else {
                   return $("<li style='z-index:19891015'>").append("<div>" + item.label + "<br>" + item.desc + "</div>").appendTo(ul);
               }
           };
        },
        error: function () {
            return;
        },
    })
}
/*正则表达式 验证字符串是否是字母*/
function CheckCharacter(Obj) {
    var reg = /^[A-Za-z]+$/;
    if (reg.test(Obj)) {
        return true;
    }
    return false;
}
/*正则表达式 验证字符串是否是数字*/
function checkNumber(Obj) {
    var reg = /^[0-9]+.?[0-9]*$/;
    if (reg.test(Obj)) {
        return true;
    }
    return false;
}
/*table中site选择*/
function SiteSelectChange(obj) {
    var radio = document.getElementsByName('Type');
    var type = '';
    for (var i = 0; i < radio.length; i++) {
        if (radio[i].checked == true) {
            type = radio[i].value;
        }
    }
    $.ajax({
        type: "post",
        url: RootPath + "/M_Room/getFreeRooms",
        dataType: "json",
        data: { "Type": type, "stime": $("#test1").val() + " " + $("#stime").val(), "etime": $("#test1").val() + " " + $("#etime").val(), "site": $("#" + $(obj).attr("id")).val() },
        success: function (result) {
            var dt = JSON.parse(result);
            var option = '';
            for (var i = 0; i < dt.FreeRoom.length; i++) {
                option += '<option value=' + dt.FreeRoom[i]._id + '>' + dt.FreeRoom[i]._roomTitle + '</option>';
            }
            var RoomId = $(obj).attr("id").replace("Sites", "Rooms");
            $("#" + RoomId).empty();
            $("#" + RoomId).append(option);
            $("#" + RoomId).selectpicker('val', "");
            $("#" + RoomId).selectpicker('refresh');
            $("#" + RoomId).selectpicker('render');
        }
    })
}
/*开始   Invite Attendees*/
function add(obj) {
    var badge = $(obj).attr("value");
    $.post(RootPath + "/M_Employee/SearchAttendees", { "Dept": "", "Name": "", "Badge": badge }, function (result) {
        var ds = JSON.parse(result);
        var body;
        for (var i = 0; i < ds.length; i++) {
            body += "<tr><td>" + ds[i]._dept + "</td><td>" + ds[i]._name + "</td><td>" + ds[i]._badge + "</td><td><i class=\"layui-icon\" style=\"font-size: 26px; color: #5FB878;\" value=" + ds[i]._badge + " onclick=\"del(this)\">&#xe640;</i></td></tr>";
        }
        $("#AttendessInfoGroup").append(body);
        layer.msg("Add Success");
    })
}
function del(obj) {
    $(obj).parents('tr').remove();
    layer.msg("Remove Success");
}
/*结束*/
