﻿$(function () {
    var scheduler = $("#scheduler").dxScheduler({
        dataSource: data,
        views: ["day"],
        currentView: "day",
        editing: {
            allowAdding: false,
        },
        onInitialized: function (e) {
            e.component
                .on("appointmentAdded", function (e) {
                    DevExpress.ui.notify("Appointment added");
                })
        },
        currentDate: new Date().getTime(),
        useDropDownViewSwitcher: false,
        firstDayOfWeek: 0,
        startDayHour: 7,
        endDayHour: 19,
        groups: ['priorityId'],
        resources: [{
            field: "priorityId",
            allowMultiple: false,
            dataSource: priorityData,
            label: "Priority"
        }],
        width: "100%",
        height: "100%",
        crossScrollingEnabled: true,
        showAllDayPanel: true,
        appointmentTooltipTemplate: function appointmentTooltip() {
        },
        onAppointmentRendered: function (e) {
            e.appointmentElement.on("dxhold", function () {
                setTimeout(function () {
                    e.component.showAppointmentTooltip(e.appointmentData, e.appointmentElement);
                }, 1000);

            });
            e.appointmentElement.on("dxhoverend", function () {
                e.component.hideAppointmentTooltip();
            });
        },
        onInitialized: function (e) {
            e.component
                .on("appointmentUpdating", function (e) {
                    e.cancel = $.Deferred();
                    DevExpress.ui.dialog.confirm("Update appointment?", "Confirm").done(function (dialogResponse) {
                        e.cancel.resolve(!dialogResponse);
                    });
                })
        },
        onCellClick: function (cellData, index, container) {

            layer.open({
                title: '在线调试',   
                content: '可以填写任意的layer代码'
            })
        }
    }).dxScheduler("instance");
})