﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data.SqlClient;

/// <summary>
/// Summary description for CommomFunction
/// </summary>
public class CommomFunction
{
    public CommomFunction()
    { }
    //
    // TODO: Add constructor logic here
    //
    string LoadDept()
    {
        string WorkCenter = null;
        string sql = "select  top 1 * from Counting_System_workcenter_mapping where dept='H23'";
        string sqlserver = ConfigurationManager.AppSettings["showdata"];

        SqlConnection sqlconn = new SqlConnection(sqlserver);
        SqlCommand SqlCmd = new SqlCommand(sql, sqlconn);
        try
        {
            sqlconn.Open();
            SqlDataReader SqlRD;
            SqlRD = SqlCmd.ExecuteReader();
            while (SqlRD.Read())
            {
                WorkCenter = WorkCenter + "'" + SqlRD["first_workcenter"].ToString() + "',";
            }
        }
        catch
        {

        }

        finally
        {
            if (WorkCenter != null && WorkCenter != "")
            {
                WorkCenter = WorkCenter.Substring(0, WorkCenter.Length - 1);

            }
            else
            {
                //MessageBox.Show("该部门没有数据显示");
                //return;
                //this.Dispose();
            }
            sqlconn.Close();
        }
        return WorkCenter;
    }
}
