﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.IO;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using SPC.BLL;
using SPC.Model;
using SPC.Commen;
using System.Data;
using System.Collections;


namespace SPC.UI
{
    /// <summary>
    /// Summary description for CheckUserState
    /// </summary>
    public class CheckUserState : IHttpHandler, System.Web.SessionState.IRequiresSessionState
    {

        public void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "text/plain";
            string action = context.Request["action"];
            BLL.SpcPartTemplateBLL bll = new SpcPartTemplateBLL();
            if (action == "CheckUserState")
            {
                #region 检查用户状态,主要看之前是否有过登陆，是否保存有session

                string c_name = bll.GetChineseName(((UserInfo)context.Session["spc_userinfo"]).User);
                context.Response.Write("ok:" + c_name);

                #endregion
            }
            else if (action == "login")
            {
                #region 登陆
                //string user = context.Request["username"];
                //string password = context.Request["password"];
                //string remember_me = context.Request["remember_me"];
                //UserInfo userinfo = new UserInfo();
                //if (bll.checkuserinfo(user, password, out userinfo))
                //{
                //    context.Session["spc_userinfo"] = userinfo;
                //    if (remember_me == "true")
                //    {
                //        HttpCookie cookie_user = new HttpCookie("sp1", user);
                //        HttpCookie cookie_password = new HttpCookie("sp2", Commen.Commen.GetMD5(password)); //加密密码    
                //        cookie_user.Expires = DateTime.Now.AddDays(7);//cookie保存在浏览器中7天
                //        cookie_password.Expires = DateTime.Now.AddDays(7);
                //        context.Response.Cookies.Add(cookie_user);
                //        context.Response.Cookies.Add(cookie_password);
                //    }
                //    else
                //    {
                //        if (context.Request.Cookies["sp1"] != null && context.Request.Cookies["sp2"] != null)
                //        {
                //            context.Response.Cookies["sp1"].Expires = DateTime.Now.AddDays(-1);  //删除cookie的方法
                //            context.Response.Cookies["sp2"].Expires = DateTime.Now.AddDays(-1);  //删除cookie的方法
                //        }
                //    }


                    string userName = "";
                    //string userName = HttpContext.Current.User.Identity.Name;
                    //string[] nameArray = userName.Split('\\');
                    userName = bll.GetChineseName(userName);
                    if (userName != "")
                    {
                        context.Response.Write(userName);
                    }
                    else
                    {
                        context.Response.Write(Environment.UserName);
                    }
                //}
                //else
                //{
                //    context.Response.Write("no:");
                //}

                #endregion
            }
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}