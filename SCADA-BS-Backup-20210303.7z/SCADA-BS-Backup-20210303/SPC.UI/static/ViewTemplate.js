$(function () {
    $("#_easyui_textbox_input1").attr('placeholder', "请输入工件号查询");

    loadTable("", "");
    $('.searchbox-button').click(function () {
        var templateType = GetType();
        doSearch(templateType);
    });


    $("#_easyui_textbox_input1").keydown(function () {
        var keynum = (event.keyCode ? event.keyCode : event.which);
        if (keynum == '13') {
            var templateType = GetType();
            doSearch(templateType);
        }
    });

    $('#_easyui_textbox_input1').focus();

});
function GetType() {
    var templateType = "";
    if ($('#IM-WS').is(':checked')) {
        templateType = "IM-WS";
    }
    else if ($('#IM-QC').is(':checked')) {
        templateType = "IM-QC";
    }
    else if ($('#EM-SBC').is(':checked')) {
        templateType = "EM-SBC";
    }
    else if ($('#EM-QC').is(':checked')) {
        templateType = "EM-QC";
    }
    else if ($('#RW').is(':checked')) {
        templateType = "RW";
    }
    else {
        templateType = "IM-WS";
    }
    return templateType;
};
function loadTable(part_num, templateType) {
    if ($("#input_changeLanguage").val() == "2") {
        $('#dg').datagrid({
            url: "ViewTemplate.ashx",   // 指向一个后台的地址，自动往后台发送pageSize，pageNumber
            title: 'Template',    //标题
            height: 700,     //高度
            fitColumns: true, //设置为 true，则会自动扩大或缩小列的尺寸以适应网格的宽度并且防止水平滚动。
            idField: 'Rowid',   //指示哪个字段是标识字段。
            loadMsg: 'Loading user information......', //加载数据的时候显示的文字
            pagination: true,  //是否分页
            singleSelect: false, //是否单选
            pageList: [10, 20, 30, 50], //指定一页显示多少个数
            pageSize: 20, //指定一页显示多少记录
            pageNumber: 1, //当前哪一页
            queryParams: { "action": "searchRecords", "part_num": part_num, "templateType": templateType }, //额外向后台发送的数据
            columns: [[
			{ field: 'ck', checkbox: true },
			{ field: 'Rowid', title: 'Seq' },
			{ field: 'Id', title: 'ID', hidden: true },
			{ field: 'Part_num', title: 'PartNum' },
			{ field: 'Part_rev', title: 'PartRev' },
			{ field: 'Badge', title: 'Badge' },
			{ field: 'Template_type', title: 'Type' },
			{ field: 'Rw_order', title: 'RwOrder' },
			{ field: 'Rw_seq', title: 'RwSeq' },
			{ field: 'Gn_type', title: 'Workcenter' },
			{ field: 'Sap_rou_workcenter', title: 'MachineType' },
			{ field: 'Fixture_pn', title: 'Fixture_pn' },
            { field: 'Fixture_array', title: 'Fixture_array' },
			{ field: 'Tooling_Ipna', title: 'Tooling_Ipna' },
			{ field: 'Gn_correl_enggdwg', title: 'Link', formatter: function (value, row, index) {
			    return CheckLink_to_drawing_lib(value);
			}
			},
			{ field: 'Dwg_label', title: 'DrawingLable' },
			{ field: 'Dwg_spec', title: 'Specification' },
			{ field: 'Upp_tol', title: 'UpperLimit' },
			{ field: 'Lwr_tol', title: 'LowerLimit' },
			{ field: 'Meas_eq', title: 'Equipment' },
			{ field: 'Eq_cal_code', title: 'GeneratedCode' },
			{ field: 'Eq_col_pts', title: 'RepeatedCounting' },
			{ field: 'Sample_plan', title: 'CheckNum' },
			{ field: 'Template_version', title: 'TemplateVersion' },
			{ field: 'Remark', title: 'Note' },
			{ field: 'Create_date', title: 'CreateDate', formatter: function (value, row, index) {
			    return ChangeDateFormat(value);
			}
			}
		]],
            toolbar: [{
                id: "btn_update",
                text: 'Update',
                iconCls: 'icon-edit',
                handler: function () {
                    //更新数据
                    updateRecords();
                    //刷新数据
                    $('#dg').datagrid('reload');

                }
            }, '-', {
                id: "btn_remove",
                text: 'Remove',
                iconCls: 'icon-remove',
                handler: function () {
                    //删除数据
                    removeRecords();
                }
            }
		]
        });
    }
    else {
        $('#dg').datagrid({
            url: "ViewTemplate.ashx",   // 指向一个后台的地址，自动往后台发送pageSize，pageNumber
            title: '模板',    //标题
            height: 700,     //高度
            fitColumns: true, //设置为 true，则会自动扩大或缩小列的尺寸以适应网格的宽度并且防止水平滚动。
            idField: 'Rowid',   //指示哪个字段是标识字段。
            loadMsg: '正在加载用户信息......', //加载数据的时候显示的文字
            pagination: true,  //是否分页
            singleSelect: false, //是否单选
            pageList: [10, 20, 30, 50], //指定一页显示多少个数
            pageSize: 20, //指定一页显示多少记录
            pageNumber: 1, //当前哪一页
            queryParams: { "action": "searchRecords", "part_num": part_num, "templateType": templateType }, //额外向后台发送的数据
            columns: [[
			{ field: 'ck', checkbox: true },
			{ field: 'Rowid', title: '序号' },
			{ field: 'Id', title: 'ID', hidden: true },
			{ field: 'Part_num', title: '工件号' },
			{ field: 'Part_rev', title: '版本号' },
			{ field: 'Badge', title: '创建人' },
			{ field: 'Template_type', title: '模板类型' },
			{ field: 'Rw_order', title: '不良单号' },
			{ field: 'Rw_seq', title: '不良序号' },
			{ field: 'Gn_type', title: '工序' },
			{ field: 'Sap_rou_workcenter', title: '机型' },
			{ field: 'Fixture_pn', title: '夹具' },
            { field: 'Fixture_array', title: '最大夹位' },
			{ field: 'Tooling_Ipna', title: 'IPNA' },
			{ field: 'Gn_correl_enggdwg', title: '图库关联', formatter: function (value, row, index) {
			    return CheckLink_to_drawing_lib(value);
			}
			},
			{ field: 'Dwg_label', title: '图标' },
			{ field: 'Dwg_spec', title: '尺寸规格' },
			{ field: 'Upp_tol', title: '上公差' },
			{ field: 'Lwr_tol', title: '下公差' },
			{ field: 'Meas_eq', title: '量仪' },
			{ field: 'Eq_cal_code', title: '合成码' },
			{ field: 'Eq_col_pts', title: '重复取点数' },
			{ field: 'Sample_plan', title: '抽检数量' },
			{ field: 'Template_version', title: '模板版本' },
			{ field: 'Remark', title: '备注' },
			{ field: 'Create_date', title: '创建时间', formatter: function (value, row, index) {
			    return ChangeDateFormat(value);
			}
			}
		]],
            toolbar: [{
                id: "btn_update",
                text: '修改',
                iconCls: 'icon-edit',
                handler: function () {
                    //更新数据
                    updateRecords();
                    //刷新数据
                    $('#dg').datagrid('reload');

                }
            }, '-', {
                id: "btn_remove",
                text: '删除',
                iconCls: 'icon-remove',
                handler: function () {
                    //删除数据
                    removeRecords();
                }
            }
		]
        });
    }
};

function doSearch(templateType) {
    if ($('.textbox-value').val() == "") {
        if ($("#input_changeLanguage").val() == "2") {
            AlertWindow("Please enter the part number.");
        }
        else {
            AlertWindow("请输入工件号");
        }
    }
    else {
        searchRecords($('.textbox-value').val(), templateType);
    }
};

//报警窗口
function AlertWindow(msg) {
    if ($("#input_changeLanguage").val() == "2") {
        $('#alert').dialog({
            title: 'Alert',
            width: 300,
            height: 200,
            closed: false,
            modal: true,
            buttons: [{
                text: 'Close',
                handler: function () {
                    $('#alert').dialog('close');

                }
            }]
        });
    }
    else {
        $('#alert').dialog({
            title: '提示',
            width: 300,
            height: 200,
            closed: false,
            modal: true,
            buttons: [{
                text: '关闭',
                handler: function () {
                    $('#alert').dialog('close');

                }
            }]
        });
    }
    $('#alert').html("<span>" + msg + "</span>");
    $('#alert').css("text-align", "center");
    $('#alert span').css({ "line-height": "88px", "font-size": "14px", "font-family": "Microsoft YaHei" });
    $('#alert').dialog('refresh');
};

//查询模板记录
function searchRecords(part_num, templateType) {
    loadTable(part_num, templateType);
};

//将序列化成json的日期转成日期格式
function ChangeDateFormat(cellval) {
    var date = new Date(parseInt(cellval.replace("/Date(", "").replace(")/", ""), 10));
    var month = date.getMonth() + 1 < 10 ? "0" + (date.getMonth() + 1) : date.getMonth() + 1;
    var currentDay = date.getDate() < 10 ? "0" + date.getDate() : date.getDate();
    var currentHour = date.getHours() < 10 ? "0" + date.getHours() : date.getHours();
    var currentMinute = date.getMinutes() < 10 ? "0" + date.getMinutes() : date.getMinutes();
    var currentSecond = date.getSeconds() < 10 ? "0" + date.getSeconds() : date.getSeconds();
    return date.getFullYear() + '-' + month + "-" + currentDay + " " + currentHour + ":" + currentMinute + ":" + currentSecond;
};

// 转换
function CheckLink_to_drawing_lib(cellval) {
    return cellval.toUpperCase() == "TRUE" ? "是" : "否";
};
//更新记录
function updateRecords() {
    var rows = $('#dg').datagrid('getSelections');
    if (rows.length == 0) {
        if ($("#input_changeLanguage").val() == "2") {
            $.messager.alert("Tips", "Please select the row first and then modify it.", "warning");
        }
        else {
            $.messager.alert("提示", "请先选中行，再修改。", "warning");
        }
        return;
    }
    else {
        updateWindow(rows);
    }


};
//删除记录
function removeRecords() {
    var rows = $('#dg').datagrid('getSelections');
    if (rows.length == 0) {
        if ($("#input_changeLanguage").val() == "2") {
            $.messager.alert("Tips", "Please select the row first and then remove it.", "warning");
        }
        else {
            $.messager.alert("提示", "请先选中行，再删除。", "warning");
        }
        return;
    }
    else {
        var delete_list = [];
        for (var i = 0; i < rows.length; i++) {
            var dict = {};
            dict["Id"] = rows[i]["Id"];
            dict["Part_num"] = rows[i]["Part_num"];
            dict["Part_rev"] = rows[i]["Part_rev"];
            dict["Template_type"] = rows[i]["Template_type"];
            dict["Template_version"] = rows[i]["Template_version"];
            dict["Dwg_spec"] = rows[i]["Dwg_spec"];
            delete_list.push(dict);
        }
        if ($("#input_changeLanguage").val() == "2") {
            ConfirmWindow("Are you sure you want to delete the " + rows.length.toString() + " rows of data?", delete_list);
        }
        else {
            ConfirmWindow("您确定要删除这" + rows.length.toString() + "行数据吗?", delete_list);
        }
    }

};

function updateWindow(rows) {
    if ($("#input_changeLanguage").val() == "2") {
        $('#update').dialog({
            title: 'Update',
            width: 1700,
            height: 500,
            modal: true,
            collapsible: true,
            minimizable: true,
            maximizable: true,
            resizable: true,
            buttons: [{
                text: 'Modify',
                iconCls: 'icon-edit',
                handler: function () {
                    $('#update').dialog('close');
                    submitUpdateDate();
                }
            }, {
                text: 'Close',
                iconCls: 'icon-cancel',
                handler: function () {
                    $('#update').dialog('close');
                }
            }]
        });
    }
    else {
        $('#update').dialog({
            title: '更新内容',
            width: 1700,
            height: 500,
            modal: true,
            collapsible: true,
            minimizable: true,
            maximizable: true,
            resizable: true,
            buttons: [{
                text: '修改',
                iconCls: 'icon-edit',
                handler: function () {
                    $('#update').dialog('close');
                    submitUpdateDate();
                }
            }, {
                text: '关闭',
                iconCls: 'icon-cancel',
                handler: function () {
                    $('#update').dialog('close');
                }
            }]
        });
    }
    var msg = showMsg(rows);
    $('#update').html(msg);
    $('#update').dialog('refresh');
};
function submitUpdateDate() {
    var $tr = $('#tb_update tr');
    var rownum = $tr.length;
    var list = [];
    if (rownum > 1) {
        for (var i = 1; i < rownum; i++) {
            var dict = {};
            var tdarr = $tr.eq(i).find("td");
            dict["Rowid"] = tdarr.eq(0).html();
            dict["Id"] = tdarr.eq(1).html();
            dict["Part_num"] = tdarr.eq(2).html();
            dict["Part_rev"] = tdarr.eq(3).html();
            dict["Badge"] = tdarr.eq(4).find('input').val();
            dict["Template_type"] = tdarr.eq(5).html();
            dict["Rw_order"] = tdarr.eq(6).find('input').val();
            dict["Rw_seq"] = tdarr.eq(7).find('input').val();
            dict["Gn_type"] = tdarr.eq(8).find('input').val();
            dict["Sap_rou_workcenter"] = tdarr.eq(9).find('input').val();
            dict["Fixture_pn"] = tdarr.eq(10).find('input').val();
            dict["Fixture_array"] = tdarr.eq(11).find('input').val();
            dict["Tooling_Ipna"] = tdarr.eq(12).find('input').val();
            dict["Gn_correl_enggdwg"] = tdarr.eq(13).find('input').val();
            dict["Dwg_label"] = tdarr.eq(14).find('input').val();
            dict["Dwg_spec"] = tdarr.eq(15).find('input').val();
            dict["Upp_tol"] = tdarr.eq(16).find('input').val();
            dict["Lwr_tol"] = tdarr.eq(17).find('input').val();
            dict["Meas_eq"] = tdarr.eq(18).find('input').val();
            dict["Eq_cal_code"] = tdarr.eq(19).find('input').val();
            dict["Eq_col_pts"] = tdarr.eq(20).find('input').val();
            dict["Sample_plan"] = tdarr.eq(21).find('input').val();
            dict["Template_version"] = tdarr.eq(22).html();
            dict["Remark"] = tdarr.eq(23).find('input').val();
            list.push(dict);
        }
    }
    if (list.length > 0) {
        $.post("ViewTemplate.ashx", { "action": "update", "data": JSON.stringify(list) }, function (data) {
            if (data["status"] == "ok") {
                if ($("#input_changeLanguage").val() == "2") {
                    $.messager.alert("Tips", "Update successfully!");
                }
                else {
                    $.messager.alert("提示", "更新成功！");
                }
            }
            else {
                if ($("#input_changeLanguage").val() == "2") {
                    $.messager.alert("Tips", "Update failed!");
                }
                else {
                    $.messager.alert("提示", "更新失败！");
                }
            }
            $('#dg').datagrid('reload');
        })
    }
};
function showMsg(rows) {
    var str_html = "";
    str_html += '<div class="container-fluid table-responsive">';
    str_html += '<table id="tb_update" class="table table-bordered">'
    str_html += "<tr>";
    if ($("#input_changeLanguage").val() == "2") {
        str_html += "<td>Seq</td>";
        str_html += "<td style='display:none'>ID</td>";
        str_html += "<td>PartNum</td>";
        str_html += "<td>PartRev</td>";
        str_html += "<td>Badge</td>";
        str_html += "<td>Type</td>";
        str_html += "<td>RwOrder</td>";
        str_html += "<td>RwSeq</td>";
        str_html += "<td>Gn_type</td>";
        str_html += "<td>Sap_rou_workcenter</td>";
        str_html += "<td>Fixture_pn</td>";
        str_html += "<td>Fixture_array</td>";
        str_html += "<td>Tooling_Ipna</td>";
        str_html += "<td>Gn_correl_enggdwg</td>";
        str_html += "<td>Dwg_label</td>";
        str_html += "<td>Dwg_spec</td>";
        str_html += "<td>Upp_tol</td>";
        str_html += "<td>Lwr_tol</td>";
        str_html += "<td>Meas_eq</td>";
        str_html += "<td>Eq_cal_code</td>";
        str_html += "<td>Eq_col_pts</td>";
        str_html += "<td>Sample_plan</td>";
        str_html += "<td>TemplateVersion</td>";
        str_html += "<td>Remark</td>";
    }
    else {
        str_html += "<td>序号</td>";
        str_html += "<td style='display:none'>ID</td>";
        str_html += "<td>工件号</td>";
        str_html += "<td>版本号</td>";
        str_html += "<td>创建人</td>";
        str_html += "<td>模板类型</td>";
        str_html += "<td>不良单号</td>";
        str_html += "<td>不良序号</td>";
        str_html += "<td>工序</td>";
        str_html += "<td>机型</td>";
        str_html += "<td>夹具</td>";
        str_html += "<td>最大夹位</td>";
        str_html += "<td>刀具</td>";
        str_html += "<td>图库关联</td>";
        str_html += "<td>图标</td>";
        str_html += "<td>尺寸规格</td>";
        str_html += "<td>上公差</td>";
        str_html += "<td>下公差</td>";
        str_html += "<td>量仪</td>";
        str_html += "<td>合成码</td>";
        str_html += "<td>重复取点数</td>";
        str_html += "<td>抽检数量</td>";
        str_html += "<td>模板版本</td>";
        str_html += "<td>备注</td>";
    }
    str_html += "</tr>";
    for (var i = 0; i < rows.length; i++) {
        str_html += "<tr>";
        str_html += "<td>" + rows[i]["Rowid"] + "</td>";
        str_html += "<td style='display:none'>" + rows[i]["Id"] + "</td>";
        str_html += "<td>" + rows[i]["Part_num"] + "</td>";
        str_html += "<td>" + rows[i]["Part_rev"] + "</td>";
        str_html += "<td><input type='text' value='" + rows[i]["Badge"] + "'/></td>";
        str_html += "<td>" + rows[i]["Template_type"] + "</td>";
        str_html += "<td><input type='text' value='" + rows[i]["Rw_order"] + "'/></td>";
        str_html += "<td><input type='text' value='" + rows[i]["Rw_seq"] + "'/></td>";
        str_html += "<td><input type='text' value='" + rows[i]["Gn_type"] + "'/></td>";
        str_html += "<td><input type='text' value='" + rows[i]["Sap_rou_workcenter"] + "'/></td>";
        str_html += "<td><input type='text' value='" + rows[i]["Fixture_pn"] + "'/></td>";
        str_html += "<td><input type='text' value='" + rows[i]["Fixture_array"] + "'/></td>";
        str_html += "<td><input type='text' value='" + rows[i]["Tooling_Ipna"] + "'/></td>";
        str_html += "<td><input type='text' value='" + rows[i]["Gn_correl_enggdwg"] + "'/></td>";
        str_html += "<td><input type='text' value='" + rows[i]["Dwg_label"] + "'/></td>";
        str_html += "<td><input type='text' value='" + rows[i]["Dwg_spec"] + "'/></td>";
        str_html += "<td><input type='text' value='" + rows[i]["Upp_tol"] + "'/></td>";
        str_html += "<td><input type='text' value='" + rows[i]["Lwr_tol"] + "'/></td>";
        str_html += "<td><input type='text' value='" + rows[i]["Meas_eq"] + "'/></td>";
        str_html += "<td><input type='text' value='" + rows[i]["Eq_cal_code"] + "'/></td>";
        str_html += "<td><input type='text' value='" + rows[i]["Eq_col_pts"] + "'/></td>";
        str_html += "<td><input type='text' value='" + rows[i]["Sample_plan"] + "'/></td>";
        str_html += "<td>" + rows[i]["Template_version"] + "</td>";
        str_html += "<td><input type='text' value='" + rows[i]["Remark"] + "'/></td>";
        str_html += "</tr>";
    }
    str_html += '</table>';
    str_html += '</div>';
    return str_html;
};


//确认窗口
function ConfirmWindow(msg, delete_list) {
    if ($("#input_changeLanguage").val() == "2") {
        $('#remove').dialog({
            title: 'Confirm',
            width: 300,
            height: 200,
            closed: false,
            modal: true,
            buttons: [{
                id: "conform_cancel",
                text: 'Cancel',
                handler: function () {
                    $('#remove').dialog('close');
                }
            }, {
                id: 'confirm_sure',
                text: 'OK',
                handler: function () {
                    $('#remove').dialog('close');
                    $.post("ViewTemplate.ashx", { "action": "delete", "data": JSON.stringify(delete_list) }, function (data) {
                        if (data["status"] == "ok") {
                            $.messager.alert("Tips", "Remove successfully！");
                        }
                        else {
                            $.messager.alert("Tips", "Remove failed！");
                        }
                        $('#dg').datagrid('reload');
                    })
                }
            }]
        });
    }
    else {
        $('#remove').dialog({
            title: '确认',
            width: 300,
            height: 200,
            closed: false,
            modal: true,
            buttons: [{
                id: "conform_cancel",
                text: '取消',
                handler: function () {
                    $('#remove').dialog('close');
                }
            }, {
                id: 'confirm_sure',
                text: '确定',
                handler: function () {
                    $('#remove').dialog('close');
                    $.post("ViewTemplate.ashx", { "action": "delete", "data": JSON.stringify(delete_list) }, function (data) {
                        if (data["status"] == "ok") {
                            $.messager.alert("提示", "删除成功！");
                        }
                        else {
                            $.messager.alert("提示", "删除失败！");
                        }
                        $('#dg').datagrid('reload');
                    })
                }
            }]
        });
    }

    $('#remove').html(msg);
    $('#remove').dialog('refresh');
};