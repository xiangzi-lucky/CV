﻿$(function () {
    loadTable("","");
    $('.searchbox-button').click(function () {
        var mode = GetType();
        doSearch(mode);
    });

    //量仪编码的筛别(回车键方法)
    $("#_easyui_textbox_input1").keydown(function () {
        var keynum = (event.keyCode ? event.keyCode : event.which);
        if (keynum == '13') {
            var templateType = GetType();
            doSearch(templateType);
        }
    });

    $('#_easyui_textbox_input1').focus();
});

function GetType() {
    var Inquiry_Mode = "";
    if ($('#CodeNumber').is(':checked')) {
        Inquiry_Mode = "CodeNumber";
    }
    else if ($('#PCNumber').is(':checked')) {
        Inquiry_Mode = "PCNumber";
    }
    else if ($('#FactoryNumber').is(':checked')) {
        Inquiry_Mode = "FactoryNumber";
    }
    else {
        Inquiry_Mode = "CodeNumber";
    }
    return Inquiry_Mode;
};


function loadTable(Equipment_code, mode) {
    $('#table_view_equipment').datagrid({
        url: "View_equipment.ashx",   // 指向一个后台的地址，自动往后台发送pageSize，pageNumber
        title: '量仪',      //标题
        height: 700,        //高度
        fitColumns: true,   //设置为 true，则会自动扩大或缩小列的尺寸以适应网格的宽度并且防止水平滚动。
        idField: 'Rowid',   //指示哪个字段是标识字段。
        loadMsg: '正在加载用户信息......', //加载数据的时候显示的文字
        pagination: true,   //是否分页
        singleSelect: false,//是否单选
        pageList: [10, 20, 30, 50], //指定一页显示多少个数
        pageSize: 20, //指定一页显示多少记录
        pageNumber: 1, //当前哪一页
        queryParams: { "action": "searchRecords", "Equipment_code": Equipment_code, "mode": mode }, //额外向后台发送的数据
        columns: [[
			{ field: 'ck', checkbox: true },
			{ field: 'Rowid', title: '序号' },
			{ field: 'Id', title: 'ID', hidden: true },
			{ field: 'Equipment_type', title: '量仪类型' },
			{ field: 'CCL_code', title: '量仪编码' },
			{ field: 'Pc_info', title: '绑定PC' },
			{ field: 'Com_type', title: '端口类型' },
			{ field: 'MFR', title: '生产厂家' },
			{ field: 'Com_port', title: '端口号' },
			{ field: 'Baud_rate', title: '波特率' },
			{ field: 'Parity_bit', title: '校验位' },
			{ field: 'Data_bit', title: '数据位' },
			{ field: 'Stop_bit', title: '停止位' },
			{ field: 'Note', title: '备注' },
			{ field: 'Create_date', title: '创建时间', formatter: function (value, row, index) {
			    return ChangeDateFormat(value);
			}
			}
		]],
        toolbar: [{
            id: "btn_update_equipment",
            text: '修改',
            iconCls: 'icon-edit',
            handler: function () {
                //更新数据
                updateRecords();
                //刷新数据
                $('#table_view_template').datagrid('reload');

            }
        }, '-', {
            id: "btn_remove_equipment",
            text: '删除',
            iconCls: 'icon-remove',
            handler: function () {
                //删除数据
                removeRecords();
            }
        }
		]
    });
};

function doSearch(mode) {
    if ($('.textbox-value').val() == "") {
        AlertWindow("请输入量仪编号");
    }
    else {
    searchRecords($('.textbox-value').val(), mode);  
    }
};

//报警窗口
function AlertWindow(msg) {
    $('#alert').dialog({
        title: '提示',
        width: 300,
        height: 200,
        closed: false,
        modal: true,
        buttons: [{
            text: '关闭',
            handler: function () {
                $('#alert').dialog('close');

            }
        }]
    });
    $('#alert').html("<span>" + msg + "</span>");
    $('#alert').css("text-align", "center");
    $('#alert span').css({ "line-height": "88px", "font-size": "14px", "font-family": "Microsoft YaHei" });
    $('#alert').dialog('refresh');
};

//查询模板记录
function searchRecords(Equipment_code, mode) {
    loadTable(Equipment_code, mode);
};

//将序列化成json的日期转成日期格式
function ChangeDateFormat(cellval) {
    var date = new Date(parseInt(cellval.replace("/Date(", "").replace(")/", ""), 10));
    var month = date.getMonth() + 1 < 10 ? "0" + (date.getMonth() + 1) : date.getMonth() + 1;
    var currentDay = date.getDate() < 10 ? "0" + date.getDate() : date.getDate();
    var currentHour = date.getHours() < 10 ? "0" + date.getHours() : date.getHours();
    var currentMinute = date.getMinutes() < 10 ? "0" + date.getMinutes() : date.getMinutes();
    var currentSecond = date.getSeconds() < 10 ? "0" + date.getSeconds() : date.getSeconds();
    return date.getFullYear() + '-' + month + "-" + currentDay + " " + currentHour + ":" + currentMinute + ":" + currentSecond;
};

//更新记录
function updateRecords() {
    var rows = $('#table_view_equipment').datagrid('getSelections');
    if (rows.length == 0) {
        $.messager.alert("提示", "请先选中行，再修改。", "warning");
        return;
    }
    else {
        updateWindow(rows);
    }
};

//删除记录
function removeRecords() {
    var rows = $('#table_view_equipment').datagrid('getSelections');
    if (rows.length == 0) {
        $.messager.alert("提示", "请先选中行，再删除。", "warning");
        return;
    }
    else {
        var delete_list = [];
        for (var i = 0; i < rows.length; i++) {
            var dict = {};
            dict["Id"] = rows[i]["Id"];
            dict["Equipment_type"] = rows[i]["Equipment_type"];
            dict["CCL_code"] = rows[i]["CCL_code"];
            dict["Pc_info"] = rows[i]["Pc_info"];
            dict["Com_type"] = rows[i]["Com_type"];
            delete_list.push(dict);
        }
        ConfirmWindow("您确定要删除这" + rows.length.toString() + "行数据吗?", delete_list);
    }
};

function updateWindow(rows) {
    $('#update_equipment').dialog({
        title: '更新内容',
        width: 1700,
        height: 500,
        modal: true,
        collapsible: true,
        minimizable: true,
        maximizable: true,
        resizable: true,
        buttons: [{
            text: '修改',
            iconCls: 'icon-edit',
            handler: function () {
                $('#update_equipment').dialog('close');
                submitUpdateDate();
            }
        }, {
            text: '关闭',
            iconCls: 'icon-cancel',
            handler: function () {
                $('#update_equipment').dialog('close');
            }
        }]
    });
    var msg = showMsg(rows);
    $('#update_equipment').html(msg);
    $('#update_equipment').dialog('refresh');
};

function submitUpdateDate() {
    var $tr = $('#tb_equipment_update tr');
    var rownum = $tr.length;
    var list = [];
    if (rownum > 1) {
        for (var i = 1; i < rownum; i++) {
            var dict = {};
            var tdarr = $tr.eq(i).find("td");
            dict["Rowid"] = tdarr.eq(0).html();
            dict["Id"] = tdarr.eq(1).html();
            dict["Equipment_type"] = tdarr.eq(2).html();
            dict["CCL_code"] = tdarr.eq(3).html();
            dict["Pc_info"] = tdarr.eq(4).find('input').val();
            dict["Com_type"] = tdarr.eq(5).html();
            dict["MFR"] = tdarr.eq(6).find('input').val();
            dict["Com_port"] = tdarr.eq(7).find('input').val();
            dict["Baud_rate"] = tdarr.eq(8).find('input').val();
            dict["Parity_bit"] = tdarr.eq(9).find('input').val();
            dict["Data_bit"] = tdarr.eq(10).find('input').val();
            dict["Stop_bit"] = tdarr.eq(11).find('input').val();
            dict["Note"] = tdarr.eq(12).find('input').val();
            list.push(dict);
        }
    }
    if (list.length > 0) {
        $.post("View_equipment.ashx", { "action": "update", "data": JSON.stringify(list) }, function (data) {
            if (data["status"] == "ok") {
                $.messager.alert("提示", "更新成功！");
            }
            else {
                $.messager.alert("提示", "更新失败！");
            }
            $('#table_view_equipment').datagrid('reload');
        })
    }
};

function showMsg(rows) {
    var str_html = "";
    str_html += '<div class="container-fluid table-responsive">';
    str_html += '<table id="tb_equipment_update" class="table table-bordered">'
    str_html += "<tr>";
    str_html += "<td>序号</td>";
    str_html += "<td style='display:none'>ID</td>";
    str_html += "<td>量仪类型</td>";
    str_html += "<td>量仪编码</td>";
    str_html += "<td>绑定PC</td>";
    str_html += "<td>端口类型</td>";
    str_html += "<td>生产厂家</td>";
    str_html += "<td>端口号</td>";
    str_html += "<td>波特率</td>";
    str_html += "<td>校验位</td>";
    str_html += "<td>数据位</td>";
    str_html += "<td>停止位</td>";
    str_html += "<td>备注</td>";
    str_html += "</tr>";
    for (var i = 0; i < rows.length; i++) {
        str_html += "<tr>";
        str_html += "<td>" + rows[i]["Rowid"] + "</td>";
        str_html += "<td style='display:none'>" + rows[i]["Id"] + "</td>";
        str_html += "<td>" + rows[i]["Equipment_type"] + "</td>";
        str_html += "<td>" + rows[i]["CCL_code"] + "</td>";
        str_html += "<td><input type='text' value='" + rows[i]["Pc_info"] + "'/></td>";
        str_html += "<td>" + rows[i]["Com_type"] + "</td>";
        str_html += "<td><input type='text' value='" + rows[i]["MFR"] + "'/></td>";
        str_html += "<td><input type='text' value='" + rows[i]["Com_port"] + "'/></td>";
        str_html += "<td><input type='text' value='" + rows[i]["Baud_rate"] + "'/></td>";
        str_html += "<td><input type='text' value='" + rows[i]["Parity_bit"] + "'/></td>";
        str_html += "<td><input type='text' value='" + rows[i]["Data_bit"] + "'/></td>";
        str_html += "<td><input type='text' value='" + rows[i]["Stop_bit"] + "'/></td>";
        str_html += "<td><input type='text' value='" + rows[i]["Note"] + "'/></td>";
        str_html += "</tr>";
    }
    str_html += '</table>';
    str_html += '</div>';
    return str_html;
};

//确认窗口
function ConfirmWindow(msg, delete_list) {
    $('#remove_equipment').dialog({
        title: '确认',
        width: 300,
        height: 200,
        closed: false,
        modal: true,
        buttons: [{
            id: "conform_cancel",
            text: '取消',
            handler: function () {
                $('#remove_equipment').dialog('close');
            }
        }, {
            id: 'confirm_sure',
            text: '确定',
            handler: function () {
                $('#remove_equipment').dialog('close');
                $.post("View_equipment.ashx", { "action": "delete", "data": JSON.stringify(delete_list) }, function (data) {
                    if (data["status"] == "ok") {
                        $.messager.alert("提示", "删除成功！");
                    }
                    else {
                        $.messager.alert("提示", "删除失败！");
                    }
                    $('#table_view_equipment').datagrid('reload');
                })
            }
        }]
    });
    $('#remove_equipment').html(msg);
    $('#remove_equipment').dialog('refresh');
};
