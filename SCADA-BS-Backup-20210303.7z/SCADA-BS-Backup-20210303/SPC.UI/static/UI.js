﻿$(function () {
    $.post("CheckUserState.ashx", { "action": "login" }, function (data) {
        $("#login_user").replaceWith('<span id="login_user">' + data + '</span>'); 
    });


    //    //登陆窗口
    //    $('#logout_status').on('click', '#a_login', function () {
    //        if ($("#input_changeLanguage").val() == "2") {
    //            $('#div_login').dialog({
    //                title: 'Login',
    //                width: 500,
    //                height: 300,
    //                closed: false,
    //                modal: true,
    //                onClose: function () {
    //                    if ($('#remember_me').prop("checked").toString().trim() == "false") {
    //                        Login_dailog_initialize();
    //                    }
    //                }
    //            });
    //        }
    //        else {
    //            $('#div_login').dialog({
    //                title: '登陆',
    //                width: 500,
    //                height: 300,
    //                closed: false,
    //                modal: true,
    //                onClose: function () {
    //                    if ($('#remember_me').prop("checked").toString().trim() == "false") {
    //                        Login_dailog_initialize();
    //                    }
    //                }
    //            });
    //        }
    //        $('#div_login').dialog('refresh');
    //    });

    //    //注册窗口
    //    $('#logout_status').on('click', '#a_register', function () {
    //        if ($("#input_changeLanguage").val() == "2") {
    //            $('#div_register').dialog({
    //                title: 'Register',
    //                width: 500,
    //                height: 350,
    //                closed: false,
    //                modal: true,
    //                onClose: function () {
    //                    Register_dailog_initialize();
    //                }
    //            });
    //        }
    //        else {
    //            $('#div_register').dialog({
    //                title: '注册',
    //                width: 500,
    //                height: 350,
    //                closed: false,
    //                modal: true,
    //                onClose: function () {
    //                    Register_dailog_initialize();
    //                }
    //            });
    //        }


    //        $('#div_register').dialog('refresh');

    //    });

    //    //取消登陆
    //    $("#div_login_status").on("click", "#login_cancel", function () {
    //        if ($('#remember_me').prop("checked").toString().trim() == "false") {
    //            Login_dailog_initialize();
    //        }
    //        $('#div_login').dialog('close');
    //    });
    //    //取消注册
    //    $("#div_register_status").on("click", "#register_cancel", function () {
    //        Register_dailog_initialize();
    //        $('#div_register').dialog('close');
    //    });

    //    // 绑定账号失去焦点事件
    //    $("#username").bind("blur", function () {
    //        if ($('#username').val() == "" && $("#input_changeLanguage").val() == "2") {
    //            ActionForCheckpassword("#span_username", "#div_account", "The account cannot be empty!", "");
    //        }
    //        else if ($('#username').val() == "" && $("#input_changeLanguage").val() == "1") {
    //            ActionForCheckpassword("#span_username", "#div_account", "账号不能为空", "");
    //        }
    //        else {
    //            checkusername();
    //        }
    //    });

    //    // 绑定密码1失去焦点事件
    //    $('#password1').bind("blur", function () {
    //        if ($('#password1').val() == "" && $("#input_changeLanguage").val() == "2") {
    //            ActionForCheckpassword("#span_password1", "#div_password1", "The password cannot be empty!", "");
    //        }
    //        else if ($('#password1').val() == "" && $("#input_changeLanguage").val() == "1") {
    //            ActionForCheckpassword("#span_password1", "#div_password1", "密码不能为空", "");
    //        }
    //        else {
    //            checkpassword();
    //        }
    //    });
    //    // 绑定密码2失去焦点事件
    //    $('#password2').bind("blur", function () {
    //        if ($('#password2').val() == "" && $("#input_changeLanguage").val() == "2") {
    //            ActionForCheckpassword("#span_password2", "#div_password2", "The password cannot be empty!", "");
    //        }
    //        else if ($('#password2').val() == "" && $("#input_changeLanguage").val() == "1") {
    //            ActionForCheckpassword("#span_password2", "#div_password2", "密码不能为空", "");
    //        }
    //        else {
    //            checkpassword();
    //        }
    //    });
    //    //确认注册
    //    $("#div_register_status").on("click", "#register", function () {
    //        if ($('#span_password1 span').prop('class') == "glyphicon glyphicon-ok" &&
    //            $('#span_password2 span').prop('class') == "glyphicon glyphicon-ok" &&
    //            $('#span_username span').prop('class') == "glyphicon glyphicon-ok") {
    //            $.post("CheckUserState.ashx", { "action": "register", "username": $('#username').val(), "password": $('#password1').val() }, function (data) {
    //                var serverData = data.split(":");
    //                AlertWindow(serverData[1]);
    //                $('#div_register').dialog('close');
    //            });
    //        }
    //        else {
    //            if ($("#input_changeLanguage").val() == "2") {
    //                AlertWindow("Insufficient conditions for registration!");
    //            }
    //            else {
    //                AlertWindow("条件不满足，无法注册");
    //            }

    //        }
    //    });
    //    //确认登陆
    //    $("#div_login_status").on("click", "#login", function () {
    //        if ($('#login_username').val().toString().trim() == "" || $('#login_password').val().toString().trim() == "") {
    //            if ($("#input_changeLanguage").val() == "2") {
    //                AlertWindow("The account or password cannot be empty!");
    //            }
    //            else {
    //                AlertWindow("账号或密码不能为空！");
    //            }
    //        }
    //        else {
    //            $.post("CheckUserState.ashx", {
    //                "action": "login",
    //                "username": $('#login_username').val().toString().trim(),
    //                "password": $('#login_password').val().toString().trim(),
    //                "remember_me": $('#remember_me').prop("checked")
    //            },
    //                function (data) {
    //                    var serverData = data.split(":");
    //                    if (serverData[0] == "ok") {
    //                        $('#login_status').css("display", "block");
    //                        $('#spc_username').html(serverData[1]);
    //                        $('#logout_status').css("display", "none");
    //                        $('#div_login').dialog('close');
    //                    }
    //                    else {
    //                        if ($("#input_changeLanguage").val() == "2") {
    //                            AlertWindow("Login failed. Please try again.");
    //                        }
    //                        else {
    //                            AlertWindow("登陆失败,请重试.");
    //                        }
    //                        $('#div_login').dialog('close');
    //                    }

    //                })
    //        }
    //    });
    //    //注销
    //    $('#login_status').on('click', '#logout', function () {
    //        if ($("#input_changeLanguage").val() == "2") {
    //            ConfirmWindow("Are you sure to log out?", "logout");
    //        }
    //        else {
    //            ConfirmWindow("您确定要注销帐号吗?", "logout");
    //        }
    //    });

    //    $('#view_template').click(function () {
    //        window.location.href = "ViewTemplate.aspx";
    //    });
    //    CheckUserState(); //检查用户状态
    //    $('#part_num').focus();

    //切换语言
    var easyui_input_num = 3;
    $('body').on('click', '#a_changeLanguage', function () {
        easyui_input_num += 3;
        //切换成英语
        if ($("#input_changeLanguage").val() == "1") {

            $("#title_scada").replaceWith('<h4 id="title_scada">SCADA Management System</h4>');                                  //系统大标题
            $("#label_changeLanguage").replaceWith('<label id="label_changeLanguage">切换语言：</label>');                       //切换语言
            $("#a_changeLanguage").replaceWith('<a href="javascript:void(0)" id="a_changeLanguage">中文</a>');                   //语言
            $("#input_changeLanguage").attr("value", "2");                                                                       //语言识别码
            $("#SCADA_Management_System_version").replaceWith('<div style="float:right;margin-top:-55px" id="SCADA_Management_System_version">System Version：V1.07</div>'); //系统版本号
            $("#a_login").replaceWith('<a href="javascript:void(0)" id="a_login">Login</a>');                                    //登陆
            $("#a_register").replaceWith('<a href="javascript:void(0)" id="a_register">Register</a>');                           //注册
            $("#logout").replaceWith('<a href="javascript:void(0)" id="logout">Logout</a>');                                     //注销
            $("#div_project_navigation").panel({ title: "Navigation" });                                                         //项目导航
            $("#create_template").replaceWith('<a id="create_template" href="index.aspx">New/Add</a>');                  //创建模板
            $("#view_template").replaceWith('<a id="view_template" href="ViewTemplate.aspx">Enquiry</a>');                 //查询模板
            $("#register_equitment").replaceWith('<a id="register_equitment" href="Register_equipment.aspx">Bind to local PC</a>'); //绑定量仪
            $("#view_equitment").replaceWith('<a id="view_equitment" href="View_equipment.aspx">CCL Equipment Enquiry</a>');            //查询量仪

            $("#content").panel({ title: "Working Area" });              //工作区
            $("#div_check_plan").attr("title", "Inspection Plan");       //检查计划 
            $("#label_register_username").replaceWith('<label id="label_register_username" style="margin-top:5px">Account:</label>');                    //注册：输入账号
            $("#username").attr("placeholder", "Please enter your badge.");                                                                              //placeholder：请输入工号
            $("#label_register_password1").replaceWith('<label id="label_register_password1">Enter Password:</label>');                                  //注册：输入密码
            $("#password1").attr("placeholder", "Enter only 6-18 letters, numbers, underscores.");                                                       //placeholder：只能输入6-18个字母、数字、下划线
            $("#label_register_password2").replaceWith('<label id="label_register_password2">Confirm Password:</label>');                                //注册：确认密码
            $("#password2").attr("placeholder", "Enter only 6-18 letters, numbers, underscores.");                                                       //placeholder：只能输入6-18个字母、数字、下划线
            $("#register").replaceWith('<button class="btn" style="width:80px;background-color:#95B8E7" id="register">Register</button>');               //确认注册
            $("#register_cancel").replaceWith('<button class="btn" style="width:80px;background-color:#95B8E7" id="register_cancel">Cancel</button>');   //取消注册
            $("#label_login_username").replaceWith('<label id="label_login_username" style="margin-top:5px">Account:</label>');                          //登陆账号
            $("#label_login_password").replaceWith('<label id="label_login_password" style="margin-top:5px">Password:</label>');                         //登陆密码
            $("#label_remember_me").replaceWith('<label id="label_remember_me" for="accept" class="textbox-label">Remember</label>');                    //记住我
            $("#login").replaceWith('<button class="btn" style="width:80px;background-color:#95B8E7" id="login">Login</button>');                        //确认登陆
            $("#login_cancel").replaceWith('<button class="btn" style="width:80px;background-color:#95B8E7" id="login_cancel">Cancel</button>');         //取消登陆

            $("#part_num_id").replaceWith('<span id="part_num_id" class="input-group-addon">Part Number</span>');         //工件号
            $("#part_num").attr("placeholder", "Please enter the part number.");                                          //placeholder：请输入工件号
            $("#part_rev_id").replaceWith('<span id="part_rev_id" class="input-group-addon">Part Version</span>');        //版本号
            $("#part_rev").attr("placeholder", "Please enter the part version.");                                         //placeholder：请输入版本号
            $("#mk_badge_id").replaceWith('<span id="mk_badge_id" class="input-group-addon">Preparer</span>');            //制作人
            $("#mk_badge").attr("placeholder", "Please enter your job number.");                                          //placeholder：请输入工号
            $("#label_checkbox_rw").replaceWith('<label id="label_checkbox_rw"><input type="checkbox" id="checkbox_rw" />Rework</label>');    //返修
            $("#rw_order_id").replaceWith('<span id="rw_order_id" class="input-group-addon">Defective Order</span>');     //不良单号
            $("#rw_order").attr("placeholder", "Order Number");                                                           //placeholder：单号
            $("#Rw_seq_id").replaceWith('<span id="Rw_seq_id" class="input-group-addon">Serial Num</span>');              //序号
            $("#Rw_seq").attr("placeholder", "Serial Number");                                                            //placeholder：序号
            $("#RW_templateType_id").replaceWith('<span id="RW_templateType_id" class="input-group-addon">Type</span>');  //返修类型
            $("#btn_rw_version").replaceWith('<button id="btn_rw_version" type="button" class="btn btn-default dropdown-toggle button" data-toggle="dropdown">Version<span class="caret"></span></button>');  //返修版本

            $("#span_gn_type_IM-WS").replaceWith('<span id="span_gn_type_IM-WS" class="input-group-addon">Process</span>');   //工序
            $("#input_gn_type_IM-WS").attr("placeholder", "Please enter the process.");                                         //placeholder：请输入工序
            $("#btn_SAP_rou_workcenter_IM-WS").replaceWith('<button id="btn_SAP_rou_workcenter_IM-WS" type="button" class="btn btn-default dropdown-toggle button" data-toggle="dropdown">Machine Type <span class="caret"></span></button>');  //机型
            $("#SAP_rou_workcenter_IM-WS").attr("placeholder", "Please select the machine type.");                                   //placeholder：请选择机型
            $("#btn_fixture_pn_IM-WS").replaceWith('<button id="btn_fixture_pn_IM-WS" type="button" class="btn btn-default dropdown-toggle button" data-toggle="dropdown">Fixture <span class="caret"></span></button>');               //夹具
            $("#fixture_pn_IM-WS").attr("placeholder", "Please select the fixture.");                                            //placeholder：请选择夹具
            $("#span_fixture_array_IM-WS").replaceWith('<span id="span_fixture_array_IM-WS" class="input-group-addon">Max Clamping Position</span>');  //最大夹位
            $("#fixture_array_IM-WS").attr("placeholder", "Please enter the max clamping position.");                                              //placeholder：请输入最大夹位
            $("#btn_tooling_ipna_IM-WS").replaceWith('<button id="btn_tooling_ipna_IM-WS" type="button" class="btn btn-default dropdown-toggle button" data-toggle="dropdown">Tool <span class="caret"></span></button>');                //刀名
            $("#tooling_ipna_IM-WS").attr("placeholder", "Please select the tool.");                                              //placeholder：请选择刀名
            $("#label_Update_Version_IM-WS").replaceWith('<label id="label_Update_Version_IM-WS" style="color: Red; margin: 7px 0 0 30px"><input id="Update_Version_IM-WS" type="checkbox" />Update/modify</label>');     //更新/修改
            $("#IM-WS_tr_1st").replaceWith('<tr id="IM-WS_tr_1st" style="background-color: #eeeeee"><td>Num</td><td>Link</td><td style="width: 13%">DrawingLabel</td><td>Specification &nbsp; &nbsp; &nbsp;<label style="color: red"><input type="checkbox" id="checkbox_gongcha_IM-WS" />13 level of tolerance</label></td><td>Equipment</td><td style="width: 15%">Check Num</td><td style="width: 10%">Note</td><td></td></tr>');  //IM-WS动态添加（表头）
            $("#btn_add_IM-WS").replaceWith('<button id="btn_add_IM-WS" name="test" type="button" class="btn btn-primary">Add New Row</button>');    //IM-WS增加新行
            $("#btn_IM-WS").replaceWith('<button type="button" class="btn btn-primary" id="btn_IM-WS">Create Template</button>');                    //IM-WS创建模板
            $("#btn_update_IM-WS").replaceWith('<button type="button" class="btn btn-primary" style="display:none" id="btn_update_IM-WS" >更新模板</button>'); //IM-WS更新模板

            $("#btn_SAP_rou_workcenter_IM-QC").replaceWith('<button id="btn_SAP_rou_workcenter_IM-QC" type="button" class="btn btn-default dropdown-toggle button" data-toggle="dropdown">SAP Standard Process <span class="caret"></span></button>'); //IM-QC SAP标准工艺
            $("#btn_meas_eq_higher_IM-QC").replaceWith('<button id="btn_meas_eq_higher_IM-QC" type="button" class="btn btn-default dropdown-toggle button" data-toggle="dropdown">Equipment <span class="caret"></span></button>');   //IM-QC量仪
            $("#label_Update_Version_IM-QC").replaceWith('<label id="label_Update_Version_IM-QC" style="color: Red; margin: 7px 0 0 30px"><input id="Update_Version_IM-QC" type="checkbox" />Update/modify</label>');                     //更新/修改
            $("#IM-QC_tr_1st").replaceWith('<tr id="IM-QC_tr_1st" style="background-color: #eeeeee"><td>Num</td><td style="width: 13%">DrawingLabel</td><td>Specification &nbsp; &nbsp; &nbsp;<label style="color: red"><input type="checkbox" id="checkbox_gongcha_IM-QC" />13 level of tolerance</label></td><td>Equipment</td><td style="width: 15%">Check Num</td><td style="width: 10%">Note</td><td></td></tr>');  //IM-QC动态添加（表头）
            $("#btn_add_IM-QC").replaceWith('<button id="btn_add_IM-QC" name="test" type="button" class="btn btn-primary">Add New Row</button>');    //IM-QC增加新行
            $("#btn_IM-QC").replaceWith('<button type="button" class="btn btn-primary" id="btn_IM-QC">Create Template</button>');                    //IM-QC创建模板

            $(".panel-title:eq(1)").replaceWith('<div class="panel-title">Inspection Plan</div>');
            $(".panel-title:eq(2)").replaceWith('<div class="panel-title">CCL Equipment</div>');
            $(".panel-title:eq(3)").replaceWith('<div class="panel-title">Report Generation</div>');
            $(".panel-title:eq(4)").replaceWith('<div class="panel-title">Monitoring</div>');                        //一次性模板

            $("#span_gn_type_EM-SBC").replaceWith('<span id="span_gn_type_EM-SBC" class="input-group-addon">Process</span>');            //工序
            $("#Supplier_code").attr("placeholder", "Please enter the process.");                                                   //placeholder：请输入工序
            $("#SAP_rou_workcenter_EM-SBC_id").replaceWith('<span id="SAP_rou_workcenter_EM-SBC_id" class="input-group-addon">Machine Type </span>');                //机型
            $("#SAP_rou_workcenter_EM-SBC").attr("placeholder", "Please select the machine type.");                                                      //placeholder：请选择机型
            $("#fixture_pn_EM-SBC_id").replaceWith('<span id="fixture_pn_EM-SBC_id" class="input-group-addon">Fixture </span>');                             //夹具
            $("#fixture_pn_EM-SBC").attr("placeholder", "Please select the fixture.");                                                               //placeholder：请选择夹具
            $("#fixture_array_EM-SBC_id").replaceWith('<span id="fixture_array_EM-SBC_id" class="input-group-addon">Max Clamping Position</span>');    //最大夹位
            $("#fixture_array_EM-SBC").attr("placeholder", "Please enter the max clamping position.");                                            //placeholder：请输入最大夹位
            $("#tooling_ipna_EM-SBC_id").replaceWith('<span id="tooling_ipna_EM-SBC_id" class="input-group-addon">Tool </span>');                              //刀名
            $("#tooling_ipna_EM-SBC").attr("placeholder", "Please select the tool.");                                                                 //placeholder：请输入刀名
            $("#label_Update_Version_EM-SBC").replaceWith('<label id="label_Update_Version_EM-SBC" style="color: Red; margin: 7px 0 0 30px"><input id="Update_Version_EM-SBC" type="checkbox" />Update/modify</label>');     //更新/修改
            $("#EM-SBC_tr_1st").replaceWith('<tr id="EM-SBC_tr_1st" style="background-color: #eeeeee"><td>Num</td><td>Link</td><td style="width: 13%">DrawingLabel</td><td>Specification &nbsp; &nbsp; &nbsp;<label style="color: red"><input type="checkbox" id="checkbox_gongcha_EM-SBC" />13 level of tolerance</label></td><td>Equipment</td><td style="width: 15%">Check Num</td><td style="width: 10%">Note</td><td></td></tr>');  //EM-SBC动态添加（表头）
            $("#btn_add_EM-SBC").replaceWith('<button id="btn_add_EM-SBC" name="test" type="button" class="btn btn-primary">Add New Row</button>');   //EM-SBC增加新行
            $("#btn_EM-SBC").replaceWith('<button type="button" class="btn btn-primary" id="btn_EM-SBC">Create Template</button>');                   //EM-SBC创建模板

            $("#btn_SAP_rou_workcenter_EM-QC").replaceWith('<button id="btn_SAP_rou_workcenter_EM-QC" type="button" class="btn btn-default dropdown-toggle button" data-toggle="dropdown">SAP Standard Process <span class="caret"></span></button>'); //IM-QC SAP标准工艺
            $("#btn_meas_eq_higher_EM-QC").replaceWith('<button id="btn_meas_eq_higher_EM-QC" type="button" class="btn btn-default dropdown-toggle button" data-toggle="dropdown">Equipment <span class="caret"></span></button>');    //EM-QC量仪
            $("#label_Update_Version_EM-QC").replaceWith('<label id="label_Update_Version_EM-QC" style="color: Red; margin: 7px 0 0 30px"><input id="Update_Version_EM-QC" type="checkbox" />Update/modify</label>');     //更新/修改
            $("#EM-QC_tr_1st").replaceWith('<tr id="EM-QC_tr_1st" style="background-color: #eeeeee"><td>Num</td><td style="width: 13%">DrawingLabel</td><td>Specification &nbsp; &nbsp; &nbsp;<label style="color: red"><input type="checkbox" id="checkbox_gongcha_EM-QC" />13 level of tolerance</label></td><td>Equipment</td><td style="width: 15%">Check Num</td><td style="width: 10%">Note</td><td></td></tr>');  //EM-QC动态添加（表头）
            $("#btn_add_EM-QC").replaceWith('<button id="btn_add_EM-QC" name="test" type="button" class="btn btn-primary">Add New Row</button>');   //EM-QC增加新行
            $("#btn_EM-QC").replaceWith('<button type="button" class="btn btn-primary" id="btn_EM-QC">Create Template</button>');                   //EM-QC创建模板

            //动态添加部分中>英
            DynamicAddPart_toEn("IM-WS");
            DynamicAddPart_toEn("IM-QC");
            DynamicAddPart_toEn("EM-SBC");
            DynamicAddPart_toEn("EM-QC");
            DynamicAddPart_toEn("RW");


            ////查询模板页面
            $("#_easyui_textbox_input1").attr('placeholder', "Please enter the part number");
            $("#label_IM-WS").replaceWith('<label class="radio-inline" id="label_IM-WS"><input type="radio" name="inlineRadioOptions" id="IM-WS" value="option1" checked="checked"/> IM-WS</label>');
            $("#label_IM-QC").replaceWith('<label class="radio-inline" id="label_IM-QC"><input type="radio" name="inlineRadioOptions" id="IM-QC" value="option2"/> IM-QC</label>');
            $("#label_EM-SBC").replaceWith('<label class="radio-inline" id="label_EM-SBC"><input type="radio" name="inlineRadioOptions" id="EM-SBC" value="option3"/> EM-SBC</label>');
            $("#label_EM-QC").replaceWith('<label class="radio-inline" id="label_EM-QC"><input type="radio" name="inlineRadioOptions" id="EM-QC" value="option4"/> EM-IQC</label>');
            $("#label_RW").replaceWith('<label class="radio-inline" id="label_RW"><input type="radio" name="inlineRadioOptions" id="RW" value="option5"/> RW</label>');
            $("#").replaceWith('');
            $("#").replaceWith('');
            $("#").replaceWith('');
            $("#").replaceWith('');
            $("#").replaceWith('');
            $("#").replaceWith('');
            $("#").replaceWith('');
            $("#").replaceWith('');
            $("#").replaceWith('');
            $("#").replaceWith('');
            $("#").replaceWith('');
            $("#").replaceWith('');
            $("#").replaceWith('');
            $("#").replaceWith('');
            $("#").replaceWith('');
            $("#").replaceWith('');
            $("#").replaceWith('');
            $("#").replaceWith('');
            $("#").replaceWith('');


        }
        //切换成中文
        else if ($("#input_changeLanguage").val() == "2") {
            $("#title_scada").replaceWith('<h4 id="title_scada">SCADA 管理系统</h4>');
            $("#label_changeLanguage").replaceWith('<label id="label_changeLanguage">Change Language：</label>');
            $("#a_changeLanguage").replaceWith('<a href="javascript:void(0)" id="a_changeLanguage">English</a>');
            $("#input_changeLanguage").attr("value", "1");
            $("#SCADA_Management_System_version").replaceWith('<div style="float:right;margin-top:-55px" id="SCADA_Management_System_version">系统版本号：V1.07</div>');
            $("#a_login").replaceWith('<a href="javascript:void(0)" id="a_login">登陆</a>');
            $("#a_register").replaceWith('<a href="javascript:void(0)" id="a_register">注册</a>');
            $("#logout").replaceWith('<a href="javascript:void(0)" id="logout">注销</a>');
            $("#div_project_navigation").panel({ title: "项目导航" });
            $("#create_template").replaceWith('<a id="create_template" href="index.aspx">创建模板</a>');
            $("#view_template").replaceWith('<a id="view_template" href="ViewTemplate.aspx">查询模板</a>');
            $("#register_equitment").replaceWith('<a id="register_equitment" href="Register_equipment.aspx">绑定量仪</a>');
            $("#view_equitment").replaceWith('<a id="view_equitment" href="View_equipment.aspx">查询量仪</a>');
            $("#content").panel({ title: "工作区" });
            $("#label_register_username").replaceWith('<label id="label_register_username" style="margin-top:5px">输入账号:</label>');
            $("#username").attr("placeholder", "请输入工号");
            $("#label_register_password1").replaceWith('<label id="label_register_password1" style="margin-top:5px">输入密码:</label>');
            $("#password1").attr("placeholder", "只能输入6-18个字母、数字、下划线");
            $("#label_register_password2").replaceWith('<label id="label_register_password2" style="margin-top:5px">确认密码:</label>');
            $("#password2").attr("placeholder", "只能输入6-18个字母、数字、下划线");
            $("#register").replaceWith('<button class="btn" style="width:80px;background-color:#95B8E7" id="register">注册</button>');
            $("#register_cancel").replaceWith('<button class="btn" style="width:80px;background-color:#95B8E7" id="register_cancel">取消</button>');
            $("#label_login_username").replaceWith('<label id="label_login_username" style="margin-top:5px">账号:</label>');
            $("#label_login_password").replaceWith('<label id="label_login_password" style="margin-top:5px">密码:</label>');
            $("#label_remember_me").replaceWith('<label id="label_remember_me" for="accept" class="textbox-label">记住我</label>');
            $("#login").replaceWith('<button class="btn" style="width:80px;background-color:#95B8E7" id="login">登陆</button>');
            $("#login_cancel").replaceWith('<button class="btn" style="width:80px;background-color:#95B8E7" id="login_cancel">取消</button>');
            $("#part_num_id").replaceWith('<span id="part_num_id" class="input-group-addon">工件号</span>');
            $("#part_num").attr("placeholder", "请输入工件号");
            $("#part_rev_id").replaceWith('<span id="part_rev_id" class="input-group-addon">版本号</span>');
            $("#part_rev").attr("placeholder", "请输入版本号");
            $("#mk_badge_id").replaceWith('<span id="mk_badge_id" class="input-group-addon">制作人</span>');
            $("#mk_badge").attr("placeholder", "请输入工号");
            $("#label_checkbox_rw").replaceWith('<label id="label_checkbox_rw"><input type="checkbox" id="checkbox_rw" />返修</label>');
            $("#rw_order_id").replaceWith('<span id="rw_order_id" class="input-group-addon">不良单号</span>');
            $("#rw_order").attr("placeholder", "单号");
            $("#Rw_seq_id").replaceWith('<span id="Rw_seq_id" class="input-group-addon">序号</span>');
            $("#Rw_seq").attr("placeholder", "序号");
            $("#RW_templateType_id").replaceWith('<span id="RW_templateType_id" class="input-group-addon">返修类型</span>');
            $("#btn_rw_version").replaceWith('<button id="btn_rw_version" type="button" class="btn btn-default dropdown-toggle button" data-toggle="dropdown">版本<span class="caret"></span></button>');
            $("#span_gn_type_IM-WS").replaceWith('<span id="span_gn_type_IM-WS" class="input-group-addon">工序</span>');
            $("#input_gn_type_IM-WS").attr("placeholder", "请输入工序");
            $("#btn_SAP_rou_workcenter_IM-WS").replaceWith('<button id="btn_SAP_rou_workcenter_IM-WS" type="button" class="btn btn-default dropdown-toggle button" data-toggle="dropdown">机型 <span class="caret"></span></button>');
            $("#SAP_rou_workcenter_IM-WS").attr("placeholder", "请选择机型");
            $("#btn_fixture_pn_IM-WS").replaceWith('<button id="btn_fixture_pn_IM-WS" type="button" class="btn btn-default dropdown-toggle button" data-toggle="dropdown">夹具 <span class="caret"></span></button>');
            $("#fixture_pn_IM-WS").attr("placeholder", "请选择夹具");
            $("#span_fixture_array_IM-WS").replaceWith('<span id="span_fixture_array_IM-WS" class="input-group-addon">最大夹位</span>');
            $("#fixture_array_IM-WS").attr("placeholder", "请输入最大夹位");
            $("#btn_tooling_ipna_IM-WS").replaceWith('<button id="btn_tooling_ipna_IM-WS" type="button" class="btn btn-default dropdown-toggle button" data-toggle="dropdown">刀名 <span class="caret"></span></button>');
            $("#tooling_ipna_IM-WS").attr("placeholder", "请选择刀名");
            $("#label_Update_Version_IM-WS").replaceWith('<label id="label_Update_Version_IM-WS" style="color: Red; margin: 7px 0 0 30px"><input id="Update_Version_IM-WS" type="checkbox" />更新/修改</label>');     //更新/修改
            $("#IM-WS_tr_1st").replaceWith('<tr id="IM-WS_tr_1st" style="background-color: #eeeeee"><td>序号</td><td>关联图库</td><td style="width: 13%">图标</td><td>图纸规格 &nbsp; &nbsp; &nbsp;<label style="color: red"><input type="checkbox" id="checkbox_gongcha_IM-WS" />13级公差</label></td><td>量仪</td><td style="width: 15%">抽检数量</td><td style="width: 10%">备注</td><td></td></tr>');
            $("#btn_add_IM-WS").replaceWith('<button id="btn_add_IM-WS" name="test" type="button" class="btn btn-primary">增加新行</button>');
            $("#btn_IM-WS").replaceWith('<button type="button" class="btn btn-primary" id="btn_IM-WS">创建模板</button>');
            $("#btn_SAP_rou_workcenter_IM-QC").replaceWith('<button id="btn_SAP_rou_workcenter_IM-QC" type="button" class="btn btn-default dropdown-toggle button" data-toggle="dropdown">SAP标准工艺 <span class="caret"></span></button>');
            $("#btn_meas_eq_higher_IM-QC").replaceWith('<button id="btn_meas_eq_higher_IM-QC" type="button" class="btn btn-default dropdown-toggle button" data-toggle="dropdown">量仪 <span class="caret"></span></button>');
            $("#label_Update_Version_IM-QC").replaceWith('<label id="label_Update_Version_IM-QC" style="color: Red; margin: 7px 0 0 30px"><input id="Update_Version_IM-QC" type="checkbox" />更新/修改</label>');                     //更新/修改
            $("#IM-QC_tr_1st").replaceWith('<tr id="IM-QC_tr_1st" style="background-color: #eeeeee"><td>序号</td><td style="width: 13%">图标</td><td>图纸规格 &nbsp; &nbsp; &nbsp;<label style="color: red"><input type="checkbox" id="checkbox_gongcha_IM-QC" />13级公差</label></td><td>量仪</td><td style="width: 15%">抽检数量</td><td style="width: 10%">备注</td><td></td></tr>');
            $("#btn_add_IM-QC").replaceWith('<button id="btn_add_IM-QC" name="test" type="button" class="btn btn-primary">增加新行</button>');
            $("#btn_IM-QC").replaceWith('<button type="button" class="btn btn-primary" id="btn_IM-QC">创建模板</button>');
            $(".panel-title:eq(1)").replaceWith('<div class="panel-title">检查计划</div>');
            $(".panel-title:eq(2)").replaceWith('<div class="panel-title">量仪登记</div>');
            $(".panel-title:eq(3)").replaceWith('<div class="panel-title">生成报告</div>');
            $(".panel-title:eq(4)").replaceWith('<div class="panel-title">监控</div>');
            $("#span_gn_type_EM-SBC").replaceWith('<span id="span_gn_type_EM-SBC" class="input-group-addon">工序</span>');
            $("#Supplier_code").attr("placeholder", "请输入工序.");
            $("#SAP_rou_workcenter_EM-SBC_id").replaceWith('<span id="SAP_rou_workcenter_EM-SBC_id" class="input-group-addon">机型 </span>');
            $("#SAP_rou_workcenter_EM-SBC").attr("placeholder", "请选择机型");
            $("#fixture_pn_EM-SBC_id").replaceWith('<span id="fixture_pn_EM-SBC_id" class="input-group-addon">夹具 </span>');
            $("#fixture_pn_EM-SBC").attr("placeholder", "请选择夹具");
            $("#fixture_array_EM-SBC_id").replaceWith('<span id="fixture_array_EM-SBC_id" class="input-group-addon">最大夹位</span>');
            $("#fixture_array_EM-SBC").attr("placeholder", "请输入最大夹位");
            $("#tooling_ipna_EM-SBC_id").replaceWith('<span id="tooling_ipna_EM-SBC_id" class="input-group-addon">刀名 </span>');
            $("#tooling_ipna_EM-SBC").attr("placeholder", "请输入刀名");
            $("#label_Update_Version_EM-SBC").replaceWith('<label id="label_Update_Version_EM-SBC" style="color: Red; margin: 7px 0 0 30px"><input id="Update_Version_EM-SBC" type="checkbox" />更新/修改</label>');     //更新/修改
            $("#EM-SBC_tr_1st").replaceWith('<tr id="EM-SBC_tr_1st" style="background-color: #eeeeee"><td>序号</td><td>关联图库</td><td style="width: 13%">图标</td><td>图纸规格 &nbsp; &nbsp; &nbsp;<label style="color: red"><input type="checkbox" id="checkbox_gongcha_EM-SBC" />13级公差</label></td><td>量仪</td><td style="width: 15%">抽检数量</td><td style="width: 10%">备注</td><td></td></tr>');
            $("#btn_add_EM-SBC").replaceWith('<button id="btn_add_EM-SBC" name="test" type="button" class="btn btn-primary">增加新行</button>');
            $("#btn_EM-SBC").replaceWith('<button type="button" class="btn btn-primary" id="btn_EM-SBC">创建模板</button>');
            $("#btn_SAP_rou_workcenter_EM-QC").replaceWith('<button id="btn_SAP_rou_workcenter_EM-QC" type="button" class="btn btn-default dropdown-toggle button" data-toggle="dropdown">SAP标准工艺 <span class="caret"></span></button>');
            $("#btn_meas_eq_higher_EM-QC").replaceWith('<button id="btn_meas_eq_higher_EM-QC" type="button" class="btn btn-default dropdown-toggle button" data-toggle="dropdown">量仪 <span class="caret"></span></button>');
            $("#label_Update_Version_EM-QC").replaceWith('<label id="label_Update_Version_EM-QC" style="color: Red; margin: 7px 0 0 30px"><input id="Update_Version_EM-QC" type="checkbox" />更新/修改</label>');     //更新/修改
            $("#btn_SaveFile").replaceWith('<button type="button" class="btn btn-primary" id="btn_SaveFile" style="margin-left:450px">导出Excel文件</button>');
            $("#EM-QC_tr_1st").replaceWith('<tr id="EM-QC_tr_1st" style="background-color: #eeeeee"><td>序号</td><td style="width: 13%">图标</td><td>图纸规格 &nbsp; &nbsp; &nbsp;<label style="color: red"><input type="checkbox" id="checkbox_gongcha_EM-QC" />13级公差</label></td><td>量仪</td><td style="width: 15%">抽检数量</td><td style="width: 10%">备注</td><td></td></tr>');
            $("#btn_add_EM-QC").replaceWith('<button id="btn_add_EM-QC" name="test" type="button" class="btn btn-primary">增加新行</button>');
            $("#btn_EM-QC").replaceWith('<button type="button" class="btn btn-primary" id="btn_EM-QC">创建模板</button>');

            //动态添加部分英>中
            DynamicAddPart_toZh("IM-WS");
            DynamicAddPart_toZh("IM-QC");
            DynamicAddPart_toZh("EM-SBC");
            DynamicAddPart_toZh("EM-QC");
            DynamicAddPart_toZh("RW");

        }

    });

});

//取消登陆后清除登陆界面
function Login_dailog_initialize() {
    $('#ll').form('clear');
    $('#remember_me').prop("checked", false);
};
//取消注册后清除注册界面
function Register_dailog_initialize() {
    $('#rr').form('clear');
    $('#span_username').html('');
    $('#span_password1').html('');
    $('#span_password2').html('');
};

function Logout() {
    $('#logout_status').css("display", "block");
    $('#login_status').css("display", "none");
    $.post("CheckUserState.ashx", { "action": "Logout", "name": $('#spc_username').html() }, function (data) {
        var serverData = data.split(":");
        if (serverData[0]=="ok") {
            $('#spc_username').html('');
        }
    });
}
function CheckUserState() {
    $.post("CheckUserState.ashx", { "action": "CheckUserState" }, function (data) {
        var serverData = data.split(":");
        if (serverData[0] == "ok") {
            
            $('#login_status').css("display", "block");
            $('#spc_username').html(serverData[1]);
            $('#logout_status').css("display", "none");
        }
        else {
            $('#logout_status').css("display", "block");
            $('#login_status').css("display", "none");
        }
    })
};
function checkusername() {
    var badge = $("#username").val();
    $.post("CheckUserState.ashx", { "action": "checkusername", "badge": badge }, function (data) {
        var serverData = data.split(":");
        if (serverData[0] == "ok") {
            ActionForCheckpassword("#span_username", "#div_account", "<span style='color:green' class='glyphicon glyphicon-ok'></span>", "ok");
        }
        else {
            ActionForCheckpassword("#span_username", "#div_account", serverData[1], "");
        }
    });
};

function checkpassword() {
    var password1 = $("#password1").val();
    var password2 = $("#password2").val();
    var patrn = /^[a-zA-Z0-9_]{6,18}$/;
    if (patrn.test(password1)) {
        if (password1 != "" && password2 != "") {
            if (password1 == password2) {
                ActionForCheckpassword("#span_password1", "#div_password1", "<span style='color:green' class='glyphicon glyphicon-ok'></span>", "ok");
                ActionForCheckpassword("#span_password2", "#div_password2", "<span style='color:green' class='glyphicon glyphicon-ok'></span>", "ok");
            }
            else {
                ActionForCheckpassword("#span_password1", "#div_password1", "<span style='color:green' class='glyphicon glyphicon-ok'></span>", "ok");
                if ($("#input_changeLanguage").val() == "2") {
                    ActionForCheckpassword("#span_password2", "#div_password2", "The two passwords did not match!", "");
                }
                else {
                    ActionForCheckpassword("#span_password2", "#div_password2", "两次输入的密码不一致", "");
                }
            }
        }
        else if (password1 != "" && password2 == "") {
            ActionForCheckpassword("#span_password1", "#div_password1", "<span style='color:green' class='glyphicon glyphicon-ok'></span>", "ok");
            if ($("#input_changeLanguage").val() == "2") {
                ActionForCheckpassword("#span_password2", "#div_password2", "The two passwords did not match!", "");
            }
            else {
                ActionForCheckpassword("#span_password2", "#div_password2", "两次输入的密码不一致", "");
            }
        }
        else if (password1 == "" && password2 != "") {
            ActionForCheckpassword("#span_password1", "#div_password1", "密码不能为空", "");
            if ($("#input_changeLanguage").val() == "2") {
                ActionForCheckpassword("#span_password2", "#div_password2", "The two passwords did not match!", "");
            }
            else {
                ActionForCheckpassword("#span_password2", "#div_password2", "两次输入的密码不一致", "");
            }
        }
        else {
            if ($("#input_changeLanguage").val() == "2") {
                ActionForCheckpassword("#span_password1", "#div_password1", "The password cannot be empty!", "");
                ActionForCheckpassword("#span_password2", "#div_password2", "The password cannot be empty!", "");
            }
            else {
                ActionForCheckpassword("#span_password1", "#div_password1", "密码不能为空", "");
                ActionForCheckpassword("#span_password2", "#div_password2", "密码不能为空", "");
            }
        }
    }
    else {
        if ($("#input_changeLanguage").val() == "2") {
            ActionForCheckpassword("#span_password1", "#div_password1", "Please enter a password of 6-18 letters, numbers and underscores!", "");
            ActionForCheckpassword("#span_password2", "#div_password2", "The two passwords did not match!", "");
        }
        else {
            ActionForCheckpassword("#span_password1", "#div_password1", "请输入6-18个字母、数字、下划线的密码", "");
            ActionForCheckpassword("#span_password2", "#div_password2", "两次输入的密码不一致", "");
        }
    }
};
function ActionForCheckpassword(id1, id2, str, status) {
    if (status == "ok") {
        $(id1).css("display", "block");
        $(id1).removeAttr("style", "color");
        $(id2 + " .textbox").css("border-color", "#95b8e7");
        $(id1).html(str);

    }
    else {
        $(id1).css("display", "block");
        $(id1).css("color", "red");
        $(id2 + " .textbox").css("border-color", "#ffa8a8");
        $(id1).html(str);
    }
};


function AlertWindow(msg) {
    if ($("#input_changeLanguage").val() == "2") {
        $('#alert').dialog({
            title: 'Alert',
            width: 300,
            height: 200,
            closed: false,
            modal: true,
            buttons: [{
                text: 'Close',
                handler: function () {
                    $('#alert').dialog('close');

                }
            }]
        });
        $('#alert').html(msg);
        $('#alert').dialog('refresh');
    }
    else {
        $('#alert').dialog({
            title: '提示',
            width: 300,
            height: 200,
            closed: false,
            modal: true,
            buttons: [{
                text: '关闭',
                handler: function () {
                    $('#alert').dialog('close');

                }
            }]
        });
        $('#alert').html(msg);
        $('#alert').dialog('refresh');
    }
};
function ConfirmWindow(msg, type) {
    if ($("#input_changeLanguage").val() == "2") {
        $('#confirm').dialog({
            title: '确认',
            width: 300,
            height: 200,
            closed: false,
            modal: true,
            buttons: [{
                id: "conform_cancel",
                text: '取消',
                handler: function () {
                    $('#confirm').dialog('close');
                }
            }, {
                id: 'confirm_sure',
                text: '确定',
                handler: function () {
                    $('#confirm').dialog('close');
                    if (type == "logout") {
                        Logout();
                    }
                }
            }]
        });
    }
    else {
        $('#confirm').dialog({
            title: 'Confirm',
            width: 300,
            height: 200,
            closed: false,
            modal: true,
            buttons: [{
                id: "conform_cancel",
                text: 'Cancel',
                handler: function () {
                    $('#confirm').dialog('close');
                }
            }, {
                id: 'confirm_sure',
                text: 'OK',
                handler: function () {
                    $('#confirm').dialog('close');
                    if (type == "logout") {
                        Logout();
                    }
                }
            }]
        });
    }
    $('#confirm').html(msg);
    $('#confirm').dialog('refresh');
};


//动态添加部分中英文切换
function DynamicAddPart_toEn(templateType) {
    var $t1 = $("#" + templateType + "_table tr");
    var $index1 = $t1.length;
    for (var i = 1; i < $index1; i++) {
        $("#" + templateType + "_btn_icon_" + i).replaceWith('<button type="button" id="' + templateType + '_btn_icon_' + i + '" class="btn button btn-default dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">DrawingLable<span class="caret"></span></button>');
        $("#" + templateType + "_input_icon_" + i).attr("placeholder", "Drawing Lable,like：CD1");
        $("#" + templateType + "_btn_symbol_" + i).replaceWith('<button type="button" id="' + templateType + '_btn_symbol_' + i + '" class="btn button btn-default dropdown-toggle" data-toggle="dropdown">Symbol <span class="caret"></span></button>');
        $("#" + templateType + "_input_symbol_" + i).attr("placeholder", "Please fill in the drawing specification.");
        $("#" + templateType + "_btn_equipment_" + i).replaceWith('<button type="button" id="' + templateType + '_btn_equipment_' + i + '" class="btn button btn-default dropdown-toggle" data-toggle="dropdown">Equipment <span class="caret"></span></button>');
        $("#" + templateType + "_input_equipment_" + i).attr("placeholder", "Please select the equipment.");
        $("#" + templateType + "_btn_equipmentSetting_" + i).replaceWith('<button type="button" id="' + templateType + '_btn_equipmentSetting_' + i + '" class="btn button btn-default" style="margin-left:-25px; padding:5px 5px 5px 5px">Setting </button>');
        $("#" + templateType + "_btn_checkWay_" + i).replaceWith('<button type="button" id="' + templateType + '_btn_checkWay_' + i + '" class="btn button btn-default dropdown-toggle" data-toggle="dropdown">Method <span class="caret"></span></button>');
        $("#" + templateType + "_input_checkNum_" + i).attr("placeholder", "Please fill in the quantity of random inspection.");
        $("#" + templateType + "_input_note_" + i).attr("placeholder", "Note");
        $("#" + templateType + "_a_delete_" + i).replaceWith('<a id="' + templateType + '_a_delete_' + i + '" href="#">Delete</a>');
    }
};

function DynamicAddPart_toZh(templateType) {
    var $t1 = $("#" + templateType + "_table tr");
    var $index1 = $t1.length;
    for (var i = 1; i < $index1; i++) {
        $("#" + templateType + "_btn_icon_" + i).replaceWith('<button type="button" id="' + templateType + '_btn_icon_' + i + '" class="btn button btn-default dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">图标 <span class="caret"></span></button>');
        $("#" + templateType + "_input_icon_" + i).attr("placeholder", "图标，例如：CD1");
        $("#" + templateType + "_btn_symbol_" + i).replaceWith('<button type="button" id="' + templateType + '_btn_symbol_' + i + '" class="btn button btn-default dropdown-toggle" data-toggle="dropdown">符号 <span class="caret"></span></button>');
        $("#" + templateType + "_input_symbol_" + i).attr("placeholder", "请填写尺寸信息");
        $("#" + templateType + "_btn_equipment_" + i).replaceWith('<button type="button" id="' + templateType + '_btn_equipment_' + i + '" class="btn button btn-default dropdown-toggle" data-toggle="dropdown">量仪 <span class="caret"></span></button>');
        $("#" + templateType + "_input_equipment_" + i).attr("placeholder", "请选择量仪");
        $("#" + templateType + "_btn_equipmentSetting_" + i).replaceWith('<button type="button" id="' + templateType + '_btn_equipmentSetting_' + i + '" class="btn button btn-default" style="margin-left:-25px">设定 </button>');
        $("#" + templateType + "_btn_checkWay_" + i).replaceWith('<button type="button" id="' + templateType + '_btn_checkWay_' + i + '" class="btn button btn-default dropdown-toggle" data-toggle="dropdown">方法 <span class="caret"></span></button>');
        $("#" + templateType + "_input_checkNum_" + i).attr("placeholder", "请填写抽检数量");
        $("#" + templateType + "_input_note_" + i).attr("placeholder", "备注");
        $("#" + templateType + "_a_delete_" + i).replaceWith('<a id="' + templateType + '_a_delete_' + i + '" href="#">删除</a>');
    }
};