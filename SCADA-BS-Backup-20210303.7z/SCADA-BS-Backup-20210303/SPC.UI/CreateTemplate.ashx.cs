﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.IO;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using SPC.BLL;
using SPC.Model;
using System.Data;
using System.Collections;
using System.Runtime.Serialization.Json;
using System.Reflection;
using Microsoft.Office.Core;
using Microsoft.Office.Interop;
using Microsoft.Office.Interop.Excel;
using System.Net;
using System.Runtime.InteropServices;
using System.Management;

namespace SPC.UI
{
    /// <summary>
    /// Summary description for index
    /// </summary>
    public class index : IHttpHandler
    {
        public void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "text/json";
            string method = context.Request.HttpMethod;
            if (method == "POST")
            {
                context.Response.Cache.SetCacheability(HttpCacheability.NoCache);
                StreamReader reader = new StreamReader(context.Request.InputStream);
                string jsondata = reader.ReadToEnd();
                reader.Close();
                reader.Dispose();
                List<dynamic> lists = new JavaScriptSerializer().Deserialize<List<dynamic>>(jsondata);
                SpcPartTemplateBLL bll = new SpcPartTemplateBLL();
                if (lists[0]["function"]=="CheckPartNum")
                {
                    #region 检查工件号
                    string str = bll.CheckPartNum(lists[1]["part_num"]);
                    context.Response.Write("{\"status\":\"" + str.ToUpper() + "\"}"); 
                    #endregion
                }
                else if (lists[0]["function"]=="GetInsertData")
                {
                    #region 插入创建的数据
                    int num = bll.GetInsertData(lists);
                    if (num == -1)
                    {
                        context.Response.Write("{\"status\":\"创建成功\"}");
                    }
                    else
                    {
                        context.Response.Write("{\"status\":\"创建失败，请检查是否重复创建完全相同的模板\"}");
                    } 
                    #endregion
                }
                else if (lists[0]["function"]=="checkPartNumAndPartRev")
                {
                    #region 检查工件号和版本号
                    string part_num = lists[1]["part_num"];
                    string part_rev = lists[2]["part_rev"];
                    string part_name = bll.GetPartDesc(part_num);
                    if (bll.checkPartNumAndPartRev(part_num, part_rev))
                    {
                        context.Response.Write("{\"status\":\"pass\",\"partname\":\"" + part_name.ToString() + "\"}");
                    }
                    else
                    {
                        context.Response.Write("{\"status\":\"fail\"}");
                    }
                    #endregion
                }
                else if (lists[0]["function"] == "connectToGNDrawingLibrary")
                {
                    #region 连接GN图库继续检查工件号和版本号
                    string part_num = lists[1]["part_num"];
                    string part_rev = lists[2]["part_rev"];
                    string site = "MET_ALG";
                    if (bll.connectToGNDrawingLibrary(part_num, part_rev, site))
                    {
                        context.Response.Write("{\"status\":\"pass\"}");
                    }
                    else
                    {
                        context.Response.Write("{\"status\":\"fail\"}");
                    }
                    #endregion
                }
                else if (lists[0]["function"]=="checkbadge")
                {
                    #region 检查工号
                    string badge = lists[1]["badge"];
                    string str = bll.checkbadge(badge);
                    if (str == "")
                    {
                        context.Response.Write("{\"status\":\"pass\"}");
                    }
                    else
                    {
                        context.Response.Write("{\"status\":\"fail\"}");
                    }
                    #endregion 
                }
                else if (lists[0]["function"]=="checkTemplateVersion")
                {
                    #region 检查模板版本
                    string part_num = lists[0]["part_num"];
                    string part_rev = lists[0]["part_rev"];
                    string templateType = lists[0]["templateType"];
                    double version = bll.GetTemplateRev(part_num, part_rev, templateType);
                    if (version != 0)
                    {
                        context.Response.Write("{\"status\":\"工件号" + part_num.ToUpper() + ",版本号" + part_rev.ToUpper() + ",当前已经存在版本S" + version.ToString() + ",请确认是否升版？\",\"version\":\"" + version.ToString() + "\"}");
                    }
                    else
                    {
                        context.Response.Write("{\"status\":\"pass\"}");
                    } 
                    #endregion
                }
                else if (lists[0]["function"]=="GetMachineType")
                {
                    #region 获得机型
                    Dictionary<string, string> dict_mt = new Dictionary<string, string>();
                    dict_mt = bll.GetMachineType();
                    JavaScriptSerializer js = new JavaScriptSerializer();
                    string str = js.Serialize(dict_mt);
                    context.Response.Write(str);
                    #endregion
                }
                else if (lists[0]["function"] == "GetFixtureAndIPNA")
                {
                    #region 获得夹具和IPNA
                    string part_num = lists[1]["part_num"];
                    string part_rev = lists[2]["part_rev"];
                    Dictionary<string, string> dict_fix = new Dictionary<string, string>();            
                    dict_fix = bll.GetFixtureNo(part_num, part_rev);
                    Dictionary<string, string> dict_ipna = new Dictionary<string, string>();
                    dict_ipna = bll.GetIPNA(part_num, part_rev);
                    ArrayList data = new ArrayList();
                    data.Add(dict_fix);
                    data.Add(dict_ipna);
                    JavaScriptSerializer js = new JavaScriptSerializer();
                    string str_fix = js.Serialize(data);
                    context.Response.Write(str_fix);
                    #endregion
                }

                else if (lists[0]["function"] == "GetShipmentList")
                {
                    #region 获得SAP标准工艺列表

                    string part_num = lists[1]["part_num"];
                    string part_rev = lists[2]["part_rev"];
                    string plant = "8700";
                    Dictionary<string, string> dict_shipment = new Dictionary<string, string>();
                    dict_shipment = bll.GetShipmentList(part_num, part_rev, plant);
                    ArrayList data = new ArrayList();
                    data.Add(dict_shipment);
                    var dicSort = from objDic in dict_shipment orderby objDic.Value select objDic;
                    JavaScriptSerializer js = new JavaScriptSerializer();
                    string str_shipment = js.Serialize(data);
                    context.Response.Write(str_shipment);
                    #endregion
                }

                else if (lists[0]["function"] == "GetQCicon")
                {
                    #region 获得QC图标
                    string part_num = lists[1]["part_num"];
                    string part_rev = lists[2]["part_rev"];
                    string type = lists[3]["type"];
                    Dictionary<string, string> dict_QCicon = new Dictionary<string, string>();
                    dict_QCicon = bll.GetQCicon(part_num, part_rev, type);
                    ArrayList data = new ArrayList();
                    data.Add(dict_QCicon);
                    JavaScriptSerializer js = new JavaScriptSerializer();
                    string str_QCicon = js.Serialize(data);
                    context.Response.Write(str_QCicon);
                    #endregion
                }
                else if (lists[0]["function"] == "CreateRw")
                {
                    #region 创建返修
                    string part_num = lists[0]["part_num"];
                    string part_rev = lists[0]["part_rev"];
                    string LinkTotemplateType = lists[0]["LinkTotemplateType"];
                    string version = lists[0]["version"];
                    Dictionary<string, object> dict_record = new Dictionary<string, object>();
                    dict_record = bll.GetRw(part_num, part_rev, LinkTotemplateType,version);
                    JavaScriptSerializer js = new JavaScriptSerializer();
                    string str = js.Serialize(dict_record);
                    context.Response.Write(str);                 
                    #endregion
                }
                else if (lists[0]["function"] == "GetExcelData")
                {
                    #region 导出excel
                    string diretory = System.AppDomain.CurrentDomain.BaseDirectory.ToString();
                    
                    try
                    {
                        if (Directory.Exists(@"C:\Windows\System32\config\systemprofile\Desktop") == false)
                        {
                            Directory.CreateDirectory(@"C:\Windows\System32\config\systemprofile\Desktop");
                        }
                        if (Directory.Exists(@" C:\Windows\SysWOW64\config\systemprofile\Desktop") == false)
                        {
                            Directory.CreateDirectory(@" C:\Windows\SysWOW64\config\systemprofile\Desktop");
                        }
                    }
                    catch { }
                    try
                    {
                        #region MyRegion
                        List<object> Exception_list = new List<object>();
                        List<SCADA_create_template> list_spc_template = new List<SCADA_create_template>();
                        if (lists.Count > 1)
                        {
                            double version = bll.GetTemplateRev((string)lists[lists.Count - 1]["Part_num"], (string)lists[lists.Count - 1]["Part_rev"], (string)lists[lists.Count - 1]["Template_type"]);
                            if (version == 0)
                            {
                                version = 1;
                            }
                            for (int i = 1; i < lists.Count; i++)
                            {
                                SCADA_create_template template_model = new SCADA_create_template();
                                template_model.Part_num = lists[i]["Part_num"];
                                template_model.Part_rev = lists[i]["Part_rev"];
                                template_model.Badge = lists[i]["Badge"];
                                template_model.Template_type = lists[i]["Template_type"];
                                template_model.Gn_type = lists[i]["Gn_type"];
                                template_model.Sap_rou_workcenter = lists[i]["Sap_rou_workcenter"];
                                template_model.Dwg_label = lists[i]["Dwg_label"];
                                template_model.Dwg_spec = lists[i]["Dwg_spec"];
                                template_model.Upp_tol = lists[i]["Upp_tol"];
                                template_model.Lwr_tol = lists[i]["Lwr_tol"];
                                template_model.Meas_eq = lists[i]["Meas_eq"];
                                template_model.Part_desc = bll.GetPartDesc(lists[i]["Part_num"]);
                                template_model.Template_version = version.ToString();
                                list_spc_template.Add(template_model);
                            }
                        }
                        #endregion

                        string templateType = lists[0]["templateType"];
                        
                        if (templateType == "EM-SBC")
                        {
                            #region EM-SBC Excel导出

                            string pathfile = diretory + @"SCADA_template.xlsx";
                            if (IsFileOpen(pathfile) == 2)
                            {
                                KillExcelProcess();
                            }

                            Microsoft.Office.Interop.Excel.Application app = new Microsoft.Office.Interop.Excel.Application();
                            Microsoft.Office.Interop.Excel.Workbook wbook = app.Workbooks.Open(pathfile);

                            Microsoft.Office.Interop.Excel.Sheets sheets = wbook.Worksheets;
                            Microsoft.Office.Interop.Excel.Worksheet myWorkSheet = sheets[1];
                            app.DisplayAlerts = false;
                            app.Visible = false;

                            string part_num = list_spc_template[0].Part_num;
                            string part_rev = list_spc_template[0].Part_rev;
                            string part_name = list_spc_template[0].Part_desc.Trim();
                            string badge = list_spc_template[0].Badge;
                            string template_ver = list_spc_template[0].Template_version;
                            string Template_type = list_spc_template[0].Template_type;
                            string Supplier_code = list_spc_template[0].Gn_type;
                            //4.向相应对位置写入相应的数据
                            myWorkSheet.Cells[3][6] = Supplier_code;    //供应商
                            myWorkSheet.Cells[2][7] = part_num;         //工件号
                            myWorkSheet.Cells[3][7] = "REV:" + part_rev;//版本号
                            myWorkSheet.Cells[3][8] = "TRMS Template Tester";
                            myWorkSheet.Cells[3][9] = "Physical Measurement";
                            myWorkSheet.Cells[3][10] = "EMQA-Vendor QC";
                            myWorkSheet.Cells[3][11] = "S" + template_ver;        //版本号
                            for (int i = 0; i < list_spc_template.Count; i++)
                            {
                                myWorkSheet.Cells[3 + i][16] = list_spc_template[i].Dwg_label;      //Attritube3:图标
                                myWorkSheet.Cells[3 + i][17] = list_spc_template[i].Dwg_spec;       //Attritube4:规格
                                myWorkSheet.Cells[3 + i][18] = list_spc_template[i].Meas_eq;           //Attritube5:量仪
                                myWorkSheet.Cells[3 + i][19] = list_spc_template[i].Upp_tol;         //max
                                myWorkSheet.Cells[3 + i][20] = list_spc_template[i].Lwr_tol;         //min
                            }

                            wbook.Saved = true;
                            string excel_path = "";
                            string copy_path = "";
                            string filename = "";
                            if (System.IO.File.Exists(diretory + @"temp\EM-SBC\EM-SBC_" + part_num + "_" + part_rev + "_" + Supplier_code + ".xlsx"))
                            {
                                for (int i = 1; i < 100; i++)
                                {
                                    if (System.IO.File.Exists(diretory + @"temp\EM-SBC\EM-SBC_" + part_num + "_" + part_rev + "_" + Supplier_code + "(" + i + ").xlsx"))
                                    {
                                    }
                                    else
                                    {
                                        excel_path = diretory + @"temp\EM-SBC\EM-SBC_" + part_num + "_" + part_rev + "_" + Supplier_code + "(" + i + ").xlsx";
                                        copy_path = @"\\Algex.asmpt.com\algfas\FileArchive\Quality\TRMS\Fab\TRMS_Template\EM-SBC\EM-SBC_" + part_num + "_" + part_rev + "_" + Supplier_code + "(" + i + ").xlsx";
                                        filename = "EM-SBC_" + part_num + "_" + part_rev + "_" + Supplier_code + "(" + i + ").xlsx";
                                        break;
                                    }
                                }
                            }
                            else
                            {
                                excel_path = diretory + @"temp\EM-SBC\EM-SBC_" + part_num + "_" + part_rev + "_" + Supplier_code + ".xlsx";
                                copy_path = @"\\Algex.asmpt.com\algfas\FileArchive\Quality\TRMS\Fab\TRMS_Template\EM-SBC\EM-SBC_" + part_num + "_" + part_rev + "_" + Supplier_code + ".xlsx";
                                filename = "EM-SBC_" + part_num + "_" + part_rev + "_" + Supplier_code + ".xlsx";
                            }

                            wbook.SaveAs(
                                excel_path,
                                Type.Missing,
                                "",
                                "",
                                Type.Missing,
                                Type.Missing,
                                Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlNoChange,
                                Microsoft.Office.Interop.Excel.XlSaveConflictResolution.xlLocalSessionChanges,
                                false,
                                Type.Missing,
                                Type.Missing,
                                Type.Missing
                                );

                            object missing = System.Reflection.Missing.Value;
                            app.Workbooks.Close();
                            app.Workbooks.Application.Quit();
                            app.Application.Quit();
                            app.Quit();

                            System.Runtime.InteropServices.Marshal.ReleaseComObject(app.Workbooks);
                            System.Runtime.InteropServices.Marshal.ReleaseComObject(app.Application);
                            System.Runtime.InteropServices.Marshal.ReleaseComObject(app);

                            app = null;

                            GC.Collect();
                            string url_1 = context.Request.Url.ToString();
                            url_1 = url_1.Substring(0, url_1.IndexOf("CreateTemplate.ashx")) + @"temp/EM-SBC/";  

                            #region 保存Excel到服务器
                            KillExcelProcess();
                            System.Diagnostics.Process proc = new System.Diagnostics.Process();
                            try
                            {
                                proc.StartInfo.FileName = "cmd.exe";
                                proc.StartInfo.UseShellExecute = false;
                                proc.StartInfo.RedirectStandardInput = true;
                                proc.StartInfo.RedirectStandardOutput = true;
                                proc.StartInfo.RedirectStandardError = true;
                                proc.StartInfo.CreateNoWindow = true;
                                proc.Start();
                                //登录验证
                                string dosLine = @"net use " + @"\\Algex.asmpt.com\algfas\FileArchive\Quality\TRMS\Fab" + " " + "iusrALGwww" + " /user:" + @"IUSR_www";
                                proc.StandardInput.WriteLine("net use * /del /y");
                                proc.StandardInput.WriteLine(dosLine);
                                proc.StandardInput.WriteLine("exit");
                                while (!proc.HasExited)
                                {
                                    proc.WaitForExit(1000);
                                }
                                string errormsg = proc.StandardError.ReadToEnd();
                                proc.StandardError.Close();
                                if (string.IsNullOrEmpty(errormsg))
                                {
                                    try
                                    {
                                        File.Copy(excel_path, copy_path);
                                    }
                                    catch (Exception)
                                    {
                                    }
                                }
                                else
                                {
                                    throw new Exception(errormsg);
                                }
                            }
                            catch (Exception ex)
                            {
                                throw ex;
                            }
                            finally
                            {
                                proc.Close();
                                proc.Dispose();
                            } 
                            #endregion

                            context.Response.Write("{\"url\":\"" + url_1 + filename + "\"}");
                            #endregion
                        } 
                        else
                        {
                            var equipmentType = lists[0]["equipmentType"];
                            if (equipmentType == "IM")
                            {
                                #region IM Excel导出

                                string pathfile = diretory + @"SCADA_template.xlsx";
                                if (IsFileOpen(pathfile) == 2)
                                {
                                    KillExcelProcess();
                                }

                                Microsoft.Office.Interop.Excel.Application app = new Microsoft.Office.Interop.Excel.Application();
                                Microsoft.Office.Interop.Excel.Workbook wbook = app.Workbooks.Open(pathfile);

                                Microsoft.Office.Interop.Excel.Sheets sheets = wbook.Worksheets;
                                Microsoft.Office.Interop.Excel.Worksheet myWorkSheet = sheets[1];
                                app.DisplayAlerts = false;
                                app.Visible = false;

                                string part_num = list_spc_template[0].Part_num;
                                string part_rev = list_spc_template[0].Part_rev;
                                string part_name = list_spc_template[0].Part_desc.Trim();
                                string badge = list_spc_template[0].Badge;
                                string template_ver = list_spc_template[0].Template_version;
                                string Template_type = list_spc_template[0].Template_type;
                                string gn_type = list_spc_template[0].Gn_type;
                                string Machine_type = list_spc_template[0].Sap_rou_workcenter;
                                //4.向相应对位置写入相应的数据
                                myWorkSheet.Cells[3][6] = "ALG";            //厂区
                                myWorkSheet.Cells[2][7] = part_num;         //工件号
                                myWorkSheet.Cells[3][7] = "REV:" + part_rev;//版本号
                                myWorkSheet.Cells[3][11] = "S" + template_ver;        //版本号
                                myWorkSheet.Cells[3][8] = part_name;        //工件名称
                                myWorkSheet.Cells[3][9] = "Physical Measurement";
                                myWorkSheet.Cells[3][10] = Machine_type;    //工序
                                for (int i = 0; i < list_spc_template.Count; i++)
                                {
                                    myWorkSheet.Cells[3 + i][16] = list_spc_template[i].Dwg_label;       //Attritube3:图标
                                    myWorkSheet.Cells[3 + i][17] = list_spc_template[i].Dwg_spec;       //Attritube4:规格
                                    myWorkSheet.Cells[3 + i][18] = list_spc_template[i].Meas_eq;           //Attritube5:量仪
                                    myWorkSheet.Cells[3 + i][19] = list_spc_template[i].Upp_tol;         //max
                                    myWorkSheet.Cells[3 + i][20] = list_spc_template[i].Lwr_tol;         //min
                                }


                                wbook.Saved = true;

                                string excel_path = "";
                                string copy_path = "";
                                string filename = "";
                                if (System.IO.File.Exists(diretory + @"temp\IM_Template\IM_" + part_num + "_" + part_rev + "_" + Machine_type + ".xlsx"))
                                {
                                    for (int i = 1; i < 100; i++)
                                    {
                                        if (System.IO.File.Exists(diretory + @"temp\IM_Template\IM_" + part_num + "_" + part_rev + "_" + Machine_type + "(" + i + ").xlsx"))
                                        {
                                        }
                                        else
                                        {
                                            excel_path = diretory + @"temp\IM_Template\IM_" + part_num + "_" + part_rev + "_" + Machine_type + "(" + i + ").xlsx";
                                            copy_path = @"\\Algex.asmpt.com\algfas\FileArchive\Quality\TRMS\Fab\Equipment_Report\IM_Template\IM_" + part_num + "_" + part_rev + "_" + Machine_type + "(" + i + ").xlsx";
                                            filename = "IM_" + part_num + "_" + part_rev + "_" + Machine_type + "(" + i + ").xlsx";
                                            break;
                                        }
                                    }
                                }
                                else
                                {
                                    excel_path = diretory + @"temp\IM_Template\IM_" + part_num + "_" + part_rev + "_" + Machine_type + ".xlsx";
                                    copy_path = @"\\Algex.asmpt.com\algfas\FileArchive\Quality\TRMS\Fab\Equipment_Report\IM_Template\IM_" + part_num + "_" + part_rev + "_" + Machine_type + ".xlsx";
                                    filename = "IM_" + part_num + "_" + part_rev + "_" + Machine_type + ".xlsx";
                                }

                                wbook.SaveAs(
                                    excel_path,
                                    Type.Missing,
                                    "",
                                    "",
                                    Type.Missing,
                                    Type.Missing,
                                    Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlNoChange,
                                    Microsoft.Office.Interop.Excel.XlSaveConflictResolution.xlLocalSessionChanges,
                                    false,
                                    Type.Missing,
                                    Type.Missing,
                                    Type.Missing
                                    );

                                object missing = System.Reflection.Missing.Value;
                                app.Workbooks.Close();
                                app.Workbooks.Application.Quit();
                                app.Application.Quit();
                                app.Quit();

                                System.Runtime.InteropServices.Marshal.ReleaseComObject(app.Workbooks);
                                System.Runtime.InteropServices.Marshal.ReleaseComObject(app.Application);
                                System.Runtime.InteropServices.Marshal.ReleaseComObject(app);

                                app = null;

                                GC.Collect();
                                string url_1 = context.Request.Url.ToString();
                                url_1 = url_1.Substring(0, url_1.IndexOf("CreateTemplate.ashx")) + @"temp/IM_Template/";

                                #region 保存Excel到服务器
                                KillExcelProcess();
                                System.Diagnostics.Process proc = new System.Diagnostics.Process();
                                try
                                {
                                    proc.StartInfo.FileName = "cmd.exe";
                                    proc.StartInfo.UseShellExecute = false;
                                    proc.StartInfo.RedirectStandardInput = true;
                                    proc.StartInfo.RedirectStandardOutput = true;
                                    proc.StartInfo.RedirectStandardError = true;
                                    proc.StartInfo.CreateNoWindow = true;
                                    proc.Start();
                                    //登录验证
                                    string dosLine = @"net use " + @"\\Algex.asmpt.com\algfas\FileArchive\Quality\TRMS\Fab" + " " + "iusrALGwww" + " /user:" + @"IUSR_www";
                                    proc.StandardInput.WriteLine("net use * /del /y");
                                    proc.StandardInput.WriteLine(dosLine);
                                    proc.StandardInput.WriteLine("exit");
                                    while (!proc.HasExited)
                                    {
                                        proc.WaitForExit(1000);
                                    }
                                    string errormsg = proc.StandardError.ReadToEnd();
                                    proc.StandardError.Close();
                                    if (string.IsNullOrEmpty(errormsg))
                                    {
                                        try
                                        {
                                            File.Copy(excel_path, copy_path);
                                        }
                                        catch (Exception)
                                        {
                                        }
                                    }
                                    else
                                    {
                                        throw new Exception(errormsg);
                                    }
                                }
                                catch (Exception ex)
                                {
                                    throw ex;
                                }
                                finally
                                {
                                    proc.Close();
                                    proc.Dispose();
                                }
                                #endregion

                                context.Response.Write("{\"url\":\"" + url_1 + filename + "\"}");
                                #endregion
                            }
                            else
                            {
                                #region CMM_ID Excel导出

                                string pathfile = diretory + @"CMM_EXCEL.xls";
                                if (IsFileOpen(pathfile) == 2)
                                {
                                    KillExcelProcess();
                                }

                                Microsoft.Office.Interop.Excel.Application app = new Microsoft.Office.Interop.Excel.Application();
                                Microsoft.Office.Interop.Excel.Workbook wbook = app.Workbooks.Open(pathfile);

                                Microsoft.Office.Interop.Excel.Sheets sheets = wbook.Worksheets;
                                Microsoft.Office.Interop.Excel.Worksheet myWorkSheet = sheets[1];
                                app.DisplayAlerts = false;
                                app.Visible = false;

                                string part_num = list_spc_template[0].Part_num;
                                string part_rev = list_spc_template[0].Part_rev;
                                string part_name = list_spc_template[0].Part_desc.Trim();
                                string badge = list_spc_template[0].Badge;
                                string template_ver = list_spc_template[0].Template_version;
                                string Template_type = list_spc_template[0].Template_type;
                                string gn_type = list_spc_template[0].Gn_type;
                                string Machine_type = list_spc_template[0].Sap_rou_workcenter;
                                //4.向相应对位置写入相应的数据

                                myWorkSheet.Cells[2][2] = part_num;         //工件号
                                myWorkSheet.Cells[2][3] = part_rev;         //版本号
                                myWorkSheet.Cells[2][6] = DateTime.Now.ToString("yyyy/MM/dd");
                                myWorkSheet.Cells[2][7] = DateTime.Now.ToString("HH:mm:ss");
                                for (int i = 0; i < list_spc_template.Count; i++)
                                {
                                    myWorkSheet.Cells[1][12 + i] = list_spc_template[i].Meas_eq;
                                    myWorkSheet.Cells[2][12 + i] = list_spc_template[i].Dwg_label;
                                    myWorkSheet.Cells[3][12 + i] = list_spc_template[i].Dwg_label;
                                    myWorkSheet.Cells[4][12 + i] = list_spc_template[i].Upp_tol;
                                    myWorkSheet.Cells[5][12 + i] = list_spc_template[i].Lwr_tol;
                                }


                                wbook.Saved = true;

                                string excel_path1 = "";
                                string copy_path1 = "";
                                string filename1 = "";
                                if (System.IO.File.Exists(diretory + @"temp\CMM_ID_Name\CMM_ID_" + part_num + "_" + part_rev + "_" + Machine_type + ".xls"))
                                {
                                    for (int i = 1; i < 100; i++)
                                    {
                                        if (System.IO.File.Exists(diretory + @"temp\CMM_ID_Name\CMM_ID_" + part_num + "_" + part_rev + "_" + Machine_type + "(" + i + ").xls"))
                                        {
                                        }
                                        else
                                        {
                                            excel_path1 = diretory + @"temp\CMM_ID_Name\CMM_ID_" + part_num + "_" + part_rev + "_" + Machine_type + "(" + i + ").xls";
                                            copy_path1 = @"\\Algex.asmpt.com\algfas\FileArchive\Quality\TRMS\Fab\Equipment_Report\CMM_ID_Name\CMM_ID_" + part_num + "_" + part_rev + "_" + Machine_type + "(" + i + ").xls";
                                            filename1 = "CMM_ID_" + part_num + "_" + part_rev + "_" + Machine_type + "(" + i + ").xls";
                                            break;
                                        }
                                    }
                                }
                                else
                                {
                                    excel_path1 = diretory + @"temp\CMM_ID_Name\CMM_ID_" + part_num + "_" + part_rev + "_" + Machine_type + ".xls";
                                    copy_path1 = @"\\Algex.asmpt.com\algfas\FileArchive\Quality\TRMS\Fab\Equipment_Report\CMM_ID_Name\CMM_ID_" + part_num + "_" + part_rev + "_" + Machine_type + ".xls";
                                    filename1 = "CMM_ID_" + part_num + "_" + part_rev + "_" + Machine_type + ".xls";
                                }

                                wbook.SaveAs(
                                    excel_path1,
                                    Type.Missing,
                                    "",
                                    "",
                                    Type.Missing,
                                    Type.Missing,
                                    Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlNoChange,
                                    Microsoft.Office.Interop.Excel.XlSaveConflictResolution.xlLocalSessionChanges,
                                    false,
                                    Type.Missing,
                                    Type.Missing,
                                    Type.Missing
                                    );

                                object missing = System.Reflection.Missing.Value;
                                app.Workbooks.Close();
                                app.Workbooks.Application.Quit();
                                app.Application.Quit();
                                app.Quit();

                                System.Runtime.InteropServices.Marshal.ReleaseComObject(app.Workbooks);
                                System.Runtime.InteropServices.Marshal.ReleaseComObject(app.Application);
                                System.Runtime.InteropServices.Marshal.ReleaseComObject(app);

                                app = null;

                                GC.Collect();
                                string url_1 = context.Request.Url.ToString();
                                url_1 = url_1.Substring(0, url_1.IndexOf("CreateTemplate.ashx")) + @"temp/CMM_ID_Name/";
                                #endregion

                                #region CMM_TPL Excel导出

                                pathfile = diretory + @"SCADA_template.xlsx";
                                if (IsFileOpen(pathfile) == 2)
                                {
                                    KillExcelProcess();
                                }

                                Microsoft.Office.Interop.Excel.Application app2 = new Microsoft.Office.Interop.Excel.Application();
                                Microsoft.Office.Interop.Excel.Workbook wbook2 = app2.Workbooks.Open(pathfile);

                                Microsoft.Office.Interop.Excel.Sheets sheets2 = wbook2.Worksheets;
                                Microsoft.Office.Interop.Excel.Worksheet myWorkSheet2 = sheets2[1];
                                app2.DisplayAlerts = false;
                                app2.Visible = false;

                                part_num = list_spc_template[0].Part_num;
                                part_rev = list_spc_template[0].Part_rev;
                                part_name = list_spc_template[0].Part_desc.Trim();
                                badge = list_spc_template[0].Badge;
                                template_ver = list_spc_template[0].Template_version;
                                Template_type = list_spc_template[0].Template_type;
                                gn_type = list_spc_template[0].Gn_type;
                                Machine_type = list_spc_template[0].Sap_rou_workcenter;
                                //4.向相应对位置写入相应的数据
                                myWorkSheet2.Cells[3][6] = "ALG";             //厂区
                                myWorkSheet2.Cells[2][7] = part_num;         //工件号
                                myWorkSheet2.Cells[3][7] = "REV:" + part_rev;//版本号
                                myWorkSheet2.Cells[3][11] = "S" + template_ver;        //版本号
                                myWorkSheet2.Cells[3][8] = part_name;        //工件名称
                                myWorkSheet2.Cells[3][9] = "Physical Measurement";
                                myWorkSheet2.Cells[3][10] = Machine_type;    //工序

                                for (int i = 0; i < list_spc_template.Count; i++)
                                {
                                    myWorkSheet2.Cells[3 + i][16] = list_spc_template[i].Dwg_label;       //Attritube3:图标
                                    myWorkSheet2.Cells[3 + i][17] = list_spc_template[i].Dwg_spec;       //Attritube4:规格
                                    myWorkSheet2.Cells[3 + i][18] = list_spc_template[i].Meas_eq;           //Attritube5:量仪
                                    myWorkSheet2.Cells[3 + i][19] = list_spc_template[i].Upp_tol;         //max
                                    myWorkSheet2.Cells[3 + i][20] = list_spc_template[i].Lwr_tol;         //min
                                    myWorkSheet2.Cells[12][3] = i + 1;
                                }


                                wbook2.Saved = true;

                                string excel_path2 = "";
                                string copy_path2 = "";
                                string filename2 = "CMM_Tpl_" + part_num + "_" + part_rev + "_" + Machine_type + ".xlsx";
                                if (System.IO.File.Exists(diretory + @"temp\CMM_Template\CMM_Tpl_" + part_num + "_" + part_rev + "_" + Machine_type + ".xlsx"))
                                {
                                    for (int i = 1; i < 100; i++)
                                    {
                                        if (System.IO.File.Exists(diretory + @"temp\CMM_Template\CMM_Tpl_" + part_num + "_" + part_rev + "_" + Machine_type + "(" + i + ").xlsx"))
                                        {
                                        }
                                        else
                                        {
                                            excel_path2 = diretory + @"temp\CMM_Template\CMM_Tpl_" + part_num + "_" + part_rev + "_" + Machine_type + "(" + i + ").xlsx";
                                            copy_path2 = @"\\Algex.asmpt.com\algfas\FileArchive\Quality\TRMS\Fab\Equipment_Report\CMM_Template\CMM_Tpl_" + part_num + "_" + part_rev + "_" + Machine_type + "(" + i + ").xlsx";
                                            filename2 = "CMM_Tpl_" + part_num + "_" + part_rev + "_" + Machine_type + "(" + i + ").xlsx";
                                            break;
                                        }
                                    }
                                }
                                else
                                {
                                    excel_path2 = diretory + @"temp\CMM_Template\CMM_Tpl_" + part_num + "_" + part_rev + "_" + Machine_type + ".xlsx";
                                    copy_path2 = @"\\Algex.asmpt.com\algfas\FileArchive\Quality\TRMS\Fab\Equipment_Report\CMM_Template\CMM_Tpl_" + part_num + "_" + part_rev + "_" + Machine_type + ".xlsx";
                                    filename2 = "CMM_Tpl_" + part_num + "_" + part_rev + "_" + Machine_type + ".xlsx";
                                }

                                wbook2.SaveAs(
                                    excel_path2,
                                    Type.Missing,
                                    "",
                                    "",
                                    Type.Missing,
                                    Type.Missing,
                                    Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlNoChange,
                                    Microsoft.Office.Interop.Excel.XlSaveConflictResolution.xlLocalSessionChanges,
                                    false,
                                    Type.Missing,
                                    Type.Missing,
                                    Type.Missing
                                    );

                                object missing2 = System.Reflection.Missing.Value;
                                app2.Workbooks.Close();
                                app2.Workbooks.Application.Quit();
                                app2.Application.Quit();
                                app2.Quit();

                                System.Runtime.InteropServices.Marshal.ReleaseComObject(app2.Workbooks);
                                System.Runtime.InteropServices.Marshal.ReleaseComObject(app2.Application);
                                System.Runtime.InteropServices.Marshal.ReleaseComObject(app2);

                                app2 = null;

                                GC.Collect();
                                string url_2 = context.Request.Url.ToString();
                                url_2 = url_2.Substring(0, url_2.IndexOf("CreateTemplate.ashx")) + @"temp/CMM_Template/";
                                #endregion

                                #region 保存Excel到服务器
                                KillExcelProcess();
                                System.Diagnostics.Process proc = new System.Diagnostics.Process();
                                try
                                {
                                    proc.StartInfo.FileName = "cmd.exe";
                                    proc.StartInfo.UseShellExecute = false;
                                    proc.StartInfo.RedirectStandardInput = true;
                                    proc.StartInfo.RedirectStandardOutput = true;
                                    proc.StartInfo.RedirectStandardError = true;
                                    proc.StartInfo.CreateNoWindow = true;
                                    proc.Start();
                                    //登录验证
                                    string dosLine = @"net use " + @"\\Algex.asmpt.com\algfas\FileArchive\Quality\TRMS\Fab" + " " + "iusrALGwww" + " /user:" + @"IUSR_www";
                                    proc.StandardInput.WriteLine("net use * /del /y");
                                    proc.StandardInput.WriteLine(dosLine);
                                    proc.StandardInput.WriteLine("exit");
                                    while (!proc.HasExited)
                                    {
                                        proc.WaitForExit(1000);
                                    }
                                    string errormsg = proc.StandardError.ReadToEnd();
                                    proc.StandardError.Close();
                                    if (string.IsNullOrEmpty(errormsg))
                                    {
                                        try
                                        {
                                            File.Copy(excel_path1, copy_path1);
                                            File.Copy(excel_path2, copy_path2);
                                        }
                                        catch (Exception)
                                        {
                                        }
                                    }
                                    else
                                    {
                                        throw new Exception(errormsg);
                                    }
                                }
                                catch (Exception ex)
                                {
                                    throw ex;
                                }
                                finally
                                {
                                    proc.Close();
                                    proc.Dispose();
                                }
                                #endregion

                                context.Response.Write("{\"url\":\"" + url_1 + filename1 + "\",\"url2\":\"" + url_2 + filename2 + "\"}");
                                
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        context.Response.Write("{\"status\":\"Excel导出失败" + ex.ToString() + "\"}");
                    } 
                    #endregion

                }
                else
                {
                    context.Response.Write("<p>页面找不到！</p>");
                }
            }
        }

        [DllImport("User32.dll", CharSet = CharSet.Auto)]
        public static extern int GetWindowThreadProcessId(IntPtr hwnd, out int ID);

        [DllImport("kernel32.dll")]
        public static extern IntPtr _lopen(string lpPathName, int iReadWrite);//调用windowsdll

        [DllImport("kernel32.dll")]
        public static extern bool CloseHandle(IntPtr hObject);//调用windowsdll
        public const int OF_READWRITE = 2;//这些参数是不可少的，当然也可以不声明，直接将值赋值给对应的函数，这里只是生明变量将其存起来而已
        public const int OF_SHARE_DENY_NONE = 0x40;//这些参数是不可少的，当然也可以不声明，直接将值赋值给对应的函数，这里只是生明变量将其存起来而已
        public static readonly IntPtr HFILE_ERROR = new IntPtr(-1);

                                    

        /// <summary>
        /// 判断文件是否被占用
        /// </summary>
        /// <param name="path"></param>
        /// <returns></returns>
        public static int IsFileOpen(string path)
        {
            string vFileName = path;
            if (!File.Exists(vFileName))
            {
                return 0;//文件不存在
            }
            IntPtr vHandle = _lopen(vFileName, OF_READWRITE | OF_SHARE_DENY_NONE);//windows Api上面有定义扩展方法
            if (vHandle == HFILE_ERROR)
            {
                return 2;//文件被占用  
            }
            CloseHandle(vHandle);//windows Api上面有定义扩展方法
            return 1;//文件存在且没被占用  
        }

        /// <summary>
        /// 杀掉所有EXCEL进程
        /// </summary>
        /// <returns></returns>
        public static void KillExcelProcess()
        {
            System.Diagnostics.Process[] pProcesses = null;

            try
            {
                pProcesses = System.Diagnostics.Process.GetProcesses();

                foreach (System.Diagnostics.Process p in pProcesses)
                {
                    if (string.Equals(p.ProcessName.ToString(), "EXCEL"))
                    {

                        p.Kill();
                        p.Dispose();
                    }
                }
            }
            catch (Exception e)
            {
                throw e;
            }


        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }

}