﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.IO;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using SPC.BLL;
using SPC.Model;
using System.Data;
using System.Collections;
using System.IO;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using SPC.BLL;
using SPC.Model;
using System.Data;
using System.Collections;


namespace SPC.UI
{
    /// <summary>
    /// Summary description for ViewTemplate1
    /// </summary>
    public class ViewTemplate1 : IHttpHandler
    {
        public void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "text/json";
            if (context.Request.HttpMethod == "POST")
            {
                context.Response.ContentType = "text/json";               
                string action = context.Request["action"];
                SpcPartTemplateBLL bll = new BLL.SpcPartTemplateBLL();
                string jsonstr = "";
                if (action == "searchRecords")
                {
                    #region searchRecords
                    int pageSize = int.Parse(context.Request["rows"] ?? "10");
                    int pageIndex = int.Parse(context.Request["page"] ?? "1");
                    string part_num = context.Request["part_num"].ToString().Trim();
                    string templateType = context.Request["templateType"].ToString().Trim();
                    int total = 0;
                    if (part_num == "")
                    {
                        jsonstr = "{\"total\":0,\"rows\":null}";
                        context.Response.Write(jsonstr);
                    }
                    else
                    {
                        List<SCADA_create_template> records = bll.GetEntityList(part_num,templateType, pageSize, pageIndex, out total);
                        Dictionary<string, Object> dict = new Dictionary<string, Object>();
                        var data = new { total = total, rows = records };
                        JavaScriptSerializer js = new System.Web.Script.Serialization.JavaScriptSerializer();
                        jsonstr = js.Serialize(data);
                        context.Response.Write(jsonstr);
                    } 
                    #endregion                    
                }
                else if (action == "update")
                {
                    #region update
                    string jsondata = context.Request["data"];
                    JavaScriptSerializer js = new System.Web.Script.Serialization.JavaScriptSerializer();
                    List<dynamic> lists = new JavaScriptSerializer().Deserialize<List<dynamic>>(jsondata);
                    if (bll.UpdateRecord(lists) == -1)
                    {
                        context.Response.Write("{\"status\":\"ok\"}");
                    }
                    else
                    {
                        context.Response.Write("{\"status\":\"no\"}");
                    } 
                    #endregion
                }
                else if (action=="delete")
                {
                    #region delete
                    string jsondata = context.Request["data"];
                    JavaScriptSerializer js = new System.Web.Script.Serialization.JavaScriptSerializer();
                    List<dynamic> lists = new JavaScriptSerializer().Deserialize<List<dynamic>>(jsondata);
                    if (bll.DeleteRecords(lists) == -1)
                    {
                        context.Response.Write("{\"status\":\"ok\"}");
                    }
                    else
                    {
                        context.Response.Write("{\"status\":\"no\"}");
                    } 
                    #endregion 
                }
                
               
                      
            }
        }
        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}