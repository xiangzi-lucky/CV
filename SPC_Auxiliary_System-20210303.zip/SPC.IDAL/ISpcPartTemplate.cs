﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using SPC.Model;
using System.Web;

namespace SPC.IDAL
{
    /// <summary>
    /// 定义接口
    /// </summary>
    public interface ISpcPartTemplate
    {
        List<SCADA_create_template> GetEntityList(string part_no,string templateType, int pageSize, int pageIndex, out int totalnum);
        List<SCADA_register_equipment> GetEquipmentList(string equipment_code, int pageSize, int pageIndex, out int totalnum, string Inquiry_Mode);
        void LoadEntity(DataRow dr, SCADA_create_template spc_part_template);
        int InsertData(List<SCADA_create_template> list);
        int InsertEquipmentData(List<SCADA_register_equipment> list);
        string GetPartDesc(string name);
        double GetTemplateRev(string part_num, string part_rev, string templateType);
        string checkbadge(string badge);
        string GetChineseName(string badge);
        DataTable GetMachineType();
        DataTable GetFixtureNo(string part_num, string part_rev);
        DataTable GetExistTemplate_PartRev_ByType(string part_num, string templateType);
        DataTable GetIPNA(string part_num, string part_rev);
        DataTable GetShipmentList(string part_num, string part_rev, string plant);
        int UpdateRecord(List<dynamic> lists);
        int DeleteRecords(List<dynamic> lists);
        DataTable GetQCicon(string part_num, string part_rev, string type);
        DataTable GetDataTable(string part_num, string part_rev, string LinkTotemplateType, params string[] pms);
        int UpdateEquipment(List<dynamic> lists);
        int DeleteEquipment(List<dynamic> lists);
        void setConnectString(string site);//Add by YZT 20191017

    }

}
