﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SPC.DAL;
namespace SPC.Factory
{
    /// <summary>
    /// 创建工厂模式(工厂类)用来创建对象
    /// </summary>
    public class FactoryClass
    {
        /// <summary>
        /// 返回对象SPC.DAL.SpcPartTemplateDAL
        /// </summary>
        /// <returns></returns>
        public static SpcPartTemplateDAL spc_part_template_object()
        {
            return new SpcPartTemplateDAL();
        }
    
    }
}
