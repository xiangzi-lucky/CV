﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using SPC.DAL;
using SPC.Model;
using SPC.IDAL;
using SPC.Commen;
using SPC.Factory;
using System.IO;
using System.Web;
using System.Configuration;
using DrawingLibrarySpecifiedAssistant;


namespace SPC.BLL
{
    public class SpcPartTemplateBLL
    {
        ISpcPartTemplate spc_part_template_dal = FactoryClass.spc_part_template_object();//目的使得BLL和DAL解耦合
        public SpcPartTemplateBLL(string site)//Add by YZT 20191017
        {
            spc_part_template_dal.setConnectString(site);
        }
        public List<SCADA_create_template> GetEntityList(string part_no,string templateType, int pageSize, int pageIndex, out int totalnum)
        {
            totalnum = 0;
            return spc_part_template_dal.GetEntityList(part_no, templateType,pageSize, pageIndex, out totalnum);
        }

        /// <summary>
        /// 获得工件描述
        /// </summary>
        /// <param name="part_num"></param>
        /// <returns></returns>
        public string GetPartDesc(string part_num)
        {
            string partDesc = spc_part_template_dal.GetPartDesc(part_num);
            if (string.IsNullOrEmpty(partDesc))
                return string.Empty;
            else
                return partDesc;
            //return spc_part_template_dal.GetPartDesc(part_num);
        }

        /// <summary>
        /// 查询量仪
        /// </summary>
        /// <param name="equipment_code"></param>
        /// <returns></returns>
        public List<SCADA_register_equipment> GetEquipmentList(string equipment_code, int pageSize, int pageIndex, out int totalnum, string Inquiry_Mode)
        {
            totalnum = 0;
            return spc_part_template_dal.GetEquipmentList(equipment_code, pageSize, pageIndex, out totalnum, Inquiry_Mode);
        }

        /// <summary>
        /// 获得模板的最新的版本
        /// </summary>
        /// <param name="part_num"></param>
        /// <param name="part_rev"></param>
        /// <returns></returns>
        public double GetTemplateRev(string part_num, string part_rev, string templateType)
        {
            return spc_part_template_dal.GetTemplateRev(part_num, part_rev, templateType);
        }

        /// <summary>
        /// 获得创建新记录的数据
        /// </summary>
        /// <param name="lists"></param>
        /// <returns></returns>
        public int GetInsertData(List<dynamic> lists)
        {

            List<object> Exception_list = new List<object>();
            List<SCADA_create_template> list_spc_template = new List<SCADA_create_template>();
            int num = 0;
            if (lists.Count > 1)
            {
                double version = GetTemplateRev((string)lists[lists.Count - 1]["Part_num"], (string)lists[lists.Count - 1]["Part_rev"], (string)lists[lists.Count - 1]["Template_type"]);
                for (int i = 1; i < lists.Count; i++)
                {
                    SCADA_create_template template_model = new SCADA_create_template();
                    template_model.Part_num = lists[i]["Part_num"];
                    template_model.Part_rev = lists[i]["Part_rev"];
                    template_model.Badge = lists[i]["Badge"];
                    template_model.Template_type = lists[i]["Template_type"];
                    template_model.Rw_order = lists[i]["Rw_order"];
                    template_model.Rw_seq = lists[i]["Rw_seq"];
                    template_model.Gn_type = lists[i]["Gn_type"];
                    template_model.Sap_rou_workcenter = lists[i]["Sap_rou_workcenter"];
                    template_model.Fixture_pn = lists[i]["Fixture_pn"];
                    template_model.Fixture_array = lists[i]["Fixture_array"];
                    template_model.Tooling_Ipna = lists[i]["Tooling_Ipna"];
                    template_model.Gn_correl_enggdwg = lists[i]["Gn_correl_enggdwg"];
                    template_model.Dwg_label = lists[i]["Dwg_label"];
                    template_model.Dwg_spec = lists[i]["Dwg_spec"];
                    template_model.Upp_tol = lists[i]["Upp_tol"]; ;
                    template_model.Lwr_tol = lists[i]["Lwr_tol"];
                    template_model.Meas_eq = lists[i]["Meas_eq"];
                    template_model.Eq_cal_code = lists[i]["Eq_cal_code"];
                    template_model.Eq_col_pts = lists[i]["Eq_col_pts"];
                    template_model.Sample_plan = lists[i]["Sample_plan"];
                    template_model.Remark = lists[i]["Remark"];
                    template_model.Cdpn_list = lists[i]["Cdpn_list"];
                    template_model.Approved = lists[i]["Approved"];
                    if (lists[0]["updateWay"] =="original")
                    {
                        if (version == 0)
                        {
                            template_model.Template_version ="1";
                        }
                        else
                        {
                            template_model.Template_version = version.ToString();
                        }
                        
                    } else
                    {
                        template_model.Template_version = (version+1).ToString();
                    }
                    list_spc_template.Add(template_model);
                }
               num= spc_part_template_dal.InsertData(list_spc_template);
            }
            return num;

        }

        /// <summary>
        /// 获取量仪数据
        /// </summary>
        /// <param name="lists"></param>
        /// <returns></returns>
        public int GetEquipmentData(List<dynamic> lists)
        {

            List<object> Exception_list = new List<object>();
            List<SCADA_register_equipment> list_equipment_template = new List<SCADA_register_equipment>();
            int num = 0;
            if (lists.Count > 0)
            {
                for (int i = 1; i <= lists.Count; i++)
                {
                    SCADA_register_equipment equipment_model = new SCADA_register_equipment();   //temp_model相当于是每一行，获取一行的数据最后添加到list_spc_template中
                    equipment_model.Equipment_type = lists[0]["equipment_type"];
                    equipment_model.CCL_code = lists[0]["CCL_code"];
                    equipment_model.MFR = lists[0]["MFR"];
                    equipment_model.Equipment_info ="";
                    equipment_model.Com_type = lists[0]["com_type"];
                    equipment_model.Pc_info = lists[0]["pc_info"];
                    equipment_model.Com_port = lists[0]["com_port"];
                    equipment_model.Baud_rate = lists[0]["baud_rate"];
                    equipment_model.Parity_bit = lists[0]["parity_bit"];
                    equipment_model.Data_bit = lists[0]["data_bit"];
                    equipment_model.Stop_bit = lists[0]["stop_bit"];
                    equipment_model.Note = lists[0]["equipment_note"];
                    list_equipment_template.Add(equipment_model);
                }
                num = spc_part_template_dal.InsertEquipmentData(list_equipment_template);
            }
            return num;
        }

        /// <summary>
        /// 检查工件号是否合格
        /// </summary>
        /// <param name="part_num"></param>
        /// <returns></returns>
        public string CheckPartNum(string part_num)
        {
            string status ="";
            if (part_num.Length < 8)  //工件长度不能小于8
            {
                status ="Fail";
            }
            else
            {
                status ="Pass";
            }
            return status;
        }

        /// <summary>
        /// 检查工件号和版本号是否合格
        /// </summary>
        /// <param name="part_num"></param>
        /// <param name="part_rev"></param>
        /// <returns></returns>
        public bool checkPartNumAndPartRev(string part_num, string part_rev)
        {
            bool bool_pass = true;
            algnts16Dwg.DwgProcessMgr GetDrawing = new algnts16Dwg.DwgProcessMgr();
            List<string> DrawingPath = new List<string>();
            try
            {
                object[] Drawing_Path1 = GetDrawing.GetFileFromDrawingLibrary(part_num, part_rev,"DwgCSPDF","misaccess");
                object[] Drawing_Path2 = GetDrawing.GetFileFromDrawingLibrary(part_num, part_rev,"Dwg0212","misaccess");
                object[] Drawing_Path3 = GetDrawing.GetFileFromDrawingLibrary(part_num, part_rev,"DwgPDF","misaccess");
                object[] Drawing_Path4 = GetDrawing.GetFileFromDrawingLibrary(part_num, part_rev,"DwgGNPDF","misaccess");
                DrawingPath = GetPDFPath(DrawingPath, Drawing_Path1);
                DrawingPath = GetPDFPath(DrawingPath, Drawing_Path2);
                DrawingPath = GetPDFPath(DrawingPath, Drawing_Path3);
                DrawingPath = GetPDFPath(DrawingPath, Drawing_Path4);
                if (DrawingPath.Count == 0)
                {
                    bool_pass = false;
                }
            }
            catch { }
            finally { }
            return bool_pass;
        }

        /// <summary>
        /// 连接GN图库继续检查工件号和版本号
        /// </summary>
        /// <param name="part_num"></param>
        /// <param name="part_rev"></param>
        /// <returns></returns>
        public bool connectToGNDrawingLibrary(string part_num, string part_rev, string site)
        {
            //bool bool_pass = true;
            bool bool_pass = false;//Modify by YZT 20191128
            if (ConnectToFileServer(site))
            {
                #region 判断路径是否正确
                string locationFirst ="";
                string locationSecond ="";
                string[] partNoArray = part_num.Split('-');
                string partNoSub = partNoArray[1].Substring(0, 1);
                locationFirst = partNoArray[0] +"-" + partNoSub;
                locationSecond = part_num +"_" + part_rev;

                DirectoryInfo dir;
                if (site =="ATH")
                {
                    dir = new DirectoryInfo(ConfigurationManager.ConnectionStrings["FileServer_ath"].ToString() + @"PMSLib\" + locationFirst + @"\" + locationSecond + @"\");
                }
                else if (site =="AMC")
                {
                    dir = new DirectoryInfo(ConfigurationManager.ConnectionStrings["FileServer_amc"].ToString() + @"PMSLib\" + locationFirst + @"\" + locationSecond + @"\");
                }
                else
                {
                    dir = new DirectoryInfo(ConfigurationManager.ConnectionStrings["FileServer_alg"].ToString() + @"PMSLib\" + locationFirst + @"\" + locationSecond + @"\");
                }
                if (!dir.Exists)
                {
                    bool_pass = false;
                    return bool_pass;
                }
                #endregion

                #region 获得最新PDF文件
                string pdfName ="";
                DateTime pdfCreateTime = DateTime.MinValue;
                string pdfNameTemp;
                DateTime pdfCreateTimeTemp;


                FileInfo[] temp_file = dir.GetFiles(@"*.pdf", SearchOption.AllDirectories);

                foreach (FileInfo fileTemp in temp_file)
                {
                    if (fileTemp.Name.Contains("GN_"))
                    {
                        pdfNameTemp = fileTemp.FullName;
                        pdfCreateTimeTemp = fileTemp.CreationTime;
                        if (pdfCreateTimeTemp > pdfCreateTime)
                        {
                            pdfName = pdfNameTemp;
                            pdfCreateTime = pdfCreateTimeTemp;
                        }
                    }
                }

                if (pdfName !="")
                {
                    bool_pass = true;
                    return bool_pass;
                }
                else
                {
                    bool_pass = false;
                    return bool_pass;
                }
                #endregion
            }
            return bool_pass;
        }


        /// <summary>
        /// 连接文件服务器
        /// </summary>
        /// <param name="site"></param>
        /// <returns></returns>
        public static bool ConnectToFileServer(string site)
        {

            int ErrInfo;
            if (site =="MET_ALG")
            {                            //WNetAddConnection2函数连接到网络资源。该函数可以将本地设备重定向到网络资源
                //ConfigurationSetting.Default.FileServer_alg：对要连接的网络资源进行了定义，后面分别是用于连接的密码和账户名
                ErrInfo = WNetConnection.WNetAddConnection2(ConfigurationManager.ConnectionStrings["FileServer_alg"].ToString(),"", ConfigurationManager.ConnectionStrings["str_Password"].ToString(), ConfigurationManager.ConnectionStrings["strLogonUser_alg"].ToString());
            }
            else if (site =="AMC")
            {
                ErrInfo = WNetConnection.WNetAddConnection2(ConfigurationManager.ConnectionStrings["FileServer_amc"].ToString(),"", ConfigurationManager.ConnectionStrings["str_Password"].ToString(), ConfigurationManager.ConnectionStrings["strLogonUser_amc"].ToString());
            }
            else if (site =="ATH")
            {
                ErrInfo = WNetConnection.WNetAddConnection2(ConfigurationManager.ConnectionStrings["FileServer_ath"].ToString(),"", ConfigurationManager.ConnectionStrings["str_Password"].ToString(), ConfigurationManager.ConnectionStrings["strLogonUser_ath"].ToString());
            }
            else
            {
                ErrInfo = WNetConnection.WNetAddConnection2(ConfigurationManager.ConnectionStrings["FileServer_alg"].ToString(),"", ConfigurationManager.ConnectionStrings["str_Password"].ToString(), ConfigurationManager.ConnectionStrings["strLogonUser_alg"].ToString());
            }

            if (ErrInfo == 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// 获得图纸的路径
        /// </summary>
        /// <param name="list1"></param>
        /// <param name="a"></param>
        /// <returns></returns>
        public List<string> GetPDFPath(List<string> list1, object[] a)
        {
            for (int i = 0; i < a.Length; i++)
            {
                if (a[i].ToString().IndexOf("Error") != -1)
                {
                    break;
                }
                else if (a[i].ToString().IndexOf(@".PDF") != -1)
                {
                    if (Path.GetFileName(a[i].ToString()).IndexOf(@"GN") == -1)
                    {
                        list1.Add(a[i].ToString());
                    }
                }
            }
            return list1;
        }

        /// <summary>
        /// 检查工号是否可用
        /// </summary>
        /// <param name="badge"></param>
        /// <returns></returns>
        public string checkbadge(string badge)
        {
            if (spc_part_template_dal.checkbadge(badge) =="")
            {
                return"工号不存在";
            }
            else
            {
                return"";
            }
        }

        /// <summary>
        /// 通过工卡获得中文名
        /// </summary>
        /// <param name="badge"></param>
        /// <returns></returns>
        public string GetChineseName(string badge)
        {          
            return spc_part_template_dal.GetChineseName(badge);
        }

        /// <summary>
        /// 获得所有机型
        /// </summary>
        /// <returns></returns>
        public Dictionary<string,string> GetMachineType() 
        {
            Dictionary<string, string> dict_mt = new Dictionary<string, string>();
            DataTable dt = spc_part_template_dal.GetMachineType();
            if (dt.Rows.Count>0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    dict_mt[(i + 1).ToString()] = dt.Rows[i]["Prog_Grp_ID"].ToString().Trim();
                }  
            }
            return dict_mt;
        }

        /// <summary>
        /// 获得夹具
        /// </summary>
        /// <param name="part_num"></param>
        /// <param name="part_rev"></param>
        /// <returns></returns>
        public Dictionary<string, string> GetFixtureNo(string part_num,string part_rev)
        {
            Dictionary<string, string> dict_mt = new Dictionary<string, string>();
            DataTable dt = spc_part_template_dal.GetFixtureNo(part_num, part_rev);
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    dict_mt["FIX" +(i + 1).ToString()] = dt.Rows[i]["fixture_no"].ToString().Trim();
                }
            }
            return dict_mt;
        }

        /// <summary>
        /// 获得刀名
        /// </summary>
        /// <param name="part_num"></param>
        /// <param name="part_rev"></param>
        /// <returns></returns>
        public Dictionary<string, string> GetIPNA(string part_num, string part_rev)
        {
            Dictionary<string, string> dict_mt = new Dictionary<string, string>();
            DataTable dt = spc_part_template_dal.GetIPNA(part_num, part_rev);
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    //if (dt.Rows[i]["T_Name"].ToString().Trim().IndexOf("R") != -1)
                    //{
                    //    var str = dt.Rows[i]["T_Name"].ToString().Trim().Substring(0, dt.Rows[i]["T_Name"].ToString().Trim().Length - 1);
                    //    dict_mt["T_Name" + (i + 1).ToString()] = str;
                    //    for (int j = 0; j < dict_mt.Count; j++)
                    //    {
                    //        if (dict_mt["T_Name" + (j + 1).ToString()] == str && j < i)
                    //        {
                    //            dict_mt["T_Name" + (i + 1).ToString()] ="";   //清除重复项
                    //            break;
                    //        }
                    //    }  
                    //}
                    //else
                    //{
                        dict_mt["T_Name" + (i + 1).ToString()] = dt.Rows[i]["T_Name"].ToString().Trim();
                    //}
                }
            }
            ////将值为空的键值对剔除
            //string keyNames="";
            //foreach(string key in dict_mt.Keys)
            //{
            //    if (dict_mt[key] == null || dict_mt[key].ToString() =="")
            //    {
            //         keyNames+=key+",";
            //    }  
            //}
            //string[] str_keyNames = keyNames.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
            //foreach (string key in str_keyNames)
            //{
            //    dict_mt.Remove(key);
            //}
            return dict_mt;
        }

        /// <summary>
        /// 获得SAP标准工艺列表
        /// </summary>
        /// <param name="part_num"></param>
        /// <param name="part_rev"></param>
        /// <param name="plant"></param>
        /// <returns></returns>
        public Dictionary<string, string> GetShipmentList(string part_num, string part_rev, string plant)
        {
            Dictionary<string, string> dict_mt = new Dictionary<string, string>();
            DataTable dt = spc_part_template_dal.GetShipmentList(part_num, part_rev, plant);
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    dict_mt["Shipment" + (i + 1).ToString()] = dt.Rows[i]["Operation"].ToString().Trim() +"_" + dt.Rows[i]["Workcenter"].ToString().Trim();
                }
            }
            Dictionary<string, string> dic1_SortedByKey = dict_mt.OrderBy(o => o.Value).ToDictionary(p => p.Key, o => o.Value);
            return dic1_SortedByKey;
        }

        /// <summary>
        /// 更新
        /// </summary>
        /// <param name="lists"></param>
        /// <returns></returns>
        public int UpdateRecord(List<dynamic> lists)
        {
            return spc_part_template_dal.UpdateRecord(lists);
        }

        /// <summary>
        /// 删除
        /// </summary>
        /// <param name="lists"></param>
        /// <returns></returns>
        public int DeleteRecords(List<dynamic> lists)
        {
            return spc_part_template_dal.DeleteRecords(lists);
        }

        /// <summary>
        /// 获得QC图标
        /// </summary>
        /// <param name="part_num"></param>
        /// <param name="part_rev"></param>
        /// <returns></returns>
        public Dictionary<string, string> GetQCicon(string part_num, string part_rev, string type)
        {
            Dictionary<string, string> dict_mt = new Dictionary<string, string>();
            DataTable dt = spc_part_template_dal.GetQCicon(part_num, part_rev, type);
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    dict_mt["ICON" + (i + 1).ToString()] = dt.Rows[i]["Dwg_label"].ToString().Trim();
                }
            }
            return dict_mt;
        }

        public DataTable GetDataTable(string part_num, string part_rev, string LinkTotemplateType, params string[] pms)
        {
            return spc_part_template_dal.GetDataTable(part_num, part_rev, LinkTotemplateType,pms);
        }

        /// <summary>
        /// 获取返修数据
        /// </summary>
        /// <param name="part_num"></param>
        /// <param name="part_rev"></param>
        /// <param name="LinkTotemplateType"></param>
        /// <param name="pms"></param>
        /// <returns></returns>
        public Dictionary<string, object> GetRw(string part_num, string part_rev, string LinkTotemplateType, params string[] pms)
        {
            DataTable dt = GetDataTable( part_num,part_rev,LinkTotemplateType,pms);
            Dictionary<string, object> dict_record = new Dictionary<string, object>();
            if (dt.Rows.Count>0)
            {
                DataView dataView = dt.DefaultView;
                DataTable Version_dt = dataView.ToTable(true,"template_version");
                //获得所有版本
                Dictionary<string, string> dict_version = new Dictionary<string, string>();
                for (int i = 0; i < Version_dt.Rows.Count; i++)
                {
                    dict_version[(i + 1).ToString()] = Version_dt.Rows[i]["template_version"].ToString().Trim();
                }
                //获得最新的版本
                string lastest_version = Version_dt.Rows[0]["template_version"].ToString().Trim();
                DataRow[] records = dt.Select("template_version='" + lastest_version +"'");
                //获得最新版本记录
                List<SCADA_create_template> lists = new List<SCADA_create_template>();
                for (int i = 0; i < records.Length; i++)
                {
                    SCADA_create_template model = new SCADA_create_template();
                    model.Badge = records[i]["Badge"].ToString();
                    model.Template_type = records[i]["Template_type"].ToString();
                    model.Gn_type = records[i]["Gn_type"].ToString();
                    model.Sap_rou_workcenter = records[i]["Sap_rou_workcenter"].ToString();
                    model.Fixture_pn = records[i]["Fixture_pn"].ToString();
                    model.Fixture_array = records[i]["Fixture_array"].ToString();
                    model.Tooling_Ipna = records[i]["Tooling_Ipna"].ToString();
                    model.Gn_correl_enggdwg = records[i]["Gn_correl_enggdwg"].ToString();
                    model.Dwg_label = records[i]["Dwg_label"].ToString();
                    model.Dwg_spec = records[i]["Dwg_spec"].ToString();
                    model.Upp_tol = records[i]["Upp_tol"].ToString();
                    model.Lwr_tol = records[i]["Lwr_tol"].ToString();
                    model.Meas_eq = records[i]["Meas_eq"].ToString();
                    model.Eq_cal_code = records[i]["Eq_cal_code"].ToString();
                    model.Eq_col_pts = records[i]["Eq_col_pts"].ToString();
                    model.Sample_plan = records[i]["Sample_plan"].ToString();
                    model.Remark = records[i]["Remark"].ToString();
                    model.Cdpn_list = records[i]["Cdpn_list"].ToString();
                    model.Approved = records[i]["Approved"].ToString();
                    lists.Add(model);
                }
                dict_record["status"] = lists;
                dict_record["version_list"] = dict_version;
                dict_record["lastest_version"] = lastest_version;
            }
            else
            {
                dict_record["status"] ="fail";
            }
            return dict_record;
        }

        /// <summary>
        /// 更新量仪
        /// </summary>
        /// <param name="lists"></param>
        /// <returns></returns>
        public int UpdateEquipment(List<dynamic> lists)
        {
            return spc_part_template_dal.UpdateEquipment(lists);
        }

        /// <summary>
        /// 删除量仪
        /// </summary>
        /// <param name="lists"></param>
        /// <returns></returns>
        public int DeleteEquipment(List<dynamic> lists)
        {
            return spc_part_template_dal.DeleteEquipment(lists);
        }

        /// <summary>
        /// 获取存在版本(工件版本)
        /// </summary>
        /// <param name="part_num"></param>
        /// <param name="templateType"></param>
        /// <returns></returns>
        public List<string> existPartVersion(string part_num, string templateType)
        {
            List<string> result=new List<string>();
            DataTable dt = spc_part_template_dal.GetExistTemplate_PartRev_ByType(part_num, templateType);
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                result.Add(dt.Rows[i][0].ToString());
            }
            return result;
        }

    }

}
