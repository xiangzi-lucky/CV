﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SPC.Model;
using SPC.IDAL;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using sgWebServiceCaller;
using System.IO;
using System.Reflection;
using System.Web;
using System.Net;

namespace SPC.DAL
{
    public class SpcPartTemplateDAL : ISpcPartTemplate
    {
        /// <summary>
        /// 厂区
        /// </summary>
        /// Add by YZT 20191017
        private string connectString_Write= ConfigurationManager.ConnectionStrings["algnts133_algcam_write"].ToString();
        private string connectString_Read= ConfigurationManager.ConnectionStrings["algnts133_algcam_read"].ToString();
        public void setConnectString(string site)
        {
            switch (site)
            {
                case "ATH":
                    {
                        connectString_Read = ConfigurationManager.ConnectionStrings["athnts31_athcam_read"].ToString();
                        connectString_Write = ConfigurationManager.ConnectionStrings["athnts31_athcam_write"].ToString();
                    };
                    break;
                case "AMC":
                    {
                        connectString_Read = ConfigurationManager.ConnectionStrings["amcnts113_bepcam_read"].ToString();
                        connectString_Write = ConfigurationManager.ConnectionStrings["amcnts113_bepcam_write"].ToString();
                    };
                    break;
                default:
                    {
                        connectString_Read = ConfigurationManager.ConnectionStrings["algnts133_algcam_read"].ToString();
                        connectString_Write = ConfigurationManager.ConnectionStrings["algnts133_algcam_write"].ToString();
                    };
                    break;
            }
        }
        /// <summary>
        /// 获得表中的数据
        /// </summary>
        /// <returns></returns>
        public List<SCADA_create_template> GetEntityList(string part_num, string templateType, int pageSize, int pageIndex, out int totalnum)
        {
            totalnum = 0;
            SqlHelper.constr = connectString_Write.ToString();
            List<SCADA_create_template> list = null;
            string sql = "";
            //sql += "declare  @pagesize int= " + pageSize + "\r\n";
            //sql += "declare @index int= " + pageIndex + "\r\n";
            //Modify by YZT 20191019 以上定义方法ATHNTS31旧版本的SQL Server不支持，无法通过编译
            sql += "declare  @pagesize int set @pagesize = " + pageSize + "\r\n";
            sql += "declare @index int set @index = " + pageIndex + "\r\n";
            sql += "select * from (select *,rn=row_number() over(order by cast(template_version as int) desc) from SCADA_create_template where part_num='" + part_num + "' and template_type='" + templateType + "') as t " + "\r\n";
            sql += "where t.rn between (@index-1) * @pagesize + 1 and @pagesize * @index ";
            System.Data.DataTable dt = SqlHelper.ExecuteDataTable(sql, CommandType.Text);
            if (dt.Rows.Count > 0)
            {
                list = new List<SCADA_create_template>();
                SCADA_create_template SCADA_create_template = null;
                foreach (DataRow dr in dt.Rows)
                {
                    SCADA_create_template = new SCADA_create_template();
                    LoadEntity(dr, SCADA_create_template);
                    list.Add(SCADA_create_template);
                }
                totalnum = (int)SqlHelper.ExecuteScalar("select count(*) from SCADA_create_template where part_num='" + part_num + "' and template_type='" + templateType + "'", CommandType.Text);
            }
            return list;
        }

        /// <summary>
        /// 加载模板数据
        /// </summary>
        /// <param name="dr"></param>
        /// <param name="SCADA_create_template"></param>
        public void LoadEntity(DataRow dr, SCADA_create_template SCADA_create_template)
        {
            SCADA_create_template.Id = Convert.ToInt32(dr["id"]);
            SCADA_create_template.Rowid = Convert.ToInt32(dr["rn"]);
            SCADA_create_template.Part_num = dr["part_num"] != DBNull.Value ? dr["part_num"].ToString() : string.Empty;
            SCADA_create_template.Part_rev = dr["part_rev"] != DBNull.Value ? dr["part_rev"].ToString() : string.Empty;
            SCADA_create_template.Badge = dr["badge"] != DBNull.Value ? dr["badge"].ToString() : string.Empty;
            SCADA_create_template.Template_type = dr["template_type"] != DBNull.Value ? dr["template_type"].ToString() : string.Empty;
            SCADA_create_template.Rw_order = dr["rw_order"] != DBNull.Value ? dr["rw_order"].ToString() : string.Empty;
            SCADA_create_template.Rw_seq = dr["rw_seq"] != DBNull.Value ? dr["rw_seq"].ToString() : string.Empty;
            SCADA_create_template.Gn_type = dr["gn_type"] != DBNull.Value ? dr["gn_type"].ToString() : string.Empty;
            SCADA_create_template.Sap_rou_workcenter = dr["sap_rou_workcenter"] != DBNull.Value ? dr["sap_rou_workcenter"].ToString() : string.Empty;
            SCADA_create_template.Fixture_pn = dr["fixture_pn"] != DBNull.Value ? dr["fixture_pn"].ToString() : string.Empty;
            SCADA_create_template.Fixture_array = dr["fixture_array"] != DBNull.Value ? dr["fixture_array"].ToString() : string.Empty;
            SCADA_create_template.Tooling_Ipna = dr["tooling_ipna"] != DBNull.Value ? dr["tooling_ipna"].ToString() : string.Empty;
            SCADA_create_template.Gn_correl_enggdwg = dr["gn_correl_enggdwg"] != DBNull.Value ? dr["gn_correl_enggdwg"].ToString() : string.Empty;
            SCADA_create_template.Dwg_label = dr["dwg_label"] != DBNull.Value ? dr["dwg_label"].ToString() : string.Empty;
            SCADA_create_template.Dwg_spec = dr["dwg_spec"] != DBNull.Value ? dr["dwg_spec"].ToString() : string.Empty;
            SCADA_create_template.Upp_tol = dr["upp_tol"] != DBNull.Value ? dr["upp_tol"].ToString() : string.Empty;
            SCADA_create_template.Lwr_tol = dr["lwr_tol"] != DBNull.Value ? dr["lwr_tol"].ToString() : string.Empty;
            SCADA_create_template.Meas_eq = dr["meas_eq"] != DBNull.Value ? dr["meas_eq"].ToString() : string.Empty;
            SCADA_create_template.Eq_cal_code = dr["eq_cal_code"] != DBNull.Value ? dr["eq_cal_code"].ToString() : string.Empty;
            SCADA_create_template.Eq_col_pts = dr["eq_col_pts"] != DBNull.Value ? dr["eq_col_pts"].ToString() : string.Empty;
            SCADA_create_template.Sample_plan = dr["sample_plan"] != DBNull.Value ? dr["sample_plan"].ToString() : string.Empty;
            SCADA_create_template.Remark = dr["remark"] != DBNull.Value ? dr["remark"].ToString() : string.Empty;
            SCADA_create_template.Template_version = dr["template_version"] != DBNull.Value ? dr["template_version"].ToString() : string.Empty;
            SCADA_create_template.Create_date = Convert.ToDateTime(dr["create_date"]);
            SCADA_create_template.Cdpn_list = dr["cdpn_list"] != DBNull.Value ? dr["cdpn_list"].ToString() : string.Empty;
            SCADA_create_template.Approved = dr["approved"] != DBNull.Value ? dr["approved"].ToString() : string.Empty;
        }

        /// <summary>
        /// 查询量仪
        /// </summary>
        /// <returns></returns>
        public List<SCADA_register_equipment> GetEquipmentList(string equipment_code, int pageSize, int pageIndex, out int totalnum, string Inquiry_Mode)
        {
            totalnum = 0;

            SqlHelper.constr = connectString_Write.ToString();
            List<SCADA_register_equipment> list = null;
            string sql = "";
            if (Inquiry_Mode == "CodeNumber")       //以量仪编码进行查询
            {
                //sql += "declare  @pagesize int= " + pageSize + "\r\n";
                //sql += "declare @index int= " + pageIndex + "\r\n";
                //Modify by YZT 20191019 以上定义方法ATHNTS31旧版本的SQL Server不支持，无法通过编译
                sql += "declare  @pagesize int set @pagesize = " + pageSize + "\r\n";
                sql += "declare @index int set @index = " + pageIndex + "\r\n";
                sql += "select * from (select *,rn=row_number() over(order by cast(id as int) desc) from SCADA_register_equipment where CCL_code='" + equipment_code + "') as t " + "\r\n";
                sql += "where t.rn between (@index-1) * @pagesize + 1 and @pagesize * @index ";
            }
            else if (Inquiry_Mode == "PCNumber")    //以PC号进行查询
            {
                //sql += "declare  @pagesize int= " + pageSize + "\r\n";
                //sql += "declare @index int= " + pageIndex + "\r\n";
                //Modify by YZT 20191019 以上定义方法ATHNTS31旧版本的SQL Server不支持，无法通过编译
                sql += "declare  @pagesize int set @pagesize = " + pageSize + "\r\n";
                sql += "declare @index int set @index = " + pageIndex + "\r\n";
                sql += "select * from (select *,rn=row_number() over(order by cast(id as int) desc) from SCADA_register_equipment where pc_info='" + equipment_code + "') as t " + "\r\n";
                sql += "where t.rn between (@index-1) * @pagesize + 1 and @pagesize * @index ";
            }
            else                                    //以生产厂家进行查询
            {
                //sql += "declare  @pagesize int= " + pageSize + "\r\n";
                //sql += "declare @index int= " + pageIndex + "\r\n";
                //Modify by YZT 20191019 以上定义方法ATHNTS31旧版本的SQL Server不支持，无法通过编译
                sql += "declare  @pagesize int set @pagesize = " + pageSize + "\r\n";
                sql += "declare @index int set @index = " + pageIndex + "\r\n";
                sql += "select * from (select *,rn=row_number() over(order by cast(id as int) desc) from SCADA_register_equipment where MFR= N'" + equipment_code + "') as t " + "\r\n";
                sql += "where t.rn between (@index-1) * @pagesize + 1 and @pagesize * @index ";
            }
            System.Data.DataTable dt = SqlHelper.ExecuteDataTable(sql, CommandType.Text);
            if (dt.Rows.Count > 0)
            {
                list = new List<SCADA_register_equipment>();
                SCADA_register_equipment equipment_list = null;
                foreach (DataRow dr in dt.Rows)
                {
                    equipment_list = new SCADA_register_equipment();
                    LoadEquipmentList(dr, equipment_list);
                    list.Add(equipment_list);
                }
                if (Inquiry_Mode == "CodeNumber")
                {
                    totalnum = (int)SqlHelper.ExecuteScalar("select count(*) from SCADA_register_equipment where CCL_code='" + equipment_code + "'", CommandType.Text);
                }
                else if (Inquiry_Mode == "PCNumber")
                {
                    totalnum = (int)SqlHelper.ExecuteScalar("select count(*) from SCADA_register_equipment where pc_info='" + equipment_code + "'", CommandType.Text);
                }
                else
                {
                    totalnum = (int)SqlHelper.ExecuteScalar("select count(*) from SCADA_register_equipment where MFR=N'" + equipment_code + "'", CommandType.Text);
                }
            }
            return list;
        }

        /// <summary>
        /// 加载量仪数据
        /// </summary>
        /// <returns></returns>
        public void LoadEquipmentList(DataRow dr, SCADA_register_equipment equipment_list)  //加载表格数据
        {
            equipment_list.Id = Convert.ToInt32(dr["id"]);
            equipment_list.Rowid = Convert.ToInt32(dr["rn"]);
            equipment_list.Equipment_type = dr["equipment_type"] != DBNull.Value ? dr["equipment_type"].ToString() : string.Empty;
            equipment_list.CCL_code = dr["CCL_code"] != DBNull.Value ? dr["CCL_code"].ToString() : string.Empty;
            equipment_list.MFR = dr["MFR"] != DBNull.Value ? dr["MFR"].ToString() : string.Empty;
            equipment_list.Equipment_info = dr["equipment_info"] != DBNull.Value ? dr["equipment_info"].ToString() : string.Empty;
            equipment_list.Create_date = Convert.ToDateTime(dr["create_date"].ToString());
            equipment_list.Com_type = dr["com_type"] != DBNull.Value ? dr["com_type"].ToString() : string.Empty;
            equipment_list.Pc_info = dr["pc_info"] != DBNull.Value ? dr["pc_info"].ToString() : string.Empty;
            equipment_list.Com_port = dr["com_port"] != DBNull.Value ? dr["com_port"].ToString() : string.Empty;
            equipment_list.Baud_rate = dr["baud_rate"] != DBNull.Value ? dr["baud_rate"].ToString() : string.Empty;
            equipment_list.Parity_bit = dr["parity_bit"] != DBNull.Value ? dr["parity_bit"].ToString() : string.Empty;
            equipment_list.Data_bit = dr["data_bit"] != DBNull.Value ? dr["data_bit"].ToString() : string.Empty;
            equipment_list.Stop_bit = dr["stop_bit"] != DBNull.Value ? dr["stop_bit"].ToString() : string.Empty;
            equipment_list.Note = dr["note"] != DBNull.Value ? dr["note"].ToString() : string.Empty;
        }

        /// <summary>
        /// 插入数据
        /// </summary>
        /// <param name="list"></param>
        /// <returns></returns>
        public int InsertData(List<SCADA_create_template> list)
        {
            SqlHelper.constr = connectString_Write.ToString();
            string sql = "";
            if (list.Count > 0)
            {
                #region sql事务
                sql += "begin " + "\r\n";
                sql += "set NOCOUNT ON;" + "\r\n";
                sql += "set xact_abort on;" + "\r\n";
                sql += "begin tran" + "\r\n";
                for (int i = 0; i < list.Count; i++)
                {
                    sql += "\r\n";
                    sql += "insert into SCADA_create_template (";
                    sql += "part_num,";
                    sql += "part_rev, ";
                    sql += "badge,";
                    sql += "template_type,";
                    sql += "rw_order,";
                    sql += "rw_seq,";
                    sql += "gn_type,";
                    sql += "sap_rou_workcenter,";
                    sql += "fixture_pn,";
                    sql += "fixture_array,";
                    sql += "tooling_ipna,";
                    sql += "gn_correl_enggdwg,";
                    sql += "dwg_label,";
                    sql += "dwg_spec,";
                    sql += "upp_tol,";
                    sql += "lwr_tol,";
                    sql += "meas_eq,";
                    sql += "eq_cal_code,";
                    sql += "eq_col_pts,";
                    sql += "sample_plan,";
                    sql += "remark,";
                    sql += "template_version,";
                    sql += "create_date,";
                    sql += "cdpn_list,";
                    sql += "approved)";
                    sql += "values (";
                    sql += "N'" + list[i].Part_num.ToString().Trim().ToUpper() + "',";
                    sql += "N'" + list[i].Part_rev.ToString().Trim().ToUpper() + "',";
                    sql += "N'" + list[i].Badge + "',";
                    sql += "N'" + list[i].Template_type + "',";
                    sql += "N'" + list[i].Rw_order + "',";
                    sql += "N'" + list[i].Rw_seq + "',";
                    sql += "N'" + list[i].Gn_type + "',";
                    sql += "N'" + list[i].Sap_rou_workcenter + "',";
                    sql += "N'" + list[i].Fixture_pn + "',";
                    sql += "N'" + list[i].Fixture_array + "',";
                    sql += "N'" + list[i].Tooling_Ipna + "',";
                    sql += "N'" + list[i].Gn_correl_enggdwg + "',";
                    sql += "N'" + list[i].Dwg_label + "',";
                    sql += "N'" + list[i].Dwg_spec + "',";
                    sql += "N'" + list[i].Upp_tol + "',";
                    sql += "N'" + list[i].Lwr_tol + "',";
                    sql += "N'" + list[i].Meas_eq + "',";
                    sql += "N'" + list[i].Eq_cal_code + "',";
                    sql += "N'" + list[i].Eq_col_pts + "',";
                    sql += "N'" + list[i].Sample_plan + "',";
                    sql += "N'" + list[i].Remark + "',";
                    sql += "N'" + list[i].Template_version + "',";
                    sql += "getdate(),";
                    sql += "N'" + list[i].Cdpn_list + "',";
                    sql += "N'" + list[i].Approved + "')";
                }
                sql += "\r\n" + "commit tran" + "\r\n";
                sql += "end" + "\r\n";
                #endregion
            }
            return SqlHelper.ExecuteNonQuery(sql, CommandType.Text);
        }

        /// <summary>
        /// 插入量仪
        /// </summary>
        /// <param name="list"></param>
        /// <returns></returns>
        public int InsertEquipmentData(List<SCADA_register_equipment> list)
        {
            SqlHelper.constr = connectString_Write.ToString();
            string sql = "";
            if (list.Count > 0)
            {
                sql += "begin " + "\r\n";
                sql += "set NOCOUNT ON;" + "\r\n";
                sql += "set xact_abort on;" + "\r\n";
                sql += "begin tran" + "\r\n";
                for (int i = 0; i < list.Count; i++)
                {
                    #region 插入SCADA_register_equipment的sql语句
                    sql += "\r\n";
                    sql += "insert into SCADA_register_equipment (";
                    sql += "equipment_type, ";
                    sql += "CCL_code, ";
                    sql += "MFR, ";
                    sql += "equipment_info, ";
                    sql += "create_date, ";
                    sql += "com_type, ";
                    sql += "pc_info, ";
                    sql += "com_port, ";
                    sql += "baud_rate, ";
                    sql += "parity_bit, ";
                    sql += "data_bit, ";
                    sql += "stop_bit, ";
                    sql += "note) ";
                    sql += "values (";
                    sql += "N'" + list[i].Equipment_type.ToString().Trim().ToUpper() + "',";
                    sql += "N'" + list[i].CCL_code + "',";
                    sql += "N'" + list[i].MFR.ToString().Trim() + "',";
                    sql += "N'" + list[i].Equipment_info + "',";
                    sql += "getdate(),";
                    sql += "N'" + list[i].Com_type + "',";
                    sql += "N'" + list[i].Pc_info + "',";
                    sql += "N'" + list[i].Com_port + "',";
                    sql += "N'" + list[i].Baud_rate + "',";
                    sql += "N'" + list[i].Parity_bit + "',";
                    sql += "N'" + list[i].Data_bit + "',";
                    sql += "N'" + list[i].Stop_bit + "',";
                    sql += "N'" + list[i].Note + "')";
                    #endregion
                }
                sql += "\r\n" + "commit tran" + "\r\n";
                sql += "end" + "\r\n";
            }

            return SqlHelper.ExecuteNonQuery(sql, CommandType.Text);

        }

        /// <summary>
        /// 获得工件描述
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        public string GetPartDesc(string name)
        {
            SqlHelper.constr = ConfigurationManager.ConnectionStrings["ALGNTS111_ecm_read"].ToString();
            string sql = "Select descri from part_master where PARTNO=@name";
            return (string)SqlHelper.ExecuteScalar(sql, CommandType.Text, new SqlParameter("@name", name));
        }

        /// <summary>
        /// 获得当前最新的版本
        /// </summary>
        /// <param name="part_num"></param>
        /// <param name="part_rev"></param>
        /// <returns></returns>
        public double GetTemplateRev(string part_num, string part_rev, string templateType)
        {
            SqlHelper.constr = connectString_Write.ToString();
            //string sql = "select top 1 cast(template_version as float) as template_version from SCADA_create_template where part_num=@part_num and part_rev=@part_rev and template_type=@template_type order by template_version desc";
            string sql = "select top 1 cast(template_version as float) as template_version from SCADA_create_template where part_num like @part_num and part_rev like @part_rev and template_type like @template_type order by template_version desc";//Modify by YZT 20191108  改成like，可使用%模糊匹配条件
            object res = SqlHelper.ExecuteScalar(sql, CommandType.Text,
                new SqlParameter("@part_num", part_num),
                new SqlParameter("@part_rev", part_rev),
                new SqlParameter("@template_type", templateType));
            if (res == null)
            {
                return 0;
            }
            else
            {
                return Convert.ToDouble(res);
            }
        }

        /// <summary>
        /// 检查工号
        /// </summary>
        /// <param name="badge"></param>
        /// <returns></returns>
        public string checkbadge(string badge)
        {
            SqlHelper.constr = ConfigurationManager.ConnectionStrings["algnts133_asmuser_read"].ToString();
            string sql = "select badge from [dbo].[Employee] where badge=@badge and status='3'";
            object obj = SqlHelper.ExecuteScalar(sql, CommandType.Text, new SqlParameter("@badge", badge));
            if (obj == null)
            {
                return "";
            }
            else
            {
                return (string)obj;
            }
        }

        /// <summary>
        /// 获得员工姓名
        /// </summary>
        /// <param name="badge"></param>
        /// <returns></returns>
        public string GetChineseName(string badge)
        {
            SqlHelper.constr = ConfigurationManager.ConnectionStrings["algnts133_asmuser_read"].ToString();
            string sql = "select c_name from [dbo].[Employee] where badge=@badge and status='3'";
            object obj = SqlHelper.ExecuteScalar(sql, CommandType.Text, new SqlParameter("@badge", badge));
            if (obj == null)
            {
                return "";
            }
            else
            {
                return (string)obj;
            }
        }

        /// <summary>
        /// 获得所有机型
        /// </summary>
        /// <returns></returns>
        public System.Data.DataTable GetMachineType()
        {
            SqlHelper.constr = connectString_Read.ToString();
            string sql = "select distinct Prog_Grp_ID from cnctype_proggrpid_mapping order by Prog_Grp_ID";
            return SqlHelper.ExecuteDataTable(sql, CommandType.Text);
        }
        /// <summary>
        /// 获取该类型模板的所有版本(工件版本)
        /// </summary>
        /// <param name="part_num"></param>
        /// <param name="templateType"></param>
        /// <returns></returns>
        public System.Data.DataTable GetExistTemplate_PartRev_ByType(string part_num,string templateType)
        {
            SqlHelper.constr = connectString_Read.ToString();
            string sql = "select distinct part_rev from SCADA_create_template where part_num like @part_num and template_type like @templateType order by part_rev desc";
            return SqlHelper.ExecuteDataTable(sql,CommandType.Text,new SqlParameter("@part_num",part_num),new SqlParameter("@templateType",templateType));
        }

        /// <summary>
        /// 获得夹具号
        /// </summary>
        /// <param name="part_num"></param>
        /// <param name="part_rev"></param>
        /// <returns></returns>
        public System.Data.DataTable GetFixtureNo(string part_num, string part_rev)
        {
            SqlHelper.constr = connectString_Read.ToString();
            string sql = "select distinct fixture_no from fms_where_use where part_no=@part_no and rev=@rev order by fixture_no ";
            return SqlHelper.ExecuteDataTable(sql, CommandType.Text, new SqlParameter("@part_no", part_num), new SqlParameter("@rev", part_rev));
        }

        /// <summary>
        /// 获得IPNA
        /// </summary>
        /// <param name="part_num"></param>
        /// <param name="part_rev"></param>
        /// <returns></returns>
        public System.Data.DataTable GetIPNA(string part_num, string part_rev)
        {
            SqlHelper.constr = connectString_Read.ToString();
            string sql = "select distinct T_Name from  [dbo].[CutterList] where Part_Num_Rev='" + part_num + "_" + part_rev + "' order by T_Name";
            return SqlHelper.ExecuteDataTable(sql, CommandType.Text);
        }

        /// <summary>
        /// 获得SAP标准工艺列表
        /// </summary>
        /// <param name="part_num"></param>
        /// <param name="part_rev"></param>
        /// <returns></returns>
        public System.Data.DataTable GetShipmentList(string part_num, string part_rev, string plant)
        {

            string site = "";
            switch (plant)
            {
                case "8700":site = "Met_alg";
                    break;
                case "H100":site = "ATH";
                    break;
                default:site = "AMC";
                    break;
            }
            sgWebServiceCaller.sapOperation sap = new sgWebServiceCaller.sapOperation(site);
            System.Data.DataTable dt1 = sap.getStandardRoutingDetailInfo(part_num, part_rev, plant);
            return dt1;
        }

        /// <summary>
        /// 更新
        /// </summary>
        /// <param name="lists"></param>
        /// <returns></returns>
        public int UpdateRecord(List<dynamic> lists)
        {
            int num = 0;
            if (lists.Count > 0)
            {
                #region sql
                string sql = "";
                sql += "begin " + "\r\n";
                sql += "set NOCOUNT ON;" + "\r\n";
                sql += "set xact_abort on;" + "\r\n";
                sql += "begin tran" + "\r\n";
                for (int i = 0; i < lists.Count; i++)
                {
                    sql += "\r\n";
                    sql += "update SCADA_create_template set ";
                    sql += "badge=N'" + lists[i]["Badge"] + "',";
                    sql += "rw_order=N'" + lists[i]["Rw_order"] + "',";
                    sql += "Rw_seq=N'" + lists[i]["Rw_seq"] + "',";
                    sql += "gn_type =N'" + lists[i]["Gn_type"] + "',";
                    sql += "sap_rou_workcenter =N'" + lists[i]["Sap_rou_workcenter"] + "',";
                    sql += "fixture_pn=N'" + lists[i]["Fixture_pn"] + "',";
                    sql += "fixture_array =N'" + lists[i]["Fixture_array"] + "',";
                    sql += "tooling_Ipna =N'" + lists[i]["Tooling_Ipna"] + "',";
                    sql += "gn_correl_enggdwg =N'" + lists[i]["Gn_correl_enggdwg"] + "',";
                    sql += "dwg_label =N'" + lists[i]["Dwg_label"] + "',";
                    sql += "dwg_spec =N'" + lists[i]["Dwg_spec"] + "',";
                    sql += "upp_tol =N'" + lists[i]["Upp_tol"] + "',";
                    sql += "lwr_tol =N'" + lists[i]["Lwr_tol"] + "',";
                    sql += "meas_eq =N'" + lists[i]["Meas_eq"] + "',";
                    sql += "eq_cal_code =N'" + lists[i]["Eq_cal_code"] + "',";
                    sql += "eq_col_pts =N'" + lists[i]["Eq_col_pts"] + "',";
                    sql += "sample_plan =N'" + lists[i]["Sample_plan"] + "',";
                    sql += "template_version=N'" + lists[i]["Template_version"] + "',";
                    sql += "remark=N'" + lists[i]["Remark"] + "',";
                    sql += "create_date=GETDATE() ";
                    sql += "where ";
                    sql += "part_num='" + lists[i]["Part_num"] + "'";
                    sql += "and part_rev='" + lists[i]["Part_rev"] + "' ";
                    sql += "and template_type ='" + lists[i]["Template_type"] + "' ";
                    sql += "and template_version='" + lists[i]["Template_version"] + "' ";
                    sql += "and id='" + lists[i]["Id"] + "' ";
                }
                sql += "\r\n" + "commit tran" + "\r\n";
                sql += "end" + "\r\n";
                #endregion

                num = SqlHelper.ExecuteNonQuery(sql, CommandType.Text);
            }
            return num;
        }

        /// <summary>
        /// 删除
        /// </summary>
        /// <param name="lists"></param>
        /// <returns></returns>
        public int DeleteRecords(List<dynamic> lists)
        {
            int num = 0;
            if (lists.Count > 0)
            {
                #region sql
                string sql = "";
                sql += "begin " + "\r\n";
                sql += "set NOCOUNT ON;" + "\r\n";
                sql += "set xact_abort on;" + "\r\n";
                sql += "begin tran" + "\r\n";
                for (int i = 0; i < lists.Count; i++)
                {
                    sql += "\r\n";
                    sql += "delete SCADA_create_template ";
                    sql += "where id=N'" + lists[i]["Id"] + "' ";
                    sql += "and part_num=N'" + lists[i]["Part_num"] + "' ";
                    sql += "and part_rev=N'" + lists[i]["Part_rev"] + "' ";
                    sql += "and template_type=N'" + lists[i]["Template_type"] + "' ";
                    sql += "and template_version=N'" + lists[i]["Template_version"] + "' ";
                    sql += "and dwg_spec=N'" + lists[i]["Dwg_spec"] + "' ";
                }
                sql += "\r\n" + "commit tran" + "\r\n";
                sql += "end" + "\r\n";
                #endregion

                num = SqlHelper.ExecuteNonQuery(sql, CommandType.Text);
            }
            return num;
        }

        /// <summary>
        /// 获得QC图标
        /// </summary>
        /// <param name="part_num"></param>
        /// <param name="part_rev"></param>
        /// <returns></returns>
        public System.Data.DataTable GetQCicon(string part_num, string part_rev, string type)
        {
            SqlHelper.constr = connectString_Write.ToString();
            string sql = "select distinct Dwg_label from SCADA_create_template where part_num=@part_num and part_rev=@part_rev and template_type=@type order by drawing_lable ";
            return SqlHelper.ExecuteDataTable(sql, CommandType.Text, new SqlParameter("@part_num", part_num), new SqlParameter("@part_rev", part_rev), new SqlParameter("@type", type));
        }

        /// <summary>
        /// 获取返修数据
        /// </summary>
        /// <param name="part_num"></param>
        /// <param name="part_rev"></param>
        /// <param name="LinkTotemplateType"></param>
        /// <param name="pms"></param>
        /// <returns></returns>
        public System.Data.DataTable GetDataTable(string part_num, string part_rev, string LinkTotemplateType, params string[] pms)
        {
            string sql = "";
            if (pms.Length > 0)
            {
                string version = pms[0];
                if (version == "")
                {
                    sql = "select * from SCADA_create_template where part_num=@part_num and part_rev=@part_rev and template_type=@template_type order by cast(template_version as float) desc";
                }
                else 
                {
                    sql = "select * from SCADA_create_template where part_num=@part_num and part_rev=@part_rev and template_type=@template_type and template_version='" + version + "' order by cast(template_version as float) desc";
                }
                
            }
            else
            {
                sql = "select * from SCADA_create_template where part_num=@part_num and part_rev=@part_rev and template_type=@template_type order by cast(template_version as float) desc";
            }
            SqlHelper.constr = connectString_Write.ToString();


            return SqlHelper.ExecuteDataTable(sql, CommandType.Text,
                new SqlParameter("@part_num", part_num),
                new SqlParameter("@part_rev", part_rev),
                new SqlParameter("@template_type", LinkTotemplateType));
        }

        /// <summary>
        /// 更新量仪
        /// </summary>
        /// <param name="lists"></param>
        /// <returns></returns>
        public int UpdateEquipment(List<dynamic> lists)
        {
            int num = 0;
            if (lists.Count > 0)
            {
                #region sql
                string sql = "";
                sql += "begin " + "\r\n";
                sql += "set NOCOUNT ON;" + "\r\n";
                sql += "set xact_abort on;" + "\r\n";
                sql += "begin tran" + "\r\n";
                for (int i = 0; i < lists.Count; i++)
                {
                    sql += "\r\n";
                    sql += "update SCADA_register_equipment set ";
                    sql += "pc_info=N'" + lists[i]["Pc_info"] + "',";
                    sql += "CCL_code =N'" + lists[i]["CCL_code"] + "',";
                    sql += "com_port=N'" + lists[i]["Com_port"] + "',";
                    sql += "baud_rate=N'" + lists[i]["Baud_rate"] + "',";
                    sql += "parity_bit=N'" + lists[i]["Parity_bit"] + "',";
                    sql += "data_bit=N'" + lists[i]["Data_bit"] + "',";
                    sql += "stop_bit=N'" + lists[i]["Stop_bit"] + "',";
                    sql += "note=N'" + lists[i]["Note"] + "',";
                    sql += "create_date=GETDATE() ";
                    sql += "where ";
                    sql += "equipment_type=N'" + lists[i]["Equipment_type"] + "'";
                    sql += "and CCL_code='" + lists[i]["CCL_code"] + "' ";
                    sql += "and com_type ='" + lists[i]["Com_type"] + "' ";
                    sql += "and id='" + lists[i]["Id"] + "' ";
                }
                sql += "\r\n" + "commit tran" + "\r\n";
                sql += "end" + "\r\n";
                #endregion

                num = SqlHelper.ExecuteNonQuery(sql, CommandType.Text);
            }
            return num;
        }

        /// <summary>
        /// 删除量仪
        /// </summary>
        /// <param name="lists"></param>
        /// <returns></returns>
        public int DeleteEquipment(List<dynamic> lists)
        {
            int num = 0;
            if (lists.Count > 0)
            {
                #region sql
                string sql = "";
                sql += "begin " + "\r\n";
                sql += "set NOCOUNT ON;" + "\r\n";
                sql += "set xact_abort on;" + "\r\n";
                sql += "begin tran" + "\r\n";
                for (int i = 0; i < lists.Count; i++)
                {
                    sql += "\r\n";
                    sql += "delete SCADA_register_equipment ";
                    sql += "where id=N'" + lists[i]["Id"] + "' ";
                    sql += "and equipment_type=N'" + lists[i]["Equipment_type"] + "' ";
                    sql += "and CCL_code =N'" + lists[i]["CCL_code"] + "' ";
                    sql += "and pc_info=N'" + lists[i]["Pc_info"] + "' ";
                    sql += "and com_type=N'" + lists[i]["Com_type"] + "' ";
                }
                sql += "\r\n" + "commit tran" + "\r\n";
                sql += "end" + "\r\n";
                #endregion

                num = SqlHelper.ExecuteNonQuery(sql, CommandType.Text);
            }
            return num;
        }

    }
}


