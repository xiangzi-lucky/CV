﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Web;
using System.Data;
using System.Data.SqlClient;

namespace SPC.DAL
{
    public class SqlHelper
    {
        public static string constr = "";

        /// <summary>
        /// 执行增删改
        /// </summary>
        /// <param name="sql"></param>
        /// <param name="type"></param>
        /// <param name="pms"></param>
        /// <returns></returns>
        public static int ExecuteNonQuery(string sql,CommandType type,params SqlParameter[] pms)
        {
            int num =0;
            using (SqlConnection con =new SqlConnection(constr))
            {
                using (SqlCommand com =new SqlCommand(sql,con))
                {
                    com.CommandType = type;
                    if (pms.Length>0)
                    {
                        com.Parameters.AddRange(pms);
                    }
                    con.Open();
                    try
                    {
                        num = com.ExecuteNonQuery();
                    }
                    catch (Exception ex)
                    {
                        
                    }
                }
            }
            return num;
        }

        /// <summary>
        /// 返回一条数据
        /// </summary>
        /// <param name="sql"></param>
        /// <param name="type"></param>
        /// <param name="pms"></param>
        /// <returns></returns>
        public static object ExecuteScalar(string sql, CommandType type, params SqlParameter[] pms)
        {
            object ob = null;
            using (SqlConnection con = new SqlConnection(constr))
            {
                using (SqlCommand com = new SqlCommand(sql, con))
                {
                    com.CommandType = type;
                    if (pms.Length > 0)
                    {
                        com.Parameters.AddRange(pms);
                    }
                    con.Open();
                    ob = com.ExecuteScalar();
                }
            }
            return ob;
        }

        /// <summary>
        /// 返回多条数据
        /// </summary>
        /// <param name="sql"></param>
        /// <param name="type"></param>
        /// <param name="pms"></param>
        /// <returns></returns>
        public static SqlDataReader ExecuteReader(string sql, CommandType type, params SqlParameter[] pms)
        {
            SqlConnection con = new SqlConnection(constr);
            using (SqlCommand com =new SqlCommand(sql,con))
            {
                com.CommandType = type;
                if (pms.Length>0)
                {
                    com.Parameters.AddRange(pms);
                }
                try
                {
                    con.Open();
                    return com.ExecuteReader(CommandBehavior.CloseConnection);
                }
                catch (Exception)
                {
                    throw;
                }
                finally
                {
                    con.Close();
                    con.Dispose();
                }
                
            }
           
        }

        /// <summary>
        /// 结果以datatable返回
        /// </summary>
        /// <param name="sql"></param>
        /// <param name="type"></param>
        /// <param name="pms"></param>
        /// <returns></returns>
        public static DataTable ExecuteDataTable(string sql, CommandType type, params SqlParameter[] pms)
        {
            DataTable dt = new DataTable();
            using (SqlConnection con =new SqlConnection(constr))
            {
                using (SqlDataAdapter da=new SqlDataAdapter(sql,con))
                {
                    da.SelectCommand.CommandType = type;
                    if (pms.Length>0)
                    {
                        da.SelectCommand.Parameters.AddRange(pms);
                    }
                    da.Fill(dt);
                }
            }
            return dt;
        }
    }
}
