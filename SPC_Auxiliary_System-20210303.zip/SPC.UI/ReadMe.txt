﻿程序说明文档：

1.本网页的使用说明：工厂（WS）、QC、外协等部门通过使用该网页，可制作SCADA测量模板，也可绑定量仪（CCL ID），二者均辅助SCADA数据采集监控系统使用。

2.逻辑：

	2.1 创建模板

		2.1.1 输入工件号和版本号，通过调用webservice(http://algnts16/CADWebService/DwgProcessMgr.asmx)中的GetFileFromDrawingLibrary查询图库中是否存在图纸，
		      如果存在图纸，则显示绿色√通过；
		      若不存在，则到文件服务器  \\ALGNTS49.ALGEX.ASMPT.COM\ALGCAM\ 中寻找，若存在则显示绿色√通过，否则显示红色×不通过。
						\\amcnts52.amcex.asmpt.com\STJCAM\
  						\\ATHNTS42.ATHEX.ASMPT.COM\ATHCAM\

		2.1.2 工件号和版本号均正确时，通过表 cnctype_proggrpid_mapping 查询机型
					      通过表 fms_where_use 查询夹具号
					      通过表 CutterList 查询刀名
					      通过调用 sgWebServiceCaller.dll 里的 getStandardRoutingDetailInfo 来查询SAP标准工艺（过程检查表的SAP标准工艺在【机型】下拉列表中显示）

		2.1.3 输入工号，查询该工号是否正确，若存在则显示绿色√通过，否则显示红色×不通过。

		2.1.4 根据需要选择不同的模块创建模板（增加新行 >> 动态增加模板行数）

		2.1.5 动态添加新行部分

			（1）同一工件号版本号下，若已经制作【产品报告表】模板，在【过程检查表】中可以勾选【关联图标】，然后在图标栏位选择需要关联的图标

			（2）【图纸规格】栏位，形位公差可以实现自动填充上下公差，图纸规格填写完毕后勾选【13级公差】，未填写上下公差的尺寸会自动按13级公差填写

			（3）【量仪】栏位，不同的量仪对应不同的特别设定，此处的设定将会使用在SCADA数据采集监控系统中，如不同的测量点数，不同的测量方法等；

		2.1.6 第一次创建模板时，默认版本为1版，此后点击【创建模板】，则默认向1版内继续添加新的模板。而勾选【更新/修改】选项后，系统会自动生成现有最新模板版本，放置在对应的模块中。
		      之后点击【更新模板】，系统会将修改后的模板升版保存。如原1版会被保存为2版，且原1版继续保留。

		2.1.7 需要创建一次性模板（即返修模版）时，需要依次填写【工件号】、【版本号】、【工号】，然后勾选【返修】，选择返修模板的类型，即可在【一次性模板】模块生成。

		2.1.8 关于导出Excel文件

			（1）【过程检查表】，【产品报告表】以及【EM-IQC】模块中，若制作的模板含有CMM/IM量仪时，将会在提示“创建成功”后，询问是否需要导出Excel文件，CMM一次会导出两个不同的Excel，IM仅会导出一个Excel

			（2）【EM-SBC】模块会依据供应商代码来导出Excel，与选择何种量仪无关

			（3）Excel文件导出地址：\\Algex.asmpt.com\algfas\FileArchive\Quality\TRMS\Fab\Equipment_Report
						\\Algex.asmpt.com\algfas\FileArchive\Quality\TRMS\Fab\TRMS_Template\EM-SBC

			（4）Excel文件导出地址（文件存放地址）各厂区不同：//Add by YZT 20191017
						ALG(\\Algex.asmpt.com\algfas\FileArchive\Quality\TRMS\Fab\);	ATH(\\athex\ATHFS\ATHProj\QWHshare\TRMS\Fab\);AMC()

	2.2 查询模板

		2.2.1 以工件号和模板类型为条件，可搜索已经制作并保存在数据库中的模板。

		2.2.2 查询模板页面支持修改、删除现有模板

	2.3 绑定量仪

		2.3.1 将刻有某串固定编码的量仪与某台PC进行绑定后，在SCADA数据采集监控系统中，若在该PC上使用已绑定的量仪，则应该拒绝用户手动输入测量结果，必须采纳绑定的量仪的测量结果

		2.3.2 仅RS232量仪需要填写串口相关信息，绑定成功后SCADA数据采集监控系统便可直接调用串口信息，开启串口，便于用户的使用

	2.4 查询量仪
	
		2.4.1 支持通过【量仪编码】、【绑定PC】、【生产厂家】三个不同的条件来进行搜索

		2.4.2 查询量仪页面同样支持修改、删除已绑定量仪













