﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.IO;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using SPC.BLL;
using SPC.Model;
using System.Data;
using System.Collections;
using System.Runtime.Serialization.Json;

namespace SPC.UI
{
    /// <summary>
    /// 查询量仪
    /// </summary>
    public class View_equipment : IHttpHandler
    {
        public void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "text/json";
            if (context.Request.HttpMethod == "POST")
            {
                context.Response.ContentType = "text/json";
                string action = context.Request["action"];
                //Modify by YZT 20191024
                SpcPartTemplateBLL bll = new BLL.SpcPartTemplateBLL(PublicFunctions.switchSiteByIP(context.Request.UserHostName.Trim()));
                lock (bll)  //Add by YZT 20191024   防止多用户乱串
                {
                    string jsonstr = "";
                    if (action == "searchRecords")
                    {
                        #region searchRecords
                        int pageSize = int.Parse(context.Request["rows"] ?? "10");
                        int pageIndex = int.Parse(context.Request["page"] ?? "1");
                        string Equipment_code = context.Request["Equipment_code"].ToString().Trim();
                        string Inquiry_Mode = context.Request["mode"].ToString().Trim();
                        int total = 0;
                        if (Equipment_code == "")
                        {
                            jsonstr = "{\"total\":0,\"rows\":null}";
                            context.Response.Write(jsonstr);
                        }
                        else
                        {
                            List<SCADA_register_equipment> records = bll.GetEquipmentList(Equipment_code, pageSize, pageIndex, out total, Inquiry_Mode);
                            Dictionary<string, Object> dict = new Dictionary<string, Object>();
                            var data = new { total = total, rows = records };
                            JavaScriptSerializer js = new System.Web.Script.Serialization.JavaScriptSerializer();
                            jsonstr = js.Serialize(data);
                            context.Response.Write(jsonstr);


                        }
                        #endregion
                    }
                    else if (action == "update")
                    {
                        #region update
                        string jsondata = context.Request["data"];
                        JavaScriptSerializer js = new System.Web.Script.Serialization.JavaScriptSerializer();
                        List<dynamic> lists = new JavaScriptSerializer().Deserialize<List<dynamic>>(jsondata);
                        if (bll.UpdateEquipment(lists) == -1)
                        {
                            context.Response.Write("{\"status\":\"ok\"}");
                        }
                        else
                        {
                            context.Response.Write("{\"status\":\"no\"}");
                        }
                        #endregion
                    }
                    else if (action == "delete")
                    {
                        #region delete
                        string jsondata = context.Request["data"];
                        JavaScriptSerializer js = new System.Web.Script.Serialization.JavaScriptSerializer();
                        List<dynamic> lists = new JavaScriptSerializer().Deserialize<List<dynamic>>(jsondata);
                        if (bll.DeleteEquipment(lists) == -1)
                        {
                            context.Response.Write("{\"status\":\"ok\"}");
                        }
                        else
                        {
                            context.Response.Write("{\"status\":\"no\"}");
                        }
                        #endregion
                    }
                };
            }
        }
        public bool IsReusable
        {
            get
            {
                return false;
            }
        }

        public object match { get; set; }
    }
}