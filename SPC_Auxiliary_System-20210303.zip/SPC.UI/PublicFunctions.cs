﻿using System.Configuration;

namespace SPC.UI
{
    public class PublicFunctions
    {
        //public static void setConnectString()
        //{
        //    switch (PublicVariables.userSite)
        //    {
        //        case "AMC":
        //            {
        //                PublicVariables.fileStore = ConfigurationManager.ConnectionStrings["fileStore_AMC"].ToString();
        //                PublicVariables.cam_Write = ConfigurationManager.ConnectionStrings["amcnts113_bepcam_write"].ToString();
        //                PublicVariables.cam_Read = ConfigurationManager.ConnectionStrings["amcnts113_bepcam_read"].ToString();
        //            };
        //            break;
        //        case "ATH":
        //            {
        //                PublicVariables.fileStore = ConfigurationManager.ConnectionStrings["fileStore_ATH"].ToString();
        //                PublicVariables.cam_Write = ConfigurationManager.ConnectionStrings["athnts31_athcam_write"].ToString();
        //                PublicVariables.cam_Read = ConfigurationManager.ConnectionStrings["athnts31_athcam_read"].ToString();
        //            };
        //            break;
        //        default:
        //            {
        //                PublicVariables.fileStore = ConfigurationManager.ConnectionStrings["fileStore_ALG"].ToString();
        //                PublicVariables.cam_Write = ConfigurationManager.ConnectionStrings["algnts133_algcam_write"].ToString();
        //                PublicVariables.cam_Read = ConfigurationManager.ConnectionStrings["algnts133_algcam_read"].ToString();
        //            };
        //            break;
        //    }
        //}
        public static string switchSiteByIP(string IP)
        {
            if (IP.Length > 5)
            {
                IP = IP.Remove(5);
                if (ConfigurationManager.ConnectionStrings["IPStyle_alg"].ToString().IndexOf(IP) >= 0)
                    return "ALG";
                else if (ConfigurationManager.ConnectionStrings["IPStyle_amc"].ToString().IndexOf(IP) >= 0)
                    return "AMC";
                else if (ConfigurationManager.ConnectionStrings["IPStyle_ath"].ToString().IndexOf(IP) >= 0)
                    return "ATH";
                else
                    return "";
            }
            else if (IP=="::1")
            {
                return "ALG";
            }
            else
            {
                return "";
            }
        }
        public static string getFileStorePath(string site)
        {
            string result = "";

            switch (site)
            {
                case "AMC":
                        result = ConfigurationManager.ConnectionStrings["fileStore_AMC"].ToString();
                    break;
                case "ATH":
                        result = ConfigurationManager.ConnectionStrings["fileStore_ATH"].ToString();
                    break;
                default:
                        result = ConfigurationManager.ConnectionStrings["fileStore_ALG"].ToString();
                    break;
            }

            return result;
        }
        public static string getBackupPathAccount()//获取备份路径登陆用户
        {
            return ConfigurationManager.ConnectionStrings["FileStoreUserAccount"].ToString();
        }
        public static string getBackupPathPassword()//获取备份路径登陆密码
        {
            return ConfigurationManager.ConnectionStrings["FileStoreUserPassword"].ToString();
        }
    }
}