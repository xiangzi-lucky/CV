//$("#input_changeLanguage").val() == "2" 时为英文状态，$("#input_changeLanguage").val() == "1" 时为中文状态

$(function () {

    $('#add_rework_column').hide();                  //页面加载时返修列为隐藏状态
    AddRow("btn_add_IM-WS", "IM-WS_table", "IM-WS"); //IM-WS动态添加行
    AddRow("btn_add_IM-QC", "IM-QC_table", "IM-QC"); //IM-QC动态添加行
    AddRow("btn_add_EM-SBC", "EM-SBC_table", "EM-SBC"); //EM-SBC动态添加行
    AddRow("btn_add_EM-QC", "EM-QC_table", "EM-QC"); //EM-QC动态添加行
    BindEventWhenLoadingPage();                      //页面加载时绑定事件

});

//页面加载时所需绑定事件
function BindEventWhenLoadingPage() {

    //获得WS参数（机型，夹具和Tooling_Ipna）
    Get_WS_Parameter("IM-WS");
    Get_WS_Parameter("EM-SBC");

    //自动替换工序
    ProcessReplacement("IM-WS");
    ProcessReplacement("EM-SBC");

    //获得QC参数(出货要求和量仪)
    Get_QC_Parameter("IM-QC");
    Get_QC_Parameter("EM-QC");
    Get_QC_Parameter("EM-SBC");

    //创建模板(按钮绑定事件)
    creat_template("#btn_IM-WS", "IM-WS_table", "IM-WS");
    creat_template("#btn_IM-QC", "IM-QC_table", "IM-QC");
    creat_template("#btn_EM-SBC", "EM-SBC_table", "EM-SBC");
    creat_template("#btn_EM-QC", "EM-QC_table", "EM-QC");
    //更新模板(即升版)
    creat_template("#btn_update_IM-WS", "IM-WS_table", "IM-WS");
    creat_template("#btn_update_IM-QC", "IM-QC_table", "IM-QC");
    creat_template("#btn_update_EM-SBC", "EM-SBC_table", "EM-SBC");
    creat_template("#btn_update_EM-QC", "EM-QC_table", "EM-QC");

    //绑定工件号失去焦点事件
    $("#div_part_num").on("blur", "#part_num", function () {
        toUpperCase(this);
        if ($("#part_rev").val() == "") {
            if ($("#part_num").val() == "") {
                $("#span_part_num").html("<span class='glyphicon glyphicon-remove' style='color:red'></span>");
                $("#part_num").val('');
                $('#Ul_fixture_pn_IM-WS').html('');
            }
            else {
                CheckPartNum($('#part_num').val()); //判断工件号是否符合条件
            };
        }
        else {
            checkPartNumAndPartRev($("#part_num").val(), $("#part_rev").val());
        }
    });

    //绑定版本号失去焦点事件
    $("#div_part_rev").on("blur", "#part_rev", function () {
        toUpperCase(this);
        var reg_part_rev = /^[A-Za-z]\d*/;
        if (reg_part_rev.test($("#part_rev").val())) {
            $('#Ul_fixture_pn_IM-WS').html('');
            $('#ul_SAP_rou_workcenter_IM-QC').html('');
            $('#ul_SAP_rou_workcenter_EM-QC').html('');
            if ($("#part_num").val() != "") {
                checkPartNumAndPartRev($("#part_num").val(), $("#part_rev").val());
            }
            else {
                $("#span_part_rev").html("<span class='glyphicon glyphicon-ok' style='color:green'></span>");
            }
        }
        else {
            $("#span_part_rev").html("<span class='glyphicon glyphicon-remove' style='color:red'></span>");
            $("#part_rev").val('');
            $('#Ul_fixture_pn_IM-WS').html('');
            $('#ul_SAP_rou_workcenter_IM-QC').html('');
            $('#ul_SAP_rou_workcenter_EM-QC').html('');
        }
    });

    //绑定工号失去焦点事件
    $("#div_mk_badge").on("blur", "#mk_badge", function () {
        var reg_badge = /^[ ]*\d{8}[ ]*$/;
        if (reg_badge.test($('#mk_badge').val())) {
            checkbadge($('#mk_badge').val());
        }
        else {
            $("#span_mk_badge").html("<span class='glyphicon glyphicon-remove' style='color:red'></span>");
            $("#mk_badge").val('');
        }
    });

    //返修按钮的消失动画
    $("#div_checkbox_rw").on("click", "#checkbox_rw", function () {
        $('#rw_order').val('');
        $('#Rw_seq').val('');
        if ($('#checkbox_rw').is(':checked')) {
            if ($('#part_num').val() != "" && $('#part_rev').val() != "" && $('#mk_badge').val() != "") {
                windowForRw();
                $('#add_rework_column').stop().fadeIn();
                $('#rw_order').focus();
            }
            else {
                $('#checkbox_rw').attr('checked', false);
                $('#add_rework_column').stop().fadeOut();
                if ($("#input_changeLanguage").val() == "2") {
                    AlertWindow("The workpiece number, version number, or work number cannot be empty!");
                }
                else {
                    AlertWindow("工件号，版本号，或者工号不能为空");
                }
            }
        }
        else {
            $('#add_rework_column').stop().fadeOut();
            $('#template_rw').html('');
            $('#ul_RW_version').html('');
        }
    });

    //选择返修的版本
    $('#ul_RW_version').on('click', "li", function () {
        var version = $(this).text();
        $('#template_rw').html('');
        $('#input_RW_version').val(version);
        $.post("CreateTemplate.ashx", JSON.stringify([{
            "function": "CreateRw",
            "part_num": $('#part_num').val(),
            "part_rev": $('#part_rev').val(),
            "LinkTotemplateType": $('#RW_templateType').val().toString(),
            "version": version
        }]),
        function (data) {
            BindEventForRW($('#RW_templateType').val(), data);
        });
    });

    //IM-WS最大夹位栏的数字检查
    $("#div_fixture_array_IM-WS").on('input propertychange', '#fixture_array_IM-WS', function () {
        var check = /^\d\d?$/;
        var str = $('#fixture_array_IM-WS').val();
        if (check.test(str)) { }
        else if (str == "") { }
        else {
            if ($("#input_changeLanguage").val() == "2") {
                AlertWindow("You can only enter integers up to 99!");
            }
            else {
                AlertWindow("您只能输入不超过99的整数！");
            }
            $('#fixture_array_IM-WS').val(null);
        }
    });

    //自动填充所有13级公差
    fillAllTolerance("IM-WS");
    fillAllTolerance("IM-QC");
    fillAllTolerance("RW");
    fillAllTolerance("EM-SBC");
    fillAllTolerance("EM-QC");

    //创建模板/更新模板
    CreateOrUpdate("IM-WS");
    CreateOrUpdate("IM-QC");
    CreateOrUpdate("EM-SBC");
    CreateOrUpdate("EM-QC");

    $("#template_rw").on("click", "#Update_Version_RW", function () {
        if ($('#Update_Version_RW').is(':checked')) {
            $("#btn_update_RW").attr("style", "margin-left:5px");
            $("#btn_RW").attr("style", "display:none;margin-left:5px");
        }
        else {
            $("#btn_RW").attr("style", "margin-left:5px");
            $("#btn_update_RW").attr("style", "display:none;margin-left:5px");
        }
    });
};

//点击更新/修改后自动创建
function CreateOrUpdate(templateType) {
    $("#div_Update_Version_" + templateType).on("click", "#Update_Version_" + templateType, function () {
        //每次点击都会把旧的清空，是不是会更合理？//Modify by YZT 20191109
        clearTemplateForm(templateType)
        if ($('#Update_Version_' + templateType).is(':checked')) {         //勾选更新后，返回待更新模板
            CreateUpdataTemplate("", "", templateType);
            $("#btn_update_" + templateType).removeAttr("style");
            $("#btn_" + templateType).attr("style", "display:none");
        }
        else {
            //$("#btn_" + templateType).removeAttr("style");
            //$("#btn_update_" + templateType).attr("style", "display:none");
            //var rows = $("#" + templateType + "_table").find("tr").length;  //取消勾选后，清空列表
            //for (var i = 0; i < rows; i++) {
            //    if (i > 0) {
            //        $("#" + templateType + "_table").find("tr:eq(1)").remove();
            //    }
            //}
        }
    });
};

//Add by YZT 20191112 清空列表
function clearTemplateForm(templateType) {
    $("#btn_" + templateType).removeAttr("style");
    $("#btn_update_" + templateType).attr("style", "display:none");
    var rows = $("#" + templateType + "_table").find("tr").length;  //取消勾选后，清空列表
    for (var i = 0; i < rows; i++) {
        if (i > 0) {
            $("#" + templateType + "_table").find("tr:eq(1)").remove();
        }
    }
}

//返回待更新模板(原模版)
function CreateUpdataTemplate(part_num, part_rev, templateType) {
    if (part_num == "")
        part_num = $('#part_num').val();
    if (part_rev == "")
        part_rev = $('#part_rev').val();
    $.post(
        "CreateTemplate.ashx",
        JSON.stringify([{
            "function": "CreateRw",
            "part_num": part_num,
            "part_rev": part_rev,
            "LinkTotemplateType": templateType,
            "version": ""
        }]),
        function (data) {
            if (data["status"] == "fail") {
                if ($("#input_changeLanguage").val() == "2") {
                    AlertWindow("Can't find the " + $('#part_num').val() + " template created by " + templateType + ", so updates/modifications are not allowed.");
                }
                else {
                    AlertWindow(templateType + "没有创建" + $('#part_num').val() + "的记录,无法更新/修改。");
                }
                $('#Update_Version_' + templateType).attr('checked', false);
                $("#btn_" + templateType).removeAttr("style");
                $("#btn_update_" + templateType).attr("style", "display:none");
            }
            else {
                BindEventForUpdataTemplate(templateType, data);
            }
        }
    );
};

//更新模板时绑定事件
function BindEventForUpdataTemplate(templateType, data) {
    var str_html = FillUpdataTemplate(templateType, data);
    $('#' + templateType + '_table').append($(str_html));
    var $tl = $('#' + templateType + '_table tr');
    var $index = $tl.length;
    var LimitIsEmpty = false;
    for (var i = 1; i < $index; i++) {
        BindEventWhenCreateNewRow(templateType + '_table', templateType, i + 1);  //创建新行时绑定事件

        if ($("#" + templateType + "_input_upper_limit_" + i).val() == "" || $("#" + templateType + "_input_lower_limit_" + i).val() == "" || $("#" + templateType + "_input_upper_limit_" + i).val() == "+" || $("#" + templateType + "_input_lower_limit_" + i).val() == "-") {
            LimitIsEmpty = true;
        }
    }
    if (LimitIsEmpty == true) {
        AlertWindow("原模版中存在上下公差未填写，请注意填充完整！<br /><br />漏填上下公差可能会引起SCADA数据采集系统报警！");
    }
}

//创建更新模板
function FillUpdataTemplate(templateType, data) {
    str_html = "";
    var Gn_type = data["status"][0]["Gn_type"] == null ? "" : data["status"][0]["Gn_type"];
    var Sap_rou_workcenter = data["status"][0]["Sap_rou_workcenter"] == null ? "" : data["status"][0]["Sap_rou_workcenter"];
    var Fixture_pn = data["status"][0]["Fixture_pn"] == null ? "" : data["status"][0]["Fixture_pn"];
    var Fixture_array = data["status"][0]["Fixture_array"] == null ? "" : data["status"][0]["Fixture_array"];
    var Tooling_Ipna = data["status"][0]["Tooling_Ipna"] == null ? "" : data["status"][0]["Tooling_Ipna"];
    if (templateType == "IM-WS") {
        $('#input_gn_type_IM-WS').val(Gn_type);
        $('#SAP_rou_workcenter_IM-WS').val(Sap_rou_workcenter);
        $('#fixture_pn_IM-WS').val(Fixture_pn);
        $('#fixture_array_IM-WS').val(Fixture_array);
        $('#tooling_ipna_IM-WS').val(Tooling_Ipna);
    }
    else if (templateType == "IM-QC") {
        $('#input_SAP_rou_workcenter_IM-QC').val(Sap_rou_workcenter);
    }
    else if (templateType == "EM-SBC") {
        $("#Supplier_code").val(Gn_type);
    }
    else if (templateType == "EM-QC") {
        $('#input_SAP_rou_workcenter_EM-QC').val(Sap_rou_workcenter);
    }
    str_html += newRowForUpdate(templateType, data);
    return str_html;
};

//更新/修改 >> 创建新行
function newRowForUpdate(templateType, data) {
    var add_tr = ""; //需要动态添加的行
    var str_li = "";
    var arr = new Array();
    var equipment_RawData = loadData("static/equipment.json", "equipment_RawData");//Add by YZT 20191112
    for (var i = 0; i < data["status"].length; i++) {
        if (arr.indexOf(data["status"][i]["Dwg_label"]) < 0) {
            arr.push(data["status"][i]["Dwg_label"]);
        }
    }
    for (var i in arr) {
        str_li += "<li><a href='javascript:void(0)'>" + arr[i] + "</a></li>"
    }
    for (var num in data["status"]) {
        var Template_type = data["status"][num]["Template_type"] == null ? "" : data["status"][num]["Template_type"];
        var Gn_correl_enggdwg = data["status"][num]["Gn_correl_enggdwg"] == null ? "" : data["status"][num]["Gn_correl_enggdwg"];
        var Dwg_label = data["status"][num]["Dwg_label"] == null ? "" : data["status"][num]["Dwg_label"];
        var Dwg_spec = data["status"][num]["Dwg_spec"] == null ? "" : data["status"][num]["Dwg_spec"];
        var Upp_tol = data["status"][num]["Upp_tol"] == null ? "" : data["status"][num]["Upp_tol"];
        var Lwr_tol = data["status"][num]["Lwr_tol"] == null ? "" : data["status"][num]["Lwr_tol"];
        var Meas_eq = data["status"][num]["Meas_eq"] == null ? "" : data["status"][num]["Meas_eq"];
        var Eq_cal_code = data["status"][num]["Eq_cal_code"] == null ? "" : data["status"][num]["Eq_cal_code"];
        var Eq_col_pts = data["status"][num]["Eq_col_pts"] == null ? "" : data["status"][num]["Eq_col_pts"];
        var Check = data["status"][num]["Sample_plan"] == null ? "" : data["status"][num]["Sample_plan"];
        if (Check.indexOf("//") != -1) {
            var serverData = Check.split("//");
            var Check_way = Check == null ? "" : serverData[0];
            var Sample_plan = Check == null ? "" : serverData[1];
        }
        else {
            var Check_way = Check;
            var Sample_plan = "";

        }
        var Remark = data["status"][num]["Remark"] == null ? "" : data["status"][num]["Remark"];

        if ($("#input_changeLanguage").val() == "2") {
            add_tr += "<tr id='" + templateType + "_tr_" + (parseInt(num) + 1).toString() + "' class='active'>";
            //第0列
            add_tr += "<td>" + (parseInt(num) + 1).toString() + "</td>";
            //第1列
            if (templateType == "IM-WS" || templateType == "EM-SBC") {
                add_tr += "<td>";
                if (Gn_correl_enggdwg == "true") {
                    add_tr += "<input name='checkbox_name' id='" + templateType + "_checkbox_link_" + (parseInt(num) + 1).toString() + "' type='checkbox' style='margin-top:15px' checked='checked'>";
                }
                else {
                    add_tr += "<input name='checkbox_name' id='" + templateType + "_checkbox_link_" + (parseInt(num) + 1).toString() + "' type='checkbox' style='margin-top:15px'>";
                }
                add_tr += "</td>";
            }
            else { }
            //第2列
            add_tr += "<td>";
            add_tr += '<div class="input-group" id="' + templateType + '_div_icon_' + (parseInt(num) + 1).toString() + '">';
            if (templateType == "IM-WS" || templateType == "EM-SBC") {
                add_tr += '<div class="input-group-btn">';
                add_tr += ' <button type="button" id="' + templateType + '_btn_icon_' + (parseInt(num) + 1).toString() + '" class="btn button btn-default dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> DrawingLable <span class="caret"></span></button>';
                add_tr += '<ul class="dropdown-menu" id="' + templateType + '_ul_icon_' + (parseInt(num) + 1).toString() + '">';
                add_tr += str_li;
                add_tr += '</ul>';
                add_tr += '</div>';
            }
            else { }
            add_tr += "<input id='" + templateType + "_input_icon_" + (parseInt(num) + 1).toString() + "' type='text' class='form-control'  placeholder='Drawing Lable,like：CD1' value='" + Dwg_label + "' onkeyup='toUpperCase(this)'>";
            add_tr += '</div>';
            add_tr += "</td>";
            //第3列
            add_tr += "<td>";
            add_tr += "<div class='col-sm-9'>";
            add_tr += "<div class='input-group'>";
            add_tr += "<div class='input-group-btn'>";
            add_tr += "<button type='button' id='" + templateType + "_btn_symbol_" + (parseInt(num) + 1).toString() + "' class='btn button btn-default dropdown-toggle' data-toggle='dropdown'>Symbol  <span class='caret'></span></button>";
            add_tr += "<ul id='" + templateType + "_ul_symbol_" + (parseInt(num) + 1).toString() + "' class='dropdown-menu' style='max-height:300px;overflow:auto'>";
            add_tr += loadData('static/symbol.json', 'symbol');
            add_tr += "</ul>";
            add_tr += "</div>";
            //add_tr += "<input id='" + templateType + "_input_symbol_" + (parseInt(num) + 1).toString() + "' type='text' class='form-control' placeholder='Please fill in the drawing Dwg_spec.' value='" + Dwg_spec + "' onkeyup='toUpperCase(this)'>";
            add_tr += "<input id='" + templateType + "_input_symbol_" + (parseInt(num) + 1).toString() + "' type='text' class='form-control' placeholder='Please fill in the drawing Dwg_spec.' value='" + Dwg_spec + "' onBlur='toUpperCase(this)'>"; //By YZT 20191209
            add_tr += "</div>";
            add_tr += "</div>";
            add_tr += "<div class='col-sm-3'>";
            add_tr += "<div class='input-group' style='margin-top: 0px;margin-bottom: 2px;height: 18px;width: 100%;'>";
            add_tr += "<input class='form-control' id='" + templateType + "_input_upper_limit_" + (parseInt(num) + 1).toString() + "' type='text' value='" + Upp_tol + "' style='height:18px;width: 100%' />";
            add_tr += "</div>";
            add_tr += "<div class='input-group' style='margin-top: 0px;margin-bottom: 2px;height: 18px;width: 100%;'>";
            add_tr += '<input class="form-control" id="' + templateType + '_input_lower_limit_' + (parseInt(num) + 1).toString() + '" type="text" value="' + Lwr_tol + '" style="height:18px; width: 100%"/>';
            add_tr += "</div>";
            add_tr += "</div>";
            add_tr += "</td>";
            //第4列
            add_tr += "<td>";
            add_tr += "<div class='col-sm-10'>";
            add_tr += "<div class='input-group'>";
            add_tr += "<div class='input-group-btn'>";
            add_tr += "<button type='button' id='" + templateType + "_btn_equipment_" + (parseInt(num) + 1).toString() + "' class='btn button btn-default dropdown-toggle' data-toggle='dropdown'>Equipment<span class='caret'></span></button>";
            add_tr += "<ul id='" + templateType + "_ul_equipment_" + (parseInt(num) + 1).toString() + "' class='dropdown-menu' style='max-height:300px;overflow:auto'>";
            add_tr += loadData('static/equipment.json', 'equipment');
            add_tr += "</ul>";
            add_tr += "</div>";
            add_tr += "<input id='" + templateType + "_input_equipment_" + (parseInt(num) + 1).toString() + "' type='text' class='form-control' placeholder='Please select the equipment.' value='" + Meas_eq + "'>";
            add_tr += "</div>";
            add_tr += "</div>";
            add_tr += "<div class='col-sm-2'>";
            add_tr += "<div class='input-group'>";
            add_tr += "<button type='button' id='" + templateType + "_btn_equipmentSetting_" + (parseInt(num) + 1).toString() + "' class='btn button btn-default' style='margin-left:-25px'>Setting </button>";
            add_tr += "<input type='text' id='" + templateType + "_generated_code_" + (parseInt(num) + 1).toString() + "' style='display:none' value='" + Eq_cal_code + "' >";     //量仪设置内的合成码
            add_tr += "<input type='text' id='" + templateType + "_repeated_points_" + (parseInt(num) + 1).toString() + "' style='display:none' value='" + Eq_col_pts + "' >";    //量仪设置内的重复测量取点数
            add_tr += "</div>";
            add_tr += "</div>";
            add_tr += "</td>";
            //第5列
            add_tr += "<td>";
            add_tr += "<div class='input-group'>";
            add_tr += "<div class='input-group-btn'>";
            add_tr += "<button type='button' id='" + templateType + "_btn_checkWay_" + (parseInt(num) + 1).toString() + "' class='btn button btn-default dropdown-toggle' data-toggle='dropdown'>" + Check_way + "<span class='caret'></span></button>";
            add_tr += "<ul id='" + templateType + "_ul_checkWay_" + (parseInt(num) + 1).toString() + "' class='dropdown-menu' style='max-height:300px;overflow:auto'>";
            add_tr += loadData('static/checkWay_IM.json', 'checkWay');
            add_tr += "</ul>";
            add_tr += "</div>";
            add_tr += "<input id='" + templateType + "_input_checkWay_" + (parseInt(num) + 1).toString() + "' type='text' class='form-control' style='display:none' value='" + Check_way + "'>";
            if (Sample_plan == "") {
                add_tr += "<input id='" + templateType + "_input_checkNum_" + (parseInt(num) + 1).toString() + "' type='text' class='form-control' readonly='true' placeholder='No need to fill in quantity.' value='" + Sample_plan + "'>";
            }
            else {
                add_tr += "<input id='" + templateType + "_input_checkNum_" + (parseInt(num) + 1).toString() + "' type='text' class='form-control' placeholder='Please fill in the quantity of random inspection.' value='" + Sample_plan + "'>";
            }
            add_tr += "</div>";
            add_tr += "</td>";
            //第6列
            add_tr += "<td><input id='" + templateType + "_input_note_" + (parseInt(num) + 1).toString() + "' type='text' class='form-control' placeholder='Remark' value='" + Remark + "'></td>";
            //第7列
            add_tr += "<td><a id='" + templateType + "_a_delete_" + (parseInt(num) + 1).toString() + "' href='#'>Delete</a></td>";
            add_tr += "</tr>";
        }
        else {
            add_tr += "<tr id='" + templateType + "_tr_" + (parseInt(num) + 1).toString() + "' class='active'>";
            //第0列
            add_tr += "<td>" + (parseInt(num) + 1).toString() + "</td>";
            //第1列
            if (templateType == "IM-WS" || templateType == "EM-SBC") {
                add_tr += "<td>";
                if (Gn_correl_enggdwg == "true") {
                    add_tr += "<input name='checkbox_name' id='" + templateType + "_checkbox_link_" + (parseInt(num) + 1).toString() + "' type='checkbox' style='margin-top:15px' checked='checked'>";
                }
                else {
                    add_tr += "<input name='checkbox_name' id='" + templateType + "_checkbox_link_" + (parseInt(num) + 1).toString() + "' type='checkbox' style='margin-top:15px'>";
                }
                add_tr += "</td>";
            }
            else { }
            //第2列
            add_tr += "<td>";
            add_tr += '<div class="input-group" id="' + templateType + '_div_icon_' + (parseInt(num) + 1).toString() + '">';
            if (templateType == "IM-WS" || templateType == "EM-SBC") {
                add_tr += '<div class="input-group-btn">';
                add_tr += ' <button type="button" id="' + templateType + '_btn_icon_' + (parseInt(num) + 1).toString() + '" class="btn button btn-default dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> 图标 <span class="caret"></span></button>';
                add_tr += '<ul class="dropdown-menu" id="' + templateType + '_ul_icon_' + (parseInt(num) + 1).toString() + '">';
                add_tr += str_li;
                add_tr += '</ul>';
                add_tr += '</div>';
            }
            else { }
            add_tr += "<input id='" + templateType + "_input_icon_" + (parseInt(num) + 1).toString() + "' type='text' class='form-control'  placeholder='图标，例如：CD1' value='" + Dwg_label + "' onkeyup='toUpperCase(this)'>";
            add_tr += '</div>';
            add_tr += "</td>";
            //第3列
            add_tr += "<td>";
            add_tr += "<div class='col-sm-9'>";
            add_tr += "<div class='input-group'>";
            add_tr += "<div class='input-group-btn'>";
            add_tr += "<button type='button' id='" + templateType + "_btn_symbol_" + (parseInt(num) + 1).toString() + "' class='btn button btn-default dropdown-toggle' data-toggle='dropdown'>符号  <span class='caret'></span></button>";
            add_tr += "<ul id='" + templateType + "_ul_symbol_" + (parseInt(num) + 1).toString() + "' class='dropdown-menu' style='max-height:300px;overflow:auto'>";
            add_tr += loadData('static/symbol.json', 'symbol');
            add_tr += "</ul>";
            add_tr += "</div>";
            //add_tr += "<input id='" + templateType + "_input_symbol_" + (parseInt(num) + 1).toString() + "' type='text' class='form-control' placeholder='请填写尺寸信息' value='" + Dwg_spec + "' onkeyup='toUpperCase(this)'>";
            add_tr += "<input id='" + templateType + "_input_symbol_" + (parseInt(num) + 1).toString() + "' type='text' class='form-control' placeholder='请填写尺寸信息' value='" + Dwg_spec + "' onBlur='toUpperCase(this)'>"; //By YZT 20191209
            add_tr += "</div>";
            add_tr += "</div>";
            add_tr += "<div class='col-sm-3'>";
            add_tr += "<div class='input-group' style='margin-top: 0px;margin-bottom: 2px;height: 18px;width: 100%;'>";
            add_tr += "<input class='form-control' id='" + templateType + "_input_upper_limit_" + (parseInt(num) + 1).toString() + "' type='text' value='" + Upp_tol + "' style='height:18px;width: 100%' />";
            add_tr += "</div>";
            add_tr += "<div class='input-group' style='margin-top: 0px;margin-bottom: 2px;height: 18px;width: 100%;'>";
            add_tr += '<input class="form-control" id="' + templateType + '_input_lower_limit_' + (parseInt(num) + 1).toString() + '" type="text" value="' + Lwr_tol + '" style="height:18px; width: 100%"/>';
            add_tr += "</div>";
            add_tr += "</div>";
            add_tr += "</td>";
            //第4列
            add_tr += "<td>";
            add_tr += "<div class='col-sm-10'>";
            add_tr += "<div class='input-group'>";
            add_tr += "<div class='input-group-btn'>";
            add_tr += "<button type='button' id='" + templateType + "_btn_equipment_" + (parseInt(num) + 1).toString() + "' class='btn button btn-default dropdown-toggle' data-toggle='dropdown'>量仪<span class='caret'></span></button>";
            add_tr += "<ul id='" + templateType + "_ul_equipment_" + (parseInt(num) + 1).toString() + "' class='dropdown-menu' style='max-height:300px;overflow:auto'>";
            add_tr += loadData('static/equipment.json', 'equipment');
            add_tr += "</ul>";
            add_tr += "</div>";
            //add_tr += "<input id='" + templateType + "_input_equipment_" + (parseInt(num) + 1).toString() + "' type='text' class='form-control' placeholder='请选择量仪' value='" + Meas_eq + "'>";
            add_tr += "<input id='" + templateType + "_input_equipment_" + (parseInt(num) + 1).toString() + "' type='text' class='form-control' placeholder='请选择量仪' value='" + rawDataMapping(equipment_RawData, "equipment", Meas_eq) + "'>";//Modify by YZT 20191112
            add_tr += "</div>";
            add_tr += "</div>";
            add_tr += "<div class='col-sm-2'>";
            add_tr += "<div class='input-group'>";
            add_tr += "<button type='button' id='" + templateType + "_btn_equipmentSetting_" + (parseInt(num) + 1).toString() + "' class='btn button btn-default' style='margin-left:-25px'>设定 </button>";
            add_tr += "<input type='text' id='" + templateType + "_generated_code_" + (parseInt(num) + 1).toString() + "' style='display:none' value='" + Eq_cal_code + "' >";     //量仪设置内的合成码
            add_tr += "<input type='text' id='" + templateType + "_repeated_points_" + (parseInt(num) + 1).toString() + "' style='display:none' value='" + Eq_col_pts + "' >";    //量仪设置内的重复测量取点数
            add_tr += "</div>";
            add_tr += "</div>";
            add_tr += "</td>";
            //第5列
            add_tr += "<td>";
            add_tr += "<div class='input-group'>";
            add_tr += "<div class='input-group-btn'>";
            add_tr += "<button type='button' id='" + templateType + "_btn_checkWay_" + (parseInt(num) + 1).toString() + "' class='btn button btn-default dropdown-toggle' data-toggle='dropdown'>" + Check_way + "<span class='caret'></span></button>";
            add_tr += "<ul id='" + templateType + "_ul_checkWay_" + (parseInt(num) + 1).toString() + "' class='dropdown-menu' style='max-height:300px;overflow:auto'>";
            add_tr += loadData('static/checkWay_IM.json', 'checkWay');
            add_tr += "</ul>";
            add_tr += "</div>";
            add_tr += "<input id='" + templateType + "_input_checkWay_" + (parseInt(num) + 1).toString() + "' type='text' class='form-control' style='display:none' value='" + Check_way + "'>";
            if (Sample_plan == "") {
                add_tr += "<input id='" + templateType + "_input_checkNum_" + (parseInt(num) + 1).toString() + "' type='text' class='form-control' readonly='true' placeholder='无需填写数量' value='" + Sample_plan + "'>";
            }
            else {
                add_tr += "<input id='" + templateType + "_input_checkNum_" + (parseInt(num) + 1).toString() + "' type='text' class='form-control' placeholder='请填写抽检数量' value='" + Sample_plan + "'>";
            }
            add_tr += "</div>";
            add_tr += "</td>";
            //第6列
            add_tr += "<td><input id='" + templateType + "_input_note_" + (parseInt(num) + 1).toString() + "' type='text' class='form-control' placeholder='备注' value='" + Remark + "'></td>";
            //第7列
            add_tr += "<td><a id='" + templateType + "_a_delete_" + (parseInt(num) + 1).toString() + "' href='#'>删除</a></td>";
            add_tr += "</tr>";
        }
    }
    return add_tr;
};

//获取数据
function GetData(submit_type, button_id, table_id) {
    if ($('#Update_Version_' + submit_type).is(':checked')) {
        var list = [{ "function": "GetInsertData", "updateWay": "update" }];
    }
    else {
        var list = [{ "function": "GetInsertData", "updateWay": "original" }];
    }
    $("#" + button_id).attr({ "disabled": "disabled" }); //设置按钮不可用，防止多次点击
    var $tl = $("#" + table_id + " tr");
    var $index = $tl.length;
    for (var i = 1; i < $index; i++) {
        var data_dict = {};
        data_dict["Part_num"] = $('#part_num').val();
        data_dict["Part_rev"] = $('#part_rev').val();
        data_dict["Badge"] = $('#mk_badge').val();
        data_dict["Template_type"] = submit_type;
        data_dict["Rw_order"] = "";
        data_dict["Rw_seq"] = "";
        data_dict["Gn_type"] = "";
        data_dict["Sap_rou_workcenter"] = "";
        data_dict["Fixture_pn"] = "";
        data_dict["Fixture_array"] = "";
        data_dict["Tooling_Ipna"] = "";
        data_dict["Cdpn_list"] = "";
        data_dict["Approved"] = "";
        data_dict["Gn_correl_enggdwg"] = $tl.eq(i).children("td:eq(1)").find("input").prop('checked').toString();
        data_dict["Dwg_label"] = $tl.eq(i).children("td:eq(2)").find("input").val();
        data_dict["Dwg_spec"] = $tl.eq(i).children("td:eq(3)").find("input:eq(0)").val();
        data_dict["Upp_tol"] = $tl.eq(i).children("td:eq(3)").find("input:eq(1)").val();
        data_dict["Lwr_tol"] = $tl.eq(i).children("td:eq(3)").find("input:eq(2)").val();
        if ($tl.eq(i).children("td:eq(3)").find("input:eq(1)").val() == "+") {
            data_dict["Upp_tol"] = null;
        }
        if ($tl.eq(i).children("td:eq(3)").find("input:eq(2)").val() == "-") {
            data_dict["Lwr_tol"] = null;
        }
        if ($tl.eq(i).children("td:eq(3)").find("input:eq(1)").val() == "+0" || $tl.eq(i).children("td:eq(3)").find("input:eq(1)").val() == "+0.0" || $tl.eq(i).children("td:eq(3)").find("input:eq(1)").val() == "+0.00"
        || $tl.eq(i).children("td:eq(3)").find("input:eq(1)").val() == "-0" || $tl.eq(i).children("td:eq(3)").find("input:eq(1)").val() == "-0.0" || $tl.eq(i).children("td:eq(3)").find("input:eq(1)").val() == "-0.00") {
            data_dict["Upp_tol"] = "0";
        }
        if ($tl.eq(i).children("td:eq(3)").find("input:eq(2)").val() == "+0" || $tl.eq(i).children("td:eq(3)").find("input:eq(2)").val() == "+0.0" || $tl.eq(i).children("td:eq(3)").find("input:eq(2)").val() == "+0.00"
        || $tl.eq(i).children("td:eq(3)").find("input:eq(2)").val() == "-0" || $tl.eq(i).children("td:eq(3)").find("input:eq(2)").val() == "-0.0" || $tl.eq(i).children("td:eq(3)").find("input:eq(2)").val() == "-0.00") {
            data_dict["Lwr_tol"] = "0";
        }
        var equipment_abbreviation = $tl.eq(i).children("td:eq(4)").find("input:eq(0)").val();
        if (equipment_abbreviation == "高度尺(HG)" || equipment_abbreviation == "Height Gauge(HG)") {
            equipment_abbreviation = "HG";
        }
        else if (equipment_abbreviation == "卡尺(VC)" || equipment_abbreviation == "Vernier Caliper(VC)") {
            equipment_abbreviation = "VC";
        }
        else if (equipment_abbreviation == "投影仪(PJ)" || equipment_abbreviation == "Profile Projector(PJ)") {
            equipment_abbreviation = "PJ";
        }
        else if (equipment_abbreviation == "百分表/千分表(DT)" || equipment_abbreviation == "Dial Indicator(DT)") {
            equipment_abbreviation = "DT";
        }
        else if (equipment_abbreviation == "高度计(DI)" || equipment_abbreviation == "Digital Indicator(DI)") {
            equipment_abbreviation = "DI";
        }
        else if (equipment_abbreviation == "内径千分尺(三爪)(HT)" || equipment_abbreviation == "Holtest Meter(HT)") {
            equipment_abbreviation = "HT";
        }
        else if (equipment_abbreviation == "外径百分尺/外径千分尺(UM)" || equipment_abbreviation == "Micrometer(UM)") {
            equipment_abbreviation = "UM";
        }
        else if (equipment_abbreviation == "硬度测量仪(HD)" || equipment_abbreviation == "Hardness Tester(HD)") {
            equipment_abbreviation = "HD";
        }
        else if (equipment_abbreviation == "块规(PS)" || equipment_abbreviation == "Block Gage(PS)") {
            equipment_abbreviation = "PS";
        }
        else if (equipment_abbreviation == "针规/塞规(PG)" || equipment_abbreviation == "Pin Gage(PG)") {
            equipment_abbreviation = "PG";
        }
        else if (equipment_abbreviation == "螺纹规(TG)" || equipment_abbreviation == "Thread Gage(TG)") {
            equipment_abbreviation = "TG";
        }
        else if (equipment_abbreviation == "R规(RR)" || equipment_abbreviation == "Radius Gage(RR)") {
            equipment_abbreviation = "RR";
        }
        else if (equipment_abbreviation == "塞片(SM)" || equipment_abbreviation == "Shim(SM)") {
            equipment_abbreviation = "SM";
        }
        else if (equipment_abbreviation == "电子磅(EB)" || equipment_abbreviation == "Electronic Balance(EB)") {
            equipment_abbreviation = "EB";
        }
        else if (equipment_abbreviation == "三坐标测量仪(CMM)" || equipment_abbreviation == "CMM(CMM)") {
            equipment_abbreviation = "CMM";
        }
        else if (equipment_abbreviation == "影像仪(IM)" || equipment_abbreviation == "Image Measure(IM)") {
            equipment_abbreviation = "IM";
        }
        else if (equipment_abbreviation == "ZYGO(ZYGO)") {
            equipment_abbreviation = "ZYGO";
        }
        else if (equipment_abbreviation == "目测(VI)" || equipment_abbreviation == "Vision Inspection(VI)") {
            equipment_abbreviation = "VI";
        }
        else if (equipment_abbreviation == "显微镜(MS)" || equipment_abbreviation == "Microscope(MS)") {
            equipment_abbreviation = "MS";
        }
        else if (equipment_abbreviation == "直尺/卷尺(RL)" || equipment_abbreviation == "Ruler(RL)") {
            equipment_abbreviation = "RL";
        }
        else if (equipment_abbreviation == "万用表(MT)" || equipment_abbreviation == "Multimeter(MT)") {
            equipment_abbreviation = "MT";
        }
        else if (equipment_abbreviation == "光洁度测量仪(SF)" || equipment_abbreviation == "Surface Roughness(SF)") {
            equipment_abbreviation = "SF";
        }
        else if (equipment_abbreviation == "万能角度尺(UA)" || equipment_abbreviation == "Universal Angle Ruler(UA)") {
            equipment_abbreviation = "UA";
        }
        else if (equipment_abbreviation == "扭力表(TM)" || equipment_abbreviation == "Torque Meter(TM)") {
            equipment_abbreviation = "TM";
        }
        else if (equipment_abbreviation == "推拉力计(PP)" || equipment_abbreviation == "Push Pull Gauge(PP)") {
            equipment_abbreviation = "PP";
        }
        else if (equipment_abbreviation == "自制量具(OT)" || equipment_abbreviation == "Tailor-made Gage(OT)") {
            equipment_abbreviation = "OT";
        }
        else if (equipment_abbreviation == "示波器(2D)" || equipment_abbreviation == "Scope Check(2D)") {
            equipment_abbreviation = "2D";
        }
        else if (equipment_abbreviation == "检具+VC" || equipment_abbreviation == "Gauge+VC") {
            equipment_abbreviation = "Gauge+VC";
        }
        else {
        }
        data_dict["Meas_eq"] = equipment_abbreviation;

        data_dict["Eq_cal_code"] = $tl.eq(i).children("td:eq(4)").find("input:eq(1)").val();
        data_dict["Eq_col_pts"] = $tl.eq(i).children("td:eq(4)").find("input:eq(2)").val();

        if ($tl.eq(i).children("td:eq(5)").find("input:eq(1)").val() == "") {
            data_dict["Sample_plan"] = $tl.eq(i).children("td:eq(5)").find("input:eq(0)").val();
        }
        else {
            data_dict["Sample_plan"] = $tl.eq(i).children("td:eq(5)").find("input:eq(0)").val() + "//" + $tl.eq(i).children("td:eq(5)").find("input:eq(1)").val();//Modify by YZT td:eq(6) ==> td:eq(5) (second eq(5))
        }
        data_dict["Remark"] = $tl.eq(i).children("td:eq(6)").find("input").val();
        if (submit_type == "IM-WS") {
            data_dict["Gn_type"] = $('#input_gn_type_IM-WS').val();
            data_dict["Sap_rou_workcenter"] = $('#SAP_rou_workcenter_IM-WS').val();
            data_dict["Fixture_pn"] = $('#fixture_pn_IM-WS').val();
            data_dict["Fixture_array"] = $('#fixture_array_IM-WS').val();
            data_dict["Tooling_Ipna"] = $('#tooling_ipna_IM-WS').val();
            if ($tl.eq(i).children("td:eq(3)").find("input:eq(1)").val() == "" || $tl.eq(i).children("td:eq(3)").find("input:eq(2)").val() == ""
            || $tl.eq(i).children("td:eq(3)").find("input:eq(1)").val() == "+" || $tl.eq(i).children("td:eq(3)").find("input:eq(2)").val() == "+"
            || $tl.eq(i).children("td:eq(3)").find("input:eq(1)").val() == "-" || $tl.eq(i).children("td:eq(3)").find("input:eq(2)").val() == "-") {
                if ($tl.eq(i).children("td:eq(4)").find("input:eq(0)").val() == "螺纹规(TG)" || $tl.eq(i).children("td:eq(4)").find("input:eq(0)").val() == "目测(VI)"
                || $tl.eq(i).children("td:eq(4)").find("input:eq(0)").val() == "显微镜(MS)" || $tl.eq(i).children("td:eq(4)").find("input:eq(0)").val() == "自制量具(OT)")  //以上几项均无需填写上下公差
                {
                    data_dict["Upp_tol"] = "";
                    data_dict["Lwr_tol"] = "";
                } else {
                    return "Tolerance is empty";
                }
            }
        }
        else if (submit_type == 'IM-QC') {
            data_dict["Sap_rou_workcenter"] = $('#input_SAP_rou_workcenter_IM-QC').val();
            data_dict["Gn_correl_enggdwg"] = "";
            data_dict["Dwg_label"] = $tl.eq(i).children("td:eq(1)").find("input").val();
            data_dict["Dwg_spec"] = $tl.eq(i).children("td:eq(2)").find("input:eq(0)").val();
            data_dict["Upp_tol"] = $tl.eq(i).children("td:eq(2)").find("input:eq(1)").val();
            data_dict["Lwr_tol"] = $tl.eq(i).children("td:eq(2)").find("input:eq(2)").val();
            if ($tl.eq(i).children("td:eq(2)").find("input:eq(1)").val() == "+0" || $tl.eq(i).children("td:eq(2)").find("input:eq(1)").val() == "+0.0" || $tl.eq(i).children("td:eq(2)").find("input:eq(1)").val() == "+0.00"
            || $tl.eq(i).children("td:eq(2)").find("input:eq(1)").val() == "-0" || $tl.eq(i).children("td:eq(2)").find("input:eq(1)").val() == "-0.0" || $tl.eq(i).children("td:eq(2)").find("input:eq(1)").val() == "-0.00") {
                data_dict["Upp_tol"] = "0";
            }
            if ($tl.eq(i).children("td:eq(2)").find("input:eq(2)").val() == "+0" || $tl.eq(i).children("td:eq(2)").find("input:eq(2)").val() == "+0.0" || $tl.eq(i).children("td:eq(2)").find("input:eq(2)").val() == "+0.00"
            || $tl.eq(i).children("td:eq(2)").find("input:eq(2)").val() == "-0" || $tl.eq(i).children("td:eq(2)").find("input:eq(2)").val() == "-0.0" || $tl.eq(i).children("td:eq(2)").find("input:eq(2)").val() == "-0.00") {
                data_dict["Lwr_tol"] = "0";
            }

            if ($tl.eq(i).children("td:eq(2)").find("input:eq(1)").val() == "" || $tl.eq(i).children("td:eq(2)").find("input:eq(2)").val() == ""
            || $tl.eq(i).children("td:eq(2)").find("input:eq(1)").val() == "+" || $tl.eq(i).children("td:eq(2)").find("input:eq(2)").val() == "+"
            || $tl.eq(i).children("td:eq(2)").find("input:eq(1)").val() == "-" || $tl.eq(i).children("td:eq(2)").find("input:eq(2)").val() == "-") {
                if ($tl.eq(i).children("td:eq(3)").find("input:eq(0)").val() == "螺纹规(TG)" || $tl.eq(i).children("td:eq(3)").find("input:eq(0)").val() == "目测(VI)"
                || $tl.eq(i).children("td:eq(3)").find("input:eq(0)").val() == "显微镜(MS)" || $tl.eq(i).children("td:eq(3)").find("input:eq(0)").val() == "自制量具(OT)") {
                    data_dict["Upp_tol"] = "";
                    data_dict["Lwr_tol"] = "";
                } else {
                    return "Tolerance is empty";
                }
            }
            equipment_abbreviation = $tl.eq(i).children("td:eq(3)").find("input:eq(0)").val();
            if (equipment_abbreviation == "高度尺(HG)" || equipment_abbreviation == "Height Gauge(HG)") {
                equipment_abbreviation = "HG";
            }
            else if (equipment_abbreviation == "卡尺(VC)" || equipment_abbreviation == "Vernier Caliper(VC)") {
                equipment_abbreviation = "VC";
            }
            else if (equipment_abbreviation == "投影仪(PJ)" || equipment_abbreviation == "Profile Projector(PJ)") {
                equipment_abbreviation = "PJ";
            }
            else if (equipment_abbreviation == "百分表/千分表(DT)" || equipment_abbreviation == "Dial Indicator(DT)") {
                equipment_abbreviation = "DT";
            }
            else if (equipment_abbreviation == "高度计(DI)" || equipment_abbreviation == "Digital Indicator(DI)") {
                equipment_abbreviation = "DI";
            }
            else if (equipment_abbreviation == "内径千分尺(三爪)(HT)" || equipment_abbreviation == "Holtest Meter(HT)") {
                equipment_abbreviation = "HT";
            }
            else if (equipment_abbreviation == "外径百分尺/外径千分尺(UM)" || equipment_abbreviation == "Micrometer(UM)") {
                equipment_abbreviation = "UM";
            }
            else if (equipment_abbreviation == "硬度测量仪(HD)" || equipment_abbreviation == "Hardness Tester(HD)") {
                equipment_abbreviation = "HD";
            }
            else if (equipment_abbreviation == "块规(PS)" || equipment_abbreviation == "Block Gage(PS)") {
                equipment_abbreviation = "PS";
            }
            else if (equipment_abbreviation == "针规/塞规(PG)" || equipment_abbreviation == "Pin Gage(PG)") {
                equipment_abbreviation = "PG";
            }
            else if (equipment_abbreviation == "螺纹规(TG)" || equipment_abbreviation == "Thread Gage(TG)") {
                equipment_abbreviation = "TG";
            }
            else if (equipment_abbreviation == "R规(RR)" || equipment_abbreviation == "Radius Gage(RR)") {
                equipment_abbreviation = "RR";
            }
            else if (equipment_abbreviation == "塞片(SM)" || equipment_abbreviation == "Shim(SM)") {
                equipment_abbreviation = "SM";
            }
            else if (equipment_abbreviation == "电子磅(EB)" || equipment_abbreviation == "Electronic Balance(EB)") {
                equipment_abbreviation = "EB";
            }
            else if (equipment_abbreviation == "三坐标测量仪(CMM)" || equipment_abbreviation == "CMM(CMM)") {
                equipment_abbreviation = "CMM";
            }
            else if (equipment_abbreviation == "影像仪(IM)" || equipment_abbreviation == "Image Measure(IM)") {
                equipment_abbreviation = "IM";
            }
            else if (equipment_abbreviation == "ZYGO(ZYGO)") {
                equipment_abbreviation = "ZYGO";
            }
            else if (equipment_abbreviation == "目测(VI)" || equipment_abbreviation == "Vision Inspection(VI)") {
                equipment_abbreviation = "VI";
            }
            else if (equipment_abbreviation == "显微镜(MS)" || equipment_abbreviation == "Microscope(MS)") {
                equipment_abbreviation = "MS";
            }
            else if (equipment_abbreviation == "直尺/卷尺(RL)" || equipment_abbreviation == "Ruler(RL)") {
                equipment_abbreviation = "RL";
            }
            else if (equipment_abbreviation == "万用表(MT)" || equipment_abbreviation == "Multimeter(MT)") {
                equipment_abbreviation = "MT";
            }
            else if (equipment_abbreviation == "光洁度测量仪(SF)" || equipment_abbreviation == "Surface Roughness(SF)") {
                equipment_abbreviation = "SF";
            }
            else if (equipment_abbreviation == "万能角度尺(UA)" || equipment_abbreviation == "Universal Angle Ruler(UA)") {
                equipment_abbreviation = "UA";
            }
            else if (equipment_abbreviation == "扭力表(TM)" || equipment_abbreviation == "Torque Meter(TM)") {
                equipment_abbreviation = "TM";
            }
            else if (equipment_abbreviation == "推拉力计(PP)" || equipment_abbreviation == "Push Pull Gauge(PP)") {
                equipment_abbreviation = "PP";
            }
            else if (equipment_abbreviation == "自制量具(OT)" || equipment_abbreviation == "Tailor-made Gage(OT)") {
                equipment_abbreviation = "OT";
            }
            else if (equipment_abbreviation == "示波器(2D)" || equipment_abbreviation == "Scope Check(2D)") {
                equipment_abbreviation = "2D";
            }
            else if (equipment_abbreviation == "检具+VC" || equipment_abbreviation == "Gauge+VC") {
                equipment_abbreviation = "Gauge+VC";
            }
            else {
            }
            data_dict["Meas_eq"] = equipment_abbreviation;
            data_dict["Eq_cal_code"] = $tl.eq(i).children("td:eq(3)").find("input:eq(1)").val();
            data_dict["Eq_col_pts"] = $tl.eq(i).children("td:eq(3)").find("input:eq(2)").val();

            if ($tl.eq(i).children("td:eq(4)").find("input:eq(1)").val() == "") {
                data_dict["Sample_plan"] = $tl.eq(i).children("td:eq(4)").find("input:eq(0)").val();
            }
            else {
                data_dict["Sample_plan"] = $tl.eq(i).children("td:eq(4)").find("input:eq(0)").val() + "//" + $tl.eq(i).children("td:eq(4)").find("input:eq(1)").val();
            }
            data_dict["Remark"] = $tl.eq(i).children("td:eq(5)").find("input").val();
        }
        else if (submit_type == 'RW') {
            data_dict["Rw_order"] = $('#rw_order').val();
            data_dict["Rw_seq"] = $('#Rw_seq').val();
            if ($('#input_SAP_rou_workcenter_RW').length > 0) {
                data_dict["Gn_type"] = $('#input_SAP_rou_workcenter_RW').val();
            }
            else {
                data_dict["Gn_type"] = $('#gn_type_RW').val();
                data_dict["Sap_rou_workcenter"] = $('#SAP_rou_workcenter_RW').val();
                data_dict["Fixture_pn"] = $('#fixture_pn_RW').val();
                data_dict["Fixture_array"] = $('#fixture_array_RW').val();
                data_dict["Tooling_Ipna"] = $('#tooling_ipna_RW').val();
            }
            if ($tl.eq(i).children("td:eq(3)").find("input:eq(1)").val() == "" || $tl.eq(i).children("td:eq(3)").find("input:eq(2)").val() == ""
            || $tl.eq(i).children("td:eq(3)").find("input:eq(1)").val() == "+" || $tl.eq(i).children("td:eq(3)").find("input:eq(2)").val() == "+"
            || $tl.eq(i).children("td:eq(3)").find("input:eq(1)").val() == "-" || $tl.eq(i).children("td:eq(3)").find("input:eq(2)").val() == "-") {
                if ($tl.eq(i).children("td:eq(4)").find("input:eq(0)").val() == "螺纹规(TG)" || $tl.eq(i).children("td:eq(4)").find("input:eq(0)").val() == "目测(VI)"
                || $tl.eq(i).children("td:eq(4)").find("input:eq(0)").val() == "显微镜(MS)" || $tl.eq(i).children("td:eq(4)").find("input:eq(0)").val() == "自制量具(OT)") {
                    data_dict["Upp_tol"] = "";
                    data_dict["Lwr_tol"] = "";
                } else {
                    return "Tolerance is empty";
                }
            }
        }
        else if (submit_type == "EM-SBC") {
            data_dict["Gn_type"] = $('#Supplier_code').val();
            if ($tl.eq(i).children("td:eq(3)").find("input:eq(1)").val() == "" || $tl.eq(i).children("td:eq(3)").find("input:eq(2)").val() == ""
            || $tl.eq(i).children("td:eq(3)").find("input:eq(1)").val() == "+" || $tl.eq(i).children("td:eq(3)").find("input:eq(2)").val() == "+"
            || $tl.eq(i).children("td:eq(3)").find("input:eq(1)").val() == "-" || $tl.eq(i).children("td:eq(3)").find("input:eq(2)").val() == "-") {
                if ($tl.eq(i).children("td:eq(4)").find("input:eq(0)").val() == "螺纹规(TG)" || $tl.eq(i).children("td:eq(4)").find("input:eq(0)").val() == "目测(VI)"
                || $tl.eq(i).children("td:eq(4)").find("input:eq(0)").val() == "显微镜(MS)" || $tl.eq(i).children("td:eq(4)").find("input:eq(0)").val() == "自制量具(OT)") {
                    data_dict["Upp_tol"] = "";
                    data_dict["Lwr_tol"] = "";
                } else {
                    return "Tolerance is empty";
                }
            }
        }
        else if (submit_type == 'EM-QC') {
            data_dict["Sap_rou_workcenter"] = $('#input_SAP_rou_workcenter_EM-QC').val();
            data_dict["Gn_correl_enggdwg"] = "";
            data_dict["Dwg_label"] = $tl.eq(i).children("td:eq(1)").find("input").val();
            data_dict["Dwg_spec"] = $tl.eq(i).children("td:eq(2)").find("input:eq(0)").val();
            data_dict["Upp_tol"] = $tl.eq(i).children("td:eq(2)").find("input:eq(1)").val();
            data_dict["Lwr_tol"] = $tl.eq(i).children("td:eq(2)").find("input:eq(2)").val();
            if ($tl.eq(i).children("td:eq(2)").find("input:eq(1)").val() == "+0" || $tl.eq(i).children("td:eq(2)").find("input:eq(1)").val() == "+0.0" || $tl.eq(i).children("td:eq(2)").find("input:eq(1)").val() == "+0.00"
            || $tl.eq(i).children("td:eq(2)").find("input:eq(1)").val() == "-0" || $tl.eq(i).children("td:eq(2)").find("input:eq(1)").val() == "-0.0" || $tl.eq(i).children("td:eq(2)").find("input:eq(1)").val() == "-0.00") {
                data_dict["Upp_tol"] = "0";
            }
            if ($tl.eq(i).children("td:eq(2)").find("input:eq(2)").val() == "+0" || $tl.eq(i).children("td:eq(2)").find("input:eq(2)").val() == "+0.0" || $tl.eq(i).children("td:eq(2)").find("input:eq(2)").val() == "+0.00"
            || $tl.eq(i).children("td:eq(2)").find("input:eq(2)").val() == "-0" || $tl.eq(i).children("td:eq(2)").find("input:eq(2)").val() == "-0.0" || $tl.eq(i).children("td:eq(2)").find("input:eq(2)").val() == "-0.00") {
                data_dict["Lwr_tol"] = "0";
            }

            if ($tl.eq(i).children("td:eq(2)").find("input:eq(1)").val() == "" || $tl.eq(i).children("td:eq(2)").find("input:eq(2)").val() == ""
            || $tl.eq(i).children("td:eq(2)").find("input:eq(1)").val() == "+" || $tl.eq(i).children("td:eq(2)").find("input:eq(2)").val() == "+"
            || $tl.eq(i).children("td:eq(2)").find("input:eq(1)").val() == "-" || $tl.eq(i).children("td:eq(2)").find("input:eq(2)").val() == "-") {
                if ($tl.eq(i).children("td:eq(3)").find("input:eq(0)").val() == "螺纹规(TG)" || $tl.eq(i).children("td:eq(3)").find("input:eq(0)").val() == "目测(VI)"
                || $tl.eq(i).children("td:eq(3)").find("input:eq(0)").val() == "显微镜(MS)" || $tl.eq(i).children("td:eq(3)").find("input:eq(0)").val() == "自制量具(OT)") {
                    data_dict["Upp_tol"] = "";
                    data_dict["Lwr_tol"] = "";
                } else {
                    return "Tolerance is empty";
                }
            }

            equipment_abbreviation = $tl.eq(i).children("td:eq(3)").find("input:eq(0)").val();
            if (equipment_abbreviation == "高度尺(HG)" || equipment_abbreviation == "Height Gauge(HG)") {
                equipment_abbreviation = "HG";
            }
            else if (equipment_abbreviation == "卡尺(VC)" || equipment_abbreviation == "Vernier Caliper(VC)") {
                equipment_abbreviation = "VC";
            }
            else if (equipment_abbreviation == "投影仪(PJ)" || equipment_abbreviation == "Profile Projector(PJ)") {
                equipment_abbreviation = "PJ";
            }
            else if (equipment_abbreviation == "百分表/千分表(DT)" || equipment_abbreviation == "Dial Indicator(DT)") {
                equipment_abbreviation = "DT";
            }
            else if (equipment_abbreviation == "高度计(DI)" || equipment_abbreviation == "Digital Indicator(DI)") {
                equipment_abbreviation = "DI";
            }
            else if (equipment_abbreviation == "内径千分尺(三爪)(HT)" || equipment_abbreviation == "Holtest Meter(HT)") {
                equipment_abbreviation = "HT";
            }
            else if (equipment_abbreviation == "外径百分尺/外径千分尺(UM)" || equipment_abbreviation == "Micrometer(UM)") {
                equipment_abbreviation = "UM";
            }
            else if (equipment_abbreviation == "硬度测量仪(HD)" || equipment_abbreviation == "Hardness Tester(HD)") {
                equipment_abbreviation = "HD";
            }
            else if (equipment_abbreviation == "块规(PS)" || equipment_abbreviation == "Block Gage(PS)") {
                equipment_abbreviation = "PS";
            }
            else if (equipment_abbreviation == "针规/塞规(PG)" || equipment_abbreviation == "Pin Gage(PG)") {
                equipment_abbreviation = "PG";
            }
            else if (equipment_abbreviation == "螺纹规(TG)" || equipment_abbreviation == "Thread Gage(TG)") {
                equipment_abbreviation = "TG";
            }
            else if (equipment_abbreviation == "R规(RR)" || equipment_abbreviation == "Radius Gage(RR)") {
                equipment_abbreviation = "RR";
            }
            else if (equipment_abbreviation == "塞片(SM)" || equipment_abbreviation == "Shim(SM)") {
                equipment_abbreviation = "SM";
            }
            else if (equipment_abbreviation == "电子磅(EB)" || equipment_abbreviation == "Electronic Balance(EB)") {
                equipment_abbreviation = "EB";
            }
            else if (equipment_abbreviation == "三坐标测量仪(CMM)" || equipment_abbreviation == "CMM(CMM)") {
                equipment_abbreviation = "CMM";
            }
            else if (equipment_abbreviation == "影像仪(IM)" || equipment_abbreviation == "Image Measure(IM)") {
                equipment_abbreviation = "IM";
            }
            else if (equipment_abbreviation == "ZYGO(ZYGO)") {
                equipment_abbreviation = "ZYGO";
            }
            else if (equipment_abbreviation == "目测(VI)" || equipment_abbreviation == "Vision Inspection(VI)") {
                equipment_abbreviation = "VI";
            }
            else if (equipment_abbreviation == "显微镜(MS)" || equipment_abbreviation == "Microscope(MS)") {
                equipment_abbreviation = "MS";
            }
            else if (equipment_abbreviation == "直尺/卷尺(RL)" || equipment_abbreviation == "Ruler(RL)") {
                equipment_abbreviation = "RL";
            }
            else if (equipment_abbreviation == "万用表(MT)" || equipment_abbreviation == "Multimeter(MT)") {
                equipment_abbreviation = "MT";
            }
            else if (equipment_abbreviation == "光洁度测量仪(SF)" || equipment_abbreviation == "Surface Roughness(SF)") {
                equipment_abbreviation = "SF";
            }
            else if (equipment_abbreviation == "万能角度尺(UA)" || equipment_abbreviation == "Universal Angle Ruler(UA)") {
                equipment_abbreviation = "UA";
            }
            else if (equipment_abbreviation == "扭力表(TM)" || equipment_abbreviation == "Torque Meter(TM)") {
                equipment_abbreviation = "TM";
            }
            else if (equipment_abbreviation == "推拉力计(PP)" || equipment_abbreviation == "Push Pull Gauge(PP)") {
                equipment_abbreviation = "PP";
            }
            else if (equipment_abbreviation == "自制量具(OT)" || equipment_abbreviation == "Tailor-made Gage(OT)") {
                equipment_abbreviation = "OT";
            }
            else if (equipment_abbreviation == "示波器(2D)" || equipment_abbreviation == "Scope Check(2D)") {
                equipment_abbreviation = "2D";
            }
            else if (equipment_abbreviation == "检具+VC" || equipment_abbreviation == "Gauge+VC") {
                equipment_abbreviation = "Gauge+VC";
            }
            else {

            }
            data_dict["Meas_eq"] = equipment_abbreviation;

            data_dict["Eq_cal_code"] = $tl.eq(i).children("td:eq(3)").find("input:eq(1)").val();
            data_dict["Eq_col_pts"] = $tl.eq(i).children("td:eq(3)").find("input:eq(2)").val();

            if ($tl.eq(i).children("td:eq(4)").find("input:eq(1)").val() == "") {
                data_dict["Sample_plan"] = $tl.eq(i).children("td:eq(4)").find("input:eq(0)").val();
            }
            else {
                data_dict["Sample_plan"] = $tl.eq(i).children("td:eq(4)").find("input:eq(0)").val() + "//" + $tl.eq(i).children("td:eq(4)").find("input:eq(1)").val();
            }
            data_dict["Remark"] = $tl.eq(i).children("td:eq(5)").find("input").val();
        }
        list.push(data_dict);
    };
    return JSON.stringify(list); //把对象转换成json
};

//创建excel
function CreateExcel(templateType, equipmentType) {

    if ($('#Update_Version_' + templateType).is(':checked')) {
        var list = [{ "function": "GetExcelData", "updateWay": "update", "templateType": templateType, "equipmentType": equipmentType }];
    }
    else {
        var list = [{ "function": "GetExcelData", "updateWay": "original", "templateType": templateType, "equipmentType": equipmentType }];
    }
    var $tl = $("#" + templateType + "_table tr");
    var $index = $tl.length;
    for (var i = 1; i < $index; i++) {
        var data_dict = {};
        data_dict["Part_num"] = $('#part_num').val();
        data_dict["Part_rev"] = $('#part_rev').val();
        data_dict["Badge"] = $('#mk_badge').val();
        data_dict["Template_type"] = templateType;
        if (templateType == "EM-SBC") {
            data_dict["Gn_type"] = $('#Supplier_code').val();
            data_dict["Sap_rou_workcenter"] = "";
            data_dict["Gn_correl_enggdwg"] = $tl.eq(i).children("td:eq(1)").find("input").prop('checked').toString();
            data_dict["Dwg_label"] = $tl.eq(i).children("td:eq(2)").find("input").val();
            var Specification_val = $tl.eq(i).children("td:eq(3)").find("input:eq(0)").val();
            var str = $tl.eq(i).children("td:eq(4)").find("input:eq(0)").val();
            if (str == "PG+VC" || str == "检具+VC") {
                data_dict["Meas_eq"] = str;
            }
            else {
                if (str.indexOf('(') != -1) {
                    data_dict["Meas_eq"] = str.substring(str.indexOf('(') + 1, str.indexOf(')'));
                }
                else {
                    data_dict["Meas_eq"] = str;
                }

            }
        }
        else if (templateType == "IM-WS") {
            data_dict["Gn_type"] = $('#input_gn_type_IM-WS').val();
            data_dict["Sap_rou_workcenter"] = $('#SAP_rou_workcenter_IM-WS').val();
            data_dict["Gn_correl_enggdwg"] = $tl.eq(i).children("td:eq(1)").find("input").prop('checked').toString();
            data_dict["Dwg_label"] = $tl.eq(i).children("td:eq(2)").find("input").val();
            var Specification_val = $tl.eq(i).children("td:eq(3)").find("input:eq(0)").val();
            var str = $tl.eq(i).children("td:eq(4)").find("input:eq(0)").val();
            if (str == "PG+VC" || str == "检具+VC") {
                data_dict["Meas_eq"] = str;
            }
            else {
                if (str.indexOf('(') != -1) {
                    data_dict["Meas_eq"] = str.substring(str.indexOf('(') + 1, str.indexOf(')'));
                }
                else {
                    data_dict["Meas_eq"] = str;
                }

            }
        }
        else if (templateType == "RW") {
            data_dict["Gn_type"] = $('#gn_type_RW').val();
            data_dict["Sap_rou_workcenter"] = $('#SAP_rou_workcenter_RW').val();
            data_dict["Gn_correl_enggdwg"] = $tl.eq(i).children("td:eq(1)").find("input").prop('checked').toString();
            data_dict["Dwg_label"] = $tl.eq(i).children("td:eq(2)").find("input").val();
            var Specification_val = $tl.eq(i).children("td:eq(3)").find("input:eq(0)").val();
            var str = $tl.eq(i).children("td:eq(4)").find("input:eq(0)").val();
            if (str == "PG+VC" || str == "检具+VC") {
                data_dict["Meas_eq"] = str;
            }
            else {
                if (str.indexOf('(') != -1) {
                    data_dict["Meas_eq"] = str.substring(str.indexOf('(') + 1, str.indexOf(')'));
                }
                else {
                    data_dict["Meas_eq"] = str;
                }

            }
        }
        else if (templateType == "IM-QC") {
            data_dict["Gn_type"] = "";
            data_dict["Sap_rou_workcenter"] = $('#input_SAP_rou_workcenter_IM-QC').val();
            data_dict["Dwg_label"] = $tl.eq(i).children("td:eq(1)").find("input").val();
            var Specification_val = $tl.eq(i).children("td:eq(2)").find("input:eq(0)").val();
            var str = $tl.eq(i).children("td:eq(3)").find("input:eq(0)").val();
            if (str == "PG+VC" || str == "检具+VC") {
                data_dict["Meas_eq"] = str;
            }
            else {
                if (str.indexOf('(') != -1) {
                    data_dict["Meas_eq"] = str.substring(str.indexOf('(') + 1, str.indexOf(')'));
                }
                else {
                    data_dict["Meas_eq"] = str;
                }
            }
        }
        else {
            data_dict["Gn_type"] = "";
            data_dict["Sap_rou_workcenter"] = $('#input_SAP_rou_workcenter_EM-QC').val();
            data_dict["Dwg_label"] = $tl.eq(i).children("td:eq(1)").find("input").val();
            var Specification_val = $tl.eq(i).children("td:eq(2)").find("input:eq(0)").val();
            var str = $tl.eq(i).children("td:eq(3)").find("input:eq(0)").val();
            if (str == "PG+VC" || str == "检具+VC") {
                data_dict["Meas_eq"] = str;
            }
            else {
                if (str.indexOf('(') != -1) {
                    data_dict["Meas_eq"] = str.substring(str.indexOf('(') + 1, str.indexOf(')'));
                }
                else {
                    data_dict["Meas_eq"] = str;
                }

            }
        }
        var max = "";
        var min = "";
        if (templateType == "IM-WS" || templateType == "EM-SBC" || templateType == "RW") {
            max = $tl.eq(i).children("td:eq(3)").find("input:eq(1)").val();
            min = $tl.eq(i).children("td:eq(3)").find("input:eq(2)").val();
            try {
                parseFloat(max).toString();
            } catch (e) {
                try {
                    if (max.indexOf("+") >= 0) {
                        max = "+" + max.replace(/[^0-9.]/g, "");
                    }
                    else if (max.indexOf("-") >= 0) {
                        max = "-" + max.replace(/[^0-9.]/g, "");
                    }
                    else {
                        max = max.replace(/[^0-9.]/g, "");
                    }
                    parseFloat(max).toString();
                } catch (e) {
                    max = "0";
                }
            }
            try {
                parseFloat(min).toString();
            } catch (e) {
                try {
                    if (min.indexOf("+") >= 0) {
                        min = "+" + min.replace(/[^0-9.]/g, "");
                    }
                    else if (min.indexOf("-") >= 0) {
                        min = "-" + min.replace(/[^0-9.]/g, "");
                    }
                    else {
                        min = min.replace(/[^0-9.]/g, "");
                    }
                    parseFloat(min).toString();
                } catch (e) {
                    min = "0";
                }
            }
        }
        else {
            max = $tl.eq(i).children("td:eq(2)").find("input:eq(1)").val();
            min = $tl.eq(i).children("td:eq(2)").find("input:eq(2)").val();
            try {
                parseFloat(max).toString();
            } catch (e) {
                try {
                    if (max.indexOf("+") >= 0) {
                        max = "+" + max.replace(/[^0-9.]/g, "");
                    }
                    else if (max.indexOf("-") >= 0) {
                        max = "-" + max.replace(/[^0-9.]/g, "");
                    }
                    else {
                        max = max.replace(/[^0-9.]/g, "");
                    }
                    parseFloat(max).toString();
                } catch (e) {
                    max = "0";
                }
            }
            try {
                parseFloat(min).toString();
            } catch (e) {
                try {
                    if (min.indexOf("+") >= 0) {
                        min = "+" + min.replace(/[^0-9.]/g, "");
                    }
                    else if (min.indexOf("-") >= 0) {
                        min = "-" + min.replace(/[^0-9.]/g, "");
                    }
                    else {
                        min = min.replace(/[^0-9.]/g, "");
                    }
                    parseFloat(min).toString();
                } catch (e) {
                    min = "0";
                }
            }
        }
        var Sample_plan = /^\d*\.?\d*$/;
        data_dict["Dwg_spec"] = Specification_val;
        //图纸规格中含有正负号（应计算上下公差）
        if (Specification_val.indexOf("±") >= 0) {
            var serverData = Specification_val.split("±");
            var str = serverData[0].replace(/[^0-9.]/g, "");
            var num = str.replace(/,/g, "");
            data_dict["Upp_tol"] = (parseFloat(num) + parseFloat(max)).toString();
            data_dict["Lwr_tol"] = (parseFloat(num) + parseFloat(min)).toString();
        }
            //图纸规格中含有形位公差（上下公差直接输入不做处理）
        else if (Specification_val.indexOf("⊥") >= 0 || Specification_val.indexOf("⫽") >= 0 || Specification_val.indexOf("▱") >= 0 || Specification_val.indexOf("―") >= 0 || Specification_val.indexOf("⌯") >= 0 ||
        Specification_val.indexOf("〇") >= 0 || Specification_val.indexOf("⌾") >= 0 || Specification_val.indexOf("⌭") >= 0 || Specification_val.indexOf("⌖") >= 0 || Specification_val.indexOf("◠") >= 0 ||
        Specification_val.indexOf("⌓") >= 0 || Specification_val.indexOf("⌔") >= 0 || Specification_val.indexOf("↗") >= 0 || Specification_val.indexOf("⌰") >= 0 || Specification_val.indexOf("⌳") >= 0) {
            data_dict["Upp_tol"] = max;
            data_dict["Lwr_tol"] = min;
        }
            //图纸规格输入为纯数字时（应计算上下公差）
        else if (Sample_plan.test(Specification_val)) {
            if (Math.abs(max) == Math.abs(min)) {
                data_dict["Dwg_spec"] += "±" + Math.abs(max);
                data_dict["Upp_tol"] = (parseFloat(Specification_val) + parseFloat(max)).toString();
                data_dict["Lwr_tol"] = (parseFloat(Specification_val) + parseFloat(min)).toString();
            }
            else {
                if (max == "+0" || max == "-0" || max == "0") {
                    max = "+0";
                }
                else if (min == "+0" || min == "-0" || min == "0") {
                    min = "0";
                }
                data_dict["Dwg_spec"] += max + "/" + min;
                data_dict["Upp_tol"] = (parseFloat(Specification_val) + parseFloat(max)).toString();
                data_dict["Lwr_tol"] = (parseFloat(Specification_val) + parseFloat(min)).toString();
            }
        }
            //图纸规格为孔径时（应计算上下公差，若还有正负号或形位公差，已在前面的情况考虑）
        else if (Specification_val.indexOf("∅") >= 0) {
            serverData = Specification_val.split("∅");
            if (Specification_val.indexOf("±") != -1) {
                var serverData1 = serverData[1].split("±");
                data_dict["Upp_tol"] = (parseFloat(serverData1[1]) + parseFloat(max)).toString();
                data_dict["Lwr_tol"] = (parseFloat(serverData1[1]) + parseFloat(min)).toString();
            }
            else {
                if (max == "+0" || max == "-0" || max == "0") {
                    max = "+0";
                }
                else if (min == "+0" || min == "-0" || min == "0") {
                    min = "0";
                }
                data_dict["Dwg_spec"] += max + "/" + min;
                data_dict["Upp_tol"] = (parseFloat(serverData[1]) + parseFloat(max)).toString();
                data_dict["Lwr_tol"] = (parseFloat(serverData[1]) + parseFloat(min)).toString();
            }
        }
        else {
            data_dict["Upp_tol"] = max;
            data_dict["Lwr_tol"] = min;
            if (max == "+") {
                data_dict["Upp_tol"] = "0";
            }
            if (min == "-") {
                data_dict["Lwr_tol"] = "0";
            }
        }
        list.push(data_dict);
    };
    return JSON.stringify(list); //把对象转换成json
};


//创建模板
function creat_template(btn, table, templateType) {
    $("#div_create_" + templateType).on("click", btn, function () {
        if (CheckBasicInfo(table)) {     //检查是否填写工件号版本号和工号
            if (templateType == "IM-WS" && $('#SAP_rou_workcenter_IM-WS').val() == "") {
                if ($("#input_changeLanguage").val() == "2") {
                    AlertWindow("You must fill in the machine type!");
                }
                else {
                    AlertWindow("您必须填写加工机型！");
                }
            }
            else if (templateType == "EM-SBC" && $('#Supplier_code').val() == "") {
                if ($("#input_changeLanguage").val() == "2") {
                    AlertWindow("You must fill in the supplier code!");
                }
                else {
                    AlertWindow("您必须填写供应商代码！");
                }
            }
            else {
                checkTemplateVersion($('#part_num').val(), $('#part_rev').val(), templateType);
                if (btn.toString().includes("#")) {
                    $(btn).attr('disabled', 'disabled');//Modify by YZT 2019-08-29 $("#" + btn) ==> if contain("#") then $(btn) else $("#" + btn)
                } else {
                    $("#" + btn).attr('disabled', 'disabled');
                }

            }
        };
    });
}

//检查是否填写工件号版本号和工号
function CheckBasicInfo(table_name) {
    var bool_check = true;
    if ($('#spc_username').html() == "") {
        if ($("#input_changeLanguage").val() == "2") {
            AlertWindow("You are not logged in yet!");
        }
        else {
            AlertWindow("您没有登陆！");
        }
        bool_check = false;
        return bool_check;
    }
    if ($('#part_num').val() == "" || $('#part_rev').val() == "" || $('#mk_badge').val() == "") {
        if ($("#input_changeLanguage").val() == "2") {
            AlertWindow("Workpiece number, version number, or work number cannot be empty");
        }
        else {
            AlertWindow("工件号,版本号,或者工号不能为空");
        }
        bool_check = false;
        return bool_check;
    };
    if ($('#' + table_name + ' tr').length < 2) {
        if ($("#input_changeLanguage").val() == "2") {
            AlertWindow("No record created!");
        }
        else {
            AlertWindow("没有创建记录！");
        }
        bool_check = false;
        return bool_check;
    }
    return bool_check;
}

//检查工件号
function CheckPartNum(part_num) {
    $.post("CreateTemplate.ashx", JSON.stringify([{ "function": "CheckPartNum" }, { "part_num": part_num }]), function (data) {
        var str = data.status;
        if (str == "PASS") {
            $("#span_part_num").html("<span class='glyphicon glyphicon-ok' style='color:green'></span>");
            $("#partnum").val($("#part_num"));
        }
        else {
            $("#span_part_num").html("<span class='glyphicon glyphicon-remove' style='color:red'></span>");
            $("#part_num").val('');
            $('#Ul_fixture_pn_IM-WS').html('');
        }
    });
};

//检查工件号和工件版本
function checkPartNumAndPartRev(part_num, part_rev) {
    $("#SAP_rou_workcenter_ul_IM-WS").html(null);
    $("#ul_SAP_rou_workcenter_IM-QC").html(null);
    $("#ul_SAP_rou_workcenter_EM-QC").html(null);
    $.post("CreateTemplate.ashx", JSON.stringify([{ "function": "checkPartNumAndPartRev" }, { "part_num": part_num }, { "part_rev": part_rev }]), function (data) {
        if (data.status == "pass") {
            $('#Ul_fixture_pn_IM-WS').html('');
            $("#span_part_num").html("<span class='glyphicon glyphicon-ok' style='color:green'></span>");
            $("#span_part_rev").html("<span class='glyphicon glyphicon-ok' style='color:green'></span>");

            GetFixtureAndIPNA(part_num, part_rev);
            //获得SAP工艺
            GetShipmentList(part_num, part_rev);
            //检查是否需要添加从其它版本导入按钮 Add by YZT 20191107
            CheckOldVersionTemplate(part_num, part_rev, "IM-WS,IM-QC");
        }
        else {
            if ($("#input_changeLanguage").val() == "2") {
                ConfirmWindow("The drawings in the engineering drawing library are not in the right format!<br />GN drawing library is now connected, please select suitable drawings for inspection!", "GN_drawing_library", "");
            }
            else {
                ConfirmWindow("工程图库内图纸格式不对<br />现连接GN图库，请用户自选合适图纸查阅", "GN_drawing_library", "");
            }
        }
    });
};

//检查是否需要添加从其它版本导入按钮 Add by YZT 20191107
function CheckOldVersionTemplate(part_num, part_rev, checkType) {
    var checkTypeArray = checkType.split(',');
    $.post("CreateTemplate.ashx", JSON.stringify([{ "function": "checkOldVersionTemplate" }, { "part_num": part_num }, { "part_rev": part_rev }, { "checkType": checkType }]), function (data) {
        for (var i = 0; i < checkTypeArray.length; i++) {
            //初始化为不可见
            $("#btn_importFromOld_" + checkTypeArray[i]).attr("style", "display:none");
        }
        if (data.status == "exist") {
            //存在当前版本的Template，取消添加的按钮
        } else {
            //对不存在的IM-QC/IM-WS/...添加对应按钮显示，并弹窗提醒由其他版本模板
            var allowType = data.status.split(',');
            for (var i = 0; i < allowType.length; i++) {
                $("#btn_importFromOld_" + allowType[i]).removeAttr("style").click(function () {
                    ImportWindow(part_num, this.id.split('_')[2]);
                    //$('#importOtherVersionTemplate').dialog('open');
                });
            }
            createImportWindow(part_num, part_rev, allowType);
            $("#confirm").dialog('open');
        }
    });
}

//连接GN图库
function GN_drawing_library() {
    var part_num = $('#part_num').val();
    var part_rev = $('#part_rev').val();
    $.post("CreateTemplate.ashx", JSON.stringify([{ "function": "connectToGNDrawingLibrary" }, { "part_num": part_num }, { "part_rev": part_rev }]), function (data) {
        if (data.status == "pass") {
            $('#Ul_fixture_pn_IM-WS').html('');
            $("#span_part_num").html("<span class='glyphicon glyphicon-ok' style='color:green'></span>");
            $("#span_part_rev").html("<span class='glyphicon glyphicon-ok' style='color:green'></span>");
            GetFixtureAndIPNA(part_num, part_rev);
            GetShipmentList(part_num, part_rev, "8700");
        }
        else {
            $("#span_part_num").html("<span class='glyphicon glyphicon-remove' style='color:red'></span>");
            $("#part_num").val('');
            $("#span_part_rev").html("<span class='glyphicon glyphicon-remove' style='color:red'></span>");
            $("#part_rev").val('');
            $('#Ul_fixture_pn_IM-WS').html('');
            if ($("#input_changeLanguage").val() == "2") {
                AlertWindow("The PDF format of this figure cannot be found!<br />Please contact GN production staff or engineering drawing designer to upload!");
            }
            else {
                AlertWindow("查无此图的PDF格式<br />请联络GN图制作人员或工程图设计者上载");
            }
        }
    });
};

//检查工号
function checkbadge(badge) {
    $.post("CreateTemplate.ashx", JSON.stringify([{ "function": "checkbadge" }, { "badge": badge }]), function (data) {
        if (data.status == "pass") {
            $("#span_mk_badge").html("<span class='glyphicon glyphicon-ok' style='color:green'></span>");
        }
        else {
            $("#span_mk_badge").html("<span class='glyphicon glyphicon-remove' style='color:red'></span>");
        }
    });
};

//自动替换工序
function ProcessReplacement(templateType) {
    $("#div_gn_type_" + templateType).on('blur', "#input_gn_type_" + templateType, function () {
        if ($("#input_gn_type_" + templateType).val().indexOf("PCS") >= 0) {
            var str = $("#input_gn_type_" + templateType).val();
            str = str.replace("PCS", "QC");
            $("#input_gn_type_" + templateType).val(str);
        }
    });
};

//获得所有的机型
function GetMachineType() {
    $.post("CreateTemplate.ashx", JSON.stringify([{ "function": "GetMachineType" }]), function (data) {
        var str = "";
        str += '<li role="separator" class="divider" style="margin:0px"></li>';
        if ($("#input_changeLanguage").val() == "2") {
            str += '<li style="font-size:16px;font-weight: bold;background-color:#cccccc">Machine Type List</li>';
        }
        else {
            str += '<li style="font-size:16px;font-weight: bold;background-color:#cccccc">机型一览表</li>';
        }
        str += '<li role="separator" class="divider" style="margin:0px"></li>';
        for (var key in data) {
            str += '<li><a href="javascript:void(0)">' + data[key] + '</a></li>';
        }
        $('#SAP_rou_workcenter_ul_IM-WS').append(str);
    });
};

//获得QC参数（出货要求和量仪）
function Get_QC_Parameter(templateType) {
    var Meas_eq = "";
    Meas_eq += loadData('static/equipment.json', 'equipment');
    $('#ul_meas_eq_higher_' + templateType).append(Meas_eq);
    var checkWay = "";//Add by YZT 20191112 增加checkWay
    checkWay += loadData('static/checkWay_IM.json', 'checkWay');
    $('#ul_checkWay_higher_' + templateType).append(checkWay);
    //SAP工艺的选择
    $("#div_SAP_rou_workcenter_" + templateType).on('click', "#ul_SAP_rou_workcenter_" + templateType + " li", function () {
        var str = $(this).text();
        if ($(this).css('background-color').toString() == "rgba(0, 0, 0, 0)") {
            $("#input_SAP_rou_workcenter_" + templateType).val(str);
        }
    });
    //选择QC(首层)量仪
    $('#div_meas_eq_higher_' + templateType).on('click', '#ul_meas_eq_higher_' + templateType + ' li', function () {
        var str = $(this).text();
        if ($(this).css('background-color').toString() == "rgba(0, 0, 0, 0)") {
            $("#input_meas_eq_higher_" + templateType).val(str);
        }
    });
    //选择QC(首层)检查方式
    $('#div_checkWay_higher_' + templateType).on('click', '#ul_checkWay_higher_' + templateType + ' li', function () {
        var current_value = $(this).text();
        if ($(this).css('background-color').toString() == "rgba(0, 0, 0, 0)") {
            //$("#input_checkWay_higher_" + templateType).val(current_value);
            if ($("#input_changeLanguage").val() == "2") {
                $("#btn_checkWay_higher_" + templateType).replaceWith("<button type='button' id='btn_checkWay_higher_" + templateType + "' class='btn button btn-default dropdown-toggle' data-toggle='dropdown'>" + current_value + "<span class='caret'></span></button>");
                $("#input_checkWay_higher_" + templateType).val(current_value);  //获取测量方法，若未选择，则为"方法"
                if (current_value == "All inspection" || current_value == "Sampling plan" || current_value == "Sampling plan(tighten up)" || current_value == "AQL0.65" || current_value == "AQL1.0") {  //以上方法无需填写抽检数量
                    $("#input_checkNum_higher_" + templateType).replaceWith("<input id='input_checkNum_higher_" + templateType + "' type='text' readonly='true' class='form-control' placeholder='No need to fill in quantity.' value=''>");
                }
                else {
                    $("#input_checkNum_higher_" + templateType).replaceWith("<input id='input_checkNum_higher_" + templateType + "' type='text' class='form-control' placeholder='Please fill in the quantity of random inspection.' value=''>");
                    $("#input_checkNum_higher_" + templateType).focus();
                }
            } else {
                $("#btn_checkWay_higher_" + templateType).replaceWith("<button type='button' id='btn_checkWay_higher_" + templateType + "' class='btn button btn-default dropdown-toggle' data-toggle='dropdown'>" + current_value + "<span class='caret'></span></button>");
                $("#input_checkWay_higher_" + templateType).val(current_value);  //获取测量方法，若未选择，则为"方法"
                if (current_value == "全检" || current_value == "抽检计划" || current_value == "抽检计划-加严" || current_value == "AQL0.65" || current_value == "AQL1.0") {  //以上方法无需填写抽检数量
                    $("#input_checkNum_higher_" + templateType).replaceWith("<input id='input_checkNum_higher_" + templateType + "' type='text' readonly='true' class='form-control' placeholder='无需填写数量' value=''>");
                }
                else {
                    $("#input_checkNum_higher_" + templateType).replaceWith("<input id='input_checkNum_higher_" + templateType + "' type='text' class='form-control' placeholder='请填写抽检数量' value=''>");
                    $("#input_checkNum_higher_" + templateType).focus();
                }
            }
        }
    });

};

//获得WS参数（机型，夹具和Tooling_Ipna）
function Get_WS_Parameter(templateType) {

    //夹具的选择
    $("#div_fixture_pn_" + templateType).on('click', "#Ul_fixture_pn_" + templateType + " li", function () {
        var str = $(this).text();
        $("#fixture_pn_" + templateType).val(str);
    });
    //刀具Tooling_Ipna的选择
    $("#div_tooling_ipna_" + templateType).on('click', "#Ul_tooling_ipna_" + templateType + " li", function () {
        var str = $(this).text();
        $("#tooling_ipna_" + templateType).val(str);
    });
    //选择机型
    $("#div_SAP_rou_workcenter_" + templateType).on('click', '#SAP_rou_workcenter_ul_' + templateType + ' li', function () {
        if ($(this).css('background-color').toString() == "rgba(0, 0, 0, 0)") {
            var str = $(this).text();
            $("#SAP_rou_workcenter_" + templateType).val(str);
        }
    });
};

// 获得夹具和Tooling_Ipna
function GetFixtureAndIPNA(part_num, part_rev) {
    $.post("CreateTemplate.ashx", JSON.stringify([{ "function": "GetFixtureAndIPNA" }, { "part_num": part_num }, { "part_rev": part_rev }]), function (data) {
        for (var i = 0; i < data.length; i++) {
            for (var key in data[i]) {
                var str = '<li><a href="javascript:void(0)">' + data[i][key] + '</a></li>';
                if (key.indexOf("FIX") != -1) {
                    $('#Ul_fixture_pn_IM-WS').append(str);
                }
                else if (key.indexOf("T_Name") != -1) {
                    $('#Ul_tooling_ipna_IM-WS').append(str);
                }
            }
        }
    });
};

//获得SAP工艺
function GetShipmentList(part_num, part_rev, plant) {
    $("#span_SAP_rou_workcenter_IM-WS").replaceWith('<span id="span_SAP_rou_workcenter_IM-WS" class="input-group-addon" style="padding:3px 3px 3px 3px"><img src="Images/timg.gif" alt="wait" style="height:24px;width:23px"/></span>');
    $("#span_SAP_rou_workcenter_IM-QC").replaceWith('<span id="span_SAP_rou_workcenter_IM-QC" class="input-group-addon" style="padding:3px 3px 3px 3px"><img src="Images/timg.gif" alt="wait" style="height:24px;width:23px"/></span>');
    $("#span_SAP_rou_workcenter_EM-QC").replaceWith('<span id="span_SAP_rou_workcenter_EM-QC" class="input-group-addon" style="padding:3px 3px 3px 3px"><img src="Images/timg.gif" alt="wait" style="height:24px;width:23px"/></span>');

    $.post("CreateTemplate.ashx", JSON.stringify([{ "function": "GetShipmentList" }, { "part_num": part_num }, { "part_rev": part_rev }, { "plant": "8700" }]), function (data) {

        $('#SAP_rou_workcenter_ul_IM-WS').html("");
        $('#ul_SAP_rou_workcenter_IM-QC').html("");
        $('#ul_SAP_rou_workcenter_EM-QC').html("");

        var key_pass = "Shipment1";
        if (data[0][key_pass] == null) {
            $("#span_SAP_rou_workcenter_IM-WS").replaceWith('<span id="span_SAP_rou_workcenter_IM-WS" class="input-group-addon" style="padding:3px 3px 3px 3px"><img src="Images/SAP_fail.png" alt="fail" style="height:24px;width:23px"/></span>');
            $("#span_SAP_rou_workcenter_IM-QC").replaceWith('<span id="span_SAP_rou_workcenter_IM-QC" class="input-group-addon" style="padding:3px 3px 3px 3px"><img src="Images/SAP_fail.png" alt="fail" style="height:24px;width:23px"/></span>');
            $("#span_SAP_rou_workcenter_EM-QC").replaceWith('<span id="span_SAP_rou_workcenter_EM-QC" class="input-group-addon" style="padding:3px 3px 3px 3px"><img src="Images/SAP_fail.png" alt="fail" style="height:24px;width:23px"/></span>');
        }
        else {
            $("#span_SAP_rou_workcenter_IM-WS").replaceWith('<span id="span_SAP_rou_workcenter_IM-WS" class="input-group-addon" style="padding:3px 3px 3px 3px"><img src="Images/SAP_pass.png" alt="pass" style="height:24px;width:23px"/></span>');
            $("#span_SAP_rou_workcenter_IM-QC").replaceWith('<span id="span_SAP_rou_workcenter_IM-QC" class="input-group-addon" style="padding:3px 3px 3px 3px"><img src="Images/SAP_pass.png" alt="pass" style="height:24px;width:23px"/></span>');
            $("#span_SAP_rou_workcenter_EM-QC").replaceWith('<span id="span_SAP_rou_workcenter_EM-QC" class="input-group-addon" style="padding:3px 3px 3px 3px"><img src="Images/SAP_pass.png" alt="pass" style="height:24px;width:23px"/></span>');

            var str = "";
            str += '<li role="separator" class="divider" style="margin:0px"></li>';
            if ($("#input_changeLanguage").val() == "2") {
                str += '<li style="font-size:16px;font-weight: bold;background-color:#cccccc">SAP Process</li>';
            }
            else {
                str += '<li style="font-size:16px;font-weight: bold;background-color:#cccccc">SAP工艺</li>';
            }
            str += '<li role="separator" class="divider" style="margin:0px"></li>';
            for (var i = 0; i < data.length; i++) {
                for (var key in data[i]) {
                    str += '<li><a href="javascript:void(0)">' + data[i][key] + '</a></li>';
                }
            }
            $('#SAP_rou_workcenter_ul_IM-WS').append(str);
            $('#ul_SAP_rou_workcenter_IM-QC').append(str);
            $('#ul_SAP_rou_workcenter_EM-QC').append(str);

        }
        //获得所有机型
        GetMachineType();


    });
};

//检查模板版次
function checkTemplateVersion(part_num, part_rev, templateType) {
    $.post("CreateTemplate.ashx", JSON.stringify([{
        "function": "checkTemplateVersion",
        "part_num": part_num,
        "part_rev": part_rev,
        "templateType": templateType
    }]), function (data) {
        if (data.status == "pass") {
            TemplateVersionUpdate(templateType);
        }
        else {
            if ($('#Update_Version_' + templateType).is(':checked')) {
                ConfirmWindow(data.status, "确认升版", templateType);

            } else {
                TemplateVersionUpdate(templateType);
            }

        }
    })
};

//更新模板版次
function TemplateVersionUpdate(templateType) {
    var clear_data = null;
    var btn_id = "";
    //if (templateType == "IM-WS") {
    //    clear_data = GetData("IM-WS", "btn_IM-WS", "IM-WS_table"); //获得json数据格式
    //    btn_id = "btn_IM-WS";
    //}
    //else if (templateType == "IM-QC") {
    //    clear_data = GetData("IM-QC", "btn_IM-QC", "IM-QC_table");
    //    btn_id = "btn_IM-QC";
    //}
    //else if (templateType == "RW") {
    //    clear_data = GetData("RW", "btn_RW", "RW_table");
    //    btn_id = "btn_RW";
    //}
    //else if (templateType == "EM-SBC") {
    //    clear_data = GetData("EM-SBC", "btn_EM-SBC", "EM-SBC_table");
    //    btn_id = "btn_EM-SBC";
    //}
    //else if (templateType == "EM-QC") {
    //    clear_data = GetData("EM-QC", "btn_EM-QC", "EM-QC_table");
    //    btn_id = "btn_EM-QC";
    //}
    if (templateType == "IM-WS" || templateType == "IM-QC" || templateType == "RW" || templateType == "EM-SBC" || templateType == "EM-QC") {
        if ($("#Update_Version_" + templateType).is(":checked")) {
            btn_id = "btn_update_" + templateType;
        } else {
            btn_id = "btn_" + templateType;
        }
        clear_data = GetData(templateType, btn_id, templateType + "_table");
    }
    else {
        clear_data = null;
        if ($("#input_changeLanguage").val() == "2") {
            AlertWindow("This module is not created");
        }
        else {
            AlertWindow("没有创建此模块");
        }
        $("#" + btn_id).removeAttr("disabled");
        return;
    }

    if (clear_data == "Tolerance is empty") {
        AlertWindow("模版中存在上下公差未填写，请注意填充完整！<br /><br />漏填上下公差可能会引起SCADA数据采集系统报警！");
        $("#" + btn_id).removeAttr("disabled");
        return;
    }

    if (clear_data.length < 2) {
        if ($("#input_changeLanguage").val() == "2") {
            AlertWindow("This module is not created");
        }
        else {
            AlertWindow("列表不能为空！");
        }
        $("#" + btn_id).removeAttr("disabled");
        return;
    };
    $.ajax({
        type: "POST",
        url: "CreateTemplate.ashx",
        dataType: "JSON",
        contentType: "application/json;charset=UTF-8",
        data: clear_data,
        success: function (data) {
            $("#" + btn_id).removeAttr("disabled");

            if (data.status == "创建成功") {
                if (templateType == "EM-SBC") {
                    ConfirmWindow("模板创建成功！<br />是否需要创建Excel表格?", "excel", templateType);
                }
                    //else if (btn_id == "btn_IM-WS" || btn_id == "btn_IM-QC" || btn_id == "btn_EM-QC") {
                else if (btn_id == "btn_IM-WS" || btn_id == "btn_IM-QC" || btn_id == "btn_EM-QC" || btn_id == "btn_update_IM-WS" || btn_id == "btn_update_IM-QC" || btn_id == "btn_update_EM-QC") { //update by YZT 20190923 Include the update buttons
                    var $tr = $('#' + templateType + '_table tr');
                    var length = $tr.length;
                    var bool_IM = false;
                    var bool_CMM = false;
                    for (var i = 1; i < length; i++) {
                        if ($("#" + templateType + "_input_equipment_" + i).val() == "影像仪(IM)") {
                            bool_IM = true;
                            //break;Cancel by YZT 20191028
                        } else if ($("#" + templateType + "_input_equipment_" + i).val() == "三坐标测量仪(CMM)") {
                            bool_CMM = true;
                            //break;Cancel by YZT 20191028
                        }
                    }
                    if (bool_IM == true || bool_CMM == true) {//Modify by YZT 20191025  如果有的话，都要保存
                        if (bool_IM == true && bool_CMM == true) {
                            templateType += "_IM&CMM";
                            ConfirmWindow("模板创建成功！<br />存在影像仪(IM)与三坐标测量仪(CMM)<br />是否需要创建Excel表格?", "excel", templateType);
                        } else if (bool_IM == true) {
                            templateType += "_IM";
                            ConfirmWindow("模板创建成功！<br />存在影像仪(IM)<br />是否需要创建Excel表格?", "excel", templateType);
                        } else if (bool_CMM == true) {
                            templateType += "_CMM";
                            ConfirmWindow("模板创建成功！<br />存在三坐标测量仪(CMM)<br />是否需要创建Excel表格?", "excel", templateType);
                        }
                    } else {
                        ConfirmWindow(data.status, "", templateType);
                    }
                } else {
                    ConfirmWindow(data.status, "", templateType);
                }
            } else {
                ConfirmWindow(data.status, "创建失败", templateType);
                $("#conform_cancel span span").text("返回检查");
                $("#confirm_sure span span").text("清除全部");

            }
        }
    });
};



//报警窗口
function AlertWindow(msg) {
    if ($("#input_changeLanguage").val() == "2") {
        var dlg = $('#alert').dialog({
            title: 'Alert',
            width: 400,
            height: 200,
            closed: false,
            modal: true,
            buttons: [{
                text: 'Close',
                handler: function () {
                    $('#alert').dialog('close');
                }
            }]
        });
    }
    else {
        var dlg = $('#alert').dialog({
            title: '提示',
            width: 400,
            height: 200,
            closed: false,
            modal: true,
            buttons: [{
                text: '关闭',
                handler: function () {
                    $('#alert').dialog('close');
                }
            }]
        });
    }

    $('#alert').html(msg);
    $('#alert').dialog('refresh');
};

//创建从旧版本导入的通知窗口
function createImportWindow(part_num, part_rev, allowType) {
    var width = 240;
    var buttons = [{
        id: "confirm_cancel",
        text: "不必，谢！",
        handler: function () {
            $('#confirm').dialog('close');
        }
    }];
    for (var i = 0; i < allowType.length; i++) {
        buttons.push({
            id: "confirm_" + allowType[i],
            text: "前往" + allowType[i],
            handler: function () {
                //根据按钮ID获取类型
                var type = this.id.split('_')[1];
                $('#confirm').dialog('close');
                //$('#importOtherVersionTemplate').attr('style','display:none');
                var panelTitle = $('#accordion_' + type).siblings('div').children('.panel-title').text();
                //打开导入版本选择窗口

                //关闭所有
                for (var i = 0; i < $('#accordion_WorkArea').accordion('panels').length; i++) {
                    $('#accordion_WorkArea').accordion('unselect', i);
                }
                //打开这个类型的版面
                $('#accordion_WorkArea').accordion('select', panelTitle);
                //ImportWindow(part_num, type)
                $('#btn_importFromOld_' + type).click();
            }
        });
        width = width + 30;
    }
    $('#confirm').dialog({
        title: 'Confirm',
        content: '检查到无当前版本的模板，是否从已有版本中导入？',
        width: width,
        height: 200,
        closed: true,
        modal: true,
        buttons: buttons
    });
};


//版本导入窗口
function ImportWindow(part_num, template_type) {
    if (part_num && template_type) {
        var para = JSON.stringify([{ "function": "getExistingVersionByType", "part_num": part_num, "template_type": template_type }]);
        $.post("CreateTemplate.ashx", para, function (data) {
            var item = []
            for (var i = 0; i < data[0].length; i++) {
                item.push({ value: data[0][i], text: data[0][i] });
            }
            $('#combobox_OtherVersion').combobox({
                valueField: 'value',
                textField: 'text',
                data: item,
                limitToList: true,
                onLoadSuccess: function () {
                    var data = $('#combobox_OtherVersion').combobox('getData');
                    $('#combobox_OtherVersion').combobox('setValue', data[0]);
                }
            });
            $('#textbox_OtherVersion_Type').textbox({
                readonly: true
            }).textbox('setValue', template_type);
            $('#textbox_OtherVersion_PartNum').textbox({
                readonly: true
            }).textbox('setText', part_num);
            $('#importOtherVersionTemplate').removeAttr('style');
            $('#importOtherVersionTemplate').dialog({
                title: 'Import Template',
                closed: false,
                closable: true,
                modal: true,
                buttons: [{
                    id: "import_Cancel",
                    text: "取消",
                    handler: function () {
                        $('#importOtherVersionTemplate').dialog('close');
                    }
                }, {
                    id: "import_OK",
                    text: "确定",
                    handler: function () {
                        var templateType = $('#textbox_OtherVersion_Type').combobox('getText');
                        var part_rev = $('#combobox_OtherVersion').combobox('getValue');
                        //通过工件号，版本号，模板类型，获取满足条件的最新版本模板
                        if ($('#Update_Version_' + templateType).is(':checked')) {
                            $('#Update_Version_' + templateType).prop('checked', false);
                        }
                        clearTemplateForm(templateType);
                        CreateUpdataTemplate($('#textbox_OtherVersion_PartNum').textbox('getText'), part_rev, templateType);
                        $('#importOtherVersionTemplate').dialog('close');
                    }
                }]
            });
        });
    }


}
//确认窗口
function ConfirmWindow(msg, type, templateType) {
    if ($("#input_changeLanguage").val() == "2") {
        $('#confirm').dialog({
            title: 'Confirm',
            width: 300,
            height: 200,
            closed: false,
            modal: true,
            buttons: [{
                id: "conform_cancel",
                text: 'Cancel',
                handler: function () {
                    $('#confirm').dialog('close');
                }
            }, {
                id: 'confirm_sure',
                text: 'OK',
                handler: function () {
                    $('#confirm').dialog('close');
                    if (type == "logout") {
                        Logout();
                    }
                    else if (type == "确认升版") {
                        TemplateVersionUpdate(templateType);
                    }
                    else if (type == "GN_drawing_library") {
                        GN_drawing_library();
                    }
                    else { }
                }
            }]
        });
    }
    else {
        $('#confirm').dialog({
            title: '确认',
            width: 300,
            height: 200,
            closed: false,
            modal: true,
            buttons: [{
                id: "conform_cancel",
                text: '取消',
                handler: function () {
                    $('#confirm').dialog('close');
                    if (type == "创建失败") {
                        //创建失败则不清除
                    } else {
                        //不创建也要清空列表
                        var rows = $("#" + templateType + "_table").find("tr").length;
                        for (var i = 0; i < rows; i++) {
                            if (i > 0) {
                                $("#" + templateType + "_table").find("tr:eq(1)").remove();
                            }
                        }
                        window.location.reload();
                    }
                }
            }, {
                id: 'confirm_sure',
                text: '确定',
                handler: function () {
                    $('#confirm').dialog('close');
                    if (type == "logout") {
                        Logout();
                    }
                    else if (type == "确认升版") {
                        TemplateVersionUpdate(templateType);
                    }
                    else if (type == "GN_drawing_library") {
                        GN_drawing_library();
                    }
                    else if (type == "excel") {
                        var excel_data = null;
                        var serverData = "";
                        serverData = templateType.split("_");
                        templateType = serverData[0];       //templateType依旧是模块类型
                        var equipmentType = serverData[1];  //equipmentType用以区分IM/CMM
                        excel_data = CreateExcel(templateType, equipmentType);

                        $.post("CreateTemplate.ashx", excel_data, function (data) {

                            var url = data.url;
                            window.open(url);
                            if (equipmentType == "CMM") {
                                var url2 = data.url2;
                                window.open(url2);
                            }
                            //创建完成后清空列表
                            var rows = $("#" + templateType + "_table").find("tr").length;
                            for (var i = 0; i < rows; i++) {
                                if (i > 0) {
                                    $("#" + templateType + "_table").find("tr:eq(1)").remove();
                                }
                            }
                            window.location.reload();
                        }).error(function (data) {//Add by YZT 2019-08-30 请求出错返回错误信息
                            var result = data.responseText.split('|');
                            alert(result[0]);
                        })
                    }
                    else {
                        //创建完成后清空列表
                        var rows = $("#" + templateType + "_table").find("tr").length;
                        for (var i = 0; i < rows; i++) {
                            if (i > 0) {
                                $("#" + templateType + "_table").find("tr:eq(1)").remove();
                            }
                        }
                        window.location.reload();
                    }
                }
            }]
        });
    }
    $('#confirm').html(msg);
    $('#confirm').dialog('refresh');
};


//量仪设置窗口(HG类及CMM)
function EquipmentSettingWindow_HG(msg_img, msg_ul) {
    var equipment_page = EquipmentPage_HG(msg_img, msg_ul);
    $('#setting').dialog({
        title: '量仪设置',
        width: 1100,
        height: 500,
        content: equipment_page,
        closed: false,
        modal: true,
        buttons: [{
            id: "HG_setting_cancel",
            text: '取消',
            handler: function () {
                $('#setting').dialog('close');
            }
        }, {
            id: 'HG_setting_sure',
            text: '确定',
            handler: function () {
                if ($("#name_equipment_setting").val() == "VI") {
                    return;
                }
                $('#setting').dialog('close');
            }
        }]
    });
    $('#setting').dialog('refresh');
};

//量仪设置窗口(HT,UM,VC)
function EquipmentSettingWindow_HT(msg_ul) {
    var equipment_page = EquipmentPage_HT(msg_ul);
    $('#setting').dialog({
        title: '量仪设置',
        width: 600,
        height: 500,
        content: equipment_page,
        closed: false,
        modal: true,
        buttons: [{
            id: "HT_setting_cancel",
            text: '取消',
            handler: function () {
                $('#setting').dialog('close');
            }
        }, {
            id: 'HT_setting_sure',
            text: '确定',
            handler: function () {
                $('#setting').dialog('close');
            }
        }]
    });
    $('#setting').dialog('refresh');
};

//量仪设置窗口(TG)
function EquipmentSettingWindow_TG() {
    var equipment_page = EquipmentPage_TG();
    $('#setting').dialog({
        title: '量仪设置',
        width: 800,
        height: 600,
        content: equipment_page,
        closed: false,
        modal: true,
        buttons: [{
            id: "TG_setting_cancel",
            text: '取消',

            handler: function () {
                $('#setting').dialog('close');
            }
        }, {
            id: 'TG_setting_sure',
            text: '确定',
            handler: function () {
                if ($('#input_ThreadPitch').val() == '') {//By YZT 20190925 螺纹直径不能为空
                    alert('螺纹直径不能为空，请填写');
                } else {
                    $('#setting').dialog('close');
                }
            }
        }]
    });
    $('#setting').dialog('refresh');
};

//量仪HG/PJ/CMM页面布局
function EquipmentPage_HG(msg_img, msg_ul) {
    var equipment_page = '';
    equipment_page += '<div id="div_equipment_page" class="container" style="margin-left:20px">';
    equipment_page += '<div class="row clearfix">';
    equipment_page += '<div class="col-md-6">';
    if ($("#input_changeLanguage").val() == "2") {
        equipment_page += '<h2>Special Settings</h2>';
    }
    else {
        equipment_page += '<h2>量仪特别设定</h2>';
    }
    equipment_page += '<div class="row clearfix" style="margin-top:40px">';
    equipment_page += '<div class="col-md-3">';
    if ($("#input_changeLanguage").val() == "2") {
        equipment_page += '<label style="margin-top:5px">Name：</label>';
    }
    else {
        equipment_page += '<label style="margin-top:5px">量仪名：</label>';
    }
    equipment_page += '</div>';
    equipment_page += '<div class="col-md-6">';
    equipment_page += '<input id="name_equipment_setting" type="text" class="form-control" value="HG" readonly="true" style="background-color:#F0F0F0; margin:0 48px 0 -48px"/>';
    equipment_page += '</div>';
    equipment_page += '</div>';
    equipment_page += '<div class="row clearfix" style="margin-top:20px">';
    equipment_page += '<div class="col-md-3">';
    if ($("#input_changeLanguage").val() == "2") {
        equipment_page += '<label id="label_special_measurement" style="margin-top:5px">Specially measure：</label>';
    }
    else {
        equipment_page += '<label id="label_special_measurement" style="margin-top:5px">特殊测量：</label>';
    }
    equipment_page += '</div>';
    equipment_page += '<div class="col-md-6">';
    equipment_page += '<div class="input-group" style="margin:0 48px 0 -48px">';
    equipment_page += '<div id="div_special_measurement" class="input-group-btn">';
    equipment_page += '<button id="btn_special_measurement" type="button" class="btn btn-default dropdown-toggle button" data-toggle="dropdown" style="height:34px" ><span class="caret"></span></button>';
    equipment_page += '<ul id="ul_special_measurement" class="dropdown-menu" style="max-height:140px;overflow:auto">';
    if ($("#input_changeLanguage").val() == "2") {
        equipment_page += '<li><a href="javascript:void(0)">Height Difference</a></li>';
        equipment_page += '<li><a href="javascript:void(0)">Pitch Row</a></li>';
    }
    else {
        equipment_page += '<li><a href="javascript:void(0)">高度差</a></li>';
        equipment_page += '<li><a href="javascript:void(0)">孔距</a></li>';
    }
    equipment_page += '</ul>';
    equipment_page += '</div>';
    if ($("#input_changeLanguage").val() == "2") {
        equipment_page += '<input id="input_special_measurement" type="text" class="form-control" value="Height Difference" style="background-color:#F0F0F0" readonly="true" />';
    }
    else {
        equipment_page += '<input id="input_special_measurement" type="text" class="form-control" value="高度差" style="background-color:#F0F0F0" readonly="true" />';
    }
    equipment_page += '</div>';
    equipment_page += '</div>';
    equipment_page += '</div>';
    equipment_page += '<div class="row clearfix" style="margin-top:20px">';
    equipment_page += '<div class="col-md-3">';
    if ($("#input_changeLanguage").val() == "2") {
        equipment_page += '<label style="margin-top:5px" id="label_repeated_measurement">Repeated measure：</label>';
    }
    else {
        equipment_page += '<label style="margin-top:5px" id="label_repeated_measurement">重复测量：</label>';
    }
    equipment_page += '</div>';
    equipment_page += '<div class="col-md-6" style="margin:0 48px 0 -48px">';
    equipment_page += '<div class="input-group">';
    equipment_page += '<div id="div_repeated_measurement" class="input-group-btn">';
    equipment_page += '<button id="btn_repeated_measurement" type="button" class="btn btn-default dropdown-toggle button" data-toggle="dropdown" style="height:34px" ><span class="caret"></span></button>';
    equipment_page += '<ul id="ul_repeated_measurement" class="dropdown-menu" style="max-height:140px;overflow:auto">';
    equipment_page += msg_ul;
    equipment_page += '</ul>';
    equipment_page += '</div>';
    equipment_page += '<input id="input_repeated_measurement" class="form-control" value="1" style="background-color:#F0F0F0" readonly="true"/>';
    equipment_page += '</div>';
    equipment_page += '</div>';
    equipment_page += '</div>';
    equipment_page += '<div class="row clearfix" style="margin-top:40px">';
    equipment_page += '<table id="table_special_measurement" class="table table-bordered">';
    equipment_page += '<tr>';
    equipment_page += '<td>';
    equipment_page += '<div class="select">';
    equipment_page += '<label class="radio-inline" id="td_special_measurement_1" >';
    if ($("#input_changeLanguage").val() == "2") {
        equipment_page += '<input name="face_to_face" id="radio_special_measurement_1" type="radio" checked="checked" /> Face to Face';
    }
    else {
        equipment_page += '<input name="face_to_face" id="radio_special_measurement_1" type="radio" checked="checked" /> 面对面';
    }
    equipment_page += '</label>';
    equipment_page += '</div>';
    equipment_page += '</td>';
    equipment_page += '<td id="middle_1"></td>';
    equipment_page += '<td id="last_1">';
    equipment_page += '<div class="select" id="div_gaoducha_point">';
    equipment_page += '<label class="radio-inline">';
    if ($("#input_changeLanguage").val() == "2") {
        equipment_page += '<input type="radio" name="Touch_point" id="Touch_one_point_1" checked="checked"/> One Point';
        equipment_page += '</label>';
        equipment_page += '<label class="radio-inline">';
        equipment_page += '<input type="radio" name="Touch_point" id="Touch_two_point_1"/> Two Points';
    }
    else {
        equipment_page += '<input type="radio" name="Touch_point" id="Touch_one_point_1" checked="checked"/> 碰1点';
        equipment_page += '</label>';
        equipment_page += '<label class="radio-inline">';
        equipment_page += '<input type="radio" name="Touch_point" id="Touch_two_point_1"/> 碰2点';
    }
    equipment_page += '</label>';
    equipment_page += '</div>';
    equipment_page += '</td>';
    equipment_page += '</tr>';
    equipment_page += '<tr style="height:35px">';
    equipment_page += '<td>';
    equipment_page += '<div class="select">';
    equipment_page += '<label class="radio-inline" id="td_special_measurement_2" >';
    if ($("#input_changeLanguage").val() == "2") {
        equipment_page += '<input name="face_to_face" id="radio_special_measurement_2" type="radio" /> Hole to Edge';
    }
    else {
        equipment_page += '<input name="face_to_face" id="radio_special_measurement_2" type="radio" /> 孔对边';
    }
    equipment_page += '</label>';
    equipment_page += '</div>';
    equipment_page += '</td>';
    equipment_page += '<td id="middle_2"></td>';
    equipment_page += '<td id="last_2"></td>';
    equipment_page += '</tr>';
    equipment_page += '</table>';
    equipment_page += '</div>';
    equipment_page += '</div>';
    equipment_page += '<div class="col-md-1 column">';
    if ($("#input_changeLanguage").val() == "2") {
        equipment_page += '<h3>graphic</h3>';
    }
    else {
        equipment_page += '<h3>图示</h3>';
    }
    equipment_page += '</div>';
    equipment_page += '<div class="col-md-5 column" style="margin:60px 0 0 -10px">';
    equipment_page += msg_img;
    equipment_page += '</div>';
    equipment_page += '</div>';
    equipment_page += '</div>';
    return equipment_page;
};

//量仪TG页面布局
function EquipmentPage_TG() {
    var equipment_page = '';
    if ($("#input_changeLanguage").val() == "2") {
        equipment_page += '<div class="container">';
        equipment_page += '<div class="row clearfix" >';
        equipment_page += '<h2 style="margin:25px 0 0 60px">Special Settings</h2>';
        equipment_page += '<hr /><div style="margin:-2px 0 25px 0">';
        equipment_page += '<div class="col-md-2"><label style="margin:6px 0 0 0">Name：</label></div>';
        equipment_page += '<div class="col-md-5"><input id="name_equipment_setting" type="text" class="form-control" value="TG" readonly="true" style="background-color:#F0F0F0;height:28px;width:80% "/></div>';
        equipment_page += '</div>';
        equipment_page += '<br /><hr />';
        equipment_page += '<div style="margin:20px 0 20px 0">';
        equipment_page += '<div class="col-md-2"><label>Types：</label></div>';
        equipment_page += '<div class="col-md-5" ><input type="radio" name="radio_name_TypeOfThread" id="radio_thread" checked="checked" />Screw Hole</div>';
        equipment_page += '<div class="col-md-5" ><input type="radio" name="radio_name_TypeOfThread" id="radio_bolt"/>Bolts/Outer Teeth</div>';
        equipment_page += '</div>';
        equipment_page += '<br /><hr />';
        equipment_page += '<div style="margin:10px 0 10px 0">';
        equipment_page += '<div class="col-md-2"><label>Standard：</label></div>';
        equipment_page += '<div class="col-md-5"><input type="radio" name="radio_name_StandardOfThread" id="radio_StandardOfThread_Simplified" checked="checked"/>ISO Thread (Metric)</div>';
        equipment_page += '<div class="col-md-2"><input type="radio" name="radio_name_StandardOfThread" id="radio_StandardOfThread_PRO"/>Professional</div>';
        equipment_page += '<div class="col-md-3">';
        equipment_page += '<div class="input-group" style="margin:-3px 0 0 -60px">';
        equipment_page += '<div id="div_StandardOfThread_PRO" class="input-group-btn">';
        equipment_page += '<button id="btn_StandardOfThread_PRO" type="button" class="btn btn-default dropdown-toggle button" data-toggle="dropdown" style="height:28px;background-color:#F0F0F0" disabled="disabled"><span class="caret"></span></button>';
        equipment_page += '<ul id="ul_StandardOfThread_PRO" class="dropdown-menu" style="max-height:140px;overflow:auto">';
        equipment_page += '</ul>';
        equipment_page += '</div>';
        equipment_page += '<input id="input_StandardOfThread_PRO" type="text" class="form-control" value="ISO Thread (Metric)" readonly="true" style="background-color:#F0F0F0;height:28px;width:80% "/>';
        equipment_page += '</div>';
        equipment_page += '</div>';
        equipment_page += '</div>';
        equipment_page += '<br /><hr />';
        equipment_page += '<div style="margin:10px 0 60px 0">';
        equipment_page += '<div class="col-md-2 column"><label style="margin-top:20px">Specification：</label></div>';
        equipment_page += '<div class="input-group col-md-5 column" style="margin-top:-4px">';
        equipment_page += '<span class="input-group-addon" >Quantity</span>';
        equipment_page += '<input id="input_ThreadNum" class="form-control" type="text" style="height:28px;width:80%" value="1PL" onkeyup="toUpperCase(this)"/>';
        equipment_page += '</div>';
        equipment_page += '<div class="input-group col-md-5 column" style="margin-top:-4px">';
        equipment_page += '<div id="div_ThreadPitch" class="input-group-btn">';
        equipment_page += '<button id="btn_ThreadPitch" type="button" class="btn btn-default dropdown-toggle button" data-toggle="dropdown" style="height:28px;padding:0 10px 0 10px" >The thread diameter <span class="caret"></span></button>';
        equipment_page += '<ul id="ul_ThreadPitch" class="dropdown-menu" style="max-height:140px;overflow:auto">';
        equipment_page += '</ul>';
        equipment_page += '</div>';
        equipment_page += '<input id="input_ThreadPitch" class="form-control" type="text" style="height:28px;width:80%;background-color:#F0F0F0" readonly="true"/>';
        equipment_page += '</div>';
        equipment_page += '<div class="col-md-5 column input-group" style="margin-top:15px">';
        equipment_page += '<span class="input-group-addon" style="padding:0 5px 0 7px">Length/Depth(DP)</span>';
        equipment_page += '<input id="input_ThreadDepth" type="text" class="form-control" style="height:28px;width:73%" onkeyup="toUpperCase(this)"/>';
        equipment_page += '</div>';
        //equipment_page += '<div class="col-md-5 column input-group" style="margin-top:15px">';
        //equipment_page += '<span class="input-group-addon" >Remark</span>';
        //equipment_page += '<input id="input_ThreadNote" type="text" class="form-control" style="height:28px;width:83%"/>';
        //equipment_page += '</div>';
        equipment_page += '<div class="col-md-5 column input-group" style="margin-top:15px">';//Modify by YZT 20190916 Let "THRU" be a checkbox
        equipment_page += '<input id="input_ThreadNote" type="checkbox" value="THRU"/>THRU';
        equipment_page += '</div>';//
        equipment_page += '</div>';
        equipment_page += '<br /><hr />';
        equipment_page += '<div>';
        equipment_page += '<div class="col-md-2" style="padding:0 0px 0 0; margin:0 0px 0 15px; width:10%;"><label id="label_thread_gauge">Thread plug gauge：</label></div>';
        equipment_page += '<div id="div_CodeContent" style="display:none"><input type="radio" name="radio_name_ThreadGauge" id="radio_CodeContent"  style="margin:9px 0px -25px 15px" checked="checked"/></div>';
        equipment_page += '<div class="col-md-5 column input-group" style="margin:0 1px 0 34px">';
        equipment_page += '<span class="input-group-addon" >GoGauge</span>';
        equipment_page += '<input id="input_GeneralCodeContent" type="text" class="form-control" readonly="true" style="background-color:#F0F0F0;height:28px;width:80%"/>';
        equipment_page += '</div>';
        equipment_page += '<div class="col-md-5 column input-group">';
        equipment_page += '<span class="input-group-addon" >NGgauge</span>';
        equipment_page += '<input id="input_StopCodeContent" type="text" class="form-control" readonly="true" style="background-color:#F0F0F0;height:28px;width:82%"/>';
        equipment_page += '</div>';
        equipment_page += '<br />';
        equipment_page += '<div id="div_AllowInput" style="display:none"><input type="radio" name="radio_name_ThreadGauge" id="radio_AllowInput" style="margin:10px 22px 0 104px"/>';
        equipment_page += '<label>Allow the user to enter the result, i.e. Pass or fail</label></div>';
        equipment_page += '</div>';
        equipment_page += '</div>';
        equipment_page += '</div>';
        equipment_page += '</div><hr />';
    }
    else {
        equipment_page += '<div class="container">';
        equipment_page += '<div class="row clearfix" >';
        equipment_page += '<h2 style="margin:25px 0 0 60px">量仪特别设定</h2>';
        equipment_page += '<hr /><div style="margin:-2px 0 25px 0">';
        equipment_page += '<div class="col-md-2"><label style="margin:6px 0 0 0">量仪名：</label></div>';
        equipment_page += '<div class="col-md-5"><input id="name_equipment_setting" type="text" class="form-control" value="TG" readonly="true" style="background-color:#F0F0F0;height:28px;width:80% "/></div>';
        equipment_page += '</div>';
        equipment_page += '<br /><hr />';
        equipment_page += '<div style="margin:20px 0 20px 0">';
        equipment_page += '<div class="col-md-2"><label>螺纹种类：</label></div>';
        equipment_page += '<div class="col-md-5" ><input type="radio" name="radio_name_TypeOfThread" id="radio_thread" checked="checked" />螺孔</div>';
        equipment_page += '<div class="col-md-5" ><input type="radio" name="radio_name_TypeOfThread" id="radio_bolt"/>螺栓/外牙</div>';
        equipment_page += '</div>';
        equipment_page += '<br /><hr />';
        equipment_page += '<div style="margin:10px 0 10px 0">';
        equipment_page += '<div class="col-md-2"><label>螺纹标准：</label></div>';
        equipment_page += '<div class="col-md-5"><input type="radio" name="radio_name_StandardOfThread" id="radio_StandardOfThread_Simplified" checked="checked"/>通用版/公制粗</div>';
        equipment_page += '<div class="col-md-2"><input type="radio" name="radio_name_StandardOfThread" id="radio_StandardOfThread_PRO"/>专业版</div>';
        equipment_page += '<div class="col-md-3">';
        equipment_page += '<div class="input-group" style="margin:-3px 0 0 -60px">';
        equipment_page += '<div id="div_StandardOfThread_PRO" class="input-group-btn">';
        equipment_page += '<button id="btn_StandardOfThread_PRO" type="button" class="btn btn-default dropdown-toggle button" data-toggle="dropdown" style="height:28px;background-color:#F0F0F0" disabled="disabled"><span class="caret"></span></button>';
        equipment_page += '<ul id="ul_StandardOfThread_PRO" class="dropdown-menu" style="max-height:140px;overflow:auto">';
        equipment_page += '</ul>';
        equipment_page += '</div>';
        equipment_page += '<input id="input_StandardOfThread_PRO" type="text" class="form-control" value="普通/粗" readonly="true" style="background-color:#F0F0F0;height:28px;width:80% "/>';
        equipment_page += '</div>';
        equipment_page += '</div>';
        equipment_page += '</div>';
        equipment_page += '<br /><hr />';
        equipment_page += '<div style="margin:10px 0 60px 0">';
        equipment_page += '<div class="col-md-2 column"><label style="margin-top:20px">规格：</label></div>';
        equipment_page += '<div class="input-group col-md-5 column" style="margin-top:-4px">';
        equipment_page += '<span class="input-group-addon" >数量</span>';
        equipment_page += '<input id="input_ThreadNum" class="form-control" type="text" style="height:28px;width:80%" value="1PL" onkeyup="toUpperCase(this)"/>';
        equipment_page += '</div>';
        equipment_page += '<div class="input-group col-md-5 column" style="margin-top:-4px">';
        equipment_page += '<div id="div_ThreadPitch" class="input-group-btn">';
        equipment_page += '<button id="btn_ThreadPitch" type="button" class="btn btn-default dropdown-toggle button" data-toggle="dropdown" style="height:28px;padding:0 10px 0 10px" >螺纹直径 <span class="caret"></span></button>';
        equipment_page += '<ul id="ul_ThreadPitch" class="dropdown-menu" style="max-height:140px;overflow:auto">';
        equipment_page += '</ul>';
        equipment_page += '</div>';
        equipment_page += '<input id="input_ThreadPitch" class="form-control" type="text" style="height:28px;width:80%;background-color:#F0F0F0" readonly="true"/>';
        equipment_page += '</div>';
        equipment_page += '<div class="col-md-5 column input-group" style="margin-top:15px">';
        equipment_page += '<span class="input-group-addon" style="padding:0 5px 0 7px">长度/深度(DP)</span>';
        equipment_page += '<input id="input_ThreadDepth" type="text" class="form-control" style="height:28px;width:73%" onkeyup="toUpperCase(this)"/>';
        equipment_page += '</div>';
        //equipment_page += '<div class="col-md-5 column input-group" style="margin-top:15px">';
        //equipment_page += '<span class="input-group-addon" >备注</span>';
        //equipment_page += '<input id="input_ThreadNote" type="text" class="form-control" style="height:28px;width:83%"/>';
        //equipment_page += '</div>';
        equipment_page += '<div class="col-md-5 column input-group" style="margin-top:15px">';//Modify by YZT 20190916 Let "THRU" be a checkbox
        equipment_page += '<input id="input_ThreadNote" type="checkbox" value="THRU"/>THRU';
        equipment_page += '</div>';//
        equipment_page += '</div>';
        equipment_page += '<br /><hr />';
        equipment_page += '<div>';
        equipment_page += '<div class="col-md-2" style="padding:0 0px 0 0; margin:0 0px 0 15px; width:10%;"><label id="label_thread_gauge">螺纹塞规：</label></div>';
        equipment_page += '<div id="div_CodeContent" style="display:none"><input type="radio" name="radio_name_ThreadGauge" id="radio_CodeContent"  style="margin:9px 0px -25px 15px" checked="checked"/></div>';
        equipment_page += '<div class="col-md-5 column input-group" style="margin:0 1px 0 34px">';
        equipment_page += '<span class="input-group-addon" >通规码</span>';
        equipment_page += '<input id="input_GeneralCodeContent" type="text" class="form-control" readonly="true" style="background-color:#F0F0F0;height:28px;width:80%"/>';
        equipment_page += '</div>';
        equipment_page += '<div class="col-md-5 column input-group">';
        equipment_page += '<span class="input-group-addon" >止规码</span>';
        equipment_page += '<input id="input_StopCodeContent" type="text" class="form-control" readonly="true" style="background-color:#F0F0F0;height:28px;width:82%"/>';
        equipment_page += '</div>';
        equipment_page += '<br />';
        equipment_page += '<div id="div_AllowInput" style="display:none"><input type="radio" name="radio_name_ThreadGauge" id="radio_AllowInput" style="margin:10px 22px 0 104px"/>';
        equipment_page += '<label>容许用户输入结果，即【pass】或【fail】</label></div>';
        equipment_page += '</div>';
        equipment_page += '</div>';
        equipment_page += '</div>';
        equipment_page += '</div><hr />';
    }

    return equipment_page;
};

//量仪HT/UM/VC页面布局
function EquipmentPage_HT(msg_ul) {
    var equipment_page = '';
    equipment_page += '<div id="div_equipment_page" class="container" style="margin-left:20px">';
    equipment_page += '<div class="row clearfix">';
    equipment_page += '<div class="col-md-12">';
    if ($("#input_changeLanguage").val() == "2") {
        equipment_page += '<h2>Special Settings</h2>';
    }
    else {
        equipment_page += '<h2>量仪特别设定</h2>';
    }
    equipment_page += '<div class="row clearfix" style="margin-top:40px">';
    equipment_page += '<div class="col-md-3">';
    if ($("#input_changeLanguage").val() == "2") {
        equipment_page += '<label style="margin-top:5px">Name：</label>';
    }
    else {
        equipment_page += '<label style="margin-top:5px">量仪名：</label>';
    }
    equipment_page += '</div>';
    equipment_page += '<div class="col-md-6">';
    equipment_page += '<input id="name_equipment_setting" type="text" class="form-control" value="HT" readonly="true" style="background-color:#F0F0F0; margin:0 48px 0 -48px"/>';
    equipment_page += '</div>';
    equipment_page += '</div>';
    equipment_page += '<div class="row clearfix" style="margin-top:20px">';
    equipment_page += '<div class="col-md-3">';
    if ($("#input_changeLanguage").val() == "2") {
        equipment_page += '<label id="label_special_measurement" style="margin-top:5px">Specially measure：</label>';
    }
    else {
        equipment_page += '<label id="label_special_measurement" style="margin-top:5px">特殊测量：</label>';
    }
    equipment_page += '</div>';
    equipment_page += '<div class="col-md-6" style="margin-left:-49px">';
    equipment_page += '<table id="table_special_measurement" class="table table-bordered">';
    equipment_page += '<tr>';
    equipment_page += '<td>';
    equipment_page += '<div class="select">';
    equipment_page += '<label class="radio-inline" id="label_average_HT" >';
    if ($("#input_changeLanguage").val() == "2") {
        equipment_page += '<input name="name_average_HT" id="name_average_HT" type="radio" checked="checked" /> Average';
    }
    else {
        equipment_page += '<input name="name_average_HT" id="name_average_HT" type="radio" checked="checked" /> 平均值';
    }
    equipment_page += '</label>';
    equipment_page += '</div>';
    equipment_page += '</td>';
    equipment_page += '<td>';
    equipment_page += '<div class="select">';
    equipment_page += '<label class="radio-inline" id="label_max_HT" >';
    if ($("#input_changeLanguage").val() == "2") {
        equipment_page += '<input name="name_average_HT" id="name_max_HT" type="radio"/>Maximum';
    }
    else {
        equipment_page += '<input name="name_average_HT" id="name_max_HT" type="radio"/> 最大';
    }
    equipment_page += '</label>';
    equipment_page += '</div>';
    equipment_page += '</td>';
    equipment_page += '<td>';
    equipment_page += '<div class="select">';
    equipment_page += '<label class="radio-inline" id="label_min_HT" >';
    if ($("#input_changeLanguage").val() == "2") {
        equipment_page += '<input name="name_average_HT" id="name_min_HT" type="radio"/> Minimum';
    }
    else {
        equipment_page += '<input name="name_average_HT" id="name_min_HT" type="radio"/> 最小';
    }
    equipment_page += '</label>';
    equipment_page += '</div>';
    equipment_page += '</td>';
    equipment_page += '</tr>';
    equipment_page += '</table>';
    equipment_page += '</div>';
    equipment_page += '</div>';
    equipment_page += '<div class="row clearfix">';
    equipment_page += '<div class="col-md-3">';
    if ($("#input_changeLanguage").val() == "2") {
        equipment_page += '<label style="margin-top:5px" id="label_repeated_measurement">Repeated measure：</label>';
    }
    else {
        equipment_page += '<label style="margin-top:5px" id="label_repeated_measurement">重复测量：</label>';
    }
    equipment_page += '</div>';
    equipment_page += '<div class="col-md-6" style="margin:0 48px 0 -48px">';
    equipment_page += '<div class="input-group">';
    equipment_page += '<div id="div_repeated_measurement" class="input-group-btn">';
    equipment_page += '<button id="btn_repeated_measurement" type="button" class="btn btn-default dropdown-toggle button" data-toggle="dropdown" style="height:34px" ><span class="caret"></span></button>';
    equipment_page += '<ul id="ul_repeated_measurement" class="dropdown-menu" style="max-height:140px;overflow:auto">';
    equipment_page += msg_ul;
    equipment_page += '</ul>';
    equipment_page += '</div>';
    equipment_page += '<input id="input_repeated_measurement" class="form-control" value="1" style="background-color:#F0F0F0" readonly="true"/>';
    equipment_page += '</div>';
    equipment_page += '</div>';
    equipment_page += '</div>';
    equipment_page += '</div>';
    equipment_page += '</div>';
    equipment_page += '</div>';
    return equipment_page;
};


//自动添加公差
function AutoAdd_gongcha(a, templateType, order, Upp_tol, Lwr_tol, checkbox_gongcha, input) {
    checkbox_gongcha = checkbox_gongcha + templateType;        //确定13级公差按钮id
    Upp_tol = "#" + templateType + Upp_tol + order;    //确定上公差id
    Lwr_tol = "#" + templateType + Lwr_tol + order;    //确定下公差id
    input = "#" + templateType + input + order;                //确定图纸规格输入框id
    //Add by YZT 20190916 For OT and TG, upp_tol/lwr_tol should be 1
    var input_Equipment_Value = "#" + templateType + "_input_equipment_" + order;
    if ($(input_Equipment_Value).val() == "自制量具(OT)" || $(input_Equipment_Value).val() == "螺纹规(TG)" || $(input_Equipment_Value).val() == "目测(VI)") {
        $(Upp_tol).val("1");
        $(Lwr_tol).val("1");
        return;
    } else if ($(input).val() == "") {
        return;
    } else {
        $(Upp_tol).val("+");
        $(Lwr_tol).val("-");
    }
    var gongchaValues = "";
    if ($(checkbox_gongcha).is(":checked")) {
        if (a > 0 && a <= 3) { gongchaValues = "0.07" }
        else if (a > 3 && a <= 6) { gongchaValues = "0.09" }
        else if (a > 6 && a <= 10) { gongchaValues = "0.11" }
        else if (a > 10 && a <= 18) { gongchaValues = "0.135" }
        else if (a > 18 && a <= 30) { gongchaValues = "0.165" }
        else if (a > 30 && a <= 50) { gongchaValues = "0.195" }
        else if (a > 50 && a <= 80) { gongchaValues = "0.23" }
        else if (a > 80 && a <= 120) { gongchaValues = "0.27" }
        else if (a > 120 && a <= 180) { gongchaValues = "0.315" }
        else if (a > 180 && a <= 250) { gongchaValues = "0.36" }
        else if (a > 250 && a <= 315) { gongchaValues = "0.405" }
        else if (a > 315 && a <= 400) { gongchaValues = "0.445" }
        else if (a > 400 && a <= 500) { gongchaValues = "0.485" }
        else if (a > 500 && a <= 630) { gongchaValues = "0.55" }
        else if (a > 630 && a <= 800) { gongchaValues = "0.625" }
        else if (a > 800 && a <= 1000) { gongchaValues = "0.7" }
        else if (a > 1000 && a <= 1250) { gongchaValues = "0.825" }
        else if (a > 1250 && a <= 1600) { gongchaValues = "0.975" }
        else if (a > 1600 && a <= 2000) { gongchaValues = "1.15" }
        else if (a > 2000 && a <= 2500) { gongchaValues = "1.4" }
        else if (a > 2500 && a <= 3150) { gongchaValues = "1.65" }
        else if (a > 3150) {
            if ($("#input_changeLanguage").val() == "2") {
                AlertWindow("The value you entered is too large！");
            }
            else {
                AlertWindow("您输入的数值过大！");
            }
        }
        else if (a == "") { }
        else { }
        $(Upp_tol).val("+" + gongchaValues);
        $(Lwr_tol).val("-" + gongchaValues);
    } else {
        var regex_symbol = new Array();
        //regex_symbol[0] = /^\d*\.?\d*±\d*\.?\d*$/;
        regex_symbol[1] = /^⊥\d*\.?\d*[A-Za-z]?$/;
        regex_symbol[2] = /^⫽\d*\.?\d*[A-Za-z]?$/;
        regex_symbol[3] = /^▱\d*\.?\d*[A-Za-z]?$/;
        regex_symbol[4] = /^―\d*\.?\d*[A-Za-z]?$/;
        regex_symbol[5] = /^⌯\d*\.?\d*[A-Za-z]?$/;
        regex_symbol[6] = /^〇\d*\.?\d*[A-Za-z]?$/;
        regex_symbol[7] = /^⌾\d*\.?\d*[A-Za-z]?$/;
        regex_symbol[8] = /^⌭\d*\.?\d*[A-Za-z]?$/;
        regex_symbol[9] = /^⌖\d*\.?\d*[A-Za-z]?$/;
        regex_symbol[10] = /^◠\d*\.?\d*[A-Za-z]?$/;
        regex_symbol[11] = /^⌓\d*\.?\d*[A-Za-z]?$/;
        regex_symbol[12] = /^⌔\d*\.?\d*[A-Za-z]?$/;
        regex_symbol[13] = /^↗\d*\.?\d*[A-Za-z]?$/;
        regex_symbol[14] = /^⌰\d*\.?\d*[A-Za-z]?$/;
        regex_symbol[15] = /^⌳\d*\.?\d*[A-Za-z]?$/;
        regex_symbol[16] = /^DP\d*\.?\d*$/;
        regex_symbol[17] = /^⌵\d*\.?\d*$/;
        regex_symbol[18] = /^⌴\d*\.?\d*$/;
        regex_symbol[19] = /^⌲\d*\.?\d*$/;
        regex_symbol[20] = /^℄\d*\.?\d*$/;
        regex_symbol[21] = /^\d*\.?\d*℃$/;
        regex_symbol[22] = /^RA\d*\.?\d*$/;
        regex_symbol[23] = /^\d*\.?\d*°$/;
        regex_symbol[24] = /^HRC\d*\.?\d*\~\d*\.?\d*$/;
        regex_symbol[25] = /^\d*\.?\d*Ω$/;
        regex_symbol[26] = /^VI\d*\.?\d*$/;
        regex_symbol[27] = /^∅\d*\.?\d*$/;
        regex_symbol[28] = /^\d*\.?\d*$/;

        var str = $(input).val();
        var serverData = "";
        if (str.indexOf("±") >= 0) {
            serverData = str.split("±");
            var Sample_plan = /^\d*\.?\d*$/;
            if (Sample_plan.test(serverData[1])) {
                $(Upp_tol).val("+" + serverData[1]);
                $(Lwr_tol).val("-" + serverData[1]);
            }
        }
        else if (str.indexOf("⊥") >= 0) {
            Automatically_add(str, Upp_tol, Lwr_tol);
        }
        else if (str.indexOf("⫽") >= 0) {
            Automatically_add(str, Upp_tol, Lwr_tol);
        }
        else if (str.indexOf("▱") >= 0) {
            Automatically_add(str, Upp_tol, Lwr_tol);
        }
        else if (str.indexOf("―") >= 0) {
            Automatically_add(str, Upp_tol, Lwr_tol);
        }
        else if (str.indexOf("⌯") >= 0) {
            Automatically_add(str, Upp_tol, Lwr_tol);
        }
        else if (str.indexOf("〇") >= 0) {
            Automatically_add(str, Upp_tol, Lwr_tol);
        }
        else if (str.indexOf("⌾") >= 0) {
            Automatically_add(str, Upp_tol, Lwr_tol);
        }
        else if (str.indexOf("⌭") >= 0) {
            Automatically_add(str, Upp_tol, Lwr_tol);
        }
        else if (str.indexOf("⌖") >= 0) {
            Automatically_add(str, Upp_tol, Lwr_tol);
        }
        else if (str.indexOf("⌒") >= 0) {
            Automatically_add(str, Upp_tol, Lwr_tol);
        }
        else if (str.indexOf("⌓") >= 0) {
            Automatically_add(str, Upp_tol, Lwr_tol);
        }
        else if (str.indexOf("⌔") >= 0) {
            Automatically_add(str, Upp_tol, Lwr_tol);
        }
        else if (str.indexOf("↗") >= 0) {
            Automatically_add(str, Upp_tol, Lwr_tol);
        }
        else if (str.indexOf("⌰") >= 0) {
            Automatically_add(str, Upp_tol, Lwr_tol);
        }
        else if (str.indexOf("⌳") >= 0) {
            Automatically_add(str, Upp_tol, Lwr_tol);
        }
        else if (regex_symbol[22].test(str)) {
            serverData = str.split("RA");
            $(Upp_tol).val("+" + serverData[1]);
            $(Lwr_tol).val(0);
        }
        else if (regex_symbol[24].test(str)) {
            gongchaValues = str.split("HRC");
            var HRCData = gongchaValues[1].split("~");
        }
        else if (regex_symbol[25].test(str)) {
        }
        else if (regex_symbol[26].test(str)) {
        }
        else if (regex_symbol[27].test(str)) {
        }
        else if (regex_symbol[28].test(str)) {
            //Add by YZT 20190916 For OT and TG, upp_tol/lwr_tol should be 1
            if ($(input_Equipment_Value).val() == "自制量具(OT)" || $(input_Equipment_Value).val() == "螺纹规(TG)" || $(input_Equipment_Value).val() == "目测(VI)") {
                $(Upp_tol).val("1");
                $(Lwr_tol).val("1");
            } else {
                $(Upp_tol).val("+");
                $(Lwr_tol).val("-");
            }
        }
        else {
        }
    }
};

//自动填充上下公差
function Automatically_add(str, Upp_tol, Lwr_tol) {
    var str1 = str.replace(/[^0-9.]/g, "");
    var num = str1.replace(/,/g, "");
    var Sample_plan = /^\d*\.?\d*$/;
    if (Sample_plan.test(num)) {
        $(Upp_tol).val("+" + num);
        $(Lwr_tol).val(0);
    }
};


//自动添加所有13级公差
function fillAllTolerance(templateType) {
    $("#" + templateType + "_table").on('click', "#checkbox_gongcha_" + templateType, function () {
        var $tl = $("#" + templateType + "_table tr");
        var $index = $tl.length;
        for (var i = 1; i < $index; i++) {
            if ($("#" + templateType + "_input_upper_limit_" + i).val() == "+") {
                var a = $("#" + templateType + "_input_symbol_" + i).val();

                if (a.indexOf("∅") >= 0 || a.indexOf("°") >= 0) {
                    var reg_input_symbol = /\d+\.?\d*/g;
                    a = a.match(reg_input_symbol);
                }
                var gongchaValues = "";
                if (a > 0 && a <= 3) { gongchaValues = "0.07" }
                else if (a > 3 && a <= 6) { gongchaValues = "0.09" }
                else if (a > 6 && a <= 10) { gongchaValues = "0.11" }
                else if (a > 10 && a <= 18) { gongchaValues = "0.135" }
                else if (a > 18 && a <= 30) { gongchaValues = "0.165" }
                else if (a > 30 && a <= 50) { gongchaValues = "0.195" }
                else if (a > 50 && a <= 80) { gongchaValues = "0.23" }
                else if (a > 80 && a <= 120) { gongchaValues = "0.27" }
                else if (a > 120 && a <= 180) { gongchaValues = "0.315" }
                else if (a > 180 && a <= 250) { gongchaValues = "0.36" }
                else if (a > 250 && a <= 315) { gongchaValues = "0.405" }
                else if (a > 315 && a <= 400) { gongchaValues = "0.445" }
                else if (a > 400 && a <= 500) { gongchaValues = "0.485" }
                else if (a > 500 && a <= 630) { gongchaValues = "0.55" }
                else if (a > 630 && a <= 800) { gongchaValues = "0.625" }
                else if (a > 800 && a <= 1000) { gongchaValues = "0.7" }
                else if (a > 1000 && a <= 1250) { gongchaValues = "0.825" }
                else if (a > 1250 && a <= 1600) { gongchaValues = "0.975" }
                else if (a > 1600 && a <= 2000) { gongchaValues = "1.15" }
                else if (a > 2000 && a <= 2500) { gongchaValues = "1.4" }
                else if (a > 2500 && a <= 3150) { gongchaValues = "1.65" }
                else if (a > 3150) {
                    if ($("#input_changeLanguage").val() == "2") {
                        AlertWindow("The value you entered is too large！");
                    }
                    else {
                        AlertWindow("您输入的数值过大！");
                    }
                }
                else if (a == "") { }
                else { }
                $("#" + templateType + "_input_upper_limit_" + i).val("+" + gongchaValues);
                $("#" + templateType + "_input_lower_limit_" + i).val("-" + gongchaValues);
            }
        }
    });
};


//弹出弹窗让用户选择创建哪种类型的返修
function windowForRw() {
    var bool_x = false;
    if ($("#input_changeLanguage").val() == "2") {
        $('#div_rw').dialog({
            title: 'Prompt',
            width: 400,
            height: 150,
            closed: false,
            modal: true,
            onClose: function () {
                if (bool_x == false) {
                    $('#checkbox_rw').attr('checked', false);
                    $('#rw_order').val('');
                    $('#Rw_seq').val('');
                    $('#add_rework_column').stop().fadeOut();
                }
            },
            buttons: [{
                id: 'btn-IM-WS',
                text: 'IM-WS',
                handler: function () {
                    bool_x = true;
                    $('#div_rw').dialog('close');
                    CreateRw('IM-WS');            //访问后台数据返回返修数据
                }
            }, {
                id: 'btn-IM-QC',
                text: 'IM-QC',
                handler: function () {
                    bool_x = true;
                    $('#div_rw').dialog('close');
                    CreateRw('IM-QC');
                }
            }, {
                id: 'btn-EM-SBC',
                text: 'EM-SBC',
                handler: function () {
                    bool_x = true;
                    $('#div_rw').dialog('close');
                    CreateRw('EM-SBC');
                }
            }, {
                id: 'btn-EM-QC',
                text: 'EM-QC',
                handler: function () {
                    bool_x = true;
                    $('#div_rw').dialog('close');
                    CreateRw('EM-QC');
                }
            }, {
                id: "conform_cancel",
                text: 'Cancel',
                handler: function () {
                    bool_x = false;
                    $('#div_rw').dialog('close');
                }
            }, ]
        })
        $('#div_rw').html("Please select the repair type:");
    }
    else {
        $('#div_rw').dialog({
            title: '提示',
            width: 400,
            height: 150,
            closed: false,
            modal: true,
            onClose: function () {
                if (bool_x == false) {
                    $('#checkbox_rw').attr('checked', false);
                    $('#rw_order').val('');
                    $('#Rw_seq').val('');
                    $('#add_rework_column').stop().fadeOut();
                }
            },
            buttons: [{
                id: 'btn-IM-WS',
                text: 'IM-WS',
                handler: function () {
                    bool_x = true;
                    $('#div_rw').dialog('close');
                    CreateRw('IM-WS');            //访问后台数据返回返修数据
                }
            }, {
                id: 'btn-IM-QC',
                text: 'IM-QC',
                handler: function () {
                    bool_x = true;
                    $('#div_rw').dialog('close');
                    CreateRw('IM-QC');
                }
            }, {
                id: 'btn-EM-SBC',
                text: 'EM-SBC',
                handler: function () {
                    bool_x = true;
                    $('#div_rw').dialog('close');
                    CreateRw('EM-SBC');
                }
            }, {
                id: 'btn-EM-QC',
                text: 'EM-QC',
                handler: function () {
                    bool_x = true;
                    $('#div_rw').dialog('close');
                    CreateRw('EM-QC');
                }
            }, {
                id: "conform_cancel",
                text: '取消',
                handler: function () {
                    bool_x = false;
                    $('#div_rw').dialog('close');
                }
            }, ]
        })
        $('#div_rw').html("请先选择返修类型是：");
    }

};

//访问后台数据返回返修数据
function CreateRw(rw_type) {
    $.post(
        "CreateTemplate.ashx",
        JSON.stringify([{
            "function": "CreateRw",
            "part_num": $('#part_num').val(),
            "part_rev": $('#part_rev').val(),
            "LinkTotemplateType": rw_type,
            "version": ""
        }]),
        function (data) {
            if (data["status"] == "fail") {
                if ($("#input_changeLanguage").val() == "2") {
                    AlertWindow(rw_type + " did not create " + $('#part_num').val() + " records. So it could not create repair records.");
                }
                else {
                    AlertWindow(rw_type + "没有创建" + $('#part_num').val() + "的记录,无法创建返修。");
                }
                $('#checkbox_rw').attr('checked', false);
                $('#rw_order').val('');
                $('#Rw_seq').val('');
                $('#add_rework_column').stop().fadeOut();
            }
            else {
                $('#input_RW_version').val(data["lastest_version"]);
                $('#RW_templateType').val(rw_type);
                var li_str = "";
                for (var version in data["version_list"]) {
                    li_str += "<li><a href='javascript:void(0)''>" + data["version_list"][version] + "</a></li>";
                }
                $('#ul_RW_version').append(li_str);
                BindEventForRW(rw_type, data);
                Get_QC_Parameter("RW");
            }
        });
};

//RW新行绑定事件
function BindEventForRW(rw_type, data) {
    var str_html = CreateRwTemplate(rw_type, data);
    $('#template_rw').append($(str_html));
    for (var i = 0; i < data["status"].length; i++) {
        BindEventWhenCreateNewRow("RW_table", "RW", parseInt(i) + 2);
    }
    //创建返修模板
    $("#btn_RW").click(function () {
        if ($('#rw_order').val() != "" && $('#Rw_seq').val() != "") {
            checkTemplateVersion($('#part_num').val(), $('#part_rev').val(), "RW");
        }
        else {
            if ($("#input_changeLanguage").val() == "2") {
                AlertWindow("Please enter the rework order number and serial number");
            }
            else {
                AlertWindow("请输入不良单号，序号");
            }
        }
    });
    //创建返修模板
    $("#btn_update_RW").click(function () {
        if ($('#rw_order').val() != "" && $('#Rw_seq').val() != "") {
            checkTemplateVersion($('#part_num').val(), $('#part_rev').val(), "RW");
        }
        else {
            if ($("#input_changeLanguage").val() == "2") {
                AlertWindow("Please enter the rework order number and serial number");
            }
            else {
                AlertWindow("请输入不良单号，序号");
            }
        }
    });
    AddRow("btn_add_RW", "RW_table", "RW");
}

//创建返修的模板
function CreateRwTemplate(templateType, data) {
    str_html = "";
    var Gn_type = data["status"][0]["Gn_type"] == null ? "" : data["status"][0]["Gn_type"];
    var Sap_rou_workcenter = data["status"][0]["Sap_rou_workcenter"] == null ? "" : data["status"][0]["Sap_rou_workcenter"];
    var Fixture_pn = data["status"][0]["Fixture_pn"] == null ? "" : data["status"][0]["Fixture_pn"];
    var Fixture_array = data["status"][0]["Fixture_array"] == null ? "" : data["status"][0]["Fixture_array"];
    var Tooling_Ipna = data["status"][0]["Tooling_Ipna"] == null ? "" : data["status"][0]["Tooling_Ipna"];
    if ($("#input_changeLanguage").val() == "2") {
        //WS模板
        if (templateType == "IM-WS" || templateType == 'EM-SBC') {
            str_html += '<div class="row clearfix">';
            str_html += '<div class="col-md-2">';
            str_html += '<div class="input-group">';
            str_html += '<span class="input-group-addon">Process</span>';
            str_html += '<input id="gn_type_RW" type="text" class="form-control" placeholder="Please enter the process." value="' + Gn_type + '"/>';
            str_html += '</div>';
            str_html += '</div>';
            str_html += '<div class="col-md-2">';
            str_html += '<div class="input-group">';
            str_html += '<span class="input-group-addon">Machine</span>';
            str_html += '<input id="SAP_rou_workcenter_RW" type="text" class="form-control" placeholder="Please select the machine type." value="' + Sap_rou_workcenter + '"/>';
            str_html += '</div>';
            str_html += '</div>';
            str_html += '<div class="col-md-2">';
            str_html += '<div class="input-group">';
            str_html += '<span class="input-group-addon">Fixture</span>';
            str_html += '<input id="fixture_pn_RW" type="text" class="form-control" placeholder="Please select the fixture." value="' + Fixture_pn + '"/>';
            str_html += '</div>';
            str_html += '</div>';
            str_html += '<div class="col-md-2">';
            str_html += '<div class="input-group">';
            str_html += '<span class="input-group-addon">Max Clamping Position</span>';
            str_html += '<input id="fixture_array_RW" type="text" class="form-control" placeholder="Please enter the max clamping position." value="' + Fixture_array + '"/>';
            str_html += '</div>';
            str_html += '</div>';
            str_html += '<div class="col-md-2">';
            str_html += '<div class="input-group">';
            str_html += '<span class="input-group-addon">Tool </span>';
            str_html += '<input id="tooling_ipna_RW" type="text" class="form-control" placeholder="Please select the tool." value="' + Tooling_Ipna + '"/>';
            str_html += '</div>';
            str_html += '</div>';
            str_html += '<div id="div_Update_Version_RW" class="col-md-2">';
            str_html += '<label style="color:Red;margin:7px 0 0 30px">';
            str_html += '<input id="Update_Version_RW" type="checkbox" /> Update/Modify';
            str_html += '</label>';
            str_html += '</div>';
            str_html += '</div>';
            str_html += '<br/>';
        }
            //QC模板
        else {
            str_html += '<div class="row clearfix">';
            //SAP标准工艺
            str_html += '<div class="col-md-3">';
            str_html += '<div class="input-group">';
            str_html += '<span class="input-group-addon">SAP Standard Process</span>';
            str_html += '<input id="input_SAP_rou_workcenter_RW" type="text" class="form-control"  value="' + Sap_rou_workcenter + '"/>';
            str_html += '</div>';
            str_html += '</div>';
            //量仪（首层量仪）
            str_html += '<div class="col-md-3">';
            str_html += '<div class="input-group">';
            str_html += '<div id="div_meas_eq_higher_RW" class="input-group-btn">';
            str_html += '<button type="button" class="btn btn-default dropdown-toggle button" data-toggle="dropdown" >Equipment <span class="caret"></span></button>';
            str_html += '<ul id="ul_meas_eq_higher_RW" class="dropdown-menu" style="max-height:300px;overflow:auto">';

            str_html += '</ul>';
            str_html += '</div>';
            str_html += '<input id="input_meas_eq_higher_RW" type="text" class="form-control" value=""/>';
            str_html += '</div>';
            str_html += '</div>';
            //保持原版
            str_html += '<div id="div_Update_Version_RW" class="col-md-2">';
            str_html += '<label style="color:Red;margin:7px 0 0 30px">';
            str_html += '<input id="Update_Version_RW" type="checkbox" /> Update/Modify';
            str_html += '</label>';
            str_html += '</div>';
            str_html += '</div>';
            str_html += '<br/>';
        }
        str_html += '<div class="row">';
        str_html += '<div class="col-md-12">';
        str_html += '<table class="table table-bordered" id="RW_table">';
        str_html += '<tr style="background-color:#eeeeee">';
        str_html += '<td>Num</td>';
        str_html += '<td>Link</td>';
        str_html += '<td>DrawingLabel</td>';
        str_html += '<td>';
        str_html += 'Specification';
        str_html += '&nbsp;';
        str_html += '&nbsp;';
        str_html += '&nbsp;';
        str_html += '<label style="color:red">';
        str_html += '<input type="checkbox" id="checkbox_gongcha_RW"/> 13 level of tolerance';
        str_html += '</label>';
        str_html += '</td>';
        str_html += '</td>';
        str_html += '<td>Equipment</td>';
        str_html += '<td>Check Num</td>';
        str_html += '<td>Remark</td>';
        str_html += '<td>';
        str_html += '</td>';
        str_html += '</tr>';
        str_html += newRowForRw("RW", data);
        str_html += '</table>';
        str_html += '</div>';
        str_html += '</div>';
        str_html += '<div id="div_create_RW" class="row" style="margin-left: 41%">';
        str_html += '<button id="btn_add_RW" name="test" type="button" class="btn btn-primary">Add New Row</button>';
        str_html += '<button type="button" class="btn btn-primary" id="btn_RW" style="margin-left:5px">Create Template</button>';
        str_html += '<button type="button" class="btn btn-primary" style="display:none;margin-left:5px" id="btn_update_RW" >Update Template</button>';
        str_html += '</div>';
    } else {
        //WS模板
        if (templateType == "IM-WS" || templateType == 'EM-SBC') {
            str_html += '<div class="row clearfix">';
            str_html += '<div class="col-md-2">';
            str_html += '<div class="input-group">';
            str_html += '<span class="input-group-addon">工序</span>';
            str_html += '<input id="gn_type_RW" type="text" class="form-control" placeholder="请输入工序" value="' + Gn_type + '"/>';
            str_html += '</div>';
            str_html += '</div>';
            str_html += '<div class="col-md-2">';
            str_html += '<div class="input-group">';
            str_html += '<span class="input-group-addon">机型</span>';
            str_html += '<input id="SAP_rou_workcenter_RW" type="text" class="form-control" placeholder="请输入机型" value="' + Sap_rou_workcenter + '"/>';
            str_html += '</div>';
            str_html += '</div>';
            str_html += '<div class="col-md-2">';
            str_html += '<div class="input-group">';
            str_html += '<span class="input-group-addon">夹具</span>';
            str_html += '<input id="fixture_pn_RW" type="text" class="form-control" placeholder="请输入夹具" value="' + Fixture_pn + '"/>';
            str_html += '</div>';
            str_html += '</div>';
            str_html += '<div class="col-md-2">';
            str_html += '<div class="input-group">';
            str_html += '<span class="input-group-addon">最大夹位</span>';
            str_html += '<input id="fixture_array_RW" type="text" class="form-control" placeholder="请输入夹具" value="' + Fixture_array + '"/>';
            str_html += '</div>';
            str_html += '</div>';
            str_html += '<div class="col-md-2">';
            str_html += '<div class="input-group">';
            str_html += '<span class="input-group-addon">刀具</span>';
            str_html += '<input id="tooling_ipna_RW" type="text" class="form-control" placeholder="请输入刀具" value="' + Tooling_Ipna + '"/>';
            str_html += '</div>';
            str_html += '</div>';
            str_html += '<div id="div_Update_Version_RW" class="col-md-2">';
            str_html += '<label style="color:Red;margin:7px 0 0 30px">';
            str_html += '<input id="Update_Version_RW" type="checkbox" /> 更新/修改';
            str_html += '</label>';
            str_html += '</div>';
            str_html += '</div>';
            str_html += '<br/>';
        }
            //QC模板
        else {
            str_html += '<div class="row clearfix">';
            //SAP标准工艺
            str_html += '<div class="col-md-3">';
            str_html += '<div class="input-group">';
            str_html += '<span class="input-group-addon">SAP标准工艺</span>';
            str_html += '<input id="input_SAP_rou_workcenter_RW" type="text" class="form-control" placeholder="请输入SAP标准工艺" value="' + Sap_rou_workcenter + '"/>';
            str_html += '</div>';
            str_html += '</div>';

            //量仪（首层量仪）
            str_html += '<div class="col-md-3">';
            str_html += '<div class="input-group">';
            str_html += '<div id="div_meas_eq_higher_RW" class="input-group-btn">';
            str_html += '<button type="button" class="btn btn-default dropdown-toggle button" data-toggle="dropdown" >量仪 <span class="caret"></span></button>';
            str_html += '<ul id="ul_meas_eq_higher_RW" class="dropdown-menu" style="max-height:300px;overflow:auto">';

            str_html += '</ul>';
            str_html += '</div>';
            str_html += '<input id="input_meas_eq_higher_RW" type="text" class="form-control" value=""/>';
            str_html += '</div>';
            str_html += '</div>';
            //保持原版
            str_html += '<div id="div_Update_Version_RW" class="col-md-2">';
            str_html += '<label style="color:Red;margin:7px 0 0 30px">';
            str_html += '<input id="Update_Version_RW" type="checkbox" /> 更新/修改';
            str_html += '</label>';
            str_html += '</div>';
            str_html += '</div>';
            str_html += '<br/>';
        }
        str_html += '<div class="row">';
        str_html += '<div class="col-md-12">';
        str_html += '<table class="table table-bordered" id="RW_table">';
        str_html += '<tr style="background-color:#eeeeee">';
        str_html += '<td>序号</td>';
        str_html += '<td>关联图库</td>';
        str_html += '<td>图标</td>';
        str_html += '<td>';
        str_html += '图纸规格';
        str_html += '&nbsp;';
        str_html += '&nbsp;';
        str_html += '&nbsp;';
        str_html += '<label style="color:red">';
        str_html += '<input type="checkbox" id="checkbox_gongcha_RW"/> 13级公差';
        str_html += '</label>';
        str_html += '</td>';
        str_html += '</td>';
        str_html += '<td>量仪</td>';
        str_html += '<td>抽检数量</td>';
        str_html += '<td>备注</td>';
        str_html += '<td>';
        str_html += '</td>';
        str_html += '</tr>';
        str_html += newRowForRw("RW", data);
        str_html += '</table>';
        str_html += '</div>';
        str_html += '</div>';
        str_html += '<div id="div_create_RW" class="row" style="margin-left: 41%">';
        str_html += '<button id="btn_add_RW" name="test" type="button" class="btn btn-primary">增加新行</button>';
        str_html += '<button type="button" class="btn btn-primary" id="btn_RW" style="margin-left:5px">创建模板</button>';
        str_html += '<button type="button" class="btn btn-primary" style="display:none;margin-left:5px" id="btn_update_RW" >更新模板</button>';
        str_html += '</div>';
    }


    return str_html;
};

// 返修新行html
function newRowForRw(templateType, data) {
    var add_tr = ""; //需要动态添加的行
    var str_li = "";
    var arr = new Array();
    for (var i = 0; i < data["status"].length; i++) {
        if (arr.indexOf(data["status"][i]["Dwg_label"]) < 0) {
            arr.push(data["status"][i]["Dwg_label"]);
        }
    }
    for (var i in arr) {
        str_li += "<li><a href='javascript:void(0)'>" + arr[i] + "</a></li>"
    }
    for (var num in data["status"]) {
        var Template_type = data["status"][num]["Template_type"] == null ? "" : data["status"][num]["Template_type"];
        var Gn_correl_enggdwg = data["status"][num]["Gn_correl_enggdwg"] == null ? "" : data["status"][num]["Gn_correl_enggdwg"];
        var Dwg_label = data["status"][num]["Dwg_label"] == null ? "" : data["status"][num]["Dwg_label"];
        var Dwg_spec = data["status"][num]["Dwg_spec"] == null ? "" : data["status"][num]["Dwg_spec"];
        var Upp_tol = data["status"][num]["Upp_tol"] == null ? "" : data["status"][num]["Upp_tol"];
        var Lwr_tol = data["status"][num]["Lwr_tol"] == null ? "" : data["status"][num]["Lwr_tol"];
        var Meas_eq = data["status"][num]["Meas_eq"] == null ? "" : data["status"][num]["Meas_eq"];
        var Eq_cal_code = data["status"][num]["Eq_cal_code"] == null ? "" : data["status"][num]["Eq_cal_code"];
        var Eq_col_pts = data["status"][num]["Eq_col_pts"] == null ? "" : data["status"][num]["Eq_col_pts"];
        var Check = data["status"][num]["Sample_plan"] == null ? "" : data["status"][num]["Sample_plan"];
        if (Check.indexOf("//") != -1) {
            var serverData = Check.split("//");
            var Check_way = Check == null ? "" : serverData[0];
            var Sample_plan = Check == null ? "" : serverData[1];
        }
        else {
            var Check_way = Check;
            var Sample_plan = "";

        }
        var Remark = data["status"][num]["Remark"] == null ? "" : data["status"][num]["Remark"];
        add_tr += "<tr id='" + templateType + "_tr_" + (parseInt(num) + 1).toString() + "' class='active'>";
        //第0列
        add_tr += "<td>" + (parseInt(num) + 1).toString() + "</td>";
        //第1列
        add_tr += "<td>";
        if (Gn_correl_enggdwg == "true") {
            add_tr += "<input name='checkbox_name' id='" + templateType + "_checkbox_link_" + (parseInt(num) + 1).toString() + "' type='checkbox' style='margin-top:15px;margin-left:15px' checked='checked'>";
        }
        else {
            add_tr += "<input name='checkbox_name' id='" + templateType + "_checkbox_link_" + (parseInt(num) + 1).toString() + "' type='checkbox' style='margin-top:15px;margin-left:16px'>";
        }
        add_tr += "</td>";
        //第2列
        add_tr += "<td>";
        if (Gn_correl_enggdwg == "true") {
            add_tr += '<div class="input-group" id="' + templateType + '_div_icon_' + (parseInt(num) + 1).toString() + '">';
        }
        else {
            add_tr += '<div class="input-group" id="' + templateType + '_div_icon_' + (parseInt(num) + 1).toString() + '">';
        }
        add_tr += '<div class="input-group-btn">';
        if ($("#input_changeLanguage").val() == "2") {
            add_tr += ' <button type="button" class="btn button btn-default dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> DrawingLable <span class="caret"></span></button>';
        }
        else {
            add_tr += ' <button type="button" class="btn button btn-default dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> 图标 <span class="caret"></span></button>';
        }
        add_tr += '<ul class="dropdown-menu" id="' + templateType + '_ul_icon_' + (parseInt(num) + 1).toString() + '">';
        add_tr += str_li;
        add_tr += '</ul>';
        add_tr += '</div>';
        if ($("#input_changeLanguage").val() == "2") {
            add_tr += "<input id='" + templateType + "_input_icon_" + (parseInt(num) + 1).toString() + "' type='text' class='form-control'  placeholder='Drawing Lable,like：CD1' value='" + Dwg_label + "'>";
        }
        else {
            add_tr += "<input id='" + templateType + "_input_icon_" + (parseInt(num) + 1).toString() + "' type='text' class='form-control'  placeholder='图标，例如：CD1' value='" + Dwg_label + "'>";
        }
        add_tr += '</div>';
        add_tr += "</td>";
        //第3列
        add_tr += "<td>";
        add_tr += "<div class='col-sm-9'>";
        add_tr += "<div class='input-group'>";
        add_tr += "<div class='input-group-btn'>";
        if ($("#input_changeLanguage").val() == "2") {
            add_tr += "<button type='button' class='btn button btn-default dropdown-toggle' data-toggle='dropdown'>Symbol  <span class='caret'></span></button>";
        }
        else {
            add_tr += "<button type='button' class='btn button btn-default dropdown-toggle' data-toggle='dropdown'>符号  <span class='caret'></span></button>";
        }
        add_tr += "<ul id='" + templateType + "_ul_symbol_" + (parseInt(num) + 1).toString() + "' class='dropdown-menu' style='max-height:300px;overflow:auto'>";
        add_tr += loadData('static/symbol.json', 'symbol');
        add_tr += "</ul>";
        add_tr += "</div>";
        if ($("#input_changeLanguage").val() == "2") {
            add_tr += "<input id='" + templateType + "_input_symbol_" + (parseInt(num) + 1).toString() + "' type='text' class='form-control' placeholder='Please fill in the drawing specification.' value='" + Dwg_spec + "'>";
        }
        else {
            add_tr += "<input id='" + templateType + "_input_symbol_" + (parseInt(num) + 1).toString() + "' type='text' class='form-control' placeholder='请填写尺寸信息' value='" + Dwg_spec + "'>";
        }
        add_tr += "</div>";
        add_tr += "</div>";
        add_tr += "<div class='col-sm-3'>";
        add_tr += "<div class='input-group' style='margin-top: 0px;margin-bottom: 2px;height: 18px;width: 100%;'>";
        add_tr += "<input class='form-control' id='" + templateType + "_input_upper_limit_" + (parseInt(num) + 1).toString() + "' type='text' value='" + Upp_tol + "' style='height:18px;width: 100%' />";
        add_tr += "</div>";
        add_tr += "<div class='input-group' style='margin-top: 0px;margin-bottom: 2px;height: 18px;width: 100%;'>";
        add_tr += '<input class="form-control" id="' + templateType + '_input_lower_limit_' + (parseInt(num) + 1).toString() + '" type="text" value="' + Lwr_tol + '" style="height:18px; width: 100%"/>';
        add_tr += "</div>";
        add_tr += "</div>";
        add_tr += "</td>";
        //第4列
        add_tr += "<td>";
        add_tr += "<div class='col-sm-10'>";
        add_tr += "<div class='input-group'>";
        add_tr += "<div class='input-group-btn'>";
        if ($("#input_changeLanguage").val() == "2") {
            add_tr += "<button type='button' class='btn button btn-default dropdown-toggle' data-toggle='dropdown'>Equipment <span class='caret'></span></button>";
        }
        else {
            add_tr += "<button type='button' class='btn button btn-default dropdown-toggle' data-toggle='dropdown'>量仪<span class='caret'></span></button>";
        }
        add_tr += "<ul id='" + templateType + "_ul_equipment_" + (parseInt(num) + 1).toString() + "' class='dropdown-menu' style='max-height:300px;overflow:auto'>";
        add_tr += loadData('static/equipment.json', 'equipment');
        add_tr += "</ul>";
        add_tr += "</div>";
        if ($("#input_changeLanguage").val() == "2") {
            add_tr += "<input id='" + templateType + "_input_equipment_" + (parseInt(num) + 1).toString() + "' type='text' class='form-control' placeholder='Please select the equipment.' value='" + Meas_eq + "'>";
        }
        else {
            add_tr += "<input id='" + templateType + "_input_equipment_" + (parseInt(num) + 1).toString() + "' type='text' class='form-control' placeholder='请选择量仪' value='" + Meas_eq + "'>";
        }
        add_tr += "</div>";
        add_tr += "</div>";
        add_tr += "<div class='col-sm-2'>";
        add_tr += "<div class='input-group'>";
        if ($("#input_changeLanguage").val() == "2") {
            add_tr += "<button type='button' id='" + templateType + "_btn_equipmentSetting_" + (parseInt(num) + 1).toString() + "' class='btn button btn-default' style='margin-left:-25px;padding:5px 5px 5px 5px'>Setting </button>";
        }
        else {
            add_tr += "<button type='button' id='" + templateType + "_btn_equipmentSetting_" + (parseInt(num) + 1).toString() + "' class='btn button btn-default' style='margin-left:-25px'>设定 </button>";
        }
        add_tr += "<input type='text' id='" + templateType + "_generated_code_" + (parseInt(num) + 1).toString() + "' style='display:none' value='" + Eq_cal_code + "' >";     //量仪设置内的合成码
        add_tr += "<input type='text' id='" + templateType + "_repeated_points_" + (parseInt(num) + 1).toString() + "' style='display:none' value='" + Eq_col_pts + "' >";    //量仪设置内的重复测量取点数
        add_tr += "</div>";
        add_tr += "</div>";
        add_tr += "</td>";

        //第5列
        add_tr += "<td>";
        add_tr += "<div class='input-group'>";
        add_tr += "<div class='input-group-btn'>";
        add_tr += "<button type='button' id='" + templateType + "_btn_checkWay_" + (parseInt(num) + 1).toString() + "' class='btn button btn-default dropdown-toggle' data-toggle='dropdown'>" + Check_way + "<span class='caret'></span></button>";
        add_tr += "<ul id='" + templateType + "_ul_checkWay_" + (parseInt(num) + 1).toString() + "' class='dropdown-menu' style='max-height:300px;overflow:auto'>";
        add_tr += loadData('static/checkWay_IM.json', 'checkWay');
        add_tr += "</ul>";
        add_tr += "</div>";
        add_tr += "<input id='" + templateType + "_input_checkWay_" + (parseInt(num) + 1).toString() + "' type='text' class='form-control' style='display:none' value='" + Check_way + "'>";
        if ($("#input_changeLanguage").val() == "2") {
            if (Sample_plan == "") {
                add_tr += "<input id='" + templateType + "_input_checkNum_" + (parseInt(num) + 1).toString() + "' type='text' class='form-control' readonly='true' placeholder='No need to fill in quantity.' value='" + Sample_plan + "'>";
            }
            else {
                add_tr += "<input id='" + templateType + "_input_checkNum_" + (parseInt(num) + 1).toString() + "' type='text' class='form-control' placeholder='Please fill in the quantity of random inspection.' value='" + Sample_plan + "'>";
            }
        }
        else {
            if (Sample_plan == "") {
                add_tr += "<input id='" + templateType + "_input_checkNum_" + (parseInt(num) + 1).toString() + "' type='text' class='form-control' readonly='true' placeholder='无需填写数量' value='" + Sample_plan + "'>";
            }
            else {
                add_tr += "<input id='" + templateType + "_input_checkNum_" + (parseInt(num) + 1).toString() + "' type='text' class='form-control' placeholder='请填写抽检数量' value='" + Sample_plan + "'>";
            }
        }
        add_tr += "</div>";
        add_tr += "</td>";
        if ($("#input_changeLanguage").val() == "2") {
            //第6列
            add_tr += "<td><input id='" + templateType + "_input_note_" + (parseInt(num) + 1).toString() + "' type='text' class='form-control' placeholder='Remark' value='" + Remark + "'></td>";
            //第7列
            add_tr += "<td><a id='" + templateType + "_a_delete_" + (parseInt(num) + 1).toString() + "' href='#'>Delete</a></td>";
        }
        else {
            //第8列
            add_tr += "<td><input id='" + templateType + "_input_note_" + (parseInt(num) + 1).toString() + "' type='text' class='form-control' placeholder='备注' value='" + Remark + "'></td>";
            //第9列
            add_tr += "<td><a id='" + templateType + "_a_delete_" + (parseInt(num) + 1).toString() + "' href='#'>删除</a></td>";
        }
        add_tr += "</tr>";
    }

    return add_tr;
};

//Add by YZT 20191112 用于各Value与text之间的对应转换
function rawDataMapping(rawData, type, target) {
    for (var item in rawData) {
        if (type == "equipment") {
            for (var i = 0; i < rawData[item].length; i++) {
                if (rawData[item][i].CodeName == target) {
                    if ($("#input_changeLanguage").val() == "2") {
                        return rawData[item][i].EnglishDescription + + "(" + rawData[item][i].CodeName + ")";
                    } else {
                        return rawData[item][i].ChineseDescription + "(" + rawData[item][i].CodeName + ")";
                    }
                }
            }
        }
    }
    return target
}

// 加载配置文件数据
function loadData(url_path, data_type) {
    var str = "";;
    var dropdown_data = "";
    $.ajax({
        url: url_path,
        async: false,
        dataType: "JSON",
        success: function (data) {
            str = data;
        }
    });
    if (data_type == "equipment_RawData") {//Add by YZT 20191112 返回用于对照
        return str;
    }
    for (var type in str) {
        dropdown_data += '<li role="separator" class="divider" style="margin:0px"></li>';
        dropdown_data += '<li style="font-size:16px;font-weight: bold;background-color:#cccccc">' + type + '</li>';
        dropdown_data += '<li role="separator" class="divider" style="margin:0px"></li>';
        for (var i = 0; i < str[type].length; i++) {
            dropdown_data += "<li>";
            if (data_type == "symbol") {                       //图纸规格
                dropdown_data += "<a href='javascript:void(0)'>";
                if ($("#input_changeLanguage").val() == "2") {
                    dropdown_data += str[type][i].meaning + "<span style='font-size:20px'>" + str[type][i].symbolShape + "</span>";
                }
                else {
                    dropdown_data += str[type][i].ChineseDescription + "<span style='font-size:20px'>" + str[type][i].symbolShape + "</span>";
                }
                dropdown_data += "</a>";
            }
            else if (data_type == "equipment")                  //量仪
            {
                dropdown_data += "<a href='javascript:void(0)'>";
                if ($("#input_changeLanguage").val() == "2") {
                    if (str[type][i].CodeName == "") {
                        dropdown_data += str[type][i].EnglishDescription;
                    }
                    else {
                        dropdown_data += str[type][i].EnglishDescription + "(" + str[type][i].CodeName + ")";
                    }
                }
                else {
                    if (str[type][i].CodeName == "") {
                        dropdown_data += str[type][i].ChineseDescription;
                    }
                    else {
                        dropdown_data += str[type][i].ChineseDescription + "(" + str[type][i].CodeName + ")";
                    }
                }
                dropdown_data += "</a>";
            }
            else if (data_type == "checkWay") {              //抽检数量
                dropdown_data += "<a href='javascript:void(0)'>";
                if ($("#input_changeLanguage").val() == "2") {
                    dropdown_data += str[type][i].checkway_en;
                }
                else {
                    dropdown_data += str[type][i].checkway;
                }
                dropdown_data += "</a>";
            }
            else if (data_type == "repeated") {              //同心度重复测量
                dropdown_data += "<a href='javascript:void(0)'>";
                dropdown_data += str[type][i].repeated;
                dropdown_data += "</a>";
            }
            else if (data_type == "qudian") {              //平行度取点
                dropdown_data += "<a href='javascript:void(0)'>";
                dropdown_data += str[type][i].qudian;
                dropdown_data += "</a>";
            }
            else if (data_type == "coarseThread") {
                dropdown_data += "<a href='javascript:void(0)'>";
                dropdown_data += str[type][i].coarseThread;  //普通/粗螺纹
                dropdown_data += "</a>";
            }
            else if (data_type == "fineThread") {
                dropdown_data += "<a href='javascript:void(0)'>";
                dropdown_data += str[type][i].fineThread;    //细螺纹
                dropdown_data += "</a>";
            }
            else if (data_type == "UNC") {
                dropdown_data += "<a href='javascript:void(0)'>";
                dropdown_data += str[type][i].UNC;           //美制粗螺紋/UNC
                dropdown_data += "</a>";
            }
            else if (data_type == "UNF") {
                dropdown_data += "<a href='javascript:void(0)'>";
                dropdown_data += str[type][i].UNF;           //美制细螺紋/UNF
                dropdown_data += "</a>";
            }
            else if (data_type == "UNEF") {
                dropdown_data += "<a href='javascript:void(0)'>";
                dropdown_data += str[type][i].UNEF;           //美制特细螺紋/UNEF
                dropdown_data += "</a>";
            }
            else if (data_type == "NPSC") {
                dropdown_data += "<a href='javascript:void(0)'>";
                dropdown_data += str[type][i].NPSC;           //美制平行管螺纹/NPSC
                dropdown_data += "</a>";
            }
            else if (data_type == "NPT") {
                dropdown_data += "<a href='javascript:void(0)'>";
                dropdown_data += str[type][i].NPT;           //美制锥管螺纹/NPT
                dropdown_data += "</a>";
            }
            else if (data_type == "BSW") {
                dropdown_data += "<a href='javascript:void(0)'>";
                dropdown_data += str[type][i].BSW;           //英制螺纹/惠氏粗螺纹/BSW/BS84
                dropdown_data += "</a>";
            }
            else if (data_type == "threadStandard") {
                dropdown_data += "<a href='javascript:void(0)'>";
                dropdown_data += str[type][i].threadStandard; //螺纹标准（专业版）
                dropdown_data += "</a>";
            }
            else if (data_type == "HT_repeated") {
                dropdown_data += "<a href='javascript:void(0)'>";
                dropdown_data += str[type][i].repeated;       //HT重复测量
                dropdown_data += "</a>";
            }
            else if (data_type == "UM_repeated") {
                dropdown_data += "<a href='javascript:void(0)'>";
                dropdown_data += str[type][i].repeated;       //HT重复测量
                dropdown_data += "</a>";
            }
            else if (data_type == "VC_repeated") {
                dropdown_data += "<a href='javascript:void(0)'>";
                dropdown_data += str[type][i].repeated;       //HT重复测量
                dropdown_data += "</a>";
            }
            else {
                dropdown_data += "<a href='javascript:void(0)'>";
                dropdown_data += "";
                dropdown_data += "</a>";
            };
            dropdown_data += "</li>";
        }
    }
    return dropdown_data;
}