﻿//该js文件包含所有在创建模板页面中动态创建新行时涉及到的方法和事件
//$("#input_changeLanguage").val() == "2" 时为英文状态，$("#input_changeLanguage").val() == "1" 时为中文状态

//动态添加行并绑定事件
function AddRow(add_id, table_name, templateType) {
    $('#div_create_' + templateType).on('click', '#' + add_id, function () {
        var str_html = ReplaceLabelID(table_name, templateType);
        $tr = $(str_html);
        $('#' + table_name).append($tr);
        SetRowNum(table_name); //设置行号
        $tl = $('#' + table_name + ' tr');
        $index = $tl.length;
        BindEventWhenCreateNewRow(table_name, templateType, $index);  //创建新行时绑定事件
    });
};

//替换标签ID
function ReplaceLabelID(table_name, templateType) {
    var add_tr = newRow(templateType);
    var $tr = $('#' + table_name + ' tr');
    var rownum = $tr.length;
    add_tr = resetID(add_tr, rownum, templateType);
    return add_tr;
};

//替换方法
function newRowReplace(str_html, rownum, Original_ID) {
    var reg_replace = new RegExp(Original_ID, "g");
    var str = Original_ID + String(rownum);
    return str_html.replace(reg_replace, str);
};

//删除时自动修改所有的id
function ChangeID(labels, table_name, templateType) {
    var $tr = $('#' + table_name + ' tr');
    var rownum = $tr.length;
    for (var i = 1; i < rownum; i++) {
        if (templateType == "IM-WS" || templateType == "RW" || templateType == "EM-SBC") {
            $tr.eq(i).attr('id', templateType + "_tr_" + i);
            $tr.eq(i).children("td:eq(1)").find('input').attr('id', templateType + "_checkbox_link_" + i);

            $tr.eq(i).children("td:eq(2)").find('div:eq(0)').attr('id', templateType + "_div_icon_" + i);
            $tr.eq(i).children("td:eq(2)").find('button').attr('id', templateType + "_btn_icon_" + i);
            $tr.eq(i).children("td:eq(2)").find('ul').attr('id', templateType + "_ul_icon_" + i);
            $tr.eq(i).children("td:eq(2)").find('input').attr('id', templateType + "_input_icon_" + i);

            $tr.eq(i).children("td:eq(3)").find('button').attr('id', templateType + "_btn_symbol_" + i);
            $tr.eq(i).children("td:eq(3)").find('ul').attr('id', templateType + "_ul_symbol_" + i);
            $tr.eq(i).children("td:eq(3)").find('input:eq(0)').attr('id', templateType + "_input_symbol_" + i);
            $tr.eq(i).children("td:eq(3)").find('input:eq(1)').attr('id', templateType + "_input_upper_limit_" + i);
            $tr.eq(i).children("td:eq(3)").find('input:eq(2)').attr('id', templateType + "_input_lower_limit_" + i);

            $tr.eq(i).children("td:eq(4)").find('button:eq(0)').attr('id', templateType + "_btn_equipment_" + i);
            $tr.eq(i).children("td:eq(4)").find('button:eq(1)').attr('id', templateType + "_btn_equipmentSetting_" + i);
            $tr.eq(i).children("td:eq(4)").find('ul').attr('id', templateType + "_ul_equipment_" + i);
            $tr.eq(i).children("td:eq(4)").find('input:eq(0)').attr('id', templateType + "_input_equipment_" + i);
            $tr.eq(i).children("td:eq(4)").find('input:eq(1)').attr('id', templateType + "_generated_code_" + i);
            $tr.eq(i).children("td:eq(4)").find('input:eq(2)').attr('id', templateType + "_repeated_points_" + i);

            $tr.eq(i).children("td:eq(5)").find('ul').attr('id', templateType + "_ul_checkWay_" + i);
            $tr.eq(i).children("td:eq(5)").find('button').attr('id', templateType + "_btn_checkWay_" + i);
            $tr.eq(i).children("td:eq(5)").find('input:eq(0)').attr('id', templateType + "_input_checkWay_" + i);
            $tr.eq(i).children("td:eq(5)").find('input:eq(1)').attr('id', templateType + "_input_checkNum_" + i);

            $tr.eq(i).children("td:eq(6)").find('input').attr('id', templateType + "_input_note_" + i);

            $tr.eq(i).children("td:eq(7)").find('a').attr('id', templateType + "_a_delete_" + i);
        }
        else {
            $tr.eq(i).attr('id', templateType + "_tr_" + i);

            $tr.eq(i).children("td:eq(1)").find('div:eq(0)').attr('id', templateType + "_div_icon_" + i);
            $tr.eq(i).children("td:eq(1)").find('button').attr('id', templateType + "_btn_icon_" + i);
            $tr.eq(i).children("td:eq(1)").find('ul').attr('id', templateType + "_ul_icon_" + i);
            $tr.eq(i).children("td:eq(1)").find('input').attr('id', templateType + "_input_icon_" + i);

            $tr.eq(i).children("td:eq(2)").find('button').attr('id', templateType + "_btn_symbol_" + i);
            $tr.eq(i).children("td:eq(2)").find('ul').attr('id', templateType + "_ul_symbol_" + i);
            $tr.eq(i).children("td:eq(2)").find('input:eq(0)').attr('id', templateType + "_input_symbol_" + i);
            $tr.eq(i).children("td:eq(2)").find('input:eq(1)').attr('id', templateType + "_input_upper_limit_" + i);
            $tr.eq(i).children("td:eq(2)").find('input:eq(2)').attr('id', templateType + "_input_lower_limit_" + i);

            $tr.eq(i).children("td:eq(3)").find('button:eq(0)').attr('id', templateType + "_btn_equipment_" + i);
            $tr.eq(i).children("td:eq(3)").find('button:eq(1)').attr('id', templateType + "_btn_equipmentSetting_" + i);
            $tr.eq(i).children("td:eq(3)").find('ul').attr('id', templateType + "_ul_equipment_" + i);
            $tr.eq(i).children("td:eq(3)").find('input:eq(0)').attr('id', templateType + "_input_equipment_" + i);
            $tr.eq(i).children("td:eq(3)").find('input:eq(1)').attr('id', templateType + "_generated_code_" + i);
            $tr.eq(i).children("td:eq(3)").find('input:eq(2)').attr('id', templateType + "_repeated_points_" + i);

            $tr.eq(i).children("td:eq(4)").find('ul').attr('id', templateType + "_ul_checkWay_" + i);
            $tr.eq(i).children("td:eq(4)").find('button').attr('id', templateType + "_btn_checkWay_" + i);
            $tr.eq(i).children("td:eq(4)").find('input:eq(0)').attr('id', templateType + "_input_checkWay_" + i);
            $tr.eq(i).children("td:eq(4)").find('input:eq(1)').attr('id', templateType + "_input_checkNum_" + i);

            $tr.eq(i).children("td:eq(5)").find('input').attr('id', templateType + "_input_note_" + i);

            $tr.eq(i).children("td:eq(6)").find('a').attr('id', templateType + "_a_delete_" + i);
        }

    }
};

//删除后重新设置各ID
function resetID(add_tr, rownum, templateType) {
    add_tr = newRowReplace(add_tr, rownum, templateType + "_tr_");               //新生成的tr的id
    add_tr = newRowReplace(add_tr, rownum, templateType + "_checkbox_link_");    //第1列checkbox的id     
    add_tr = newRowReplace(add_tr, rownum, templateType + "_div_icon_");         //第2列容器的ID
    add_tr = newRowReplace(add_tr, rownum, templateType + "_btn_icon_");          //第2列button的ID
    add_tr = newRowReplace(add_tr, rownum, templateType + "_ul_icon_");          //第2列ul的ID
    add_tr = newRowReplace(add_tr, rownum, templateType + "_input_icon_");       //第2列input标签的ID
    add_tr = newRowReplace(add_tr, rownum, templateType + "_btn_symbol_");        //第3列button标签的ID
    add_tr = newRowReplace(add_tr, rownum, templateType + "_ul_symbol_");        //第3列ul标签的ID
    add_tr = newRowReplace(add_tr, rownum, templateType + "_input_symbol_");     //第3列尺寸input标签的ID
    add_tr = newRowReplace(add_tr, rownum, templateType + "_input_upper_limit_"); //第3列上公差input标签的ID
    add_tr = newRowReplace(add_tr, rownum, templateType + "_input_lower_limit_"); //第3列下公差input标签的ID
    add_tr = newRowReplace(add_tr, rownum, templateType + "_ul_equipment_");     //第4列ul标签的ID
    add_tr = newRowReplace(add_tr, rownum, templateType + "_input_equipment_");  //第4列量仪input标签的ID
    add_tr = newRowReplace(add_tr, rownum, templateType + "_generated_code_");   //第4列合成码input标签的ID
    add_tr = newRowReplace(add_tr, rownum, templateType + "_repeated_points_");  //第4列重复测量取点数input标签的ID
    add_tr = newRowReplace(add_tr, rownum, templateType + "_btn_equipment_");         //第4列button的ID
    add_tr = newRowReplace(add_tr, rownum, templateType + "_btn_equipmentSetting_");  //第4列设置button的ID
    add_tr = newRowReplace(add_tr, rownum, templateType + "_btn_checkWay_");      //第6列btn标签的ID
    add_tr = newRowReplace(add_tr, rownum, templateType + "_ul_checkWay_");      //第6列ul标签的ID
    add_tr = newRowReplace(add_tr, rownum, templateType + "_input_checkWay_");   //第6列checkWay的ID
    add_tr = newRowReplace(add_tr, rownum, templateType + "_input_checkNum_");   //第6列checkNum的ID
    add_tr = newRowReplace(add_tr, rownum, templateType + "_input_note_");       //第7列input标签的ID
    add_tr = newRowReplace(add_tr, rownum, templateType + "_a_delete_");         //第8列a标签的ID
    return add_tr;
};

//重新设置编号 
function SetRowNum(table_name) {
    var $tr = $('#' + table_name + ' tr');
    var rownum = $tr.length;
    for (var i = 1; i < rownum; i++) {
        var td_seq = $tr.eq(i).find("td:eq(0)");
        td_seq.html(String(i));
    }
};


//表格动态添加的新行html
function newRow(templateType) {
    if ($("#input_changeLanguage").val() == "2") {
        var add_tr = "";

        //每一行的id
        add_tr += "<tr id='" + templateType + "_tr_' class='active'>";

        //第0列：每行开头处的编号
        add_tr += "<td>1</td>";

        //第一列
        if (templateType == "IM-QC" || templateType == "EM-QC") {
        }
        else if (templateType == "IM-WS" || templateType == "EM-SBC") {
            add_tr += "<td>";
            add_tr += "<input name='checkbox_name' id='" + templateType + "_checkbox_link_' type='checkbox' style='margin-top:15px;margin-left:-3px'>";
            add_tr += "</td>";
        }
        else {
            add_tr += "<td>";
            add_tr += "<input name='checkbox_name' id='" + templateType + "_checkbox_link_' type='checkbox' style='margin-top:15px;margin-left:-3px'>";
            add_tr += "</td>";
        }

        //第二列
        add_tr += "<td>";
        if (templateType == "IM-WS" || templateType == "EM-SBC") {
            add_tr += '<div class="input-group" id="' + templateType + '_div_icon_">';
            add_tr += '<div class="input-group-btn">';
            add_tr += '<button type="button" id="' + templateType + '_btn_icon_" class="btn button btn-default dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">DrawingLable <span class="caret"></span></button>';
            add_tr += '<ul class="dropdown-menu" id="' + templateType + '_ul_icon_">';
            add_tr += '</ul>';
            add_tr += '</div>';
            add_tr += "<input id='" + templateType + "_input_icon_' type='text' class='form-control'  placeholder='Drawing Lable,like：CD1' value='' onkeyup='toUpperCase(this)'>";
            add_tr += '</div>';
        }
        else if (templateType == "IM-QC" || templateType == "EM-QC" || templateType == "RW") {
            add_tr += "<input id='" + templateType + "_input_icon_' type='text' class='form-control'  placeholder='Drawing Lable,like：CD1' value='' onkeyup='toUpperCase(this)'>";
        }
        else {
            add_tr += "";
        }
        add_tr += "</td>";

        //第三列：填写图纸规格
        add_tr += "<td>";
        //填写图纸规格
        add_tr += "<div class='col-sm-9'>";
        add_tr += "<div class='input-group'>";
        add_tr += "<div class='input-group-btn'>";
        add_tr += "<button type='button' id='" + templateType + "_btn_symbol_' class='btn button btn-default dropdown-toggle' data-toggle='dropdown'>Symbol <span class='caret'></span></button>";
        add_tr += "<ul id='" + templateType + "_ul_symbol_' class='dropdown-menu' style='max-height:300px;overflow:auto'>";
        add_tr += loadData('static/symbol.json', 'symbol');
        add_tr += "</ul>";
        add_tr += "</div>";
        //add_tr += "<input id='" + templateType + "_input_symbol_' type='text' class='form-control' placeholder='Please fill in the drawing specification.' value='' onkeyup='toUpperCase(this)'>";
        add_tr += "<input id='" + templateType + "_input_symbol_' type='text' class='form-control' placeholder='Please fill in the drawing specification.' value='' onBlur='toUpperCase(this)'>"; //By YZT 20191209
        add_tr += "</div>";
        add_tr += "</div>";
        //自动填写上下公差和符号名称
        add_tr += "<div class='col-sm-3'>";
        add_tr += "<div class='input-group' style='margin-top: 0px;margin-bottom: 2px;height: 18px;width: 100%;'>";
        //add_tr +='<span class="input-group-addon" id="basic-addon1" style="padding:2px 10px;font-size:9px">+</span>';
        add_tr += '<input class="form-control" id="' + templateType + '_input_upper_limit_" type="text" style="height:18px;width: 100%" />';    //上公差
        add_tr += "</div>";
        add_tr += "<div class='input-group' style='margin-top: 0px;margin-bottom: 2px;height: 18px;width: 100%;'>";
        //add_tr +='<span class="input-group-addon" id="basic-addon1" style="padding:2px 12px;font-size:9px">-</span>';
        add_tr += '<input class="form-control" id="' + templateType + '_input_lower_limit_" type="text"  style="height:18px; width: 100%"/>';    //下公差
        add_tr += "</div>";
        add_tr += "</div>";
        add_tr += "</td>";

        //第四列：选择量仪
        add_tr += "<td>";
        add_tr += "<div class='col-sm-10'>";
        add_tr += "<div class='input-group'>";
        add_tr += "<div class='input-group-btn'>";
        add_tr += "<button type='button' id='" + templateType + "_btn_equipment_' class='btn button btn-default dropdown-toggle' data-toggle='dropdown'>Equipment<span class='caret'></span></button>";
        add_tr += "<ul id='" + templateType + "_ul_equipment_' class='dropdown-menu' style='max-height:300px;overflow:auto'>";
        add_tr += loadData('static/equipment.json', 'equipment');
        add_tr += "</ul>";
        add_tr += "</div>";
        add_tr += "<input id='" + templateType + "_input_equipment_' type='text' class='form-control' placeholder='Please select the equipment.' value='Height Gauge(HG)'>";
        add_tr += "</div>";
        add_tr += "</div>";
        add_tr += "<div class='col-sm-2'>";
        add_tr += "<div class='input-group'>";
        add_tr += "<button type='button' id='" + templateType + "_btn_equipmentSetting_' class='btn button btn-default' style='margin-left:-25px;padding:5px 5px 5px 5px'>Setting </button>";
        add_tr += "<input type='text' id='" + templateType + "_generated_code_' style='display:none' >";     //量仪设置内的合成码
        add_tr += "<input type='text' id='" + templateType + "_repeated_points_' style='display:none' >";    //量仪设置内的重复测量取点数
        add_tr += "</div>";
        add_tr += "</div>";
        add_tr += "</td>";

        //第五列：选择抽检方法
        add_tr += "<td>";
        add_tr += "<div class='input-group'>";
        add_tr += "<div class='input-group-btn'>";
        add_tr += "<button type='button' id='" + templateType + "_btn_checkWay_' class='btn button btn-default dropdown-toggle' data-toggle='dropdown'>Method<span class='caret'></span></button>";
        add_tr += "<ul id='" + templateType + "_ul_checkWay_' class='dropdown-menu' style='max-height:300px;overflow:auto'>";
        if (templateType == "EM-SBC" || templateType == "EM-QC") {
            add_tr += loadData('static/checkWay_EM.json', 'checkWay');
        }
        else {
            add_tr += loadData('static/checkWay_IM.json', 'checkWay');
        }
        add_tr += "</ul>";
        add_tr += "</div>";
        add_tr += "<input id='" + templateType + "_input_checkWay_' type='text' class='form-control' style='display:none' value='Method'>";
        add_tr += "<input id='" + templateType + "_input_checkNum_' type='text' class='form-control' placeholder='Please fill in the quantity of random inspection.' value=''>";
        add_tr += "</div>";
        add_tr += "</td>";

        //第六列：备注
        add_tr += "<td><input id='" + templateType + "_input_note_' type='text' class='form-control' placeholder='Note' value=''></td>";

        //第七列：删除
        add_tr += "<td><a id='" + templateType + "_a_delete_' href='#'>Delete</a></td>";
        add_tr += "</tr>";
        return add_tr;
    }
    else {
        var add_tr = "";

        //每一行的id
        add_tr += "<tr id='" + templateType + "_tr_' class='active'>";

        //第0列：每行开头处的编号
        add_tr += "<td>1</td>";

        //第一列
        if (templateType == "IM-QC" || templateType == "EM-QC") {
        }
        else if (templateType == "IM-WS" || templateType == "EM-SBC") {
            add_tr += "<td>";
            add_tr += "<input name='checkbox_name' id='" + templateType + "_checkbox_link_' type='checkbox' style='margin-top:15px;margin-left:-3px'>";
            add_tr += "</td>";
        }
        else {
            add_tr += "<td>";
            add_tr += "<input name='checkbox_name' id='" + templateType + "_checkbox_link_' type='checkbox' style='margin-top:15px;margin-left:-3px'>";
            add_tr += "</td>";
        }

        //第二列
        add_tr += "<td>";
        if (templateType == "IM-WS" || templateType == "EM-SBC") {
            add_tr += '<div class="input-group" id="' + templateType + '_div_icon_">';
            add_tr += '<div class="input-group-btn">';
            add_tr += '<button type="button" id="' + templateType + '_btn_icon_" class="btn button btn-default dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">图标<span class="caret"></span></button>';
            add_tr += '<ul class="dropdown-menu" id="' + templateType + '_ul_icon_">';
            add_tr += '</ul>';
            add_tr += '</div>';
            add_tr += "<input id='" + templateType + "_input_icon_' type='text' class='form-control'  placeholder='图标，例如：CD1' value='' onkeyup='toUpperCase(this)'>";
            add_tr += '</div>';
        }
        else if (templateType == "IM-QC" || templateType == "EM-QC" || templateType == "RW") {
            add_tr += "<input id='" + templateType + "_input_icon_' type='text' class='form-control'  placeholder='图标，例如：CD1' value='' onkeyup='toUpperCase(this)'>";
        }
        else {
            add_tr += "";
        }
        add_tr += "</td>";

        //第三列：填写图纸规格
        add_tr += "<td>";
        //填写图纸规格
        add_tr += "<div class='col-sm-9'>";
        add_tr += "<div class='input-group'>";
        add_tr += "<div class='input-group-btn'>";
        add_tr += "<button type='button' id='" + templateType + "_btn_symbol_' class='btn button btn-default dropdown-toggle' data-toggle='dropdown'>符号  <span class='caret'></span></button>";
        add_tr += "<ul id='" + templateType + "_ul_symbol_' class='dropdown-menu' style='max-height:300px;overflow:auto'>";
        add_tr += loadData('static/symbol.json', 'symbol');
        add_tr += "</ul>";
        add_tr += "</div>";
        //add_tr += "<input id='" + templateType + "_input_symbol_' type='text' class='form-control' placeholder='请填写尺寸信息' value='' onkeyup='toUpperCase(this)'>";
        add_tr += "<input id='" + templateType + "_input_symbol_' type='text' class='form-control' placeholder='请填写尺寸信息' value='' onBlur='toUpperCase(this)'>"; //By YZT 20191209
        add_tr += "</div>";
        add_tr += "</div>";
        //自动填写上下公差和符号名称
        add_tr += "<div class='col-sm-3'>";
        add_tr += "<div class='input-group' style='margin-top: 0px;margin-bottom: 2px;height: 18px;width: 100%;'>";
        //add_tr +='<span class="input-group-addon" id="basic-addon1" style="padding:2px 10px;font-size:9px">+</span>';
        add_tr += '<input class="form-control" id="' + templateType + '_input_upper_limit_" type="text"  style="height:18px;width: 100%" />';    //上公差
        add_tr += "</div>";
        add_tr += "<div class='input-group' style='margin-top: 0px;margin-bottom: 2px;height: 18px;width: 100%;'>";
        //add_tr +='<span class="input-group-addon" id="basic-addon1" style="padding:2px 12px;font-size:9px">-</span>';
        add_tr += '<input class="form-control" id="' + templateType + '_input_lower_limit_" type="text"  style="height:18px; width: 100%"/>';    //下公差
        add_tr += "</div>";
        add_tr += "</div>";
        add_tr += "</td>";

        //第四列：选择量仪
        add_tr += "<td>";
        add_tr += "<div class='col-sm-10'>";
        add_tr += "<div class='input-group'>";
        add_tr += "<div class='input-group-btn'>";
        add_tr += "<button type='button' id='" + templateType + "_btn_equipment_' class='btn button btn-default dropdown-toggle' data-toggle='dropdown'>量仪<span class='caret'></span></button>";
        add_tr += "<ul id='" + templateType + "_ul_equipment_' class='dropdown-menu' style='max-height:300px;overflow:auto'>";
        add_tr += loadData('static/equipment.json', 'equipment');
        add_tr += "</ul>";
        add_tr += "</div>";
        add_tr += "<input id='" + templateType + "_input_equipment_' type='text' class='form-control' placeholder='请选择量仪' value='高度尺(HG)'>";
        add_tr += "</div>";
        add_tr += "</div>";
        add_tr += "<div class='col-sm-2'>";
        add_tr += "<div class='input-group'>";
        add_tr += "<button type='button' id='" + templateType + "_btn_equipmentSetting_' class='btn button btn-default' style='margin-left:-25px'>设定 </button>";
        add_tr += "<input type='text' id='" + templateType + "_generated_code_' style='display:none' >";     //量仪设置内的合成码
        add_tr += "<input type='text' id='" + templateType + "_repeated_points_' style='display:none' >";    //量仪设置内的重复测量取点数
        add_tr += "</div>";
        add_tr += "</div>";
        add_tr += "</td>";

        //第五列：选择抽检方法
        add_tr += "<td>";
        add_tr += "<div class='input-group'>";
        add_tr += "<div class='input-group-btn'>";
        add_tr += "<button type='button' id='" + templateType + "_btn_checkWay_' class='btn button btn-default dropdown-toggle' data-toggle='dropdown'>方法<span class='caret'></span></button>";
        add_tr += "<ul id='" + templateType + "_ul_checkWay_' class='dropdown-menu' style='max-height:300px;overflow:auto'>";
        if (templateType == "EM-SBC" || templateType == "EM-QC") {
            add_tr += loadData('static/checkWay_EM.json', 'checkWay');
        }
        else {
            add_tr += loadData('static/checkWay_IM.json', 'checkWay');
        }
        add_tr += "</ul>";
        add_tr += "</div>";
        add_tr += "<input id='" + templateType + "_input_checkWay_' type='text' class='form-control' style='display:none' value='方法'>";
        add_tr += "<input id='" + templateType + "_input_checkNum_' type='text' class='form-control' placeholder='请填写抽检数量' value=''>";
        add_tr += "</div>";
        add_tr += "</td>";

        //第六列：备注
        add_tr += "<td><input id='" + templateType + "_input_note_' type='text' class='form-control' placeholder='备注' value=''></td>";

        //第七列：删除
        add_tr += "<td><a id='" + templateType + "_a_delete_' href='#'>删除</a></td>";
        add_tr += "</tr>";
        return add_tr;
    }
};

//创建新行时绑定事件
function BindEventWhenCreateNewRow(table_name, templateType, $index) {

    //QC首层量仪的数值添加至各行
    if ($("#input_meas_eq_higher_" + templateType).val() != "") {
        if (templateType == "IM-QC" || templateType == "EM-SBC" || templateType == "EM-QC") {
            $("#" + templateType + "_input_equipment_" + String($index - 1)).val($("#input_meas_eq_higher_" + templateType).val())
        }
    } else {

    }

    //首层检查方式及计划添加至各行
    if ($('#input_checkWay_higher_' + templateType).val() != "方法") {
        var checkWay = $('#input_checkWay_higher_' + templateType).val();
        if (templateType == "IM-QC" || templateType == "EM-SBC" || templateType == "EM-QC") {
            $('#' + templateType + '_btn_checkWay_' + String($index - 1)).replaceWith(
                '<button type="button" id="' + templateType + '_btn_checkWay_' + String($index - 1)
                + '" class="btn button btn-default dropdown-toggle" data-toggle="dropdown">'
                + $('#input_checkWay_higher_' + templateType).val() + '<span class="caret"></span></button>');
            $('#' + templateType + '_input_checkWay_' + String($index - 1)).val(checkWay);
            if ($("#input_changeLanguage").val() == "2") {
                if (checkWay == "All inspection" || checkWay == "Sampling plan" || checkWay == "Sampling plan(tighten up)" || checkWay == "AQL0.65" || checkWay == "AQL1.0") {
                    $('#' + templateType + '_input_checkNum_' + String($index - 1)).replaceWith('<input id="" type="text" readonly="true" class="form-control" placeholder="No need to fill in quantity." value="" />')
                } else {
                    $('#' + templateType + '_input_checkNum_' + String($index - 1)).replaceWith(
                        '<input id="' + templateType + '_input_checkNum_' + String($index - 1)
                        + '" type="text" class="form-control" placeholder="Please fill in the quantity of random inspection." value="'
                        + $('#input_checkNum_higher_' + templateType).val() + '" />'
                        )
                }
            } else {
                if (checkWay == "全检" || checkWay == "抽检计划" || checkWay == "抽检计划-加严" || checkWay == "AQL0.65" || checkWay == "AQL1.0") {
                    $('#' + templateType + '_input_checkNum_' + String($index - 1)).replaceWith('<input id="" type="text" readonly="true" class="form-control" placeholder="无需填写数量" value="" />');
                } else {
                    $('#' + templateType + '_input_checkNum_' + String($index - 1)).replaceWith(
                        '<input id="' + templateType + '_input_checkNum_' + String($index - 1)
                        + '" type="text" class="form-control" placeholder="请填写抽检数量" value="'
                        + $('#input_checkNum_higher_' + templateType).val() + '" />'
                        )
                }
            }
        }
    } else {

    }

    //EM-SBC添加默认事件
    if (templateType == "EM-SBC") {
        if ($("#input_changeLanguage").val() == "2") {
            $("#EM-SBC_btn_checkWay_" + String($index - 1)).replaceWith("<button type='button' id='EM-SBC_btn_checkWay_" + String($index - 1) + "' class='btn button btn-default dropdown-toggle' data-toggle='dropdown'>All inspection<span class='caret'></span></button>");
            $("#EM-SBC_input_checkWay_" + String($index - 1)).attr("value", "All inspection");
            $("#EM-SBC_input_checkNum_" + String($index - 1)).replaceWith("<input id='EM-SBC_input_checkNum_" + String($index - 1) + "' type='text' readonly='true' class='form-control' placeholder='No need to fill in quantity.' value=''>");
        }
        else {
            $("#EM-SBC_btn_checkWay_" + String($index - 1)).replaceWith("<button type='button' id='EM-SBC_btn_checkWay_" + String($index - 1) + "' class='btn button btn-default dropdown-toggle' data-toggle='dropdown'>全检<span class='caret'></span></button>");
            $("#EM-SBC_input_checkWay_" + String($index - 1)).attr("value", "全检");
            $("#EM-SBC_input_checkNum_" + String($index - 1)).replaceWith("<input id='EM-SBC_input_checkNum_" + String($index - 1) + "' type='text' readonly='true' class='form-control' placeholder='无需填写数量' value=''>");
        }
    }
    else {
    }

    //绑定动态生成的标签的事件，需要绑定元素的父元素，此父元素必须为静态元素
    //绑定之前先解除绑定
    $('#' + table_name).off('click', "#" + templateType + "_a_delete_" + String($index - 1))
    $('#' + table_name).on('click', "#" + templateType + "_a_delete_" + String($index - 1), function () {
        $(this).closest('tr').remove(); //closest() 方法返回被选元素的第一个祖先元素。
        SetRowNum(table_name);
        var num = $(this).attr('id').substring($(this).attr('id').length - 1);
        ChangeID($(this), table_name, templateType);
    });
    //图标名称选择
    $("#" + table_name).off('click', "#" + templateType + "_ul_icon_" + String($index - 1) + " li");
    $("#" + table_name).on('click', "#" + templateType + "_ul_icon_" + String($index - 1) + " li", function () {
        var value = $(this).text();
        $(this).closest('tr').children('td:eq(2)').find('input').val(value);
    });
    //图纸规格选择
    $("#" + table_name).off('click', "#" + templateType + "_ul_symbol_" + String($index - 1) + " li");
    $("#" + table_name).on('click', "#" + templateType + "_ul_symbol_" + String($index - 1) + " li", function () {
        //var symbol_info = $(this).text();
        if ($(this).css('background-color').toString() == "rgba(0, 0, 0, 0)") {
            //var symbol = symbol_info.substring(symbol_info.length - 1, symbol_info.length);
            var symbol = $(this).find('span').text();

            if (templateType == "IM-WS" || templateType == "EM-SBC" || templateType == "RW") {
                current_value = $(this).closest('tr').children("td:eq(3)").find("input:eq(0)").val();  //当前的值
                if (symbol == "VI") {
                    $("#" + templateType + "_ul_equipment_" + String($index - 1) + " li").find("a:contains('目测(VI)')").parent().click();
                } else if (current_value.indexOf(symbol) == -1 && symbol != "自定文字" && current_value.indexOf("VI-") == -1) {
                    $(this).closest('tr').children("td:eq(3)").find("input:eq(0)").val(current_value + symbol);
                    $(this).closest('tr').children("td:eq(3)").find("input:eq(0)").focus();  //input获得焦点
                } else {
                    $(this).closest('tr').children("td:eq(3)").find("input:eq(0)").focus();  //input获得焦点
                }
            }
            else if (templateType == "IM-QC" || templateType == "EM-QC") {
                current_value = $(this).closest('tr').children("td:eq(2)").find("input:eq(0)").val();  //当前的值
                if (symbol == "VI") {
                    $("#" + templateType + "_ul_equipment_" + String($index - 1) + " li").find("a:contains('目测(VI)')").parent().click();
                } else if (current_value.indexOf(symbol) == -1 && symbol != "自定文字" && current_value.indexOf("VI-") == -1) {
                    $(this).closest('tr').children("td:eq(2)").find("input:eq(0)").val(current_value + symbol);
                    $(this).closest('tr').children("td:eq(2)").find("input:eq(0)").focus();  //input获得焦点
                } else {
                    $(this).closest('tr').children("td:eq(2)").find("input:eq(0)").focus();  //input获得焦点
                }
            }
            //Cancel By YZT 20191217 下面的判断太多余了，代码见备份Backup20191217的CreateTemplate_AddRow.js
            //代码
            //
        }
    });



    //上下公差不能输入多个小数点或正负号
    $("#" + table_name).off('keydown', "#" + templateType + "_input_upper_limit_" + String($index - 1));
    $("#" + table_name).on('keydown', "#" + templateType + "_input_upper_limit_" + String($index - 1), function (e) {
        var key = e.which;
        if (key == 110 || key == 190) {
            if (this.value.indexOf(".") != -1) {
                if ($("#input_changeLanguage").val() == "2") {
                    AlertWindow("Only one decimal point can be entered!");
                } else {
                    AlertWindow("只能输入一个小数点！");
                }
                e.preventDefault();
            }
        }
        else if (key == 107 || key == 109) {
            if (this.value.indexOf("+") != -1 || this.value.indexOf("-") != -1) {
                if ($("#input_changeLanguage").val() == "2") {
                    AlertWindow("Only one plus or minus sign can be entered!");
                } else {
                    AlertWindow("只能输入一个正负号！");
                }
                e.preventDefault();
            }
        }
    });
    //上下公差不能输入多个小数点或正负号
    $("#" + table_name).off('keydown', "#" + templateType + "_input_lower_limit_" + String($index - 1));
    $("#" + table_name).on('keydown', "#" + templateType + "_input_lower_limit_" + String($index - 1), function (e) {
        var key = e.which;
        if (key == 110 || key == 190) {
            if (this.value.indexOf(".") != -1) {
                if ($("#input_changeLanguage").val() == "2") {
                    AlertWindow("Only one decimal point can be entered!");
                } else {
                    AlertWindow("只能输入一个小数点！");
                }
                e.preventDefault();
            }
        }
        else if (key == 107 || key == 109) {
            if (this.value.indexOf("+") != -1 || this.value.indexOf("-") != -1) {
                if ($("#input_changeLanguage").val() == "2") {
                    AlertWindow("Only one plus or minus sign can be entered!");
                } else {
                    AlertWindow("只能输入一个正负号！");
                }
                e.preventDefault();
            }
        }
    });

    //量仪名称选择
    $("#" + table_name).off('click', "#" + templateType + "_ul_equipment_" + String($index - 1) + " li");
    $("#" + table_name).on('click', "#" + templateType + "_ul_equipment_" + String($index - 1) + " li", function () {
        $("#" + templateType + "_generated_code_" + String($index - 1)).val("");     //选择量仪前先清空Attr1和Attr2的值
        $("#" + templateType + "_repeated_points_" + String($index - 1)).val("");
        var current_value = $(this).text();
        if ($(this).css('background-color').toString() == "rgba(0, 0, 0, 0)") {
            if (templateType == "IM-WS" || templateType == "EM-SBC" || templateType == "RW") {
                $(this).closest('tr').children("td:eq(4)").find("input:eq(0)").val(current_value);
                //Add by YZT 20190916 For OT and TG, upp_tol/lwr_tol should be 1
                if (current_value == "螺纹规(TG)" || current_value == "自制量具(OT)" || current_value == "目测(VI)") {
                    $(this).closest('tr').children("td:eq(3)").find("input:eq(1)").val("1");
                    $(this).closest('tr').children("td:eq(3)").find("input:eq(2)").val("1");
                }
                $(this).closest('tr').children("td:eq(4)").find("input:eq(0)").focus();  //input获得焦点
            }
            else if (templateType == "IM-QC" || templateType == "EM-QC") {
                $(this).closest('tr').children("td:eq(3)").find("input:eq(0)").val(current_value);
                //Add by YZT 20190916 For OT and TG, upp_tol/lwr_tol should be 1
                if (current_value == "螺纹规(TG)" || current_value == "自制量具(OT)" || current_value == "目测(VI)") {
                    $(this).closest('tr').children("td:eq(2)").find("input:eq(1)").val("1");
                    $(this).closest('tr').children("td:eq(2)").find("input:eq(2)").val("1");
                }
                $(this).closest('tr').children("td:eq(3)").find("input:eq(0)").focus();  //input获得焦点
            }
        }
        if (current_value == "螺纹规(TG)" || current_value == "显微镜(MS)" || current_value == "自制量具(OT)" || current_value == "硬度测量仪(HD)" || current_value == "目测(VI)") {
            $("#" + templateType + "_btn_equipmentSetting_" + String($index - 1)).click();
        } else if (current_value == "投影仪(PJ)" || current_value == "高度尺(HG)" || current_value == "卡尺(VC)" || current_value == "外径百分尺/外径千分尺(UM)" || current_value == "百分表/千分表(DT)" || current_value == "电子磅(EB)" || current_value == "内径千分尺(三爪)(HT)") {
            $("#" + templateType + "_btn_equipmentSetting_" + String($index - 1)).click();
            $('#setting').dialog('close');
        }
        //Add by YZT 20190916 Load the default setting after Click action.

    });
    //抽检数量选择
    $("#" + table_name).off('click', "#" + templateType + "_ul_checkWay_" + String($index - 1) + " li");
    $("#" + table_name).on('click', "#" + templateType + "_ul_checkWay_" + String($index - 1) + " li", function () {
        var current_value = $(this).text();
        if ($(this).css('background-color').toString() == "rgba(0, 0, 0, 0)") {
            var tdIndex = "";
            if (templateType == "IM-WS" || templateType == "EM-SBC" || templateType == "RW") {
                tdIndex = "td:eq(5)";
            }
            else if (templateType == "IM-QC" || templateType == "EM-QC") {
                tdIndex = "td:eq(4)";
            }
            if ($("#input_changeLanguage").val() == "2") {
                $(this).closest('tr').children(tdIndex).find("button").replaceWith("<button type='button' id='" + templateType + "_btn_checkWay_" + String($index - 1) + "' class='btn button btn-default dropdown-toggle' data-toggle='dropdown'>" + current_value + "<span class='caret'></span></button>");
                $(this).closest('tr').children(tdIndex).find("input:eq(0)").val(current_value);  //获取测量方法，若未选择，则为"方法"
                if (current_value == "All inspection" || current_value == "Sampling plan" || current_value == "Sampling plan(tighten up)" || current_value == "AQL0.65" || current_value == "AQL1.0") {  //以上方法无需填写抽检数量
                    $(this).closest('tr').children(tdIndex).find("input:eq(1)").replaceWith("<input id='" + templateType + "_input_checkNum_" + String($index - 1) + "' type='text' readonly='true' class='form-control' placeholder='No need to fill in quantity.' value=''>");
                }
                else {
                    $(this).closest('tr').children(tdIndex).find("input:eq(1)").replaceWith("<input id='" + templateType + "_input_checkNum_" + String($index - 1) + "' type='text' class='form-control' placeholder='Please fill in the quantity of random inspection.' value=''>");
                    $(this).closest('tr').children(tdIndex).find("input:eq(1)").focus();
                }
            }
            else {
                $(this).closest('tr').children(tdIndex).find("button").replaceWith("<button type='button' id='" + templateType + "_btn_checkWay_" + String($index - 1) + "' class='btn button btn-default dropdown-toggle' data-toggle='dropdown'>" + current_value + "<span class='caret'></span></button>");
                $(this).closest('tr').children(tdIndex).find("input:eq(0)").val(current_value);  //获取测量方法，若未选择，则为"方法"
                if (current_value == "全检" || current_value == "抽检计划" || current_value == "抽检计划-加严" || current_value == "AQL0.65" || current_value == "AQL1.0") {  //以上方法无需填写抽检数量
                    $(this).closest('tr').children(tdIndex).find("input:eq(1)").replaceWith("<input id='" + templateType + "_input_checkNum_" + String($index - 1) + "' type='text' readonly='true' class='form-control' placeholder='无需填写数量' value=''>");
                }
                else {
                    $(this).closest('tr').children(tdIndex).find("input:eq(1)").replaceWith("<input id='" + templateType + "_input_checkNum_" + String($index - 1) + "' type='text' class='form-control' placeholder='请填写抽检数量' value=''>");
                    $(this).closest('tr').children(tdIndex).find("input:eq(1)").focus();
                }
            }
        }
    });
    // 添加实时监控input中值变化的事
    //$("#" + table_name).off('input propertychange', "#" + templateType + "_input_symbol_" + String($index - 1));
    $("#" + table_name).off('blur', "#" + templateType + "_input_symbol_" + String($index - 1));
    //$("#" + table_name).on('input propertychange', "#" + templateType + "_input_symbol_" + String($index - 1), function () { //By YZT 20191209
    $("#" + table_name).on('blur', "#" + templateType + "_input_symbol_" + String($index - 1), function () {
        var a = $(this).val();

        if (a.indexOf("∅") >= 0 || a.indexOf("°") >= 0) {
            var reg_input_symbol = /\d+\.?\d*/g;
            a = a.match(reg_input_symbol);
        }
        var order = $(this).closest('tr').children("td:eq(0)").text();
        AutoAdd_gongcha(a, templateType, order, "_input_upper_limit_", "_input_lower_limit_", "#checkbox_gongcha_", "_input_symbol_");
        //var input_Equipment_Value = "#" + templateType + "_input_equipment_" + order;//By YZT 20190925 haha
        //if ($(input_Equipment_Value).val == "螺纹规(TG)") {
        //    $("#" + templateType + "_btn_equipmentSetting_" + order).click();
        //}
    });

    //选择关联
    $("#" + table_name).off('click', "#" + templateType + "_checkbox_link_" + String($index - 1));
    $("#" + table_name).on('click', "#" + templateType + "_checkbox_link_" + String($index - 1), function () {
        $(this).closest('tr').children("td:eq(2)").find('ul').html('');
        if ($("#" + templateType + "_checkbox_link_" + String($index - 1)).is(':checked') == false) {
            return;
        }
        if ($(this).closest('tr').children("td:eq(1)").find('input').is(':checked')) {  //插入数据库时显示"true" or "false"字符串
            $(this).closest('tr').children("td:eq(1)").find('input').val("true");
        }
        else {
            $(this).closest('tr').children("td:eq(1)").find('input').val("false");
        }
        $(this).closest('tr').children("td:eq(2)").find('input').focus();
        var part_num = $('#part_num').val();
        var part_rev = $('#part_rev').val();
        var order = $(this).closest('tr').children("td:eq(0)").text();
        if (templateType == "IM-WS") {
            GetQCicon(part_num, part_rev, order, "IM-QC");       //搜寻已插入的IM_QC图标并关联至IM_WS
        }
        else if (templateType == "EM-SBC") {
            GetQCicon(part_num, part_rev, order, "EM-QC");       //搜寻已插入的EM_QC图标并关联至EM_WS
        }
    });
    //量仪设置弹出窗口
    $("#" + table_name).off('click', "#" + templateType + "_btn_equipmentSetting_" + String($index - 1));
    $("#" + table_name).on('click', "#" + templateType + "_btn_equipmentSetting_" + String($index - 1), function () {
        if (templateType == "IM-WS" || templateType == "EM-SBC" || templateType == "RW") {
            var specification = $(this).closest('tr').children("td:eq(3)").find('input').val();
            var equipment_type = $(this).closest('tr').children("td:eq(4)").find('input').val();
        }
        else {
            var specification = $(this).closest('tr').children("td:eq(2)").find('input').val();
            var equipment_type = $(this).closest('tr').children("td:eq(3)").find('input').val();
        }
        $("#" + templateType + "_generated_code_" + String($index - 1)).val("");
        var msg_img = "";
        var msg_ul = "";
        //公差输入了对称度，量仪选择了高度尺
        if (equipment_type.indexOf("HG") != -1 && specification.indexOf("⌯") != -1) {
            msg_img = '<img id="equipment_img" alt="HG-Basic" src="Images/HG-DuiChengDu.png"';
            EquipmentSettingWindow_HG(msg_img, msg_ul);
            $("#div_repeated_measurement").remove();      //隐藏第三行
            $("#label_repeated_measurement").remove();    //隐藏第三行
            $("#input_repeated_measurement").remove();
            $("#div_special_measurement").remove();       //隐藏特殊测量按钮
            if ($("#input_changeLanguage").val() == "2") {
                $("#input_special_measurement").replaceWith('<input id="input_special_measurement" type="text" class="form-control" value="  ⌯  Degree of Symmetry" style="background-color:#F0F0F0; width:117%" readonly="true" />');
            }
            else {
                $("#input_special_measurement").replaceWith('<input id="input_special_measurement" type="text" class="form-control" value="  ⌯  对称度" style="background-color:#F0F0F0; width:117%" readonly="true" />');
            }
            $("#table_special_measurement").remove();     //隐藏最下方表格
        }
            //公差输入了同心度，量仪选择了高度尺
        else if (equipment_type.indexOf("HG") != -1 && specification.indexOf("⌾") != -1) {
            msg_img = '<img id="equipment_img" alt="HG-Basic" src="Images/HG-TongXinDu-1.png"';
            msg_ul = loadData('static/TongXinDu_repeated.json', 'repeated');
            EquipmentSettingWindow_HG(msg_img, msg_ul);
            if ($("#input_changeLanguage").val() == "2") {
                $("#input_special_measurement").replaceWith('<input id="input_special_measurement" type="text" class="form-control" value="  ⌾  Concentricity" style="background-color:#F0F0F0; width:117%" readonly="true" />');
            }
            else {
                $("#input_special_measurement").replaceWith('<input id="input_special_measurement" type="text" class="form-control" value="  ⌾  同心度" style="background-color:#F0F0F0; width:117%" readonly="true" />');
            }
            $("#" + templateType + "_repeated_points_" + String($index - 1)).val(1);               //重复测量取点数默认值为1
            $("#table_special_measurement").remove();   //隐藏最下方表格
            $("#btn_special_measurement").remove();     //隐藏特殊测量按钮
            //同心度重复测量次数选择
            $("#div_repeated_measurement").on('click', "#ul_repeated_measurement li", function () {
                var str = $(this).text();
                if ($(this).css('background-color').toString() == "rgba(0, 0, 0, 0)") {
                    $("#input_repeated_measurement").val(str);
                    $("#" + templateType + "_repeated_points_" + String($index - 1)).val(str);     //重复测量取点数
                    if ($("#input_repeated_measurement").val() == 1) {
                        $("#equipment_img").replaceWith('<img id="equipment_img" alt="HG-Basic" src="Images/HG-TongXinDu-1.png" />');  //输入为1
                    }
                    else if ($("#input_repeated_measurement").val() > 1 && $("#input_repeated_measurement").val() <= 5) {
                        $("#equipment_img").replaceWith('<img id="equipment_img" alt="HG-Basic" src="Images/HG-TongXinDu-2.png" />');  //输入为2-5
                    }
                }
            });
        }
            //公差输入了平行度，量仪选择了高度尺
        else if (equipment_type.indexOf("HG") != -1 && specification.indexOf("⫽") != -1) {
            msg_img = '<img id="equipment_img" alt="HG-Basic" src="Images/HG-PingXingDu.png"';
            msg_ul = loadData('static/PingXingDu_qudian.json', 'qudian');
            EquipmentSettingWindow_HG(msg_img, msg_ul);
            if ($("#input_changeLanguage").val() == "2") {
                $("#input_special_measurement").replaceWith('<input id="input_special_measurement" type="text" class="form-control" value="  ⫽  Depth of Parallelism" style="background-color:#F0F0F0; width:117%" readonly="true" />');
            }
            else {
                $("#input_special_measurement").replaceWith('<input id="input_special_measurement" type="text" class="form-control" value="  ⫽  平行度" style="background-color:#F0F0F0; width:117%" readonly="true" />');
            }
            $("#input_repeated_measurement").replaceWith('<input id="input_repeated_measurement" class="form-control" value="3" style="background-color:#F0F0F0" readonly="true"/>');
            $("#" + templateType + "_repeated_points_" + String($index - 1)).val(3);               //重复测量取点数默认值为3
            $("#label_repeated_measurement").replaceWith('<label id="label_repeated_measurement" style="margin-top:6px">取点：</label>');
            $("#table_special_measurement").remove();    //隐藏最下方表格
            $("#btn_special_measurement").remove();      //隐藏特殊测量按钮
            //平行度取点数目选择
            $("#div_repeated_measurement").on('click', "#ul_repeated_measurement li", function () {
                var str = $(this).text();
                if ($(this).css('background-color').toString() == "rgba(0, 0, 0, 0)") {
                    $("#" + templateType + "_repeated_points_" + String($index - 1)).val(str);     //重复测量取点数
                    $("#input_repeated_measurement").val(str);
                }
            });
        }
            //公差输入了孔径，量仪选择了高度尺
        else if (equipment_type.indexOf("HG") != -1 && specification.indexOf("∅") != -1) {
            if ($("#input_changeLanguage").val() == "2") {
                msg = '<img id="equipment_img" alt="HG-Basic" src="Images/HG-KongJing-En.png"';
                EquipmentSettingWindow_HG(msg);
                $("#input_special_measurement").replaceWith('<input id="input_special_measurement" type="text" class="form-control" value="  ∅  Diameter" style="background-color:#F0F0F0; width:117%" readonly="true" />');
            }
            else {
                msg = '<img id="equipment_img" alt="HG-Basic" src="Images/HG-KongJing.png"';
                EquipmentSettingWindow_HG(msg);
                $("#input_special_measurement").replaceWith('<input id="input_special_measurement" type="text" class="form-control" value="  ∅  孔径" style="background-color:#F0F0F0; width:117%" readonly="true" />');
            }
            $("#label_repeated_measurement").remove();   //隐藏第三行
            $("#input_repeated_measurement").remove();
            $("#table_special_measurement").remove();    //隐藏最下方表格
            $("#btn_special_measurement").remove();      //隐藏特殊测量按钮
            $("#btn_repeated_measurement").remove();     //隐藏重复测量按钮
        }
            //公差输入了位置度/平面度/圆度/圆柱度/垂直度/全跳动，量仪选择了高度尺
        else if (equipment_type.indexOf("HG") != -1 && (specification.indexOf("⌖") >= 0 || specification.indexOf("▱") >= 0 || specification.indexOf("〇") >= 0 || specification.indexOf("⌭") >= 0 || specification.indexOf("⊥") >= 0 || specification.indexOf("⌰") >= 0)) {
            if ($("#input_changeLanguage").val() == "2") {
                msg = '<img id="equipment_img" alt="HG-Basic" src="Images/HG-WeiZhiDu-En.png"';
                EquipmentSettingWindow_HG(msg);
                $("#input_special_measurement").replaceWith('<input id="input_special_measurement" type="text" class="form-control" value="  ⌖  Position Degrees" style="background-color:#F0F0F0; width:117%" readonly="true" />');
                $("#label_repeated_measurement").replaceWith('<label id="label_repeated_measurement">Self-input:</label>');               //label文字“重复输入”改为“自行输入”
            }
            else {
                msg = '<img id="equipment_img" alt="HG-Basic" src="Images/HG-WeiZhiDu.png"';
                EquipmentSettingWindow_HG(msg);
                $("#input_special_measurement").replaceWith('<input id="input_special_measurement" type="text" class="form-control" value="  ⌖  位置度" style="background-color:#F0F0F0; width:117%" readonly="true" />');
                $("#label_repeated_measurement").replaceWith('<label id="label_repeated_measurement">自行输入：</label>');               //label文字“重复输入”改为“自行输入”
            }
            $("#table_special_measurement").remove();    //隐藏最下方表格  
            $("#btn_special_measurement").remove();      //隐藏特殊测量按钮
            $("#btn_repeated_measurement").remove();     //隐藏重复测量按钮
            $("#input_repeated_measurement").replaceWith('<input id="input_repeated_measurement" type="checkbox" checked="true"/>'); //input改为多选框
        }
            //仅选择了高度尺
        else if (equipment_type.indexOf("HG") != -1) {
            msg_img = '<img id="equipment_img" alt="HG-Basic" src="Images/HG-Basic.png"';
            EquipmentSettingWindow_HG(msg_img, msg_ul);
            $("#" + templateType + "_generated_code_" + String($index - 1)).val("Basic");                                     //HG默认版面generated code为"Basic"
            $("#div_repeated_measurement").remove();   //隐藏第三行
            $("#input_repeated_measurement").remove(); //隐藏第三行
            $("#label_repeated_measurement").remove(); //隐藏第三行
            $("#td_special_measurement_2").hide();     //隐藏表格第二行
            $("#Touch_one_point_1").click(function () {
                $("#equipment_img").replaceWith('<img id="equipment_img" alt="HG-Basic" src="Images/HG-Basic.png" />');       //如选择碰1点，则展示碰1点的图例
                $("#" + templateType + "_generated_code_" + String($index - 1)).val("Basic");                                 //HG碰1点版面generated code为"Basic"
            });
            $("#Touch_two_point_1").click(function () {
                $("#equipment_img").replaceWith('<img id="equipment_img" alt="HG-Basic" src="Images/HG-Basic_2pts.png" />');  //如选择碰2点，则展示碰2点的图例
                $("#" + templateType + "_generated_code_" + String($index - 1)).val("Basic_2pts");                            //HG碰2点版面generated code为"Basic_2pts"
            });
            $("#div_special_measurement").on('click', "#ul_special_measurement li", function () {
                var str = $(this).text();
                if ($(this).css('background-color').toString() == "rgba(0, 0, 0, 0)") {
                    $("#input_special_measurement").val(str);    //特殊测量的值
                    //特殊测量选择为高度差
                    if ($("#input_special_measurement").val() == "高度差" || $("#input_special_measurement").val() == "Height Difference") {
                        $("#td_special_measurement_2").hide();
                        $("#equipment_img").replaceWith('<img id="equipment_img" alt="HG-Basic" src="Images/HG-Basic.png" />');           //图片切换为碰1点的图片
                        $("#" + templateType + "_generated_code_" + String($index - 1)).val("Basic");                                     //HG碰1点版面generated code为"Basic"
                        var gaoducha = "";
                        gaoducha += '<div class="select" id="div_gaoducha_point">';
                        if ($("#input_changeLanguage").val() == "2") {
                            $("#td_special_measurement_1").replaceWith('<label class="radio-inline" id="td_special_measurement_1" ><input name="face_to_face" id="radio_special_measurement_1" type="radio" checked="checked" /> Face to Face</label>');  //隐藏第二行的面对面
                            gaoducha += '<label class="radio-inline"><input type="radio" name="Touch_point" id="Touch_one_point_1" checked="checked"/> One Point </label>';
                            gaoducha += '<label class="radio-inline"><input type="radio" name="Touch_point" id="Touch_two_point_1"/> Two Point </label>';
                        }
                        else {
                            $("#td_special_measurement_1").replaceWith('<label class="radio-inline" id="td_special_measurement_1" ><input name="face_to_face" id="radio_special_measurement_1" type="radio" checked="checked" /> 面对面</label>');  //隐藏第二行的面对面
                            gaoducha += '<label class="radio-inline"><input type="radio" name="Touch_point" id="Touch_one_point_1" checked="checked"/> 碰1点 </label>';
                            gaoducha += '<label class="radio-inline"><input type="radio" name="Touch_point" id="Touch_two_point_1"/> 碰2点 </label>';
                        }
                        gaoducha += '</div>';
                        $('#div_gaoducha_point').replaceWith(gaoducha);
                        $("#Touch_one_point_1").click(function () {
                            $("#equipment_img").replaceWith('<img id="equipment_img" alt="HG-Basic" src="Images/HG-Basic.png" />');       //如选择碰1点，则展示碰1点的图例
                            $("#" + templateType + "_generated_code_" + String($index - 1)).val("Basic");                                 //HG碰1点版面generated code为"Basic"
                        });
                        $("#Touch_two_point_1").click(function () {
                            $("#equipment_img").replaceWith('<img id="equipment_img" alt="HG-Basic" src="Images/HG-Basic_2pts.png" />');  //如选择碰2点，则展示碰2点的图例
                            $("#" + templateType + "_generated_code_" + String($index - 1)).val("Basic_2pts");                            //HG碰2点版面generated code为"Basic_2pts"
                        });
                    }
                        //特殊测量选择为孔距
                    else if ($("#input_special_measurement").val() == "孔距" || $("#input_special_measurement").val() == "Pitch Row") {
                        if ($("#input_changeLanguage").val() == "2") {
                            $("#td_special_measurement_1").replaceWith('<label class="radio-inline" id="td_special_measurement_1" ><input name="face_to_face" type="radio" checked="checked"/> Hole to Hole </label>');  //修改第一行第一列的值
                            $("#td_special_measurement_2").replaceWith('<label class="radio-inline" id="td_special_measurement_2" ><input name="face_to_face" type="radio" /> Hole to Edge </label>');                   //修改第二行第一列的值
                        }
                        else {
                            $("#td_special_measurement_1").replaceWith('<label class="radio-inline" id="td_special_measurement_1" ><input name="face_to_face" type="radio" checked="checked"/> 孔对孔 </label>');  //修改第一行第一列的值
                            $("#td_special_measurement_2").replaceWith('<label class="radio-inline" id="td_special_measurement_2" ><input name="face_to_face" type="radio" /> 孔对边 </label>');                   //修改第二行第一列的值
                        }
                        $("#equipment_img").replaceWith('<img id="equipment_img" alt="HG-Basic" src="Images/HG-Hole-Hole-2pts.png" />');  //图片切换为碰2点的图片
                        $("#" + templateType + "_generated_code_" + String($index - 1)).val("Hole-Hole_2pts");                            //HG孔对孔碰2点版面generated code为"Hole-Hole&2pts"
                        var kongju = "";
                        kongju += '<div class="select" id="div_gaoducha_point">';
                        if ($("#input_changeLanguage").val() == "2") {
                            kongju += '<label class="radio-inline"><input type="radio" name="Touch_point" id="Touch_two_point_2" checked="checked"/> Two Points </label>';
                            kongju += '<label class="radio-inline"><input type="radio" name="Touch_point" id="Touch_four_point_2"/> Four Points </label>';
                        }
                        else {
                            kongju += '<label class="radio-inline"><input type="radio" name="Touch_point" id="Touch_two_point_2" checked="checked"/> 碰2点 </label>';
                            kongju += '<label class="radio-inline"><input type="radio" name="Touch_point" id="Touch_four_point_2"/> 碰4点 </label>';
                        }
                        kongju += '</div>';
                        $('#div_gaoducha_point').replaceWith(kongju);

                        $("#Touch_two_point_2").click(function () {           //选中碰2点
                            $("#equipment_img").replaceWith('<img id="equipment_img" alt="HG-Basic" src="Images/HG-Hole-Hole-2pts.png" />');
                            if ($("#input_changeLanguage").val() == "2") {
                                $("#td_special_measurement_1").replaceWith('<label class="radio-inline" id="td_special_measurement_1" ><input name="face_to_face" type="radio" checked="checked"/> Hole to Hole </label>');
                            }
                            else {
                                $("#td_special_measurement_1").replaceWith('<label class="radio-inline" id="td_special_measurement_1" ><input name="face_to_face" type="radio" checked="checked"/> 孔对孔 </label>');
                            }
                            $("#" + templateType + "_generated_code_" + String($index - 1)).val("Hole-Hole_2pts");                            //HG孔对孔碰2点版面generated code为"Hole-Hole&2pts"
                        });
                        $("#Touch_four_point_2").click(function () {          //选中碰4点
                            $("#equipment_img").replaceWith('<img id="equipment_img" alt="HG-Basic" src="Images/HG-Hole-Hole-4pts.png" />');
                            if ($("#input_changeLanguage").val() == "2") {
                                $("#td_special_measurement_1").replaceWith('<label class="radio-inline" id="td_special_measurement_1" ><input name="face_to_face" type="radio" checked="checked"/> Hole to Hole </label>');
                            }
                            else {
                                $("#td_special_measurement_1").replaceWith('<label class="radio-inline" id="td_special_measurement_1" ><input name="face_to_face" type="radio" checked="checked"/> 孔对孔 </label>');
                            }
                            $("#" + templateType + "_generated_code_" + String($index - 1)).val("Hole-Hole_4pts");                            //HG孔对孔碰4点版面generated code为"Hole-Hole&4pts"
                        });
                        $("#td_special_measurement_2").click(function () {    //选中孔对边
                            $("#equipment_img").replaceWith('<img id="equipment_img" alt="HG-Basic" src="Images/HG-Hole-Edge.png" />');
                            $("#" + templateType + "_generated_code_" + String($index - 1)).val("Hole-Edge");                            //HG孔对边版面generated code为"Hole-Edge"
                            $("#Touch_two_point_2").removeAttr("checked");    //移除碰两点和碰四点的选中属性
                            $("#Touch_four_point_2").removeAttr("checked");
                        });
                    }
                    else {
                        if ($("#input_changeLanguage").val() == "2") {
                            AlertWindow("Incorrect input for special measurements！");
                        }
                        else {
                            AlertWindow("特殊测量输入有误！");
                        }
                    }
                }
            });
        }
            //量仪选择螺纹规
        else if (equipment_type.indexOf("TG") != -1) {
            EquipmentSettingWindow_TG();
            $("#" + templateType + "_generated_code_" + String($index - 1)).val("Key-in");
            $("#" + templateType + "_input_symbol_" + String($index - 1)).val("");
            $("#" + templateType + "_input_upper_limit_" + String($index - 1)).val("1");
            $("#" + templateType + "_input_lower_limit_" + String($index - 1)).val("1");

            //选择不同的螺纹种类：螺孔 或 螺栓/外牙
            $("#radio_thread").click(function () {
                if ($("#input_changeLanguage").val() == "2") {
                    $("#label_thread_gauge").replaceWith('<label id="label_thread_gauge" style="margin:20px 0 0 0">Thread Plug Gauge:</label>');
                }
                else {
                    $("#label_thread_gauge").replaceWith('<label id="label_thread_gauge" style="margin:20px 0 0 0">螺纹塞规：</label>');
                }
                $('#input_GeneralCodeContent').val("");
                $('#input_StopCodeContent').val("");
                $("#input_ThreadPitch").val("");
            });
            $("#radio_bolt").click(function () {
                if ($("#input_changeLanguage").val() == "2") {
                    $("#label_thread_gauge").replaceWith('<label id="label_thread_gauge" style="margin:20px 0 0 0">Thread Ring Gauge:</label>');
                }
                else {
                    $("#label_thread_gauge").replaceWith('<label id="label_thread_gauge" style="margin:20px 0 0 0">螺纹环规：</label>');
                }
                $('#input_GeneralCodeContent').val("");
                $('#input_StopCodeContent').val("");
                $("#input_ThreadPitch").val("");
            });

            //选择不同螺纹标准下的牙距
            $("#div_ThreadPitch").on("click", "#btn_ThreadPitch", function () {
                var thread_version = $("#input_StandardOfThread_PRO").val();
                var equipment_page = "";
                equipment_page += '<ul id="ul_ThreadPitch" class="dropdown-menu" style="max-height:140px;overflow:auto">';
                if (thread_version == "普通/粗" || thread_version == "ISO Thread (Metric)") {
                    equipment_page += loadData('static/coarseThread.json', 'coarseThread');
                }
                else if (thread_version == "细螺纹" || thread_version == "ISO Fine Thread") {
                    equipment_page += loadData('static/fineThread.json', 'fineThread');
                }
                else if (thread_version == "美制粗螺纹/UNC" || thread_version == "UNC") {
                    equipment_page += loadData('static/UNC.json', 'UNC');
                }
                else if (thread_version == "美制细螺纹/UNF" || thread_version == "UNF") {
                    equipment_page += loadData('static/UNF.json', 'UNF');
                }
                else if (thread_version == "美制特细螺纹/UNEF" || thread_version == "UNEF") {
                    equipment_page += loadData('static/UNEF.json', 'UNEF');
                }
                else if (thread_version == "美制平行管螺纹/NPSC" || thread_version == "NPSC") {
                    equipment_page += loadData('static/NPSC.json', 'NPSC');
                }
                else if (thread_version == "美制锥管螺纹/NPT" || thread_version == "NPT") {
                    equipment_page += loadData('static/NPT.json', 'NPT');
                }
                else if (thread_version == "英制螺纹/惠氏粗螺纹/BSW/BS84" || thread_version == "BSW") {
                    equipment_page += loadData('static/BSW.json', 'BSW');
                }
                else {
                    equipment_page += "";
                }
                equipment_page += '</ul>';
                $("#ul_ThreadPitch").replaceWith(equipment_page);

                //填充螺纹牙距,通规码/止规码内容,图纸规格
                if ($("#radio_thread").is(":checked")) {     //如果选中的是螺孔
                    FillThreadPitch("Screw_hole", templateType, $index);
                }
                else if ($("#radio_bolt").is(":checked")) {  //如果选中的是螺栓/外牙
                    FillThreadPitch("Screw_bolt", templateType, $index);
                }
            });

            //螺纹标准：专业版
            $("#radio_StandardOfThread_PRO").click(function () {
                if ($("#input_changeLanguage").val() == "2") {
                    $("#input_StandardOfThread_PRO").replaceWith('<input id="input_StandardOfThread_PRO" type="text" class="form-control" value="ISO Thread (Metric)" style="height:28px;width:80% "/>');
                }
                else {
                    $("#input_StandardOfThread_PRO").replaceWith('<input id="input_StandardOfThread_PRO" type="text" class="form-control" value="普通/粗" style="height:28px;width:80% "/>');
                }
                $("#btn_StandardOfThread_PRO").replaceWith('<button id="btn_StandardOfThread_PRO" type="button" class="btn btn-default dropdown-toggle button" data-toggle="dropdown" style="height:28px" ><span class="caret"></span></button>');
                $("#div_CodeContent").removeAttr("style");
                $("#div_AllowInput").removeAttr("style");

                //填充螺纹牙距,通规码/止规码内容,图纸规格
                if ($("#radio_thread").is(":checked")) {     //如果选中的是螺孔
                    FillThreadPitch("Screw_hole", templateType, $index);
                }
                else if ($("#radio_bolt").is(":checked")) {  //如果选中的是螺栓/外牙
                    FillThreadPitch("Screw_bolt", templateType, $index);
                }

                //专业版下螺纹标准选择
                $("#btn_StandardOfThread_PRO").click(function () {
                    $("#" + templateType + "_generated_code_" + String($index - 1)).val(null);
                    var equipment_page = "";
                    equipment_page += '<ul id="ul_StandardOfThread_PRO" class="dropdown-menu" style="max-height:140px;overflow:auto">';
                    equipment_page += loadData('static/threadStandard.json', 'threadStandard');
                    equipment_page += '</ul>';
                    $("#ul_StandardOfThread_PRO").replaceWith(equipment_page);
                    $("#div_StandardOfThread_PRO").on('click', "#ul_StandardOfThread_PRO li", function () {
                        var str = $(this).text();
                        if ($(this).css('background-color').toString() == "rgba(0, 0, 0, 0)") {
                            $("#input_StandardOfThread_PRO").val(str);
                            if ($("#input_StandardOfThread_PRO").val() == "自定") {
                                $("#btn_ThreadPitch").replaceWith('<span id="btn_ThreadPitch" class="input-group-addon">螺纹直径</span>');
                                $("#input_ThreadPitch").replaceWith('<input id="input_ThreadPitch" class="form-control" type="text" style="height:28px;width:80%" />');
                                $("#input_GeneralCodeContent").replaceWith('<input id="input_GeneralCodeContent" type="text" class="form-control" style="height:28px;width:80%"/>');
                                $("#input_StopCodeContent").replaceWith('<input id="input_StopCodeContent" type="text" class="form-control" style="height:28px;width:82%"/>');
                            }
                            else {
                                $("#btn_ThreadPitch").replaceWith('<button id="btn_ThreadPitch" type="button" class="btn btn-default dropdown-toggle button" data-toggle="dropdown" style="height:28px;padding:0 10px 0 10px" >螺纹直径 <span class="caret"></span></button>');
                                $("#input_ThreadPitch").replaceWith('<input id="input_ThreadPitch" class="form-control" type="text" style="height:28px;width:80%;background-color:#F0F0F0" readonly="true"/>');
                                $("#input_GeneralCodeContent").replaceWith('<input id="input_GeneralCodeContent" type="text" class="form-control" readonly="true" style="background-color:#F0F0F0;height:28px;width:80%"/>');
                                $("#input_StopCodeContent").replaceWith('<input id="input_StopCodeContent" type="text" class="form-control" readonly="true" style="background-color:#F0F0F0;height:28px;width:82%"/>');
                            }
                        }
                    });
                });
            });
            //螺纹标准：通用版
            $("#radio_StandardOfThread_Simplified").click(function () {
                $("#input_StandardOfThread_PRO").replaceWith('<input id="input_StandardOfThread_PRO" type="text" class="form-control" value="普通/粗" readonly="true" style="background-color:#F0F0F0;height:28px;width:80% "/>');
                $("#btn_StandardOfThread_PRO").replaceWith('<button id="btn_StandardOfThread_PRO" type="button" class="btn btn-default dropdown-toggle button" data-toggle="dropdown" style="height:28px;background-color:#F0F0F0" disabled="disabled"><span class="caret"></span></button>');
                $("#" + templateType + "_generated_code_" + String($index - 1)).val("Key-in");
                $("#div_CodeContent").attr("style", "display:none");
                $("#div_AllowInput").attr("style", "display:none");
            });
        }
            //量仪选择三坐标测量仪CMM
        else if (equipment_type.indexOf("CMM") != -1) {
            msg = '<img id="equipment_img" alt="CMM" src="Images/CMM.png"';
            EquipmentSettingWindow_HG(msg);
            $("#name_equipment_setting").replaceWith('<input id="name_equipment_setting" type="text" class="form-control" value="CMM" readonly="true" style="background-color:#F0F0F0; margin:0 48px 0 -48px"/>');
            $("#div_special_measurement").replaceWith('<div id="div_special_measurement" class="input-group-btn"><label style="margin-top:5px">软件名称：PC-DMIS v2017 或以上</label><br /><br /><label style="margin:50px 0 ">注：CMM编程员必须严格遵循CMM_ID_Name文件夹内的名称来命名</label></div>');
            $("#input_special_measurement").remove();
            $("#table_special_measurement").remove();
            $("#btn_special_measurement").remove();
            $("#label_repeated_measurement").remove();
            $("#input_repeated_measurement").remove();
            $("#btn_repeated_measurement").remove();
        }

        else if (equipment_type.indexOf("IM") != -1) {
            msg = '<img id="equipment_img" alt="IM" src="Images/IM.png" width="300px" height="300px"';
            EquipmentSettingWindow_HG(msg);
            $("#name_equipment_setting").replaceWith('<input id="name_equipment_setting" type="text" class="form-control" value="IM" readonly="true" style="background-color:#F0F0F0; margin:0 48px 0 -48px"/>');
            $("#div_special_measurement").replaceWith('<div id="div_special_measurement" class="input-group-btn"><label style="margin-top:5px">IM Series</label><br /><br /><label style="margin:50px 0 ">注：IM编程员必须严格遵循IM_ID_Name文件夹内的名称来命名</label></div>');
            $("#input_special_measurement").remove();
            $("#table_special_measurement").remove();
            $("#btn_special_measurement").remove();
            $("#label_repeated_measurement").remove();
            $("#input_repeated_measurement").remove();
            $("#btn_repeated_measurement").remove();
        }
            //量仪选择投影仪(PJ)，公差输入对称度
        else if (equipment_type.indexOf("PJ") != -1 && specification.indexOf("⌯") != -1) {
            msg_img = '<img id="equipment_img" alt="HG-Basic" src="Images/PJ-DuiChengDu.png"';
            EquipmentSettingWindow_HG(msg_img, msg_ul);
            $("#div_repeated_measurement").remove();      //隐藏第三行
            $("#label_repeated_measurement").remove();    //隐藏第三行
            $("#input_repeated_measurement").remove();
            $("#div_special_measurement").remove();     //隐藏特殊测量按钮
            $("#name_equipment_setting").replaceWith('<input id="name_equipment_setting" type="text" class="form-control" value="PJ" readonly="true" style="background-color:#F0F0F0; margin:0 48px 0 -48px"/>');
            if ($("#input_changeLanguage").val() == "2") {
                $("#input_special_measurement").replaceWith('<input id="input_special_measurement" type="text" class="form-control" value="  ⌯  Degree of Symmetry" style="background-color:#F0F0F0; width:117%" readonly="true" />');
            }
            else {
                $("#input_special_measurement").replaceWith('<input id="input_special_measurement" type="text" class="form-control" value="  ⌯  对称度" style="background-color:#F0F0F0; width:117%" readonly="true" />');
            }
            $("#table_special_measurement").remove();   //隐藏最下方表格
        }
            //量仪选择投影仪(PJ)，公差输入圆度
        else if (equipment_type.indexOf("PJ") != -1 && specification.indexOf("〇") != -1) {
            msg_img = '<img id="equipment_img" alt="HG-Basic" src="Images/PJ-YuanDu.png"';
            EquipmentSettingWindow_HG(msg_img, msg_ul);
            $("#name_equipment_setting").replaceWith('<input id="name_equipment_setting" type="text" class="form-control" value="PJ" readonly="true" style="background-color:#F0F0F0; margin:0 48px 0 -48px"/>');
            if ($("#input_changeLanguage").val() == "2") {
                $("#input_special_measurement").replaceWith('<input id="input_special_measurement" type="text" class="form-control" value="  〇  Circularity" style="background-color:#F0F0F0; width:117%" readonly="true" />');
            }
            else {
                $("#input_special_measurement").replaceWith('<input id="input_special_measurement" type="text" class="form-control" value="  〇  圆度" style="background-color:#F0F0F0; width:117%" readonly="true" />');
            }
            $("#" + templateType + "_repeated_points_" + String($index - 1)).val(1);               //重复测量取点数默认值为1
            $("#input_repeated_measurement").replaceWith('<input id="input_repeated_measurement" class="form-control" value="1" style="background-color:#F0F0F0;width:117%" readonly="true"/>');
            $("#btn_repeated_measurement").remove();
            $("#table_special_measurement").remove();   //隐藏最下方表格
            $("#btn_special_measurement").remove();     //隐藏特殊测量按钮
        }
            //公差输入了同心度，量仪选择了投影仪(PJ)
        else if (equipment_type.indexOf("PJ") != -1 && specification.indexOf("⌾") != -1) {
            msg_img = '<img id="equipment_img" alt="HG-Basic" src="Images/PJ-TongXinDu-1.png"';
            msg_ul = loadData('static/TongXinDu_repeated.json', 'repeated');
            EquipmentSettingWindow_HG(msg_img, msg_ul);
            $("#name_equipment_setting").replaceWith('<input id="name_equipment_setting" type="text" class="form-control" value="PJ" readonly="true" style="background-color:#F0F0F0; margin:0 48px 0 -48px"/>');
            if ($("#input_changeLanguage").val() == "2") {
                $("#input_special_measurement").replaceWith('<input id="input_special_measurement" type="text" class="form-control" value="  ⌾  Concentricity" style="background-color:#F0F0F0; width:117%" readonly="true" />');
            }
            else {
                $("#input_special_measurement").replaceWith('<input id="input_special_measurement" type="text" class="form-control" value="  ⌾  同心度" style="background-color:#F0F0F0; width:117%" readonly="true" />');
            }
            $("#" + templateType + "_repeated_points_" + String($index - 1)).val(1);               //重复测量取点数默认值为1
            $("#table_special_measurement").remove();   //隐藏最下方表格
            $("#btn_special_measurement").remove();     //隐藏特殊测量按钮
            //同心度重复测量次数选择
            $("#div_repeated_measurement").on('click', "#ul_repeated_measurement li", function () {
                var str = $(this).text();
                if ($(this).css('background-color').toString() == "rgba(0, 0, 0, 0)") {
                    $("#input_repeated_measurement").val(str);
                    $("#" + templateType + "_repeated_points_" + String($index - 1)).val(str);     //重复测量取点数
                    if ($("#input_repeated_measurement").val() == 1) {
                        $("#equipment_img").replaceWith('<img id="equipment_img" alt="HG-Basic" src="Images/PJ-TongXinDu-1.png" />');  //输入为1
                    }
                    else if ($("#input_repeated_measurement").val() > 1 && $("#input_repeated_measurement").val() <= 5) {
                        $("#equipment_img").replaceWith('<img id="equipment_img" alt="HG-Basic" src="Images/PJ-TongXinDu-2.png" />');  //输入为2-5
                    }
                }
            });
        }
            //公差输入了角度，量仪选择了投影仪(PJ)
        else if (equipment_type.indexOf("PJ") != -1 && (specification.indexOf("°") != -1 || specification.indexOf("∅") != -1)) {
            if ($("#input_changeLanguage").val() == "2") {
                msg = '<img id="equipment_img" alt="HG-Basic" src="Images/PJ-JiaoDu-En.png"';
                EquipmentSettingWindow_HG(msg);
                $("#input_special_measurement").replaceWith('<input id="input_special_measurement" type="text" class="form-control" value=" Degee" style="background-color:#F0F0F0; width:117%" readonly="true" />');
                $("#label_repeated_measurement").replaceWith('<label id="label_repeated_measurement">Self-input:</label>');               //label文字“重复输入”改为“自行输入”
            }
            else {
                msg = '<img id="equipment_img" alt="HG-Basic" src="Images/PJ-JiaoDu.png"';
                EquipmentSettingWindow_HG(msg);
                $("#input_special_measurement").replaceWith('<input id="input_special_measurement" type="text" class="form-control" value=" 角度" style="background-color:#F0F0F0; width:117%" readonly="true" />');
                $("#label_repeated_measurement").replaceWith('<label id="label_repeated_measurement">自行输入：</label>');               //label文字“重复输入”改为“自行输入”
            }
            $("#name_equipment_setting").replaceWith('<input id="name_equipment_setting" type="text" class="form-control" value="PJ" readonly="true" style="background-color:#F0F0F0; margin:0 48px 0 -48px"/>');
            $("#table_special_measurement").remove();    //隐藏最下方表格 
            $("#btn_special_measurement").remove();      //隐藏特殊测量按钮
            $("#btn_repeated_measurement").remove();     //隐藏重复测量按钮
            $("#input_repeated_measurement").replaceWith('<input id="input_repeated_measurement" type="checkbox" checked="true"/>'); //input改为多选框
        }
            //量仪选择投影仪(PJ)
        else if (equipment_type.indexOf("PJ") != -1) {
            msg_img = '<img id="equipment_img" alt="distance&L" src="Images/PJ-distance.png"';
            EquipmentSettingWindow_HG(msg_img, msg_ul);
            $("#name_equipment_setting").replaceWith('<input id="name_equipment_setting" type="text" class="form-control" value="PJ" readonly="true" style="background-color:#F0F0F0; margin:0 48px 0 -48px"/>');
            $("#" + templateType + "_generated_code_" + String($index - 1)).val("distance&L");                                     //HG默认版面generated code为"Basic"
            $("#div_repeated_measurement").remove();
            $("#input_repeated_measurement").remove();
            $("#label_repeated_measurement").remove();
            $("#btn_special_measurement").remove();
            $("#input_special_measurement").replaceWith('<input id="input_special_measurement" type="text" class="form-control" value="距离" style="background-color:#F0F0F0;width:117%" readonly="true" />');
            $("#td_special_measurement_1").replaceWith('<label class="radio-inline" id="td_special_measurement_1" ><input name="face_to_face" id="radio_special_measurement_1" type="radio" checked="checked" /> 长度</label>');
            $("#td_special_measurement_2").replaceWith('<label class="radio-inline" id="td_special_measurement_2" ><input name="face_to_face" id="radio_special_measurement_2" type="radio" /> 孔距</label>');
            $("#middle_1").remove();
            $("#middle_2").remove();
            $("#div_gaoducha_point").hide();
            $("#last_2").replaceWith('<td id="last_2"><label class="radio-inline" id="td_special_measurement_3" ><input name="face_to_face" id="radio_special_measurement_3" type="radio" /> 孔对边</label></td>');
            $("#last_1").replaceWith('<td id="last_1"><label class="radio-inline" id="td_special_measurement_4" ><input name="face_to_face" id="radio_special_measurement_4" type="radio" /> X/Y轴向距离</label></td>');

            $("#td_special_measurement_1").click(function () {
                $("#equipment_img").replaceWith('<img id="equipment_img" alt="HG-Basic" src="Images/PJ-distance.png" />');
                $("#" + templateType + "_generated_code_" + String($index - 1)).val("distance&L");
            });
            $("#td_special_measurement_2").click(function () {
                $("#equipment_img").replaceWith('<img id="equipment_img" alt="HG-Basic" src="Images/PJ-Hole-Hole.png" />');
                $("#" + templateType + "_generated_code_" + String($index - 1)).val("distance&Hole-Hole");
            });
            $("#td_special_measurement_3").click(function () {
                $("#equipment_img").replaceWith('<img id="equipment_img" alt="HG-Basic" src="Images/PJ-Hole-Edge.png" />');
                $("#" + templateType + "_generated_code_" + String($index - 1)).val("distance&Hole-Edge");
            });
            $("#td_special_measurement_4").click(function () {
                $("#equipment_img").replaceWith('<img id="equipment_img" alt="HG-Basic" src="Images/PJ-distance_axisL.png" />');
                $("#" + templateType + "_generated_code_" + String($index - 1)).val("distance&axisL");
            });
        }
            //量仪选择目测(VI)
        else if (equipment_type.indexOf("VI") != -1) {
            msg_img = '<img id="equipment_img" alt="VI-G_M" src="Images/VI-G_M.png"';
            EquipmentSettingWindow_HG(msg_img, msg_ul);
            $("#name_equipment_setting").replaceWith('<input id="name_equipment_setting" type="text" class="form-control" value="VI" readonly="true" style="background-color:#F0F0F0; margin:0 48px 0 -48px"/>');
            $("#" + templateType + "_generated_code_" + String($index - 1)).val("VI-G_M");
            var specialForVI = "";
            var current_dwg_spec = $("#" + templateType + "_input_symbol_" + String($index - 1)).val();
            current_dwg_spec = current_dwg_spec.substring(3);
            //$("#table_special_measurement").parent("div").remove();
            $("#middle_1").remove();
            $("#middle_2").remove();
            $("#last_1").remove();
            $("#last_2").remove();
            $("#div_repeated_measurement").parent("div").remove();
            $("#input_repeated_measurement").parent("div").remove();
            $("#label_repeated_measurement").parent("div").remove();
            $("#table_special_measurement").parent().css("margin-top", "20px");
            if ($("#input_changeLanguage").val() == "2") {
                $("#name_equipment_setting").parent().parent().after('<div class="row clearfix" style="margin-top:20px"><div class="col-md-3"><label id="label_dwg_spec" style="margin-top:5px">Dwg_Spec：</label></div><div class="col-md-6" style="margin:0 48px 0 -48px"><input id="VI_dwg_spec" type="text" class="form-control" placeholder="Please input Dwg_Spec" ></div></div>');
                $("#table_special_measurement").before("<div class='col-md-3'><label style='margin-top:5px'>Workpiece's area</label></div>");
                $("#table_special_measurement").replaceWith("<div class='col-md-6'>" + $("#table_special_measurement").prop("outerHTML") + "</div>");
                $("#td_special_measurement_1").replaceWith('<label class="radio-inline" id="td_special_measurement_1" ><input name="VI_Scale" id="radio_special_measurement_1" type="radio" checked="checked" /> Large(More than about 300 mm<sup>2</sup>)</label>');
                $("#td_special_measurement_2").replaceWith('<label class="radio-inline" id="td_special_measurement_2" ><input name="VI_Scale" id="radio_special_measurement_2" type="radio" /> Small(Less than (about) 300 mm<sup>2</sup>)</label>');
                $("#input_special_measurement").replaceWith('<input id="input_special_measurement" type="text" class="form-control" value="General Mode" style="background-color:#F0F0F0" readonly="true" />');
                $("#ul_special_measurement").html('<li><a href="javascript:void(0)">General Mode</a></li><li><a href="javascript:void(0)">Strict Mode</a></li><li><a href="javascript:void(0)">Custom Mode</a></li>');
                $("#label_special_measurement").text("Measure Type:").parent("div").parent("div").next().prepend('<div class="col-md-3"><label id="VI_Mark" style="margin-top:5px">Requirement</label></div>');
                $("#VI_Mark").parent().next().empty().append('<label>Accept slight damage, chipping, drape, knife grain, grain, color difference and mark.</label>');
                $("#label_dwg_spec").parent().next().empty().append('<input id="VI_dwg_spec" type="text" class="form-control" placeholder="请输入图纸规格" value="' + current_dwg_spec + '" >');
                specialForVI += "<div class='row clearfix' style='margin-top:0;'><div class='col-md-3'><label style='margin-top:5px'>Picture Required:</label></div><div class='col-md-6' style='margin:5px 48px 0 -48px'><input id='VI_NeedUploadPicture' type='checkbox' /></div></div>";
                specialForVI += "<div class='row clearfix' style='margin-top:0;'><div class='col-md-3'><label style='margin-top:5px'>参考路径：</label></div><div class='col-md-6' style='margin-top:5px;margin-left:-48px'><a href='javascript:void(0)'>轻微的外观缺点图片集</a></div></div>";
            } else {
                $("#name_equipment_setting").parent().parent().after('<div class="row clearfix" style="margin-top:20px"><div class="col-md-3"><label id="label_dwg_spec" style="margin-top:5px">图纸规格：</label></div><div class="col-md-6" style="margin:0 48px 0 -48px"><input id="VI_dwg_spec" type="text" class="form-control" placeholder="请输入图纸规格" ></div></div>');
                $("#table_special_measurement").before("<div class='col-md-3'><label style='margin-top:5px'>工件面积：</label></div>");
                $("#table_special_measurement").replaceWith("<div class='col-md-6'>" + $("#table_special_measurement").prop("outerHTML") + "</div>");
                $("#td_special_measurement_1").replaceWith('<label class="radio-inline" id="td_special_measurement_1" ><input name="VI_Scale" id="radio_special_measurement_1" type="radio" checked="checked" /> 大（面积约300mm<sup>2</sup>以上）</label>');
                $("#td_special_measurement_2").replaceWith('<label class="radio-inline" id="td_special_measurement_2" ><input name="VI_Scale" id="radio_special_measurement_2" type="radio" /> 小（面积约300mm<sup>2</sup>以下）</label>');
                $("#input_special_measurement").replaceWith('<input id="input_special_measurement" type="text" class="form-control" value="普通" style="background-color:#F0F0F0" readonly="true" />');
                $("#ul_special_measurement").html('<li><a href="javascript:void(0)">普通</a></li><li><a href="javascript:void(0)">严格</a></li><li><a href="javascript:void(0)">自定义</a></li>');
                $("#label_special_measurement").text("测量种类：").parent("div").parent("div").next().prepend('<div class="col-md-3"><label id="VI_Mark" style="margin-top:5px">备注：</label></div>');
                $("#VI_Mark").parent().next().empty().append('<label>接受轻微的损伤、崩缺、披锋、刀纹、纹路、色差、印渍。</label>');
                $("#label_dwg_spec").parent().next().empty().append('<input id="VI_dwg_spec" type="text" class="form-control" placeholder="请输入图纸规格" value="' + current_dwg_spec + '" >');
                //照片存档
                specialForVI += "<div class='row clearfix' style='margin-top:0;'><div class='col-md-3'><label style='margin-top:5px'>照片存档：</label></div><div class='col-md-6' style='margin:5px 48px 0 -48px'><input id='VI_NeedUploadPicture' type='checkbox' /></div></div>";
                //参考路径
                specialForVI += "<div class='row clearfix' style='margin-top:0;'><div class='col-md-3'><label style='margin-top:5px'>参考路径：</label></div><div class='col-md-6' style='margin-top:5px;margin-left:-48px'><a href='Resource/ASM Cosmetic Standard -- Chinese Rev A.pdf' target='_blank'>轻微的外观缺点图片集</a></div></div>";
            }
            $("#table_special_measurement").parent().parent().after(specialForVI);
            //测量种类点击事件绑定
            $("#div_special_measurement").on('click', "#ul_special_measurement li", function () {
                var str = $(this).text();
                if ($(this).css('background-color').toString() == "rgba(0, 0, 0, 0)") {
                    $("#input_special_measurement").val(str);
                    if ($("#input_special_measurement").val() == "普通" || $("#input_special_measurement").val() == "General Mode") {
                        //还有选择面积大小的判断
                        if ($("#" + templateType + "_generated_code_" + String($index - 1)).val() == "VI-G_M") {
                            $('#equipment_img').replaceWith('<img id="equipment_img" alt="VI-G_M" src="Images/VI-G_M.png" />');
                            $("#VI_Mark").parent().next().empty().append('<label>接受轻微的损伤、崩缺、披锋、刀纹、纹路、色差、印渍。</label>');
                        } else {
                            $('#equipment_img').replaceWith('<img id="equipment_img" alt="VI-G_S" src="Images/VI-G_S.png" />');
                            $("#VI_Mark").parent().next().empty().append('<label>接受轻微的损伤、崩缺、披锋、刀纹、纹路、色差、印渍。</label>');
                        }
                        $("#table_special_measurement").parent().parent().show();

                    } else if ($("#input_special_measurement").val() == "严格" || $("#input_special_measurement").val() == "Strict Mode") {
                        $("#" + templateType + "_generated_code_" + String($index - 1)).val("VI-A_M");
                        $('#equipment_img').replaceWith('<img id="equipment_img" alt="VI-A_M" src="Images/VI-A_M.png" />');
                        $("#table_special_measurement").parent().parent().hide();
                        $("#VI_Mark").parent().next().empty().append('<label><b style="color:red">不容许</b>任何的损伤、崩缺、披锋、刀纹、纹路、色差、印渍</label>');
                    } else {
                        $("#" + templateType + "_generated_code_" + String($index - 1)).val("VI-TailorM");
                        $('#equipment_img').replaceWith('<img id="equipment_img" alt="VI-TailorM" src="Images/VI-TailorM.png" />');
                        $("#table_special_measurement").parent().parent().hide();
                        var markText = $("#" + templateType + "_input_note_" + String($index - 1)).val();
                        $("#VI_Mark").parent().next().empty().append('<textarea id="VI_Requirement_text" style="margin-top:5px;width:300px;height:70px;resize:none;" placeholder="请输入检查要求，字数小于50">' + markText + '</textarea><span id="VI_Requirement_alarm" style="color:red">字数应小于50</span>');
                    }
                }
            });
            $("#td_special_measurement_1").click(function () {
                $("#equipment_img").replaceWith('<img id="equipment_img" alt="VI-G_M" src="Images/VI-G_M.png" />');
                $("#" + templateType + "_generated_code_" + String($index - 1)).val("VI-G_M");
            });
            $("#td_special_measurement_2").click(function () {
                $("#equipment_img").replaceWith('<img id="equipment_img" alt="VI-G_S" src="Images/VI-G_S.png" />');
                $("#" + templateType + "_generated_code_" + String($index - 1)).val("VI-G_S");
            });
            //HG_setting_sure在#setting里面有设置了，把VI隔离开单独做处理
            $("#HG_setting_sure").click(function () {
                if ($('#name_equipment_setting').val() == "VI") {
                    if ($("#" + templateType + "_generated_code_" + String($index - 1)).val() == "VI-TailorM") {
                        if ($("#VI_dwg_spec").val() != "" && $("#VI_Requirement_text").val() != "") {
                            $("#" + templateType + "_input_symbol_" + String($index - 1)).val("VI-" + $("#VI_dwg_spec").val()).attr("readonly", "readonly");
                            $("#" + templateType + "_input_note_" + String($index - 1)).val($("#VI_Requirement_text").val());
                        } else {
                            $("#VI_Requirement_alarm").remove();
                            $("#VI_dwg_spec_alarm").remove();
                            if ($("#VI_dwg_spec").val() == "") {
                                $("#VI_dwg_spec").after('<span id="VI_dwg_spec_alarm" style="color:red">请输入图纸规格！</span>');
                            }
                            if ($("#VI_Requirement_text").val() == "") {
                                $("#VI_Requirement_text").after('<span id="VI_Requirement_alarm" style="color:red">请输入检查要求，且字数应小于50！</span>');
                            }
                            return false;
                        }
                    } else {
                        if ($("#VI_dwg_spec").val() != "") {
                            $("#" + templateType + "_input_symbol_" + String($index - 1)).val("VI-" + $("#VI_dwg_spec").val()).attr("readonly","readonly");
                        } else {
                            $("#VI_dwg_spec_alarm").remove();
                            $("#VI_dwg_spec").after('<span id="VI_dwg_spec_alarm" style="color:red">请输入图纸规格！</span>');
                            return false;
                        }
                    }
                }
                $("#setting").dialog('close');
            });
            $("#VI_NeedUploadPicture").click(function () {
                var str = ($("#VI_NeedUploadPicture").prop("checked")) ? "ImgNeed" : "";
                $("#" + templateType + "_repeated_points_" + String($index - 1)).val(str);
            });
            $("#setting").height("auto");
        }
            //公差输入了孔径，量仪选择了内径千分尺(三爪)(HT)
        else if (equipment_type.indexOf("HT") != -1 && specification.indexOf("∅") != -1) {
            msg_ul = loadData('static/HT_repeated.json', 'HT_repeated');
            EquipmentSettingWindow_HT(msg_ul);
            $("#name_equipment_setting").replaceWith('<input id="name_equipment_setting" type="text" class="form-control" value="HT" readonly="true" style="background-color:#F0F0F0; margin:0 48px 0 -48px"/>');
            $("#" + templateType + "_generated_code_" + String($index - 1)).val("ave");
            $("#" + templateType + "_repeated_points_" + String($index - 1)).val(1);
            $("#label_average_HT").click(function () {
                $("#" + templateType + "_generated_code_" + String($index - 1)).val("ave");
            });
            $("#label_max_HT").click(function () {
                $("#" + templateType + "_generated_code_" + String($index - 1)).val("max");
            });
            $("#label_min_HT").click(function () {
                $("#" + templateType + "_generated_code_" + String($index - 1)).val("min");
            });

            //重复测量
            $("#div_repeated_measurement").on('click', "#ul_repeated_measurement li", function () {
                var str = $(this).text();
                if ($(this).css('background-color').toString() == "rgba(0, 0, 0, 0)") {
                    $("#input_repeated_measurement").val(str);
                    $("#" + templateType + "_repeated_points_" + String($index - 1)).val(str);     //重复测量取点数
                }
            });
        }
            //量仪选择了外径百分尺/外径千分尺(UM)
        else if (equipment_type.indexOf("UM") != -1) {
            msg_ul = loadData('static/UM_repeated.json', 'UM_repeated');
            EquipmentSettingWindow_HT(msg_ul);
            $("#name_equipment_setting").replaceWith('<input id="name_equipment_setting" type="text" class="form-control" value="UM" readonly="true" style="background-color:#F0F0F0; margin:0 48px 0 -48px"/>');
            $("#" + templateType + "_generated_code_" + String($index - 1)).val("ave");
            $("#" + templateType + "_repeated_points_" + String($index - 1)).val(1);
            $("#label_average_HT").click(function () {
                $("#" + templateType + "_generated_code_" + String($index - 1)).val("ave");
            });
            $("#label_max_HT").click(function () {
                $("#" + templateType + "_generated_code_" + String($index - 1)).val("max");
            });
            $("#label_min_HT").click(function () {
                $("#" + templateType + "_generated_code_" + String($index - 1)).val("min");
            });
            //重复测量
            $("#div_repeated_measurement").on('click', "#ul_repeated_measurement li", function () {
                var str = $(this).text();
                if ($(this).css('background-color').toString() == "rgba(0, 0, 0, 0)") {
                    $("#input_repeated_measurement").val(str);
                    $("#" + templateType + "_repeated_points_" + String($index - 1)).val(str);     //重复测量取点数
                }
            });
        }
            //量仪选择了卡尺(VC)
        else if (equipment_type.indexOf("VC") != -1) {
            msg_ul = loadData('static/VC_repeated.json', 'VC_repeated');
            EquipmentSettingWindow_HT(msg_ul);
            $("#name_equipment_setting").replaceWith('<input id="name_equipment_setting" type="text" class="form-control" value="VC" readonly="true" style="background-color:#F0F0F0; margin:0 48px 0 -48px"/>');
            $("#" + templateType + "_generated_code_" + String($index - 1)).val("ave");
            $("#" + templateType + "_repeated_points_" + String($index - 1)).val(1);
            $("#label_average_HT").click(function () {
                $("#" + templateType + "_generated_code_" + String($index - 1)).val("ave");
            });
            $("#label_max_HT").click(function () {
                $("#" + templateType + "_generated_code_" + String($index - 1)).val("max");
            });
            $("#label_min_HT").click(function () {
                $("#" + templateType + "_generated_code_" + String($index - 1)).val("min");
            });
            //重复测量
            $("#div_repeated_measurement").on('click', "#ul_repeated_measurement li", function () {
                var str = $(this).text();
                if ($(this).css('background-color').toString() == "rgba(0, 0, 0, 0)") {
                    $("#input_repeated_measurement").val(str);
                    $("#" + templateType + "_repeated_points_" + String($index - 1)).val(str);     //重复测量取点数
                }
            });
        }
    });
};

//填充螺纹牙距,通规码/止规码内容,图纸规格
function FillThreadPitch(threadType, templateType, $index) {
    if (threadType == "Screw_hole") {
        var putong = "6H";
        var meizhi = "2B";
    }
    else if (threadType == "Screw_bolt") {
        var putong = "6g";
        var meizhi = "2A";
    }
    var str1 = "";
    var str2 = "";
    var thread_version = $("#input_StandardOfThread_PRO").val();
    $("#div_ThreadPitch").on('click', "#ul_ThreadPitch li", function () {   //填充牙距数据
        str1 = $(this).text();
        $("#input_ThreadPitch").val(str1);
        //牙距数据填充后，通规码内容和止规码内容会自动添加（识别螺纹标准）
        if (thread_version == "普通/粗" || thread_version == "细螺纹") {
            $('#input_GeneralCodeContent').val(str1 + "-" + putong + " T");
            $('#input_StopCodeContent').val(str1 + "-" + putong + " Z");
        }
        else if (thread_version == "美制粗螺纹/UNC") {
            $('#input_GeneralCodeContent').val(str1 + "UNC-" + meizhi + " T");
            $('#input_StopCodeContent').val(str1 + "UNC-" + meizhi + " Z");
        }
        else if (thread_version == "美制细螺纹/UNF") {
            $('#input_GeneralCodeContent').val(str1 + "UNF-" + meizhi + " T");
            $('#input_StopCodeContent').val(str1 + "UNF-" + meizhi + " Z");
        }
        else if (thread_version == "美制特细螺纹/UNEF") {
            $('#input_GeneralCodeContent').val(str1 + "UNEF-" + meizhi + " T");
            $('#input_StopCodeContent').val(str1 + "UNEF-" + meizhi + " Z");
        }
        else if (thread_version == "美制平行管螺纹/NPSC") {
            $('#input_GeneralCodeContent').val(str1 + "NPSC T");
            $('#input_StopCodeContent').val(str1 + "NPSC Z");
        }
        else if (thread_version == "美制锥管螺纹/NPT") {
            $('#input_GeneralCodeContent').val(str1 + "NPT T");
            $('#input_StopCodeContent').val(str1 + "NPT Z");
        }
        else if (thread_version == "英制螺纹/惠氏粗螺纹/BSW/BS84") {
            $('#input_GeneralCodeContent').val(str1 + "BSW T");
            $('#input_StopCodeContent').val(str1 + "BSW Z");
        }
    });
    //螺纹规设置页面确定
    $("#TG_setting_sure").click(function () {
        //if ($('#input_ThreadPitch').val() == "") {
        //    alert('螺纹直径不能为空，请填写');
        //    return;
        //}
        var num_test = /^\d*\.?\d*$/;
        str2 = $("#input_ThreadDepth").val();

        //        var num1 = str2.replace(/[^0-9.]/g, "");
        //        var num2 = num1.replace(/,/g, "");
        //        str2 = num2;
        var str3 = $("#input_ThreadNum").val().toString();
        if (str3 == "") { }
        else {
            str3 = $("#input_ThreadNum").val() + " ";
        }
        var str4 = $("#input_ThreadNote").val().toString();
        //if (str4 == "") { }
        //else {
        //    str4 = " " + $("#input_ThreadNote").val();
        //}
        if ($("#input_ThreadNote").is(":checked")) {
            str4 = " " + $("#input_ThreadNote").val();
        } else {
            str4 = "";
        }//Modify by YZT 20190916 if selected, get "THRU"
        if (thread_version == "美制粗螺纹/UNC") {
            if (str2 != "") {
                $("#" + templateType + "_input_symbol_" + String($index - 1)).val(str3 + str1 + "UNC DP" + str2 + str4);
            }
            else {
                $("#" + templateType + "_input_symbol_" + String($index - 1)).val(str3 + str1 + "UNC" + str4);
            }
            if ($("#radio_CodeContent").is(":checked")) {
                $("#" + templateType + "_repeated_points_" + String($index - 1)).val("UNC-" + meizhi + " T//UNC-" + meizhi + " Z");
            }
        }
        else if (thread_version == "美制细螺纹/UNF") {
            if (str2 != "") {
                $("#" + templateType + "_input_symbol_" + String($index - 1)).val(str3 + str1 + "UNF DP" + str2 + str4);
            }
            else {
                $("#" + templateType + "_input_symbol_" + String($index - 1)).val(str3 + str1 + "UNF" + str4);
            }
            if ($("#radio_CodeContent").is(":checked")) {
                $("#" + templateType + "_repeated_points_" + String($index - 1)).val("UNF-" + meizhi + " T//UNF-" + meizhi + " Z");
            }
        }
        else if (thread_version == "美制特细螺纹/UNEF") {
            if (str2 != "") {
                $("#" + templateType + "_input_symbol_" + String($index - 1)).val(str3 + str1 + "UNEF DP" + str2 + str4);
            }
            else {
                $("#" + templateType + "_input_symbol_" + String($index - 1)).val(str3 + str1 + "UNEF" + str4);
            }
            if ($("#radio_CodeContent").is(":checked")) {
                $("#" + templateType + "_repeated_points_" + String($index - 1)).val("UNEF-" + meizhi + " T//UNEF-" + meizhi + " Z");
            }
        }
        else if (thread_version == "美制平行管螺纹/NPSC") {
            if (str2 != "") {
                $("#" + templateType + "_input_symbol_" + String($index - 1)).val(str3 + str1 + "NPSC DP" + str2 + str4);
            }
            else {
                $("#" + templateType + "_input_symbol_" + String($index - 1)).val(str3 + str1 + "NPSC" + str4);
            }
            if ($("#radio_CodeContent").is(":checked")) {
                $("#" + templateType + "_repeated_points_" + String($index - 1)).val("NPSC T//NPSC Z");
            }
        }
        else if (thread_version == "美制锥管螺纹/NPT") {
            if (str2 != "") {
                $("#" + templateType + "_input_symbol_" + String($index - 1)).val(str3 + str1 + "NPT DP" + str2 + str4);
            }
            else {
                $("#" + templateType + "_input_symbol_" + String($index - 1)).val(str3 + str1 + "NPT" + str4);
            }
            if ($("#radio_CodeContent").is(":checked")) {
                $("#" + templateType + "_repeated_points_" + String($index - 1)).val("NPT T//NPT Z");
            }
        }
        else if (thread_version == "英制螺纹/惠氏粗螺纹/BSW/BS84") {
            if (str2 != "") {
                $("#" + templateType + "_input_symbol_" + String($index - 1)).val(str3 + str1 + "BSW" + str2 + str4);
            }
            else {
                $("#" + templateType + "_input_symbol_" + String($index - 1)).val(str3 + str1 + "BSW" + str4);
            }
            if ($("#radio_CodeContent").is(":checked")) {
                $("#" + templateType + "_repeated_points_" + String($index - 1)).val("BSW T//BSW Z");
            }
        }
        else {
            str1 = $("#input_ThreadPitch").val();
            if (str2 != "") {
                $("#" + templateType + "_input_symbol_" + String($index - 1)).val(str3 + str1 + " DP" + str2 + str4);
            }
            else {
                $("#" + templateType + "_input_symbol_" + String($index - 1)).val(str3 + str1 + str4);
            }
            if ($("#radio_CodeContent").is(":checked")) {
                $("#" + templateType + "_repeated_points_" + String($index - 1)).val(putong + " T//" + putong + " Z");
            }
        }
        if ($("#radio_AllowInput").is(":checked")) {
            $("#" + templateType + "_repeated_points_" + String($index - 1)).val("AllowInputData");
        }
    })
};

//小写转大写
function toUpperCase(obj) {
    obj.value = obj.value.toUpperCase()
};

//获得关联图标
function GetQCicon(part_num, part_rev, order, type) {
    $.post("CreateTemplate.ashx", JSON.stringify([{ "function": "GetQCicon" }, { "part_num": part_num }, { "part_rev": part_rev }, { "type": type }]), function (data) {
        for (var i = 0; i < data.length; i++) {
            for (var key in data[i]) {
                var str = '<li><a href="javascript:void(0)">' + data[i][key] + '</a></li>';
                if (key.indexOf("ICON") != -1 && type == "IM-QC") {
                    $('#IM-WS_ul_icon_' + order).append(str);
                }
                else if (key.indexOf("ICON") != -1 && type == "EM-QC") {
                    $('#EM-SBC_ul_icon_' + order).append(str);
                }
            }
        }
    });
}


