﻿$(function () {

    //通过JSON文件绑定量仪
    var equipment = "";
    equipment += loadData('static/equipment.json', 'equipment');
    $('#ul_equipment_type').append(equipment);

    //RS232相关属性框的隐藏和显示
    $('#hide_RS232').hide();
    $('input[type=radio][name=inlineRadioOptions]').change(function () {
        if (this.value == 'RS232') {
            if ($('#inlineRadio_rs232').is(':checked')) {
                $('#hide_RS232').stop().fadeToggle();
            }
        }
        else if (this.value == 'USB') {
            $('#hide_RS232').hide();
        }
    });

    //量仪类型选择
    $("#div_equipment_type").off('click', "#ul_equipment_type li");
    $("#div_equipment_type").on('click', "#ul_equipment_type li", function () {
        var value = $(this).text();
        $("#input_equipment_type").val(value);
        $("#input_manufacturer").val(null);
        $("#input_com_port").val(null);
        $("#input_baud_rate").val(null);
        $("#input_parity_bit").val(null);
        $("#input_data_bit").val(null);
        $("#input_stop_bit").val(null);
    });

    //量仪编码的筛别(失去焦点方法)
    $("#input_CCL_code").bind('blur', function () {
        toUpperCase(this);
        var EquipmentCode = $("#input_CCL_code").val();
        var list = [{ "function": "CheckEquipmentCode", "CCL_code": EquipmentCode}];
        $.ajax({
            type: "POST",
            url: "Register_equipment.ashx",
            dataType: "JSON",
            contentType: "application/json;charset=UTF-8",
            data: JSON.stringify(list),
            success: function (data) {
                if (data.status.indexOf("量仪") < 0) {
                    if (data.status == "Mahr" || data.status == "TESA" || data.status == "TESA-BT" || data.status == "青量" || data.status == "Keyence") {
                        $("#input_equipment_note").val(data.status);
                        AlertWindow("量仪校验通过！");
                    }
                    else {
                        $("#input_equipment_note").val(null);
                        AlertWindow("量仪校验通过，请自行选择生产厂家！");
                    }
                }
                else {
                    AlertWindow(data.status);
                    $("#input_CCL_code").val(null);
                }
            }
        });
    })


    $("#input_pc_info").bind('blur', function () {
        toUpperCase(this);
    })


    //生产厂家的选择
    $("#div_manufacturer").off('click', "#ul_manufacturer li");
    $("#div_manufacturer").on('click', "#ul_manufacturer li", function () {
        var value = $(this).text();
        $("#input_manufacturer").val(value);
        $("#input_com_port").val(null);
        $("#input_baud_rate").val(null);
        $("#input_parity_bit").val(null);
        $("#input_data_bit").val(null);
        $("#input_stop_bit").val(null);
        if ($("#input_equipment_type").val().indexOf("VC") != -1 && $("#input_manufacturer").val() == "Mahr") {
            $("#input_com_port").val("COM31");
            $("#input_baud_rate").val("9600");
            $("#input_parity_bit").val("None");
            $("#input_data_bit").val("8");
            $("#input_stop_bit").val("1");
        }
        else if ($("#input_equipment_type").val().indexOf("UM") != -1 && $("#input_manufacturer").val() == "Mahr") {
            $("#input_com_port").val("COM41");
            $("#input_baud_rate").val("9600");
            $("#input_parity_bit").val("None");
            $("#input_data_bit").val("8");
            $("#input_stop_bit").val("1");
        }
        else if ($("#input_equipment_type").val().indexOf("HT") != -1 && $("#input_manufacturer").val() == "Mahr") {
            $("#input_com_port").val("COM51");
            $("#input_baud_rate").val("9600");
            $("#input_parity_bit").val("None");
            $("#input_data_bit").val("8");
            $("#input_stop_bit").val("1");
        }
        else if ($("#input_equipment_type").val().indexOf("DT") != -1 && $("#input_manufacturer").val() == "Mahr") {
            $("#input_com_port").val("COM61");
            $("#input_baud_rate").val("9600");
            $("#input_parity_bit").val("None");
            $("#input_data_bit").val("8");
            $("#input_stop_bit").val("1");
        }
        else if ($("#input_equipment_type").val().indexOf("DI") != -1 && $("#input_manufacturer").val() == "Mahr") {
            $("#input_com_port").val("COM65");
            $("#input_baud_rate").val("9600");
            $("#input_parity_bit").val("None");
            $("#input_data_bit").val("8");
            $("#input_stop_bit").val("1");
        }
        else if ($("#input_equipment_type").val().indexOf("DI") != -1 && $("#input_manufacturer").val() == "Nikon") {
            $("#input_baud_rate").val("4800");
            $("#input_parity_bit").val("None");
            $("#input_data_bit").val("8");
            $("#input_stop_bit").val("2");
        }
        else if ($("#input_equipment_type").val().indexOf("PJ") != -1 && $("#input_manufacturer").val() == "Nikon") {
            $("#input_baud_rate").val("4800");
            $("#input_parity_bit").val("None");
            $("#input_data_bit").val("8");
            $("#input_stop_bit").val("2");
        }
        else if ($("#input_equipment_type").val().indexOf("VC") != -1 && $("#input_manufacturer").val() == "TESA-BT") {
            $("#input_com_port").val("COM71");
            $("#input_baud_rate").val("1200");
            $("#input_parity_bit").val("Even");
            $("#input_data_bit").val("7");
            $("#input_stop_bit").val("2");
        }
        else if ($("#input_equipment_type").val().indexOf("HG") != -1 && $("#input_manufacturer").val() == "TESA-BT") {
            $("#input_com_port").val("COM81");
            $("#input_baud_rate").val("1200");
            $("#input_parity_bit").val("Even");
            $("#input_data_bit").val("7");
            $("#input_stop_bit").val("2");
        }
        else if ($("#input_equipment_type").val().indexOf("HG") != -1 && $("#input_manufacturer").val() == "TESA") {
            $("#input_baud_rate").val("1200");
            $("#input_parity_bit").val("Even");
            $("#input_data_bit").val("7");
            $("#input_stop_bit").val("2");
        }
        else if ($("#input_manufacturer").val() == "青量") {
            $("#input_baud_rate").val("1200");
            $("#input_parity_bit").val("Even");
            $("#input_data_bit").val("7");
            $("#input_stop_bit").val("2");
        }
        else if ($("#input_manufacturer").val() == "Keyence") {
            $("#input_baud_rate").val("115200");
            $("#input_parity_bit").val("Even");
            $("#input_data_bit").val("8");
            $("#input_stop_bit").val("1");
        }
    });

    //串口号的选择
    $("#div_com_port").off('click', "#ul_com_port li");
    $("#div_com_port").on('click', "#ul_com_port li", function () {
        var value = $(this).text();
        $("#input_com_port").val(value).focus();

    });

    //波特率的选择
    $("#div_baud_rate").off('click', "#ul_baud_rate li");
    $("#div_baud_rate").on('click', "#ul_baud_rate li", function () {
        var value = $(this).text();
        $("#input_baud_rate").val(value);
    });

    //校验位的选择
    $("#div_parity_bit").off('click', "#ul_parity_bit li");
    $("#div_parity_bit").on('click', "#ul_parity_bit li", function () {
        var value = $(this).text();
        $("#input_parity_bit").val(value);
    });

    //数据位的选择
    $("#div_data_bit").off('click', "#ul_data_bit li");
    $("#div_data_bit").on('click', "#ul_data_bit li", function () {
        var value = $(this).text();
        $("#input_data_bit").val(value);
    });

    //停止位的选择
    $("#div_stop_bit").off('click', "#ul_stop_bit li");
    $("#div_stop_bit").on('click', "#ul_stop_bit li", function () {
        var value = $(this).text();
        $("#input_stop_bit").val(value);
    });


    //注册量仪
    $('#btn_Reg').click(function () {
        if ($("#input_equipment_type").val() == "" || $("#input_CCL_code").val() == "" || $("#input_pc_info").val() == "") {
            AlertWindow("您必须填写量仪类型,量仪编码以及PC号！");
        }
        else {
            var Reg_data = GetRegInfo("btn_Reg");
            $.ajax({
                type: "POST",
                url: "Register_equipment.ashx",
                dataType: "JSON",
                contentType: "application/json;charset=UTF-8",
                data: Reg_data,
                success: function (data) {
                    AlertWindow(data.status);
                    $("#btn_Reg").removeAttr("disabled");
                    setTimeout('window.location.reload()', 2000); //延时2000毫秒执行
                }
            });
        }
    });
});

//获取量仪信息
function GetRegInfo(button_id) {
    var list = [];
    $("#" + button_id).attr({ "disabled": "disabled" });
    var data_dict = {};
    data_dict["function"] = "register_equipment";

    equipment_abbreviation = $('#input_equipment_type').val();
    if (equipment_abbreviation == "高度尺(HG)" || equipment_abbreviation == "Height Gauge(HG)") {
        equipment_abbreviation = "HG";
    }
    else if (equipment_abbreviation == "卡尺(VC)" || equipment_abbreviation == "Vernier Caliper(VC)") {
        equipment_abbreviation = "VC";
    }
    else if (equipment_abbreviation == "投影仪(PJ)" || equipment_abbreviation == "Profile Projector(PJ)") {
        equipment_abbreviation = "PJ";
    }
    else if (equipment_abbreviation == "百分表/千分表(DT)" || equipment_abbreviation == "Dial Indicator(DT)") {
        equipment_abbreviation = "DT";
    }
    else if (equipment_abbreviation == "高度计(DI)" || equipment_abbreviation == "Digital Indicator(DI)") {
        equipment_abbreviation = "DI";
    }
    else if (equipment_abbreviation == "内径千分尺(三爪)(HT)" || equipment_abbreviation == "Holtest Meter(HT)") {
        equipment_abbreviation = "HT";
    }
    else if (equipment_abbreviation == "外径百分尺/外径千分尺(UM)" || equipment_abbreviation == "Micrometer(UM)") {
        equipment_abbreviation = "UM";
    }
    else if (equipment_abbreviation == "硬度测量仪(HD)" || equipment_abbreviation == "Hardness Tester(HD)") {
        equipment_abbreviation = "HD";
    }
    else if (equipment_abbreviation == "块规(PS)" || equipment_abbreviation == "Block Gage(PS)") {
        equipment_abbreviation = "PS";
    }
    else if (equipment_abbreviation == "针规/塞规(PG)" || equipment_abbreviation == "Pin Gage(PG)") {
        equipment_abbreviation = "PG";
    }
    else if (equipment_abbreviation == "螺纹规(TG)" || equipment_abbreviation == "Thread Gage(TG)") {
        equipment_abbreviation = "TG";
    }
    else if (equipment_abbreviation == "R规(RR)" || equipment_abbreviation == "Radius Gage(RR)") {
        equipment_abbreviation = "RR";
    }
    else if (equipment_abbreviation == "塞片(SM)" || equipment_abbreviation == "Shim(SM)") {
        equipment_abbreviation = "SM";
    }
    else if (equipment_abbreviation == "电子磅(EB)" || equipment_abbreviation == "Electronic Balance(EB)") {
        equipment_abbreviation = "EB";
    }
    else if (equipment_abbreviation == "三坐标测量仪(CMM)" || equipment_abbreviation == "CMM(CMM)") {
        equipment_abbreviation = "CMM";
    }
    else if (equipment_abbreviation == "影像仪(IM)" || equipment_abbreviation == "Image Measure(IM)") {
        equipment_abbreviation = "IM";
    }
    else if (equipment_abbreviation == "ZYGO(ZYGO)") {
        equipment_abbreviation = "ZYGO";
    }
    else if (equipment_abbreviation == "目测(VI)" || equipment_abbreviation == "Vision Inspection(VI)") {
        equipment_abbreviation = "VI";
    }
    else if (equipment_abbreviation == "显微镜(MS)" || equipment_abbreviation == "Microscope(MS)") {
        equipment_abbreviation = "MS";
    }
    else if (equipment_abbreviation == "直尺/卷尺(RL)" || equipment_abbreviation == "Ruler(RL)") {
        equipment_abbreviation = "RL";
    }
    else if (equipment_abbreviation == "万用表(MT)" || equipment_abbreviation == "Multimeter(MT)") {
        equipment_abbreviation = "MT";
    }
    else if (equipment_abbreviation == "光洁度测量仪(SF)" || equipment_abbreviation == "Surface Roughness(SF)") {
        equipment_abbreviation = "SF";
    }
    else if (equipment_abbreviation == "万能角度尺(UA)" || equipment_abbreviation == "Universal Angle Ruler(UA)") {
        equipment_abbreviation = "UA";
    }
    else if (equipment_abbreviation == "扭力表(TM)" || equipment_abbreviation == "Torque Meter(TM)") {
        equipment_abbreviation = "TM";
    }
    else if (equipment_abbreviation == "推拉力计(PP)" || equipment_abbreviation == "Push Pull Gauge(PP)") {
        equipment_abbreviation = "PP";
    }
    else if (equipment_abbreviation == "自制量具(OT)" || equipment_abbreviation == "Tailor-made Gage(OT)") {
        equipment_abbreviation = "OT";
    }
    else if (equipment_abbreviation == "示波器(2D)" || equipment_abbreviation == "Scope Check(2D)") {
        equipment_abbreviation = "2D";
    }
    else if (equipment_abbreviation == "检具+VC" || equipment_abbreviation == "Gauge+VC") {
        equipment_abbreviation = "Gauge+VC";
    }
    else {

    }
    data_dict["equipment_type"] = equipment_abbreviation;

    data_dict["CCL_code"] = $('#input_CCL_code').val();
    data_dict["pc_info"] = $('#input_pc_info').val();
    data_dict["equipment_note"] = $('#input_equipment_note').val();
    data_dict["com_type"] = $('input[name="inlineRadioOptions"]:checked').val();
    if (data_dict["com_type"] == "USB") {
        data_dict["MFR"] = "";
        data_dict["com_port"] = "";
        data_dict["baud_rate"] = "";
        data_dict["parity_bit"] = "";
        data_dict["data_bit"] = "";
        data_dict["stop_bit"] = "";
    }
    else {
        data_dict["MFR"] = $('#input_manufacturer').val();
        data_dict["com_port"] = $('#input_com_port').val();
        data_dict["baud_rate"] = $('#input_baud_rate').val();
        data_dict["parity_bit"] = $('#input_parity_bit').val();
        data_dict["data_bit"] = $('#input_data_bit').val();
        data_dict["stop_bit"] = $('#input_stop_bit').val();
    }
    list.push(data_dict);
    return JSON.stringify(list);
};

function AlertWindow(msg) {
    $('#alert').dialog({
        title: '提示',
        width: 300,
        height: 200,
        closed: false,
        modal: true,
        buttons: [{
            text: '关闭',
            handler: function () {
                $('#alert').dialog('close');

            }
        }]
    });
    $('#alert').html(msg);
    $('#alert').dialog('refresh');
};




// 加载配置文件数据
function loadData(url_path, data_type) {
    var str = ""; ;
    var dropdown_data = "";
    $.ajax({
        url: url_path,
        async: false,
        dataType: "JSON",
        success: function (data) {
            str = data;
        }
    });
    for (var type in str) {
        for (var i = 0; i < str[type].length; i++) {
            dropdown_data += "<li>";
            if (data_type == "equipment")                  //量仪
            {
                dropdown_data += "<a href='javascript:void(0)'>";
                if ($("#input_changeLanguage").val() == "2") {
                    if (str[type][i].CodeName == "") {
                        dropdown_data += str[type][i].EnglishDescription;
                    }
                    else {
                        dropdown_data += str[type][i].EnglishDescription + "(" + str[type][i].CodeName + ")";
                    }
                }
                else {
                    if (str[type][i].CodeName == "") {
                        dropdown_data += str[type][i].ChineseDescription;
                    }
                    else {
                        dropdown_data += str[type][i].ChineseDescription + "(" + str[type][i].CodeName + ")";
                    }
                }
                dropdown_data += "</a>";
            }

            dropdown_data += "</li>";
        }
    }
    return dropdown_data;
}


//小写转大写
function toUpperCase(obj) {
    obj.value = obj.value.toUpperCase()
};