﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SPC.UI
{
    public class PublicVariables
    {
        public static string userSite { get; set; }
        public static string fileStore { get; set; }
        public static string cam_Write { get; set; }
        public static string cam_Read { get; set; }
    }
}