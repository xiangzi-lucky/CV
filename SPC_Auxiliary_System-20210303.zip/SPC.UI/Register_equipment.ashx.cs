﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.IO;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using SPC.BLL;
using SPC.Model;
using System.Data;
using System.Collections;
using System.Net;

namespace SPC.UI
{
    /// <summary>
    /// Summary description for Register_equipment1
    /// </summary>
    public class Register_equipment1 : IHttpHandler
    {

        public void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "text/json";   //获取或设置输出流的 HTTP MIME 类型，ContentType：用于定义用户的浏览器或相关设备如何显示将要加载的数据，或者如何处理将要加载的数据
            string method = context.Request.HttpMethod;   //ASP.NET中Request封装了客户端请求信息，是从客户端得到数据(从浏览器获取数据);常用的三种取得数据的方法是：Request.Form，Request.QueryString，Request,其中第三种是前两种的一个缩写，可以取代前两种情况。而前两种主要对应的Form提交时的两种不同的提交方法：分别是Post方法和Get方法。
            if (method == "POST")
            {
                context.Response.Cache.SetCacheability(HttpCacheability.NoCache);     //这一行的代码可以让客户端不使用缓存，而从服务器重新读取，用于页面一直更新内容而不用缓存中的内容
                StreamReader reader = new StreamReader(context.Request.InputStream);  //StreamReader读取文件，接收端通过Request.InputStream读取请求页面参数，最终的字符串
                string jsondata = reader.ReadToEnd();                                 //将读出对象转成string类型（string str = reader.ReadToEnd();）
                reader.Close();                                                       //close是关闭而已，不释放资源。就像开门和关门一样,对于你进去做的事情他不管
                reader.Dispose();                                                     //而dispose就是释放资源！就是把StreamReader对象里面的数据给清空,不耗存储空间.
                List<dynamic> lists = new JavaScriptSerializer().Deserialize<List<dynamic>>(jsondata);
                //Modify by YZT 20191024
                SpcPartTemplateBLL bll = new SpcPartTemplateBLL( PublicFunctions.switchSiteByIP(context.Request.UserHostName.Trim()) );               //List指的是集合.<>是泛型,里面指定了这个集合中存放的是什么数据；调用GetInsertData()函数
                if (lists[0]["function"] == "CheckEquipmentCode")
                {
                    #region 校验量仪
                    string EquipmentCode = lists[0]["CCL_code"];
                    EquipmentWS.EquipmentWSClient xxx = new EquipmentWS.EquipmentWSClient();
                    EquipmentWS.Input input_data = new EquipmentWS.Input();
                    input_data.ownDept = "";
                    input_data.serialNo = EquipmentCode;
                    //input_data.serialNo = "A030758";
                    input_data.ExtensionData = null;
                    string userName = Environment.UserName;
                    //Modify by YZT 20191024
                    EquipmentWS.Output output_data = xxx.GetEquipmentData("SPC_Measuring_System", userName, PublicFunctions.switchSiteByIP(context.Request.UserHostName.Trim()), input_data); //Modify by YZT 2019-08-30 "HKG" ==> "ALG" 最好改为根据部门等判断厂区 //By YZT 20191019 "ALG" ==> PublicVariable.userSite //By YZT 20191024 ==> switchSiteByIP
                    EquipmentWS.EquipmentData ED = output_data.equipmentData;
                    if (output_data.WSStatus == "E")
                    {
                        if (output_data.WSMessage == "More Than One Data Found.")//Add by YZT 2019-09-02 WSStatus=="E"时，会有"MoreThanOneDataFound"的信息
                            context.Response.Write("{\"status\":\"量仪号" + input_data.serialNo + "存在重复编号，请重新设定。\"}");
                        else
                            context.Response.Write("{\"status\":\"量仪未在工量具系统登记，请使用其他量仪。\"}");
                    }
                    else if (ED.nextEmendDate == null)
                    {
                        context.Response.Write("{\"status\":\"量仪缺少校正日期。请使用其他量仪。\"}");
                    }
                    else if (output_data.WSStatus == "S" && ED.nextEmendDate != null)
                    {
                        string ED_year = ED.nextEmendDate.Year.ToString();
                        string ED_month = TransferTwo(ED.nextEmendDate.Month.ToString());
                        string ED_day = TransferTwo(ED.nextEmendDate.Day.ToString());
                        int ED_time = int.Parse(ED_year + ED_month + ED_day);
                        DateTime time = DateTime.Now;
                        string year = time.Year.ToString();
                        string month = TransferTwo(time.Month.ToString());
                        string day = TransferTwo(time.Day.ToString());
                        int today_time = int.Parse(year + month + day);
                        if (ED_time < today_time)
                        {
                            context.Response.Write("{\"status\":\"量仪超过有效日期(" + ED_month + "/" + ED_day + "/" + ED_year + ")。请使用其他量仪。\"}");
                        }
                        else
                        {
                            context.Response.Write("{\"status\":\"" + ED.brandName + "\"}");
                        }
                    } 
                    #endregion
                }
                else if (lists[0]["function"] == "register_equipment")
                {
                    #region 插入创建的数据
                    int num = bll.GetEquipmentData(lists);
                    if (num == -1)
                    {
                        context.Response.Write("{\"status\":\"创建成功\"}");
                    }
                    else
                    {
                        context.Response.Write("{\"status\":\"创建失败\"}");
                    }
                    #endregion
                }
                
            }
        }

        /// <summary>
        /// 时间转换
        /// </summary>
        /// <param name="a"></param>
        /// <returns></returns>
        private string TransferTwo(string a)
        {
            string str = "";
            if (Convert.ToDouble(a) < 10)
            {
                str = "0" + a;
            }
            else
            {
                str = a;
            }
            return str;
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}