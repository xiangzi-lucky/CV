﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SPC.Model
{
    public class SCADA_register_equipment
    {
        //id, equipment_type, equipment_code, manufacturer, equipment_info, create_date, 
        //com_type, pc_info, com_port, baud_rate, parity_bit, data_bit, stop_bit, note
        public int Id { get; set; }
        public int Rowid { get; set; }
        public string Equipment_type { get; set; }
        public string CCL_code { get; set; }
        public string MFR { get; set; }
        public string Equipment_info { get; set; }
        public DateTime Create_date { get; set; }
        public string Com_type { get; set; }
        public string Pc_info { get; set; }
        public string Com_port { get; set; }
        public string Baud_rate { get; set; }
        public string Parity_bit { get; set; }
        public string Data_bit { get; set; }
        public string Stop_bit { get; set; }
        public string Note { get; set; }
    }
}
