﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SPC.Model
{
    public class SpcPartTemplateModel
    {
        public string VENDOR{ get; set; }
        public string PART_NO { get; set; }
        public string PART_REV { get; set; }
        public string PART_NAME { get; set; }
        public string TEST_ITEM_NAME { get; set; }
        public string TEST_STATION_NAME { get; set; }
        public string SPEC_Ver { get; set; }
        public DateTime DO_NO { get; set; }
        public DateTime WORK_ORDER { get; set; }
        public string SP_NO { get; set; }
        public string GRN_NO { get; set; }
        public string PO_NO { get; set; }
        public DateTime DATE_RECEIVED { get; set; }
        public DateTime DATE_INSPECTED { get; set; }
        public string BADGE { get; set; }
        public string QTY_RECEIVED { get; set; }
        public string SAMPLE_INSPECTED { get; set; }
        public string SAMPLE_REJECTED { get; set; }
        public string Attribute_1 { get; set; }
        public string Attribute_2 { get; set; }
        public string Attribute_3 { get; set; }
        public string Attribute_4 { get; set; }
        public string Attribute_5 { get; set; }
        public string MAX { get; set; }
        public string MIN { get; set; }
        public string TRMS_Upload_Tool_Ver { get; set; }
        public string Template_Ver { get; set; }
        public string  ROW_ID { get; set; }

    }
}
