﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SPC.Model
{
    public class UserInfo
    {
        public string User { get; set; }
        public string Password { get; set; }
        public string Right { get; set; }
        public string Note { get; set; }
        public DateTime Register_time { get; set; }
    }
}
