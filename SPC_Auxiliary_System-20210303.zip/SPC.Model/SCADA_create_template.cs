﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SPC.Model
{
    public class SCADA_create_template
    {
        //id, part_num, part_desc, part_rev, badge, template_type, rw_order, Rw_seq, shipment, gn_type, 
        //machine_type, fixture_pn, ipna, link_to_drawing_lib, drawing_lable, specification, 
        //upper_limit, lower limit, equipment, attribute_1, attribute_2, check_num, note, template_version, create_date

        public int Id { get; set; }
        public int Rowid { get; set; }
        public string Part_num { get; set; }
        public string Part_rev { get; set; }
        public string Badge { get; set; }
        public string Template_type { get; set; }
        public string Rw_order { get; set; }
        public string Rw_seq { get; set; }
        public string Gn_type { get; set; }
        public string Sap_rou_workcenter { get; set; }
        public string Fixture_pn { get; set; }
        public string Fixture_array { get; set; }
        public string Tooling_Ipna { get; set; }
        public string Gn_correl_enggdwg { get; set; }
        public string Dwg_label { get; set; }
        public string Dwg_spec { get; set; }
        public string Upp_tol { get; set; }
        public string Lwr_tol { get; set; }
        public string Meas_eq { get; set; }
        public string Eq_cal_code { get; set; }
        public string Eq_col_pts { get; set; }
        public string Sample_plan { get; set; }
        public string Remark { get; set; }
        public string Template_version { get; set; }
        public DateTime Create_date { get; set; }
        public string Cdpn_list { get; set; }
        public string Approved { get; set; }
        public string Part_desc { get; set; }
    }
}